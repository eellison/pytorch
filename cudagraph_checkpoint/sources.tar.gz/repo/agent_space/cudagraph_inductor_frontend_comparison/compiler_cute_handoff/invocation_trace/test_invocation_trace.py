from dataclasses import replace
import gc
import json
from pathlib import Path
from types import MappingProxyType, SimpleNamespace
from unittest import mock
import weakref

from compiler_cute_handoff.descriptor import (
    attach_descriptors, bind_descriptors, CuTeCall, CuTeDescriptors, TensorFact,
)
from compiler_cute_handoff.invocation import register_cute_entry, register_cpu_standin
import cutlass.cute as cute
from cute_bridge.tracing import trace_cute_invocation
from cute_dispatch.entry import TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import build_entry_signature, MetadataSnapshot, ParameterMetadata, SignaturePolicy
from fx_adapter.contract import InputContract, IntegerRange, TensorInput
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from ordinary_artifact_reuse.binding import _bind_parameters
import python_entry
from python_entry import PythonHostUnsupported
import torch
from torch._inductor.runtime.cudagraph_arg_mapping import (
    BufferSource, InputSource, IntegerInput, IntExpr, pointwise_product,
)
from torch._subclasses.fake_tensor import FakeTensor, FakeTensorMode
from torch.fx import Node
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
from torch.utils._sympy.value_ranges import ValueRanges


CAPTURE = Path(__file__).resolve().parents[2] / "ordinary_artifact_capture/attempts/capture_attempt1/capture.json"


@instantiate_parametrized_tests
class TestCuTeInvocationTrace(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(torch.no_grad())
        self.assertFalse(torch.cuda.is_initialized())
        self.compile = self.enterContext(mock.patch.object(
            cute, "compile", side_effect=AssertionError("Tracing cannot compile CuTe")))

    def tearDown(self):
        self.compile.assert_not_called()
        self.assertIsNone(python_entry._ACTIVE.get())
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, *, rows=7, kind="shared", width=128, source_input=False):
        python_entry, kernel, _ = make_fixture()
        policy = SignaturePolicy(32, 64, 16, "stream")
        shape = (rows, None) if kind == "width" else (rows if kind == "static" else None, width)
        layout = TensorPolicy(shape, (0, 1))
        owner = ObservedOrdinaryEntry(python_entry, kernel, policy=policy,
                                     tensor_policies={"source": layout, "destination": layout})
        entry = register_cute_entry(owner)
        self.addCleanup(entry.close)
        self.enterContext(mock.patch.object(owner, "run", side_effect=AssertionError("No ordinary execution")))
        self.enterContext(mock.patch.object(owner, "join", side_effect=AssertionError("No second host compile")))
        if kind == "static":
            kinds, names, ranges, integers = ("tensor",), ("input_blob",), (), ()
            source_rows = destination_rows = rows
            input_index, box = 0, [object()]
        elif kind == "independent":
            kinds, names = ("integer", "tensor", "integer"), ("right_extent", "input_blob", "left_extent")
            ranges = (IntegerRange(2, 1, 100), IntegerRange(0, 1, 100))
            integers = (IntegerInput("left_extent", 2), IntegerInput("right_extent", 0))
            source_rows, destination_rows = IntExpr("boxed", 2), IntExpr("boxed", 0)
            input_index, box = 1, [rows, object(), rows]
        else:
            kinds, names = ("tensor", "integer"), ("input_blob", "extent")
            ranges, integers = (IntegerRange(1, 1, 100),), (IntegerInput("extent", 1),)
            source_rows = destination_rows = IntExpr("boxed", 1)
            input_index, box = 0, [object(), rows]
        columns = width
        if kind == "width":
            source_rows = destination_rows = rows
            columns = IntExpr("boxed", 1)
            box[1] = width
        input_fact = TensorFact(InputSource(input_index), torch.float32, "cuda:0",
                               (source_rows, columns), (columns, 1))
        if kind == "product":
            source_rows = destination_rows = pointwise_product((source_rows, 2))
        source = input_fact if source_input else TensorFact(
            BufferSource("produced_value"), torch.float32, "cuda:0", (source_rows, columns), (columns, 1))
        destination = TensorFact(BufferSource("fresh_result"), torch.float32, "cuda:0",
                                 (destination_rows, columns), (columns, 1))
        facts = (input_fact, destination) if source_input else (input_fact, source, destination)
        call = CuTeCall(entry.key, "saved_entry", entry.kind, entry.formals, (source, destination))
        records = CuTeDescriptors(1, names, integers, facts, (call,), (destination.source,))
        contract = InputContract(kinds, (TensorInput(input_index, input_fact.dtype, input_fact.size,
                                                    input_fact.stride),), ranges, 0)
        namespace = {"saved_entry": entry}
        exec("def call(box):\n    raise AssertionError('The CPU attachment fixture is never executed')\n", namespace)
        function = namespace["call"]
        attach_descriptors(function, records)
        bound = bind_descriptors(function)
        return SimpleNamespace(owner=owner, entry=entry, function=function, records=records,
                               contract=contract, box=box, bound=bound)

    def trace(self, fixture):
        return trace_cute_invocation(fixture.bound, fixture.contract, fixture.box)

    @parametrize("source_input", (False, True))
    def test_exact_declared_operands_without_host_allocation(self, source_input):
        fixture = self.fixture(source_input=source_input)
        trace = self.trace(fixture)
        trace.check()
        self.assertIs(trace.binding, fixture.bound)
        self.assertIs(trace.descriptor, fixture.records.calls[0])
        self.assertIs(trace.input_contract, fixture.contract)
        self.assertEqual(trace.outputs, ())
        self.assertEqual(trace.events, trace.calls)
        self.assertEqual(len(trace.calls), 1)
        self.assertIs(trace.dependencies.functions[0][0], fixture.entry.provider.host)
        call = trace.calls[0]
        self.assertIs(call.entry, fixture.owner.entry)
        self.assertIs(call.target, fixture.owner.entry.target)
        self.assertEqual(call.keyword_arguments, ())
        self.assertTrue(call.node.is_impure())
        self.assertIsNot(trace.operand_tensors[0], trace.operand_tensors[1])
        for index, (fact, tensor, operand) in enumerate(zip(trace.descriptor.operands,
                                                         trace.operand_tensors, call.operands)):
            self.assertIs(type(tensor), FakeTensor)
            self.assertIs(tensor.fake_mode, trace.fake_mode)
            self.assertIs(trace.tensor_sources[fact.source], tensor)
            self.assertIs(operand.value, tensor)
            self.assertEqual(operand.path, ("args", index))
            self.assertIs(type(operand.fx_argument), Node)
            self.assertIs(operand.fx_argument, call.arguments[index])
            self.assertEqual(tensor.device, torch.device("cuda:0"))
        self.assertFalse(any(node.target in (torch.ops.aten.empty_like.default, torch.ops.aten.empty_strided.default)
                             for node in trace.graph_module.graph.nodes))
        self.assertIsNone(fixture.owner.selected)

    @parametrize("kind", ("shared", "independent", "product"))
    def test_original_boxed_origins_and_ranges_survive_equal_hints(self, kind):
        fixture = self.fixture(kind=kind)
        trace = self.trace(fixture)
        by_index = {source.value: symbol for symbol, source in trace.symbol_sources.items()}
        self.assertEqual(set(by_index), {row.index for row in fixture.contract.integer_ranges})
        self.assertEqual(tuple(value.node.expr for value in trace.integer_placeholders),
                         tuple(by_index[row.index] for row in fixture.contract.integer_ranges))
        for row, value, source in zip(fixture.contract.integer_ranges, trace.integer_placeholders,
                                      trace.integer_sources):
            self.assertEqual(trace.shape_env.var_to_range[value.node.expr], ValueRanges(row.lower, row.upper))
            self.assertTrue(any(source is original for original in trace.shape_env.var_to_sources[value.node.expr]))
        if kind == "independent":
            self.assertNotEqual(by_index[0], by_index[2])
            self.assertEqual(tuple(tensor.shape[0].node.expr for tensor in trace.operand_tensors),
                             (by_index[2], by_index[0]))
        else:
            expected = by_index[1] * (2 if kind == "product" else 1)
            self.assertEqual(tuple(tensor.shape[0].node.expr for tensor in trace.operand_tensors), (expected, expected))
        signature = build_entry_signature(trace, trace.calls[0], policy=fixture.owner.policy)
        signature.check()
        self.assertEqual(tuple(row.name for row in signature.operands), ("source", "destination", "stream"))
        for index, row in enumerate(signature.operands[:2]):
            self.assertIs(row.tensor.value, trace.operand_tensors[index])
            self.assertIs(row.tensor.shape[0].shape_env, trace.shape_env)
            self.assertEqual(row.tensor.assumed_alignment, 16)
        self.assertEqual(signature.operands[2].origin, "environment_stream")
        self.assertTrue(any(row.kind == "integer_range" and row.maximum == 2**31 - 1
                            for row in signature.requirements))

    def test_static_layout_needs_no_invented_boxed_integer(self):
        fixture = self.fixture(kind="static", rows=5, width=32)
        trace = self.trace(fixture)
        self.assertEqual((trace.integer_placeholders, trace.integer_sources, dict(trace.symbol_sources)), ((), (), {}))
        self.assertEqual(tuple(tuple(tensor.shape) for tensor in trace.operand_tensors), ((5, 32), (5, 32)))
        signature = build_entry_signature(trace, trace.calls[0], policy=fixture.owner.policy)
        signature.check()
        self.assertEqual(signature.symbols, ())
        self.assertTrue(all(use.shape_env is None for row in signature.operands[:2] for use in row.tensor.shape))

    def test_symbolic_stride_preserves_its_boxed_origin_and_64_bit_requirement(self):
        fixture = self.fixture(kind="width", rows=7, width=7)
        trace = self.trace(fixture)
        signature = build_entry_signature(trace, trace.calls[0], policy=fixture.owner.policy)
        signature.check()
        symbol, = trace.symbol_sources
        self.assertEqual(trace.symbol_sources[symbol], IntExpr("boxed", 1))
        self.assertEqual({row.bits for row in signature.symbols}, {32, 64})
        for row in signature.operands[:2]:
            self.assertIsNone(row.tensor.shape[0].shape_env)
            self.assertEqual(row.tensor.shape[0].value, 7)
            self.assertEqual(row.tensor.shape[1].expression, symbol)
            self.assertEqual(row.tensor.strides[0].expression, symbol)
            self.assertIs(row.tensor.strides[0].shape_env, trace.shape_env)
            self.assertTrue(any(requirement.path == row.tensor.strides[0].path
                                and requirement.maximum == 2**63 - 1 for requirement in signature.requirements))

    def test_saved_ordinary_metadata_binds_both_actual_formal_uses(self):
        fixture = self.fixture()
        trace = self.trace(fixture)
        signature = build_entry_signature(trace, trace.calls[0], policy=fixture.owner.policy)
        data = json.loads(CAPTURE.read_text())["metadata"]

        def parameter(row):
            row = dict(row)
            for name in ("dtype", "element_dtype"):
                if row[name] is not None:
                    row[name] = tuple(row[name])
            for name in ("shape", "strides"):
                row[name] = tuple(tuple(value) for value in row[name])
            return ParameterMetadata(**row)

        metadata = MetadataSnapshot(data["symbol_name"], data["display_name"], data["abi"],
                                    tuple(tuple(row) for row in data["symbols"]),
                                    tuple(parameter(row) for row in data["params"]), parameter(data["ret"]))
        parameters, symbols, requirements = _bind_parameters(signature, metadata)
        self.assertEqual(tuple((row.name, row.bits) for row in symbols), (("n0", 32), ("n1", 32)))
        self.assertIsNot(symbols[0].uses[0], symbols[1].uses[0])
        for index, symbol in enumerate(symbols):
            use, = symbol.uses
            self.assertIs(use, signature.operands[index].tensor.shape[0])
            self.assertEqual(trace.symbol_sources[use.expression], IntExpr("boxed", 1))
            self.assertEqual(parameters[index].metadata.data_alignment, 16)
            self.assertEqual(parameters[index].metadata.strides, (("constant", 128), ("constant", 1)))
        self.assertEqual(parameters[2].metadata.kind, "Stream")
        self.assertTrue(any(row.maximum == 2**31 - 1 for row in requirements))
        self.assertIsNone(fixture.owner.selected)

    @parametrize("fault", ("kinds", "range_index", "duplicate_range", "tensor_layout", "dtype", "device", "boolean_layout"))
    def test_contract_mismatch_is_not_reconstructed_from_hints(self, fault):
        fixture = self.fixture(kind="static", rows=1) if fault == "boolean_layout" else self.fixture()
        contract = fixture.contract
        if fault == "kinds":
            contract = replace(contract, kinds=("integer", "tensor"))
        elif fault == "range_index":
            contract = replace(contract, integer_ranges=(IntegerRange(0, 1, 100),))
        elif fault == "duplicate_range":
            contract = replace(contract, integer_ranges=contract.integer_ranges * 2)
        elif fault == "device":
            contract = replace(contract, device_index=1)
        else:
            row = contract.tensor_inputs[0]
            if fault == "dtype":
                row = replace(row, dtype=torch.float16)
            else:
                row = replace(row, size=(True if fault == "boolean_layout" else 7, 128))
            contract = replace(contract, tensor_inputs=(row,))
        with self.assertRaises(PythonHostUnsupported):
            trace_cute_invocation(fixture.bound, contract, fixture.box)

    @parametrize("hint", (0, 101, True))
    def test_integer_hints_must_satisfy_original_ranges(self, hint):
        fixture = self.fixture()
        fixture.box[1] = hint
        with self.assertRaisesRegex(PythonHostUnsupported, "hint"):
            self.trace(fixture)

    @parametrize("fault", ("noncontiguous", "rank", "unproved_positive"))
    def test_unsupported_operand_layout_declines(self, fault):
        fixture = self.fixture()
        records = fixture.records
        destination = records.calls[0].operands[1]
        if fault == "noncontiguous":
            destination = replace(destination, stride=(129, 1))
        elif fault == "rank":
            destination = replace(destination, size=(128,), stride=(1,))
        else:
            fixture.contract = replace(fixture.contract, integer_ranges=(IntegerRange(1, 0, 100),))
        if fault != "unproved_positive":
            call = replace(records.calls[0], operands=(records.calls[0].operands[0], destination))
            records = replace(records, calls=(call,), tensors=(*records.tensors[:-1], destination))
            function = fixture.function
            del function._cute_invocation_attachment
            attach_descriptors(function, records)
            fixture.bound = bind_descriptors(function)
        with self.assertRaisesRegex(PythonHostUnsupported, "contiguous|positive|rank-two"):
            self.trace(fixture)

    def test_cpu_standin_does_not_supply_ordinary_cute_authority(self):
        entry = register_cpu_standin(lambda source, destination: None)
        self.addCleanup(entry.close)
        source = TensorFact(InputSource(0), torch.float32, "cpu", (7, 128), (128, 1))
        destination = replace(source, source=BufferSource("result"))
        call = CuTeCall(entry.key, "saved_entry", entry.kind, entry.formals, (source, destination))
        records = CuTeDescriptors(1, ("source",), (), (source, destination), (call,), (destination.source,))
        namespace = {"saved_entry": entry}
        exec("def call(box):\n    return None\n", namespace)
        function = namespace["call"]
        attach_descriptors(function, records)
        contract = InputContract(("tensor",), (TensorInput(0, source.dtype, source.size, source.stride),), ())
        with self.assertRaisesRegex(PythonHostUnsupported, "owned ordinary CuTe"):
            trace_cute_invocation(bind_descriptors(function), contract, [object()])

    @parametrize("fault", ("owner_close", "entry_global", "provider_host", "range", "operand", "source_map"))
    def test_trace_checks_lifetime_and_exact_associations(self, fault):
        fixture = self.fixture()
        trace = self.trace(fixture)
        if fault == "owner_close":
            fixture.owner.close()
        elif fault == "entry_global":
            fixture.function.__globals__["saved_entry"] = object()
        elif fault == "provider_host":
            fixture.entry.provider.host = lambda source, destination: None
        elif fault == "range":
            symbol, = trace.symbol_sources
            trace.shape_env.var_to_range[symbol] = ValueRanges(1, 200)
        elif fault == "operand":
            object.__setattr__(trace, "operand_tensors", tuple(reversed(trace.operand_tensors)))
        else:
            object.__setattr__(trace, "tensor_sources", MappingProxyType(
                dict(zip(trace.tensor_sources, reversed(trace.operand_tensors)))))
        with self.assertRaises((ValueError, RuntimeError)):
            trace.check()

    def test_trace_does_not_retain_real_box_tensors(self):
        fixture = self.fixture()
        value = torch.empty(3, 9)
        reference, storage = weakref.ref(value), StorageWeakRef(value.untyped_storage())
        fixture.box[0] = value
        trace = self.trace(fixture)
        fixture.box.clear()
        del value
        gc.collect()
        self.assertIsNone(reference())
        self.assertTrue(storage.expired())
        trace.check()

    def test_ambient_fake_mode_rejected_without_touching_box(self):
        fixture = self.fixture()
        with FakeTensorMode(), self.assertRaisesRegex(PythonHostUnsupported, "isolated"):
            self.trace(fixture)


if __name__ == "__main__":
    run_tests()
