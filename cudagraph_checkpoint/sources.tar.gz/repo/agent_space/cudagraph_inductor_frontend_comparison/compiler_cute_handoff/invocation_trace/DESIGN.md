The candidate adds `trace_cute_invocation(binding, inputs, example_inputs)` to a
copy of `cute_bridge.tracing`. Every existing class and function body, including
the one-input `trace_cute_host`, is unchanged. No selected predecessor is edited.

The entry point consumes an exact `BoundCuTeCalls` with one ordinary CuTe call.
It uses the provider's saved forwarding host and `PythonEntry`, materializes the
two declared `TensorFact` layouts in one local FakeTensor/ShapeEnv, and runs only
that forwarding host under the existing PythonEntry recorder. Neither the
generated compiler function, `OrdinaryEntry.run`, the CuTe target, nor
`cute.compile` executes. The host must forward the two operands in their declared
order and return `None`; Tensor operations or allocations inside it decline.

The supported layouts are positive, contiguous, zero-offset rank-two CUDA
layouts. Both operands may have different declared expressions or dtypes; their
actual ordinary ABI is checked later. The source may be an original InputSource
or a produced BufferSource. The destination remains the descriptor's distinct
BufferSource. Materializing its FakeTensor represents that compiler allocation;
it does not introduce an allocation or output event into the traced host. The
trace's `outputs` is empty, because output projection belongs to the enclosing
compiler program.

Every declared boxed integer receives its own LocalSource and backed symbol,
including equal hints at different indices. Original index order and integer
ranges remain available in `integer_sources`, `integer_placeholders`,
`symbol_sources`, and `shape_env`. Integer examples supply hints only; Tensor
box entries are neither inspected nor retained. The descriptor layout must be
positive and contiguous before FakeTensor creation, and each actual traced
Tensor must retain its exact declared dtype and unsimplified shape/stride
expressions. Literal layouts work without an invented boxed integer.

The result holds the exact bound descriptor, source-to-FakeTensor map, recorded
EntryCall, local graph and dependency checks. Its check preserves the local
guards, replacements, ranges, boxed origins, graph and formal Tensor identities,
and invokes the original descriptor/entry lifetime check. This is a cold
intermediate proof, not replay admission or a portable cache object. The existing
`build_entry_signature(trace, trace.calls[0], policy=owner.policy)` consumes its
real record; `bind_ordinary_metadata(signature, owner.compilation())` must still
prove the actual generation, shape32/stride64 ABI, independent ordinary symbols,
explicit Stream, dtype, static dimensions, compact strides and alignment.
Pointer effects, allocation initialization, device launch selection, native
guards and capture remain outside this candidate.

Matching a caller-supplied InputContract to descriptor layouts does not prove
that the contract was collected for that function. The intended composition is:

```python
checked = bind_envelope(original_function)
trace = trace_cute_invocation(checked.binding, checked.inputs, observed_box)
checked.check()
signature = build_entry_signature(trace, trace.calls[0], policy=owner.policy)
bound = bind_ordinary_metadata(signature, owner.compilation())
```

The envelope binding must own the exact collected InputContract and descriptor
attachment for the same original function/code. It also owns operation order,
allocation/output projection and source initialization. No argument names,
sampled shapes or equal numeric hints establish that relationship here.

The 30 proposed CPU controls use real uncompiled ordinary CuTe owners, actual
PythonEntry recording and actual entry-signature construction. Their descriptor
attachments are explicit data fixtures, not compiler-generated evidence. They
cover InputSource and BufferSource operands, shared and distinct boxed origins,
product expressions, symbolic shape32/stride64 uses, static layouts, malformed contract/hints/layouts, foreign
provider rejection, owner/global/host/range/operand/map changes, ambient fake
mode rejection and release of real example Tensor storage. A saved real ordinary
metadata snapshot checks the exact two n0/n1 uses, Stream and alignment through
the original parameter binder; it does not claim a live compilation capsule.
The controller should also rerun the unchanged `cute_bridge/test_tracing.py`
suite. Root's separate public CuTe GPU control can supply the actual compiler
envelope, observed boxed order and live ordinary compilation proof.

Only stdlib source checks have been performed by the author. No framework,
GPU, build, timing measurement or native-policy change is part of this work.
