This source-only GPU control extends the qualified automatic-owner public test.
It adds one read-only module Parameter to the generated prefix:
`source = (value * weight).sin(); destination = source.clone()`, followed by the
same owned two-Tensor CuTe invocation. Both normal and fast generated launchers
use dynamic batch M and public static width 128, with `no_grad`, `freezing=False`
and compiler-recorded static-input normalization enabled at compilation.

The actual original generated function's entry supplies Parameter and input
indices by object identity. Its checked InputContract independently supplies
layouts and the boxed batch origin. No boxed index, symbol name, allocation name
or pointer correspondence is guessed. Both CuTe operands remain exact fresh
Tensor buffers in the complete compiler envelope. Passive observations require
the exact envelope AlignmentCopy sequence to reach `_make_replay` with the
canonical native copy function. During the misaligned cold capture, the real
preparation state must contain a distinct aligned normalization Tensor.

The call sequence is warm M13, in-place update/native M7, aligned replacement/native
M35, misaligned replacement/ordinary local miss M2, native M3, then another
in-place update of the misaligned weight/native M36. Replacements preserve dtype,
shape and stride; the misaligned backing slice is released immediately after
Parameter creation. All calls use the same outer artifact and dispatcher, one
ordinary CuTe compilation, and the actual compiled predicates for both local
branches. The control retains the original cache-box/ordinary-callback/generated
function identity chain and the exact ordinary tuple at the cold boundary;
public Tensor result identity is checked separately from its outer container.

The policy and config reference are released before all later calls. The live
artifact must retain its miss owner. Native hits trap ordinary execution and
cold preparation and have no checked generated, CuTe or preparation frames;
outer Dynamo/AOT Python remains outside that claim. There is no native-entry
wrapper or new per-hit validation. The original selected providers, ordinary
borrow protection, restoration on close and post-close ordinary M5 are checked.

Only weak storage references and scalar metadata survive observations. Replaced
weight storage must expire before close. After removing the model's last weight,
all weight storage must expire even while the closed installation/artifact remain
live. Inputs, normalization copies and generated temporaries must expire; held
outputs remain correct after close and expire when released by the caller.

This is a proposed correctness/lifetime control, not execution evidence or a
benchmark. The separate native-linker qualification owns the complete capture-byte
and grid oracle. CuTe persistent caching, mutation/aliasing, buffer reuse, training,
direct Parameter operands to OrdinaryEntry, and other operator families remain
outside this two-case control. No helper module or native build is added.
