This candidate admits module Parameters in the generated prefix of the existing
automatic mixed CuTe policy. It uses the qualified AO manifest, including its
revision4 mode/lifecycle correction. Only three module mappings change; their
actual selected paths and hashes are recorded in base_sources.json.

The generated policy now exposes one pure cold coverage helper. It requires
unique exact integer indices in Tensor input slots and an existing validated
normalization copy for each static index. Its existing caller still snapshots
the index container before bind_alignment_copies and rechecks identity/content
after validation. No compiler/config/hash behavior changes: CPAR's normal
normalize_static_input_alignment option and CPAR150/CDP32 authority are reused.

Mixed arming obtains copies from the complete bound envelope. It saves the exact
kwargs object, original list/tuple and an immutable index snapshot together;
the installation seals that state and checks it before and after cold source
validation. The copy projection remains bracketed by full envelope checks.
Changing even one index to another covered Tensor slot is not a new authority.
Admission depends on recorded facts, independently of the current config flag.
Absent coverage remains an ordinary fallback, including initially misaligned
inputs for which the compiler did not emit normalization.

The linker's existing checked compiler path now accepts exact torch.nn.Parameter
in boxed Tensor slots. The standalone path still requires exact torch.Tensor;
arbitrary subclasses remain unsupported. No extra terminal-input scan is needed:
compiler.check() revalidates the envelope, whose terminal CuTe operands must
already be initialized BufferSource values. A Parameter is consumed by generated
prefix kernels; it is never passed directly to the ordinary CuTe host. Allocation
and output Tensor checks remain unchanged.

The ordinary call, exact result/box handling, AOT mode boundary, selected effects,
capture, native publication, local misses, borrow/close and serialization paths
are unchanged. Native replay already normalizes recorded inputs and binds fresh
Tensor/Parameter pointers. This candidate adds no hot checks or pointer/alias
scans, no native code and no cache transport.

The 38 new CPU controls reuse the actual qualified AO and NLI fixture modules
through explicit helper aliases. Policy controls use real compiler IR, emitted
metadata and CompiledFxGraph with ordinary-body/native-entry stand-ins. A second
typed input/control proves that a different covered slot still cannot replace
the saved index. Link controls use the existing real envelope/trace/numeric
projection fixture with synthetic selected handles and CuTe ABI; no real device
execution or native ABI proof is claimed by CPU tests. Negative metadata changes
are deliberate cold transport fixtures. The direct boxed CuTe source negative
checks the existing authoritative envelope restriction.

Exactly one AO control is intentionally superseded:
TestAutomaticCuTeOwner.test_ineligible_admission_does_not_acquire_borrow_fault_static_inputs.
It rejects the already covered Tensor slot 1, which this candidate admits.
The replacement is test_covered_static_slot_admits_parameter_independently_of_flag,
expanded over flag and list/tuple forms. The qualified AO file remains unchanged;
run its other 51 cases, plus CPAR30, NLI27, CPH44 and CFP34. Root owns public GPU
controls and execution; this source handoff runs no framework/GPU/build commands.
