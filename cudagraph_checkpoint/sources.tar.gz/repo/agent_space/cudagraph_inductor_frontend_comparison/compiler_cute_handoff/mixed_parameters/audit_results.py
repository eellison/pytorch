import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


review = json.loads((ROOT / "execution_review.json").read_text())
expected = review["files"] | {str(ROOT / "execution_review.json"): digest(ROOT / "execution_review.json")}
for path, sha in expected.items():
    if digest(path) != sha:
        raise RuntimeError("Changed execution input: " + path)
manifest = json.loads((ROOT / "manifest.json").read_text())
selection = json.loads((ROOT / "selected_attempts.json").read_text())
if set(selection) != set(review["cases"]):
    raise RuntimeError("Selected attempts do not cover the reviewed suites")
files = {str(ROOT / name): digest(ROOT / name) for name in (
    "execution_review.json", "manifest.json", "audit_results.py", "selected_attempts.json",
    "root_source_review.json", "source_independent_review.json", "gpu_draft/independent_review.json",
)}
attempts = []
for suite, cases in review["cases"].items():
    directory = ROOT / "attempts" / selection[suite]
    result = json.loads((directory / "result.json").read_text())
    saved = json.loads((directory / "sources.json").read_text())
    if saved != expected:
        raise RuntimeError("Snapshot map mismatch: " + suite)
    for index, (path, sha) in enumerate(saved.items()):
        copy = directory / "sources" / f"{index:03d}_{Path(path).name}"
        if digest(copy) != sha:
            raise RuntimeError("Saved source mismatch: " + str(copy))
    gpu = suite in ("frontend", "pipeline", "public", "legacy_public")
    if (result["accepted"] is not True or result["exit_code"] != 0
            or result["sources_unchanged"] is not True or result["identities_checked"] is not True
            or result["manifest_sha256"] != digest(ROOT / "manifest.json")
            or result["loaded_modules"] != {name: row["path"] for name, row in manifest["modules"].items()}
            or result["native_source"] != manifest["native"]["torch_python"]
            or result["native_extension"] != manifest["native"]["extension"]
            or result["cuda_initialized"] != gpu or result["initialization_checked"] != gpu
            or sorted(row["id"] for row in result["cases"]) != sorted(cases)
            or any(row["result"] != "ok" for row in result["cases"])):
        raise RuntimeError("Result mismatch: " + suite)
    for name in ("result.json", "sources.json", "output.log"):
        files[str(directory / name)] = digest(directory / name)
    if gpu:
        for name in ("gpu_before.json", "gpu_initialization.json"):
            guard = json.loads((directory / name).read_text())
            if (guard["physical_index"] != 1 or guard["uuid"] != "GPU-93d3590a-5f90-d77c-fe32-095983771555"
                    or guard["memory_mib"] > 128 or guard["utilization"] != 0 or guard["processes"]):
                raise RuntimeError("Idle guard mismatch: " + suite)
            files[str(directory / name)] = digest(directory / name)
        cpu = ROOT / "attempts" / selection["cpu"] / "result.json"
        if result["cpu_result"] != {"path": str(cpu), "sha256": digest(cpu)}:
            raise RuntimeError("CPU prerequisite mismatch: " + suite)
    attempts.append({"suite": suite, "path": str(directory), "cases": len(cases),
                     "accepted": True, "execution_revision": 1,
                     "saved_inputs_checked": len(saved)})

log = (ROOT / "attempts" / selection["legacy_public"] / "output.log").read_text()
markers = [json.loads(line.split("AUTOMATIC_CUTE_POLICY_RESULT=", 1)[1])
           for line in log.splitlines() if "AUTOMATIC_CUTE_POLICY_RESULT=" in line]
if len(markers) != 2 or sorted(row["fast"] for row in markers) != [False, True]:
    raise RuntimeError("Missing public CuTe GPU cases")
for marker in markers:
    if (marker["ordinary_batches"] != [13, 2, 5] or marker["native_hit_batches"] != [7, 3, 35, 36]
            or marker["ordinary_compilations"] != 1 or marker["public_hit_checked_frames"] != []
            or any(marker[key] is not True for key in (
                "single_original_artifact", "one_ordinary_call_per_miss", "exact_cold_return_tuple",
                "public_ordinary_output_tensor_identity", "same_dispatcher_after_miss",
                "same_compilation_fresh_signatures", "policy_expired_before_hit_and_local_miss",
                "artifact_retains_miss_owner", "ordinary_borrow_protected",
                "input_and_temporary_storage_expired", "held_outputs_after_close",
                "output_storage_expired_after_release", "close_restores_ordinary_call",
                "automatic_public_policy"))):
        raise RuntimeError("Public CuTe semantic marker mismatch")
    cold = marker["cold_preparations"]
    if (len(cold) != 2 or [row["batch"] for row in cold] != [13, 2]
            or [row["arm"] for row in cold] != [False, True]
            or any(row["outputs"] != 1 or row["generated_calls"] < 1 for row in cold)):
        raise RuntimeError("Public local variant mismatch")

log = (ROOT / "attempts" / selection["public"] / "output.log").read_text()
parameters = [json.loads(line.split("MIXED_PARAMETER_POLICY_RESULT=", 1)[1])
              for line in log.splitlines() if "MIXED_PARAMETER_POLICY_RESULT=" in line]
if len(parameters) != 2 or sorted(row["fast"] for row in parameters) != [False, True]:
    raise RuntimeError("Missing mixed Parameter GPU cases")
for marker in parameters:
    if (marker["ordinary_batches"] != [13, 2, 5] or marker["native_hit_batches"] != [7, 35, 3, 36]
            or marker["ordinary_compilations"] != 1 or marker["public_hit_checked_frames"] != []
            or any(marker[key] is not True for key in (
                "single_original_artifact", "one_ordinary_call_per_miss", "exact_cold_return_tuple",
                "public_ordinary_output_tensor_identity", "same_dispatcher_after_miss",
                "same_compilation_fresh_signatures", "policy_expired_before_hit_and_local_miss",
                "artifact_retains_miss_owner", "ordinary_borrow_protected",
                "input_and_temporary_storage_expired", "held_outputs_after_close",
                "output_storage_expired_after_release", "close_restores_ordinary_call",
                "automatic_public_policy", "compiler_recorded_parameter_normalization",
                "replaced_and_final_parameter_storage_expired"))):
        raise RuntimeError("Mixed Parameter semantic marker mismatch")
    cold, copies = marker["cold_preparations"], marker["native_copies"]
    if (len(cold) != 2 or [row["batch"] for row in cold] != [13, 2]
            or [row["arm"] for row in cold] != [False, True]
            or len(copies) != 2 or [row["parameter_copied"] for row in copies] != [False, True]):
        raise RuntimeError("Mixed Parameter local variant/normalization mismatch")
    for row, copy in zip(cold, copies):
        if (row["outputs"] != 1 or row["generated_calls"] < 1
                or len(row["boxed_indices"]) != 1
                or len({row["parameter_index"], row["input_index"], *row["boxed_indices"]}) != 3
                or row["parameter_index"] not in row["recorded_copies"]
                or copy["indices"] != row["recorded_copies"] or copy["batch"] != row["batch"]):
            raise RuntimeError("Mixed Parameter boxed/copy correspondence mismatch")
    expected_updates = [(13, "cold", "unchanged"), (7, "hit", "in_place"),
                        (35, "hit", "aligned_replacement"), (2, "cold", "misaligned_replacement"),
                        (3, "hit", "same_misaligned"), (36, "hit", "misaligned_in_place"),
                        (5, "ordinary", "unchanged")]
    if [(row["batch"], row["mode"], row["weight"]) for row in marker["updates"]] != expected_updates:
        raise RuntimeError("Mixed Parameter update sequence mismatch")

directory = ROOT / "attempts" / selection["pipeline"]
for frontend, fast in (("fx", True), ("retained", False)):
    path = directory / f"pipeline_{frontend}_{fast}.json"
    result = json.loads(path.read_text())
    if (result["frontend"] != frontend or result["fast"] != fast
            or result["ordinary_cute_compilations"] != 1 or result["python_frames"] != []
            or len(result["variants"]) != 4 or len(result["native_hit_batches"]) != 10
            or any(result[key] is not True for key in (
                "same_capsule_across_misses", "original_embedded_binaries_verified",
                "cold_input_and_output_storage_released_before_hits",
                "native_output_storage_released_after_caller_drops_outputs",
                "held_outputs_correct_after_close", "captured_buffers_untouched",
                "generated_wrapper_usable_after_pipeline_close"))):
        raise RuntimeError("Existing pipeline regression mismatch")
    files[str(path)] = digest(path)

counts = {"cpu": sum(row["cases"] for row in attempts if row["suite"] not in ("frontend", "pipeline", "public", "legacy_public")),
          "gpu": sum(row["cases"] for row in attempts if row["suite"] in ("frontend", "pipeline", "public", "legacy_public"))}
counts["total"] = counts["cpu"] + counts["gpu"]
evidence = {
    "scope": "Compiler-recorded normalization admits module Parameters in automatic mixed CuTe replay, with affected regressions.",
    "reviewed_utc": datetime.now(timezone.utc).isoformat(), "accepted": True,
    "counts": counts, "attempts": attempts,
    "current_execution_inputs_checked": len(expected),
    "saved_execution_inputs_checked": sum(row["saved_inputs_checked"] for row in attempts),
    "files": files, "native_changed": False, "automatic_public_native_cute": True, "mixed_module_parameters": True,
    "regression_epochs": "All selected controls and regressions use the same MP runtime, test inventory, controller, source snapshots and native installation. The one former AO covered-static rejection is replaced by four positive MP cases; AO51 remains selected.",
    "limits": [
        "Opt-in records frontend, inference, read-only module Parameters in the generated prefix and one terminal CuTe call with two owned Tensor operands; no aliases, arbitrary subclasses or buffer reuse.",
        "Public hit profiling checks the generated/CuTe/cold paths; outer Dynamo Python frames are not claimed absent.",
        "Both FX and retained IR pass the existing explicitly composed three-provider pipeline; automatic mixed CuTe uses compiler records.",
        "No new timing benchmark, native build, full CI or production-readiness claim.",
    ],
}
path = ROOT / "evidence_review.json"
if path.exists():
    raise RuntimeError("Evidence already exists")
path.write_text(json.dumps(evidence, indent=2) + "\n")
print(json.dumps({"audit": digest(path), "files": len(files), "cases": counts["total"],
                  "saved_inputs": evidence["saved_execution_inputs_checked"]}))
