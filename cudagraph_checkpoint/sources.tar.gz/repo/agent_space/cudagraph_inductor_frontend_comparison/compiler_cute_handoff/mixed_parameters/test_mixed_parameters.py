from dataclasses import replace
from unittest import mock

from compiler_cute_handoff import policy as mixed
from compiler_cute_handoff.envelope import _check_envelope, attach_envelope, bind_envelope, EnvelopeDeclined
from compiler_policy_handoff.policy import HandoffInvalidated
from cute_bridge import preparation
from cute_bridge.lowering import _bind_compiler_program
import mixed_parameters_link_fixture as link_fixture
import mixed_parameters_owner_fixture as owner_fixture
import torch
from torch._inductor import config, ir
from torch._inductor.codegen.wrapper import InputAlignmentLine
from torch._inductor.runtime.cudagraph_arg_mapping import AlignmentCopy, InputSource
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch._inductor.virtualized import V
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


@instantiate_parametrized_tests
class TestMixedParameters(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.enterContext(torch.no_grad())
        self.enterContext(mock.patch.object(torch._C, "_cuda_make_boxed_dispatch", side_effect=owner_fixture.Dispatcher))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, *, second_input=False, copy_fault=None):
        compiler = owner_fixture.CompilerFixture(self)
        if second_input:
            other = ir.InputBuffer(name="other", layout=compiler.layout)
            compiler.buffers["other"] = other
            compiler.graph.graph_inputs["other"] = ir.TensorBox.create(other)
            compiler.graph.graph_input_names.append("other")
            compiler.graph.inputs_to_check.append(len(compiler.graph.graph_input_names) - 1)
            compiler.destination.data = compiler.computation("unused", "other").data
            position = compiler.wrapper.lines.index(compiler.output_call)
            with V.set_graph_handler(compiler.graph):
                compiler.graph.scheduler.current_node = compiler.output_scheduler
                compiler.call("clone_kernel", other, compiler.destination)
            compiler.wrapper.lines[position] = compiler.wrapper.lines.pop()
            compiler.wrapper.lines.insert(2, InputAlignmentLine("other"))
        with mock.patch.object(owner_fixture, "CompilerFixture", return_value=compiler):
            fixture = owner_fixture.TestAutomaticCuTeOwner.fixture(self, arm=False)
        records = fixture.original._cute_mixed_envelope
        if copy_fault is not None:
            original = next(event for event in records.events if type(event) is AlignmentCopy)
            replacements = {
                "missing": (),
                "late": (replace(original, before_call=1),),
                "wrong_slot": (replace(original, input_index=0),),
                "bool": (replace(original, input_index=True),),
                "duplicate": (original, original),
            }[copy_fault]
            events = tuple(row for event in records.events for row in (
                replacements if event is original else (event,)))
            del fixture.original._cute_mixed_attachment
            attach_envelope(fixture.original, replace(records, events=events))
        fixture.artifact.fx_kwargs["static_input_idxs"] = [compiler.source_index]
        return fixture

    @parametrize("normalize", (False, True))
    @parametrize("container", ("list", "tuple"))
    def test_covered_static_slot_admits_parameter_independently_of_flag(self, normalize, container):
        fixture = self.fixture()
        index = fixture.compiler.source_index
        indices = [index] if container == "list" else (index,)
        fixture.artifact.fx_kwargs["static_input_idxs"] = indices
        with config.patch(normalize_static_input_alignment=normalize):
            self.assertIs(fixture.policy.wrap_output(fixture.artifact), fixture.artifact)
        installation, = fixture.policy.installations
        parameter = torch.nn.Parameter(torch.ones(13, 128), requires_grad=False)
        box = owner_fixture.TestAutomaticCuTeOwner.box(self, fixture)
        box[index] = parameter

        def prepare(values):
            self.assertIs(values[index], parameter)
            self.assertEqual(box, [])
            self.assertIs(installation._ordinary_result[1], fixture.namespace["outcomes"][-1])
            return owner_fixture.TestAutomaticCuTeOwner.prepare(self, installation, [])

        with mock.patch.object(installation, "_prepare_variant", side_effect=prepare) as prepared:
            result = fixture.artifact.current_callable(box)
        prepared.assert_called_once()
        self.assertIs(result, fixture.namespace["outcomes"][0])
        self.assertIs(fixture.namespace["calls"][0], box)
        self.assertEqual(box, [])
        self.assertIs(fixture.artifact.current_callable, installation.entry)
        self.assertIs(fixture.artifact.fx_kwargs["static_input_idxs"], indices)
        self.assertEqual(tuple(indices), (index,))
        installation.close()
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    @parametrize("fault", ("missing", "none", "dict", "bool", "float", "negative",
                           "range", "duplicate", "integer", "kwargs"))
    def test_invalid_static_indices_decline_without_borrow(self, fault):
        fixture = self.fixture()
        index = fixture.compiler.source_index
        if fault == "missing":
            fixture.artifact.fx_kwargs = {}
        elif fault == "kwargs":
            fixture.artifact.fx_kwargs = []
        else:
            fixture.artifact.fx_kwargs["static_input_idxs"] = {
                "none": None, "dict": {index: True}, "bool": [True], "float": [float(index)],
                "negative": [-1], "range": [len(fixture.original._cute_mixed_envelope.inputs.kinds)],
                "duplicate": [index, index], "integer": [0],
            }[fault]
        with mock.patch.object(mixed.InvocationEntry, "borrow_native") as borrow:
            fixture.policy.wrap_output(fixture.artifact)
        borrow.assert_not_called()
        self.assertEqual(fixture.policy.installations, ())
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertEqual(fixture.namespace["calls"], [])

    @parametrize("fault", ("missing", "late", "wrong_slot", "bool", "duplicate"))
    def test_missing_or_malformed_copy_facts_do_not_authorize_static_inputs(self, fault):
        fixture = self.fixture(copy_fault=fault)
        with config.patch(normalize_static_input_alignment=True), mock.patch.object(
                mixed.InvocationEntry, "borrow_native") as borrow:
            fixture.policy.wrap_output(fixture.artifact)
        borrow.assert_not_called()
        self.assertEqual(fixture.policy.installations, ())
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertEqual(fixture.namespace["calls"], [])

    @parametrize("fault", ("kwargs", "container", "content", "state"))
    def test_armed_static_authority_cannot_be_replaced(self, fault):
        fixture = self.fixture()
        fixture.policy.wrap_output(fixture.artifact)
        installation, = fixture.policy.installations
        state = installation._static_state
        kwargs, indices, snapshot = state
        box = owner_fixture.TestAutomaticCuTeOwner.box(self, fixture)
        try:
            if fault == "kwargs":
                fixture.artifact.fx_kwargs = dict(kwargs)
            elif fault == "container":
                kwargs["static_input_idxs"] = list(indices)
            elif fault == "content":
                indices[0] = 0
            else:
                installation._static_state = (*state,)
            with self.assertRaises(HandoffInvalidated):
                fixture.artifact.current_callable(box)
            self.assertNotEqual(box, [])
            self.assertEqual(fixture.namespace["calls"], [])
        finally:
            fixture.artifact.fx_kwargs = kwargs
            kwargs["static_input_idxs"] = indices
            indices[:] = snapshot
            installation._static_state = state

    def test_in_place_change_to_another_covered_tensor_slot_is_not_new_authority(self):
        fixture = self.fixture(second_input=True)
        checked = bind_envelope(fixture.original)
        indices = fixture.artifact.fx_kwargs["static_input_idxs"]
        copies = tuple(event.input_index for event in checked.records.events if type(event) is AlignmentCopy)
        other, = [row.index for row in checked.inputs.tensor_inputs if row.index != indices[0]]
        self.assertIn(indices[0], copies)
        self.assertIn(other, copies)
        mixed._check_static_input_coverage(checked.inputs, (other,), copies)
        fixture.policy.wrap_output(fixture.artifact)
        box = owner_fixture.TestAutomaticCuTeOwner.box(self, fixture)
        saved = indices[0]
        try:
            indices[0] = other
            with self.assertRaisesRegex(HandoffInvalidated, "static input indices changed"):
                fixture.artifact.current_callable(box)
            self.assertNotEqual(box, [])
            self.assertEqual(fixture.namespace["calls"], [])
        finally:
            indices[0] = saved

    @parametrize("armed", (False, True))
    @parametrize("fault", ("container", "content", "source", "callable"))
    def test_mutation_during_coverage_check_preserves_box_and_competitor(self, armed, fault):
        fixture = self.fixture()
        if armed:
            fixture.policy.wrap_output(fixture.artifact)
        kwargs = fixture.artifact.fx_kwargs
        indices = kwargs["static_input_idxs"]
        snapshot = tuple(indices)
        attachment = fixture.original._cute_mixed_attachment
        competitor = lambda box: None
        check = mixed._check_static_input_coverage
        box = owner_fixture.TestAutomaticCuTeOwner.box(self, fixture)

        def change(*args):
            result = check(*args)
            if fault == "container":
                kwargs["static_input_idxs"] = list(indices)
            elif fault == "content":
                indices[0] = 0
            elif fault == "source":
                fixture.original._cute_mixed_attachment = None
            else:
                fixture.artifact.current_callable = competitor
            return result

        try:
            with mock.patch.object(mixed, "_check_static_input_coverage", side_effect=change):
                if not armed and fault == "source":
                    fixture.policy.wrap_output(fixture.artifact)
                else:
                    with self.assertRaises(HandoffInvalidated):
                        if armed:
                            fixture.artifact.current_callable(box)
                        else:
                            fixture.policy.wrap_output(fixture.artifact)
            self.assertEqual(fixture.namespace["calls"], [])
            self.assertNotEqual(box, [])
            if fault == "callable":
                self.assertIs(fixture.artifact.current_callable, competitor)
            if not armed:
                self.assertEqual(fixture.policy.installations, ())
                self.assertEqual(fixture.compiler.owner._native_borrows, set())
        finally:
            kwargs["static_input_idxs"] = indices
            indices[:] = snapshot
            fixture.original._cute_mixed_attachment = attachment

    def test_unexpected_coverage_error_propagates_without_borrow(self):
        fixture = self.fixture()
        error = ValueError("unexpected copy analysis failure")
        with mock.patch.object(mixed, "_check_static_input_coverage", side_effect=error), self.assertRaises(ValueError) as raised:
            fixture.policy.wrap_output(fixture.artifact)
        self.assertIs(raised.exception, error)
        self.assertEqual(fixture.policy.installations, ())
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    @parametrize("parameter", (False, True))
    def test_compiler_bound_link_accepts_exact_tensor_or_parameter(self, parameter):
        fixture = link_fixture.TestCompilerCuTeLink.fixture(self, return_prefix=False)
        linked = link_fixture.TestCompilerCuTeLink.link(self, fixture)
        context = _bind_compiler_program(linked.program, fixture.providers, fixture.checked)
        index = fixture.checked.inputs.tensor_inputs[0].index
        value = torch.ones(1)
        if parameter:
            value = torch.nn.Parameter(value, requires_grad=False)
        fixture.box[index] = value
        before = tuple(fixture.box)
        plan = preparation._validate(linked.program, fixture.providers, fixture.box, compiler=context)
        self.assertEqual(len(plan.calls), len(fixture.checked.records.generated_calls) + 1)
        self.assertIs(fixture.box[index], value)
        self.assertTrue(all(left is right for left, right in zip(fixture.box, before)))

    @parametrize("fault", ("unbound", "subclass"))
    def test_parameter_requires_checked_compiler_path_and_exact_type(self, fault):
        class ParameterSubclass(torch.nn.Parameter):
            pass

        fixture = link_fixture.TestCompilerCuTeLink.fixture(self, return_prefix=False)
        linked = link_fixture.TestCompilerCuTeLink.link(self, fixture)
        context = _bind_compiler_program(linked.program, fixture.providers, fixture.checked)
        index = fixture.checked.inputs.tensor_inputs[0].index
        cls = ParameterSubclass if fault == "subclass" else torch.nn.Parameter
        fixture.box[index] = cls(torch.ones(1), requires_grad=False)
        with self.assertRaisesRegex(UnsupportedCapture, "ordinary Tensor"):
            preparation._validate(linked.program, fixture.providers, fixture.box,
                                  compiler=None if fault == "unbound" else context)

    def test_existing_envelope_excludes_direct_boxed_cute_source(self):
        fixture = self.fixture()
        records = fixture.original._cute_mixed_envelope
        original, = records.cute.calls
        source = next(row for row in records.cute.tensors if row.source == InputSource(fixture.compiler.source_index))
        call = replace(original, operands=(source, original.operands[1]))
        changed = replace(records, cute=replace(records.cute, calls=(call,)),
                          events=tuple(call if event == original else event for event in records.events))
        with self.assertRaisesRegex(EnvelopeDeclined, "initialized prefix and fresh destination"):
            _check_envelope(changed)


if __name__ == "__main__":
    run_tests()
