# Native physical output slots

Design only. The completed DR build and all frozen inputs remain unchanged. The compiler side must provide the exact physical tuple from the generated backward, including every literal None; this native change cannot infer missing positions.

## Contract

Extend the existing private argument rather than add a second output map:

    output_indices: tuple[int | None, ...] | None = None

The outer None keeps the current legacy meaning: return every allocation in allocation order. An explicit exact tuple is the complete physical result: each exact nonnegative int selects one allocation; each literal None returns None in that position. Preserve the existing distinct, in-range rule for Tensor indices. Repeated None slots are valid and have no allocation, pointer binding or storage owner. Bool, integer subclasses, other constants, nested tuples and arbitrary objects remain invalid.

For example, (None, 1, None, 0) returns (None, buffer1, None, buffer0), while (1, 0) and omitted output_indices retain their current behavior. The compiler bridge must not infer this map from shape values, gradient names or the count of integer inputs. A None slot is supported only because the emitted physical output tuple contains that literal.

## Minimal native delta

Only two source files should need edits:

- [/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:434](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:434): parse literal None rows before the existing exact nonnegative-integer parser; keep integer uniqueness/range checks. Change BoxedReplayPlan.output_indices at line 493 to vector<optional<size_t>>. Optional is already used in this file, including layout value indices. Keep has_explicit_output_indices unchanged, so release still requires an explicit tuple.
- [/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:638](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:638): the current prelaunch PyTuple_New uses the physical slot count and needs no reordering. Keep its allocation and subsequent box/reentrancy checks at their current point.
- [/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:805](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:805): after graph enqueue, fill a None slot with Py_NewRef(Py_None); for a Tensor slot use the existing StorageImpl/TensorImpl construction with the selected allocation index. Do not preconstruct output Tensors or move ownership transfers before enqueue.
- [/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:1036](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/source_delta/torch/csrc/cuda/Graph.cpp:1036): dispatcher append currently compares output arity, which was sufficient when every slot was a Tensor. Compare the cold Tensor/None slot pattern too, ignoring branch-local allocation indices. A small stored vector<bool> can replace output_count_ and carry both arity and kind compatibility. This happens only while appending a variant, never on a replay hit.
- [/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/source_delta/torch/_C/__init__.pyi.in:2632](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/source_delta/torch/_C/__init__.pyi.in:2632): widen the template annotation to tuple[_int | None, ...] | None. The pybind argument order and defaults at Graph.cpp:1399 stay unchanged. Edit the .pyi.in template, not the generated installed stub.

No changes are needed to allocation layouts, numeric evaluation, pointer/scalar/grid bindings, release steps or the allocator. None slots do not count as buffers and do not alter input_count + allocation_index correspondence. CUDAGraphParams and GraphReplayLease continue receiving the same pointer arrays, numeric values, pending state and enqueue ordering.

## Ownership and failures

The result tuple is allocated before box consumption, as today. Native replay still normalizes operands, evaluates numeric layouts, arms pending input backing, executes the allocation/drop schedule, and enqueues the graph before constructing output objects. A None slot neither releases storage nor reserves it. Unique Tensor output indices ensure each allocation's DataPtr moves into one returned StorageImpl.

The existing catch/close path owns partially constructed tuples and allocations after enqueue. Py_NewRef(Py_None) introduces no new allocation or recovery path. Unexpected errors continue to propagate and invalidate the owner; cleanup needed for queued work remains unchanged. No per-hit output-schema validation, alias scan, refcount polling or fallback retry is added.

## Focused checks before qualification

1. With real captured typed kernels, request interleaved leading/middle/trailing and repeated None slots plus two distinct Tensor outputs in reversed allocation order. Check exact physical arity, None identity, numerical values and held Tensor lifetimes after close.
2. Run that mapping for static pointer replay and dynamic numeric replay. The numeric case changes size over one entry, with release enabled, and retains the direct control's required matching-byte saved-address reuse. A no-release counterpart confirms the output map is independent of reclamation.
3. Reject negative/out-of-range/duplicate Tensor indices and non-exact primitive rows cold; allow repeated None. Replay a pristine entry afterward to show rejection did not alter the captured graph.
4. Preserve omitted output_indices and all-int explicit tuples. For dispatch, reject equal-arity variants with different Tensor/None patterns at append; accept the same pattern with different branch-local allocation indices. Existing one/many-call variants remain all-Tensor.
5. After compiler/reader transport preserves the physical tuple, revise the nine admission probes to observe that actual Tensor/None result rather than filter outputs. Keep the original AOT boxed indices, Tensor-only drops, reader record identity, native-hit frame checks, numerical gradients and retain_graph protections. Re-run the established static and numeric native controls as regressions.

Actual tuple collection and serialization belong to the common compiler/reader output contract. The first implementation should support only owned Tensor buffers and literal None; other constants, aliases, nested returns and repeated Tensor outputs can continue to decline. A fresh isolated native build is required before executing the new output form.
