import dynamic_metadata_fixture
import release_metadata_fixture
import schedule_fixture
import static_metadata_fixture
import transport_fixture
from torch.testing._internal.common_utils import run_tests


class TestStaticMetadata(static_metadata_fixture.TestStaticMetadata):
    pass

class TestCompilerMetadata(dynamic_metadata_fixture.TestCompilerMetadata):
    pass

class TestActivationReleaseSchedule(schedule_fixture.TestActivationReleaseSchedule):
    pass

class TestReleaseMetadata(release_metadata_fixture.TestReleaseMetadata):
    pass

class TestSavedInputTransport(transport_fixture.TestSavedInputTransport):
    pass


if __name__ == "__main__":
    run_tests()
