from dataclasses import fields, is_dataclass, replace
from types import SimpleNamespace
from unittest import mock

import torch
from torch._inductor import config, ir
from torch._inductor.codegen.common import ArgName, SizeArg, TensorArg
from torch._inductor.codegen.wrapper import (
    AllocateLine, EnterDeviceContextManagerLine, ExitDeviceContextManagerLine, FreeLine,
    InputAlignmentLine, KernelCallLine, PythonWrapperCodegen, ReuseLine, TritonCallArgument,
)
from torch._inductor.runtime.cudagraph_arg_mapping import AlignmentCopy, bind_alignment_copies, InputSource, IntegerInput, KernelCallRecord, OwnedBuffer
from torch._inductor.sizevars import SizeVarAllocator
from torch._inductor.virtualized import ops, V
from torch.fx.experimental.symbolic_shapes import ShapeEnv
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)

from compiler_saved_inputs import schedule
from compiler_saved_inputs.classification import BackwardInput, SavedActivations
from compiler_saved_inputs.handoff import FinalSavedInputs


class CompilerFixture:
    """Synthetic compiler carrier with real typed wrapper IR and its actual collector."""

    def __init__(self, test, *, late_weight=False, copies=False):
        test.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True,
                                       allow_buffer_reuse=False, inplace_buffers=False))
        self.layout = ir.FixedLayout(torch.device("cuda:0"), torch.float32, (32, 128), (128, 1))
        self.activation = ir.InputBuffer(name="activation", layout=self.layout)
        self.weight = ir.InputBuffer(name="weight", layout=self.layout)
        self.temp = self.computation("temp", ("activation",) if late_weight else ("activation", "weight"))
        self.output = self.computation("output", ("temp", "weight"))
        nodes = (self.activation, self.weight, self.temp, self.output)
        scheduler_nodes = [SimpleNamespace(node=node) for node in (self.temp, self.output)]
        self.graph = SimpleNamespace(
            name="release_fixture", sizevars=SizeVarAllocator(ShapeEnv()),
            graph_inputs={node.get_name(): ir.TensorBox.create(node) for node in nodes[:2]},
            graph_input_names=["activation", "weight"], graph_outputs=[self.output],
            cpp_wrapper=False, aot_mode=False, partition_maps=None, effectful_ops={},
            mutated_inputs=set(), constants={}, operations=[self.temp, self.output],
            scheduler=SimpleNamespace(current_node=scheduler_nodes[0], nodes=scheduler_nodes),
            is_unspec_arg=lambda name: False, get_allocation_size=lambda node: node.get_size(),
        )
        self.wrapper = PythonWrapperCodegen.__new__(PythonWrapperCodegen)
        self.wrapper._multistream_alignment_copies = set()
        test.enterContext(V.set_graph_handler(self.graph))
        self.allocate_temp = AllocateLine(self.wrapper, self.temp)
        self.graph.scheduler.current_node = scheduler_nodes[1]
        self.allocate_output = AllocateLine(self.wrapper, self.output)
        self.first = self.call("first", (self.activation,) if late_weight else (self.activation, self.weight), self.temp)
        self.second = self.call("second", (self.temp, self.weight), self.output)
        self.free_activation = FreeLine(self.wrapper, self.activation)
        self.free_weight = FreeLine(self.wrapper, self.weight)
        self.wrapper.lines = [
            EnterDeviceContextManagerLine(0, None), self.allocate_temp, self.first,
            self.free_activation, self.allocate_output, self.second,
            FreeLine(self.wrapper, self.temp), self.free_weight, ExitDeviceContextManagerLine(),
        ]
        if copies:
            self.wrapper.lines.insert(self.wrapper.lines.index(self.first), InputAlignmentLine("activation"))
            before = self.second if late_weight else self.first
            self.wrapper.lines.insert(self.wrapper.lines.index(before), InputAlignmentLine("weight"))
        # The AOT origin bridge has separate real callback controls.
        self.saved = FinalSavedInputs(("activation", "weight"), SavedActivations((
            BackwardInput(0, "activation", "activation", 0, 0),
            BackwardInput(1, "weight", "input_alias", 1, 1),
        )))
        self.records = self.wrapper.collect_cudagraph_call_records()
        test.assertIsNotNone(self.records)
        test.assertIsNotNone(self.collect())

    def computation(self, name, inputs):
        def body(index):
            left = ops.load(inputs[0], index[0] * 128 + index[1])
            right = ops.load(inputs[1], index[0] * 128 + index[1]) if len(inputs) == 2 else ops.constant(1, self.layout.dtype)
            return ops.sin(ops.add(left, right))
        data = ir.Pointwise(device=self.layout.device, dtype=self.layout.dtype, inner_fn=body, ranges=self.layout.size)
        return ir.ComputedBuffer(name=name, layout=self.layout, data=data)

    def call(self, name, inputs, output):
        buffers = (*inputs, output)
        formals = tuple(f"ptr{index}" for index in range(len(buffers))) + ("xnumel",)
        values = tuple(node.get_name() for node in buffers) + (4096,)
        signatures = tuple(TensorArg(formal, node.get_name(), torch.float32)
                           for formal, node in zip(formals, buffers)) + (SizeArg("xnumel", 4096),)
        return KernelCallLine(
            self.wrapper, name, values, (), (), [], True,
            {"signature": dict(zip(formals, ("*fp32",) * len(buffers) + ("i32",))), "constants": {}},
            {"grid_type": "Grid1D", "cudagraph_formal_indices": dict(zip(formals, range(len(formals)))),
             "cudagraph_parameter_provenance": {
                 formal: (node.get_name(), node is output, 16) for formal, node in zip(formals, buffers)}},
            self.layout.device, self.graph.name, name,
            cudagraph_args=tuple(TritonCallArgument(ArgName(formal), signature)
                                 for formal, signature in zip(formals, signatures, strict=True)),
        )

    def collect(self):
        return schedule.collect_release_schedule(self.saved, self.wrapper, self.records)


class TestActivationReleaseSchedule(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def test_actual_ir_order_and_complete_call_slots(self):
        fixture = CompilerFixture(self)
        result = fixture.collect()
        self.assertEqual(result.input_uses, ((0,), (0, 1)))
        self.assertEqual(result.steps, (
            fixture.records.allocations[0], fixture.records.calls[0], schedule.DropInput(0, 0),
            fixture.records.allocations[1], fixture.records.calls[1],
        ))
        self.assertEqual(result.outputs, fixture.records.outputs)
        calls = tuple(step for step in result.steps if type(step) is KernelCallRecord)
        self.assertEqual(calls, fixture.records.calls)
        self.assertEqual(tuple((arg.formal, arg.source_arg_index, arg.call_arg_index, arg.source)
                               for arg in calls[0].arguments),
                         tuple((arg.formal, arg.source_arg_index, arg.call_arg_index, arg.source)
                               for arg in fixture.records.calls[0].arguments))

    def test_records_alone_do_not_determine_allocation_release_order(self):
        fixture = CompilerFixture(self)
        early = fixture.collect()
        fixture.wrapper.lines.remove(fixture.free_activation)
        fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.second), fixture.free_activation)
        self.assertEqual(fixture.wrapper.collect_cudagraph_call_records(), fixture.records)
        late = fixture.collect()
        self.assertIsNotNone(late)
        self.assertNotEqual(early.steps, late.steps)
        self.assertEqual(late.steps[2:4], (fixture.records.allocations[1], schedule.DropInput(0, 0)))

    @parametrize("alias", (False, True))
    def test_drop_is_only_a_reference_release(self, alias):
        fixture = CompilerFixture(self)
        result = fixture.collect()
        owned = [torch.empty(32, 128), torch.empty(32, 128)]
        storage = StorageWeakRef(owned[0].untyped_storage())
        weight = StorageWeakRef(owned[1].untyped_storage())
        external = owned[0].view(-1) if alias else None
        dropped = False
        for step in result.steps:
            if type(step) is schedule.DropInput:
                owned[step.input_index] = None
                dropped = True
            if type(step) is OwnedBuffer and step.source == fixture.records.allocations[1].source:
                self.assertTrue(dropped)
                self.assertEqual(storage.expired(), not alias)
                self.assertFalse(weight.expired())
        del external
        self.assertTrue(storage.expired())
        self.assertFalse(weight.expired())

    def test_result_has_no_live_compiler_or_tensor_owners(self):
        result = CompilerFixture(self).collect()
        def check(value):
            if is_dataclass(value):
                for field in fields(value):
                    check(getattr(value, field.name))
            elif type(value) is tuple:
                for item in value:
                    check(item)
            else:
                self.assertIn(type(value), (str, int, float, bool, type(None), torch.dtype))
        check(result)

    @parametrize("damage", ("call_order", "formal", "slot", "source", "allocation", "output", "names"))
    def test_records_must_match_live_source(self, damage):
        fixture = CompilerFixture(self)
        records = fixture.records
        if damage == "call_order":
            records = replace(records, calls=records.calls[::-1])
        elif damage in ("formal", "slot", "source"):
            argument = records.calls[0].arguments[0]
            change = {"formal": "wrong"} if damage == "formal" else (
                {"call_arg_index": 2} if damage == "slot" else {"source": InputSource(1)})
            argument = replace(argument, **change)
            call = replace(records.calls[0], arguments=(argument, *records.calls[0].arguments[1:]))
            records = replace(records, calls=(call, records.calls[1]))
        elif damage == "allocation":
            records = replace(records, allocations=records.allocations[::-1])
        elif damage == "output":
            records = replace(records, outputs=(records.allocations[0],))
        else:
            records = replace(records, input_names=records.input_names[::-1])
        self.assertIsNone(schedule.collect_release_schedule(fixture.saved, fixture.wrapper, records))

    @parametrize("damage", ("early_free", "missing_free", "duplicate_free", "wrong_node", "copy", "reuse", "input_write"))
    def test_unsupported_lifetimes_and_effects_decline(self, damage):
        fixture = CompilerFixture(self)
        lines = fixture.wrapper.lines
        if damage == "early_free":
            lines.remove(fixture.free_activation)
            lines.insert(lines.index(fixture.first), fixture.free_activation)
        elif damage == "missing_free":
            lines.remove(fixture.free_activation)
        elif damage == "duplicate_free":
            lines.insert(lines.index(fixture.free_activation), fixture.free_activation)
        elif damage == "wrong_node":
            fixture.free_activation.node = ir.InputBuffer(name="activation", layout=fixture.layout)
        elif damage == "copy":
            lines.insert(1, InputAlignmentLine("activation"))
        elif damage == "reuse":
            lines.insert(2, ReuseLine(fixture.wrapper, fixture.temp, fixture.output))
        else:
            provenance = fixture.first.inductor_meta["cudagraph_parameter_provenance"]
            provenance["ptr0"] = ("activation", True, 16)
        self.assertIsNone(fixture.collect())

    @parametrize("late_weight", (False, True))
    def test_normalization_preserves_real_first_use(self, late_weight):
        fixture = CompilerFixture(self, late_weight=late_weight, copies=True)
        result = fixture.collect()
        copies = tuple(step for step in result.steps if type(step) is AlignmentCopy)
        self.assertEqual(copies, (AlignmentCopy(0, 0), AlignmentCopy(1, int(late_weight))))
        self.assertEqual(copies, fixture.records.alignment_copies)
        self.assertEqual(result.input_uses, ((0,), (1,) if late_weight else (0, 1)))
        self.assertLess(result.steps.index(copies[0]), result.steps.index(fixture.records.calls[0]))
        self.assertLess(result.steps.index(copies[1]), result.steps.index(fixture.records.calls[int(late_weight)]))
        drop = schedule.DropInput(0, 0)
        self.assertLess(result.steps.index(copies[0]), result.steps.index(drop))
        self.assertLess(result.steps.index(drop), result.steps.index(fixture.records.allocations[1]))

    @parametrize("version", (2, 3, 4))
    def test_later_first_use_binding_by_version(self, version):
        fixture = CompilerFixture(self, late_weight=True, copies=True)
        records = replace(fixture.records, version=version)
        if version == 4:
            records = replace(records, input_names=(*records.input_names, "rows"),
                              integer_inputs=(IntegerInput("rows", 2),))
        self.assertEqual(bind_alignment_copies(records), None if version == 2 else (0, 1))

    @parametrize("damage", ("duplicate", "after_use", "past_first_use", "unknown_input", "reverse"))
    def test_invalid_normalization_records_decline(self, damage):
        fixture = CompilerFixture(self, late_weight=True, copies=True)
        copies = fixture.records.alignment_copies
        if damage == "duplicate":
            copies = (copies[0], copies[0], copies[1])
        elif damage == "after_use":
            copies = (AlignmentCopy(0, 1), copies[1])
        elif damage == "past_first_use":
            copies = (copies[0], AlignmentCopy(1, 2))
        elif damage == "unknown_input":
            copies = (copies[0], AlignmentCopy(2, 1))
        else:
            copies = copies[::-1]
        self.assertIsNone(bind_alignment_copies(replace(fixture.records, alignment_copies=copies)))

    @parametrize("write", (True, None, 0, "read"))
    def test_source_collector_requires_read_only_inputs(self, write):
        fixture = CompilerFixture(self)
        provenance = fixture.first.inductor_meta["cudagraph_parameter_provenance"]
        provenance["ptr0"] = ("activation", write, 16)
        self.assertIsNone(fixture.wrapper.collect_cudagraph_call_records())

    def test_absent_annotation_and_non_candidates(self):
        fixture = CompilerFixture(self)
        self.assertIsNone(schedule.collect_release_schedule(None, fixture.wrapper, fixture.records))
        rows = tuple(replace(row, kind="input_alias") for row in fixture.saved.classification.inputs)
        fixture.saved = replace(fixture.saved, classification=SavedActivations(rows))
        self.assertIsNone(fixture.collect())

    def test_unexpected_source_failure_propagates(self):
        fixture = CompilerFixture(self)
        error = RuntimeError("unexpected compiler collector failure")
        with mock.patch.object(PythonWrapperCodegen, "collect_cudagraph_call_records", side_effect=error):
            with self.assertRaisesRegex(RuntimeError, "unexpected compiler collector failure") as caught:
                fixture.collect()
        self.assertIs(caught.exception, error)


instantiate_parametrized_tests(TestActivationReleaseSchedule)


if __name__ == "__main__":
    run_tests()
