"""Build the reviewed native release delta and restore the warm source tree."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time


ROOT = Path(__file__).resolve().parent
REPO = Path("/data/eellison/src/pytorch")
PREVIOUS = REPO / "agent_space/cudagraph_inductor_frontend_comparison/cute_bridge"
WARM = REPO / "agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1"
SOURCE = WARM / "source"
NEW_HEADER = "c10/cuda/CUDACachingAllocatorPendingGraph.h"
GENERATED = ("torch/_C/__init__.pyi", "torch/version.py")
DELTAS = {
    "c10/cuda/CUDACachingAllocator.cpp": "d0f998fe816cf161e81166431066c521120493be5a7ced34cc991b9562d5e3a4",
    NEW_HEADER: "491ef6197baadbfc9cec736762754c3ac1ea64de9dfcf5c0daaae61df2b5f2a1",
    "aten/src/ATen/cuda/CUDAGraph.cpp": "d60a4f78a5000d5c539acb2de7eef9c13b987f2a94111851351d0dcdc6fa1f59",
    "aten/src/ATen/cuda/CUDAGraph.h": "6522b29eac090e334dd77326434d037a02148e5f729b59643a1070439b8336a7",
    "aten/src/ATen/cuda/CUDAGraphParams.cpp": "fff69a8ec792f7e937b0f66c226c0aec33d09d057e4aa14870ba2ca9f5bffc9a",
    "aten/src/ATen/cuda/CUDAGraphParams.h": "10fd5d5c9b43edc988191fde9d5fe5b9185cef611dcb1d0a60cb59eb13592f25",
    "torch/csrc/cuda/Graph.cpp": "05670ad3932d5af23f99086917abe87fa9974ceb9bf5d9e050309f44d4bce50c",
    "torch/_C/__init__.pyi.in": "008b1d3e3afcfdfa98a776904ed33d32db75f4123b239c8f1de5320a81a41a0a",
}
RECEIPTS = {
    "native_source_review.json": "db547156f8786bc850f3a8fbb9fbe2128538faf40a0a85e5f0f2ca5ddaf70fe1",
    "native_source_independent_review.json": "0b3e7e3695c61c2390852ee42b6ee1dd0549ef4b30091056c446e9483380a5bb",
}
BASELINE_RECEIPTS = {
    "evidence/source_manifest.json": "6992cdbea6fbd230645fd38c403d74f35a430a3b48ff76f80c8060b0b2c913a1",
    "evidence/build_result.json": "60af91f9d9d7e69bcb688b509a6a17afefb7c40c41ad49b8fff1f3ceb98c4ba3",
}


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def write(path, value):
    with path.open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def main():
    with (WARM / "native_dispatch_build.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        build()


def build():
    for name, sha in BASELINE_RECEIPTS.items():
        if digest(PREVIOUS / name) != sha:
            raise RuntimeError("Qualified native baseline receipt changed: " + name)
    previous_manifest_path = PREVIOUS / "evidence/source_manifest.json"
    previous_result_path = PREVIOUS / "evidence/build_result.json"
    previous = json.loads(previous_manifest_path.read_text())
    previous_result = json.loads(previous_result_path.read_text())
    if (not previous_result["accepted"] or not previous_result["source_restored"]
            or previous_result["manifest_sha256"] != digest(previous_manifest_path)
            or Path(previous["source_root"]) != SOURCE
            or Path(previous["install_root"]) != PREVIOUS / "install_attempt1"):
        raise RuntimeError("Expected the qualified CuTe build and restored warm source")
    expected = {**previous["source_files"], **previous["restored_source_files"]}
    for name, sha in expected.items():
        if digest(SOURCE / name) != sha:
            raise RuntimeError("Accepted warm source changed: " + name)
    if (SOURCE / NEW_HEADER).exists() or (SOURCE / NEW_HEADER).is_symlink():
        raise RuntimeError("The new pending-input header must be absent before staging")
    for name, sha in RECEIPTS.items():
        if digest(ROOT / name) != sha:
            raise RuntimeError("Frozen native source review changed: " + name)
    peer = json.loads((ROOT / "native_source_independent_review.json").read_text())
    if not peer["accepted"] or {row["relative_source"]: row["sha256"] for row in peer["sources"]} != DELTAS:
        raise RuntimeError("Independent native review does not cover these exact deltas")
    for name, sha in DELTAS.items():
        if digest(ROOT / "source_delta" / name) != sha:
            raise RuntimeError("Reviewed native delta changed: " + name)
    old_install = PREVIOUS / "install_attempt1"
    old_hashes = previous_result["installed_native_hashes"]
    if set(old_hashes) != set(previous["native_files"]):
        raise RuntimeError("Previous installed native inventory differs from its manifest")
    for name, sha in old_hashes.items():
        if digest(old_install / name) != sha:
            raise RuntimeError("Accepted native installation changed: " + name)
    if digest(old_install / GENERATED[0]) != previous_result["installed_stub_sha256"]:
        raise RuntimeError("Accepted installed stub changed")
    if (ROOT / "install_attempt1").exists() or not (WARM / "build").is_dir():
        raise RuntimeError("Expected a fresh install target and existing warm build directory")

    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=False)
    backup = evidence / "accepted_source_backup"
    backup.mkdir()
    preserved = (*[name for name in DELTAS if name != NEW_HEADER], *GENERATED)
    before = {}
    for name in preserved:
        destination = backup / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / name, destination)
        before[name] = digest(destination)
    scaffold = ("build_native.py", "build_candidate.sh", "build_site/sitecustomize.py",
                "runtime_site/sitecustomize.py", "python.sh", "check_native.py")
    manifest = {
        "head": previous["head"], "source_root": str(SOURCE),
        "install_root": str(ROOT / "install_attempt1"),
        "source_files": {**previous["source_files"], **DELTAS}, "delta_files": DELTAS,
        "base_source_files": expected, "restored_source_files": before,
        "restored_absent_files": [NEW_HEADER], "generated_files": list(GENERATED),
        "native_files": previous["native_files"], "native_review_hashes": RECEIPTS,
        "scaffold_hashes": {name: digest(ROOT / name) for name in scaffold},
        "previous_manifest_sha256": digest(previous_manifest_path),
        "previous_build_result_sha256": digest(previous_result_path),
        "gpu_uuid": previous["gpu_uuid"], "gpu_guard": previous["gpu_guard"],
    }
    write(evidence / "source_manifest.json", manifest)
    result = {
        "accepted": False, "started_utc": datetime.now(timezone.utc).isoformat(),
        "manifest_sha256": digest(evidence / "source_manifest.json"),
        "build_script_sha256": digest(ROOT / "build_candidate.sh"),
        "build_controller_sha256": digest(Path(__file__)),
        "command": ["bash", str(ROOT / "build_candidate.sh")],
    }
    started = time.monotonic()
    try:
        for name in DELTAS:
            shutil.copyfile(ROOT / "source_delta" / name, SOURCE / name)
        with (evidence / "build.log").open("x") as log:
            child = subprocess.run(result["command"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        result["exit_code"] = child.returncode
        if child.returncode:
            raise RuntimeError("Native pip build failed; inspect evidence/build.log")
        for name, sha in manifest["source_files"].items():
            if digest(SOURCE / name) != sha:
                raise RuntimeError("Source changed during compilation: " + name)
        generated_hashes = {}
        for name in GENERATED:
            destination = evidence / "generated_source" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / name, destination)
            generated_hashes[name] = digest(destination)
        result["generated_source_hashes"] = generated_hashes
        result["installed_native_hashes"] = {
            name: digest(ROOT / "install_attempt1" / name) for name in previous["native_files"]
        }
        result["installed_stub_sha256"] = digest(ROOT / "install_attempt1" / GENERATED[0])
        result["installed_version_sha256"] = digest(ROOT / "install_attempt1" / GENERATED[1])
        result["accepted"] = True
    except Exception as error:
        result["error"] = repr(error)
    finally:
        restoration_errors = []
        for name in preserved:
            try:
                # Refresh mtimes so the next warm build cannot reuse this candidate's objects.
                shutil.copyfile(backup / name, SOURCE / name)
            except Exception as error:
                restoration_errors.append({"path": name, "error": repr(error)})
        try:
            (SOURCE / NEW_HEADER).unlink(missing_ok=True)
        except Exception as error:
            restoration_errors.append({"path": NEW_HEADER, "error": repr(error)})
        result["restoration_errors"] = restoration_errors
        result["source_restored"] = not restoration_errors and all(
            (SOURCE / name).is_file() and digest(SOURCE / name) == sha for name, sha in expected.items()
        ) and not (SOURCE / NEW_HEADER).exists() and not (SOURCE / NEW_HEADER).is_symlink()
        result["previous_install_preserved"] = all(
            digest(old_install / name) == sha for name, sha in old_hashes.items()
        ) and digest(old_install / GENERATED[0]) == previous_result["installed_stub_sha256"]
        result["accepted"] &= result["source_restored"] and result["previous_install_preserved"]
        result["elapsed_seconds"] = time.monotonic() - started
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        write(evidence / "build_result.json", result)
    print(json.dumps(result, indent=2), flush=True)
    if not result["accepted"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
