from copy import copy
from dataclasses import asdict
import json
import pickle
from pathlib import Path
import sys
from unittest import mock

import dynamic_frontend_release_fixture as fixture
from compiler_metadata_handoff.metadata import MetadataDeclined, read_metadata
from compiler_saved_inputs.schedule import DropInput
from torch._inductor.codecache import PyCodeCache
from torch._inductor.output_code import CompiledFxGraph, CompiledFxGraphConstants
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class TestSavedReleaseSerialization(TestCase):
    @parametrize("frontend", ("fx", "retained"))
    def test_actual_backward_artifact_roundtrip(self, device, frontend):
        observer_type = fixture.NativeObservation
        reports = []

        def inspect_before_hits(installation):
            artifact, original, metadata = installation.artifact, installation.original, installation.metadata
            entry = installation.entry
            owner = artifact._cudagraph_installation_owner
            records = original._cudagraph_call_records
            attachment = original._cudagraph_frontend_attachment
            schedule = metadata.release_schedule
            self.assertIs(type(artifact), CompiledFxGraph)
            self.assertEqual(installation.status, "ready")
            self.assertIs(artifact.current_callable, entry)
            self.assertIs(artifact._cudagraph_original_callable, original)
            self.assertIs(attachment.function(), original)
            self.assertIs(attachment.records, records)
            self.assertIs(attachment.metadata, metadata)
            self.assertEqual(records.version, 4)
            self.assertIsNotNone(schedule)
            drops = tuple(step for step in schedule.steps if type(step) is DropInput)
            self.assertTrue(drops)
            self.assertEqual(schedule.outputs, records.outputs)

            serialized = copy(artifact)
            self.assertIs(serialized._cudagraph_installation_owner, owner)
            serialized.prepare_for_serialization()
            cleared = ("current_callable", "_cudagraph_original_callable", "_cudagraph_installation_owner",
                       "_compile_context", "recursively_apply_fns", "compiled_fn_runner")
            for name in cleared:
                self.assertIsNone(getattr(serialized, name))
            payload = pickle.dumps(serialized, protocol=pickle.HIGHEST_PROTOCOL)
            restored = pickle.loads(payload)
            self.assertIs(type(restored), CompiledFxGraph)
            self.assertIsNot(restored, artifact)
            for name in cleared:
                self.assertIsNone(getattr(restored, name))
            self.assertEqual(restored.source_code, artifact.source_code)
            self.assertEqual(restored.cache_key, artifact.cache_key)
            with self.assertRaisesRegex(MetadataDeclined, "original generated function"):
                read_metadata(restored)

            module_name = original.__module__
            absent = object()
            prior_module = sys.modules.get(module_name, absent)
            try:
                artifact_path = restored.after_deserialization(CompiledFxGraphConstants())
                self.assertEqual(Path(artifact_path).read_text(), artifact.source_code)
                function, restored_metadata = read_metadata(restored)
                self.assertIsNot(function, original)
                self.assertIsNot(function.__code__, original.__code__)
                self.assertIsNot(function.__globals__, original.__globals__)
                self.assertEqual(function.__module__, module_name)
                self.assertIs(function, restored.current_callable)
                self.assertIs(function, restored._cudagraph_original_callable)
                self.assertIsNone(restored._cudagraph_installation_owner)
                new_records = function._cudagraph_call_records
                new_attachment = function._cudagraph_frontend_attachment
                self.assertIsNot(new_records, records)
                self.assertIsNot(new_attachment, attachment)
                self.assertIs(new_attachment.function(), function)
                self.assertIs(new_attachment.code, function.__code__)
                self.assertIs(new_attachment.records, new_records)
                self.assertIs(new_attachment.metadata, restored_metadata)
                self.assertEqual(new_records, records)
                self.assertEqual(restored_metadata, metadata)
                new_schedule = restored_metadata.release_schedule
                self.assertIsNot(new_schedule, schedule)
                self.assertEqual(new_schedule.steps, schedule.steps)
                self.assertEqual(new_schedule.input_uses, schedule.input_uses)
                self.assertEqual(new_schedule.outputs, records.outputs)
                new_drops = tuple(step for step in new_schedule.steps if type(step) is DropInput)
                for old_drop, new_drop in zip(drops, new_drops, strict=True):
                    self.assertIsNot(old_drop, new_drop)
                self.assertIs(function.__globals__[function.__name__], function)
                self.assertTrue(any(module.__dict__ is function.__globals__ for module in PyCodeCache.modules))
                function._cudagraph_frontend_attachment = attachment
                try:
                    with self.assertRaisesRegex(MetadataDeclined, "original metadata attachment"):
                        read_metadata(restored)
                finally:
                    function._cudagraph_frontend_attachment = new_attachment
                self.assertIs(read_metadata(restored)[1], restored_metadata)
                self.assertIsNone(restored._cudagraph_installation_owner)
            finally:
                if prior_module is absent:
                    sys.modules.pop(module_name, None)
                else:
                    sys.modules[module_name] = prior_module

            self.assertIs(artifact.current_callable, entry)
            self.assertIs(artifact._cudagraph_original_callable, original)
            self.assertIs(artifact._cudagraph_installation_owner, owner)
            self.assertIs(original._cudagraph_frontend_attachment, attachment)
            self.assertIs(original._cudagraph_call_records, records)
            self.assertIs(installation.metadata.release_schedule, schedule)
            self.assertIs(installation.entry, entry)
            self.assertFalse(entry.closed)
            self.assertFalse(entry.failed)
            reports.append({
                "frontend": frontend, "records_version": records.version,
                "input_names": records.input_names, "integer_indices": [row.boxed_index for row in records.integer_inputs],
                "output_names": [None if row is None else row.source.name for row in records.outputs],
                "drops": [asdict(drop) for drop in drops], "input_uses": schedule.input_uses,
                "pickle_bytes": len(payload), "fresh_exact_attachment": True,
                "native_owner_serialized": False, "restored_native_installation": False,
                "cache_hit_exercised": False, "original_owner_preserved": True,
            })
            return observer_type(installation)

        method = getattr(fixture.TestDynamicFrontendSavedReleaseCUDA,
                         f"test_generated_backward_release_frontend_{frontend}_mode_release_cuda")
        with mock.patch.object(fixture, "NativeObservation", new=inspect_before_hits):
            method(self)
        self.assertEqual(len(reports), 1)
        report, = reports
        report["original_native_numerics_and_lifetimes_passed"] = True
        print("SAVED_RELEASE_SERIALIZATION " + json.dumps(report, sort_keys=True))


instantiate_device_type_tests(TestSavedReleaseSerialization, globals(), only_for="cuda")

if __name__ == "__main__":
    run_tests()
