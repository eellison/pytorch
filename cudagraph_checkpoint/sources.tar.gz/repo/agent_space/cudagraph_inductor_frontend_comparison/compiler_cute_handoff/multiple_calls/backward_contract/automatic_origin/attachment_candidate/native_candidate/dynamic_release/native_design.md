# Native numeric saved-input release

Source-only assessment of the frozen NC native candidate, whose eight source
hashes still match `native_source_review.json`. Static frontend release is frozen
with CPU192 passed; its GPU qualification is still in progress. The companion
`source_delta` implements the four-file proposal below. No framework execution
or build accompanies this candidate.

The smallest native change is four files. Keep the existing
`release_plan=(steps, nodes)` argument and allocator protocol. Numeric replay
already computes current allocation sizes; it needs to carry pending inputs to
the existing enqueue hook, plus one cold Tensor-slot check. The V4 compiler
annotation and reader projection remain prerequisites, as described in
`../next_frontend_release.md`.

## Existing authority and ordering

Paths below are relative to `../source_delta/`:

| Source | Existing behavior to preserve |
| --- | --- |
| `torch/csrc/cuda/Graph.cpp:198` | `BoxedNumericPlan` fixes the exact integer/Tensor slot partition and instruction tape. |
| `torch/csrc/cuda/Graph.cpp:324` | Numeric plan and numeric update batch must agree. Integer slots cannot supply pointer bindings; the referenced-pointer mask must exactly cover declared Tensor inputs and allocations (lines 329-350). |
| `torch/csrc/cuda/Graph.cpp:373` | Symbolic layouts use explicit value indices and contiguous rank-one/rank-two relationships; no captured size is substituted. |
| `torch/csrc/cuda/Graph.cpp:682` | Evaluate numeric values, validate scalar ABI/grid ranges, update invocation layouts, check positive extents and element-count/storage-byte overflow, then clear the box at line 703. |
| `torch/csrc/cuda/Graph.cpp:706` | Complete the normalization prologue before arming pending backing. Preserve original-copy source stream recording at line 745. |
| `torch/csrc/cuda/Graph.cpp:752` | The shared allocation lambda already uses `layouts[index].nbytes` for both claims and ordinary allocations. In numeric mode, `layouts` is the current invocation's layouts (line 702). |
| `aten/src/ATen/cuda/CUDAGraphParams.cpp:716` | Cold release proof uses actual graph nodes, full-completion consecutive edges, and checked pointer slots to derive all old/new uses and allocation eligibility. |
| `aten/src/ATen/cuda/CUDAGraph.cpp:337` | Begin submission immediately before `cudaGraphLaunch`; finish pending publication only after successful enqueue. |
| `c10/cuda/CUDACachingAllocator.cpp:5842` | Arm actual backing, group shared blocks, require the native deleter, and decline unsupported policies before any scheduled drop. |
| `c10/cuda/CUDACachingAllocator.cpp:5900` | Claims require current requested bytes to equal the old storage bytes, eligible use ordering for every grouped member, and a real final deleter. The device allocator also rejects live owners, foreign allocation streams and outstanding stream uses (line 2654). |

The proof is about complete kernel uses, not individual threads or sampled
extents. Numeric batch construction preserves node/parameter identity and stores
pointer slots separately from scalar/grid fields
(`CUDAGraphParams.cpp:554-635`). Changing scalar/grid values therefore does not
change the conservative pointer-use relation. The existing requirement that the
node list cover the complete linear graph must remain; no conditional graph or
unbound pointer extension is implied.

## Proposed native delta

1. **`torch/csrc/cuda/Graph.cpp`.** Remove the numeric exclusion from the
   constructor's release-plan gate at line 564; retain exact tuple parsing and
   explicit output indices. Build the existing cold `InputReleasePlan`, then,
   before storing it, reject any candidate whose
   `boxed_plan_->numeric->integer_inputs[index]` is true. Candidate range and
   uniqueness already come from `prepare_input_release`; do not recheck them on
   hits or add another slot descriptor. An unused boxed integer has an empty
   pointer-use list, so last-use validation alone is insufficient.

   In `call_impl<true>` at line 789, pass `invocation.pending.get()` as the third
   argument to numeric replay. The existing shared arm/allocate/drop code then
   runs unchanged. Keep Tensor admission, owner locking, dispatch snapshot checks
   and the no-release branches unchanged.

2. **`aten/src/ATen/cuda/CUDAGraphParams.h/.cpp`.** Add an optional
   `PendingGraphInputs* pending = nullptr` to the numeric
   `GraphReplayLease::replay(pointers, values)` overload
   (header line 207, implementation line 842), and forward it.
   In `prepare_input_release` at line 723, remove only `!batch_->numeric_`.
   Retain the complete node/binding, edge, step order, last-use and grouped
   eligibility checks. No scalar/grid validation is added to this structural
   proof or repeated after allocation.

3. **`aten/src/ATen/cuda/CUDAGraph.h` and Params implementation.** Add the same
   optional pointer to private `replay_kernel_updates_impl`
   (header line 161, `CUDAGraphParams.cpp:675`). After all numeric parameter
   setters, call `replay_impl(pending)` instead of `replay_impl()` at line 686.
   Keep partial-setter failure invalidation at lines 687-689.

No allocator, pending-input header, ATen `CUDAGraph.cpp` enqueue-hook, Python
method signature, or generated stub change is needed. This is still a native
binary change and requires an isolated build and qualification before use.

The matching cold Python bridge change is small but separately owned:
`torch/_inductor/runtime/cudagraph_boxed_replay.py:284` should continue requiring
explicit allocation/output ownership while permitting a numeric plan; line 394
must pass the real `(numeric.integer_indices, tuple(numeric.instructions))`
beside the existing release tuple instead of passing `None`. Existing numeric
batch construction and checked layout tags at lines 290 and 383 remain the
authority. The V4 metadata validator must reject integer drop targets too, while
the native constructor remains independently safe for its private direct API.

## Invocation and failure semantics

Keep this sequence: evaluate/check all current numbers and storage sizes;
consume the box; normalize inputs; arm actual normalized backing; run the cold
allocate/drop sequence; update kernel parameters; mark submission and enqueue;
finish pending publication; construct outputs from current layouts.

A drop releases only this invocation's original and normalized references.
Reusing the backing additionally requires a real final deleter and the existing
allocator claim conditions. Integer values remain in the box snapshot/tape and
are never treated as storage. Captured buffer bytes are never allocation or
claim sizes. Unequal current storage/allocation sizes simply use the existing
ordinary allocation path. Unsupported pending policy likewise retains the
existing no-early-drop path.

Preserve the present catch/close behavior (`Graph.cpp:817`, `Graph.cpp:867`):
pre-work numeric errors leave the input box untouched; an unsubmitted pending
invocation aborts its pending tags; errors after work begins invalidate the
owner and retain resources needed by queued work. An uncertain enqueue retains
backing until checked stream completion. Output-construction failure occurs
after enqueue and needs that same lifetime protection. No retry, recovery or
OOM-specific machinery is proposed. Normalization remains entirely before
arming, so no released backing can be recycled into an eager copy.

## Qualification matrix

| Control | Required observation |
| --- | --- |
| Direct numeric graph with two full-completion kernel nodes | One native owner across several increasing/decreasing positive extents; real scalar and grid updates; correct outputs. A saved input's last use precedes a later allocation. Exact pointer equality demonstrates claims when current sizes match, including a size different from capture. |
| Current size differs from candidate storage bytes | Correct output and ordinary allocation, with no claim of the candidate even if capture-time sizes happened to match. Use an actual declared graph/ABI, not guessed addresses. |
| Cold invalid plans | Reject an integer-slot drop, including an integer with no pointer uses; premature Tensor drop; wrong/repeated node order; missing allocation/node. Existing static direct controls remain unchanged. |
| Numeric failure before destructive work | Wrong integer type, scalar/grid bound violation, nonpositive dynamic extent, multiplication or storage-size overflow: input box unchanged, zero normalization/claim/enqueue, existing failure semantics preserved. Use a fresh owner where needed. |
| Ownership and streams | Live external owner, same-storage view, retained backward graph, foreign allocation stream, and unsupported history policy preserve data and prevent unauthorized reuse. Include held outputs after close. Reuse the existing finite-delay stream control; no spin gates. |
| V4 compiler integration, both readers | Actual compiler-origin schedule, symbolic layouts and boxed Tensor-only drops, unchanged call/slot identities, native hits with no watched Python work; release enabled/disabled and retain-graph behavior. Start with pointwise backward and same-shaped differentiable weight, avoiding a new dynamic reduction contract. |
| Failure after work begins | Exercise available setter/enqueue failure controls without a production hook; confirm invalidation and retained backing. If no safe injection exists, record that coverage gap instead of adding recovery machinery. |

Run existing static release, ordinary numeric replay and frontend regressions on
the same new binary. Address reuse is a correctness/control observation, not a
peak-memory claim; measuring memory benefit is a separate workload decision.
