#pragma once

#include <c10/core/Device.h>
#include <c10/macros/Export.h>
#include <c10/util/ArrayRef.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <utility>
#include <vector>

namespace c10::cuda::CUDACachingAllocator {
class PendingGraphInputs;
}

namespace at::cuda {
struct CUDAGraph;

namespace detail {

struct CaptureFrontier {
  int status = 0;
  uint64_t capture_id = 0;
  uintptr_t graph = 0;
  std::vector<std::pair<uintptr_t, std::array<uint8_t, 8>>> dependencies;
};

TORCH_CUDA_CPP_API CaptureFrontier get_capture_frontier(uintptr_t stream);

struct KernelArgumentSnapshot {
  size_t offset;
  size_t size;
  std::vector<uint8_t> value;
};

struct KernelNodeSnapshot {
  uintptr_t node;
  uintptr_t function;
  uintptr_t kernel;
  uintptr_t context;
  std::array<unsigned int, 3> grid;
  std::array<unsigned int, 3> block;
  unsigned int shared_memory;
  bool packed;
  std::vector<KernelArgumentSnapshot> arguments;
};

struct CapturedGraphSnapshot {
  uintptr_t graph;
  uint64_t capture_id;
  std::vector<uintptr_t> nodes;
  std::vector<KernelNodeSnapshot> kernels;
};

struct KernelArgumentUpdate {
  int64_t index;
  std::vector<uint8_t> value;
};

struct KernelNodeUpdate {
  uintptr_t node;
  std::vector<KernelArgumentUpdate> arguments;
};

// The caller declares pointer slots; width alone does not establish their type.
struct KernelPointerBinding {
  uintptr_t node;
  int64_t argument;
  size_t pointer_index;
  // An absent offset requires a whole argument of the binding's width.
  std::optional<size_t> byte_offset = std::nullopt;
};

struct KernelPointerSlot {
  size_t offset;
  size_t pointer_index;
};

struct KernelScalarBinding {
  uintptr_t node;
  int64_t argument;
  size_t width;
  size_t value_index;
  std::optional<size_t> byte_offset = std::nullopt;
};

struct KernelGridBinding {
  uintptr_t node;
  std::array<size_t, 3> values;
};

struct KernelScalarSlot {
  size_t offset;
  size_t width;
  size_t value_index;
};

// Owns argument bytes; it does not own the graph, kernel module or device data.
class TORCH_CUDA_CPP_API KernelNodeParams {
  friend struct at::cuda::CUDAGraph;

 public:
  explicit KernelNodeParams(uintptr_t node);
  ~KernelNodeParams();
  KernelNodeParams(const KernelNodeParams&) = delete;
  KernelNodeParams& operator=(const KernelNodeParams&) = delete;

  void validate(const std::vector<KernelArgumentUpdate>& updates) const;
  void update(uintptr_t graph_exec, const std::vector<KernelArgumentUpdate>& updates);
  KernelNodeSnapshot snapshot() const;

 private:
  size_t pointer_offset(int64_t argument, std::optional<size_t> byte_offset) const;
  size_t scalar_offset(int64_t argument, size_t width, std::optional<size_t> byte_offset) const;
  void update_pointers(
      uintptr_t graph_exec,
      c10::ArrayRef<KernelPointerSlot> slots,
      c10::ArrayRef<uintptr_t> pointers);
  void update_replay(
      uintptr_t graph_exec,
      c10::ArrayRef<KernelPointerSlot> pointer_slots,
      c10::ArrayRef<KernelScalarSlot> scalar_slots,
      const std::optional<std::array<size_t, 3>>& grid,
      c10::ArrayRef<uintptr_t> pointers,
      c10::ArrayRef<int64_t> values);
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

class KernelParamCache;

class TORCH_CUDA_CPP_API KernelParamUpdateBatch {
  friend struct at::cuda::CUDAGraph;

  std::shared_ptr<KernelParamCache> cache_;
  uint64_t generation_ = 0;
  bool needs_instantiation_ = false;
  std::vector<KernelNodeUpdate> updates_;
  std::vector<std::shared_ptr<KernelNodeParams>> nodes_;
};

class KernelPointerUpdateBatch {
  friend struct at::cuda::CUDAGraph;
  friend class GraphReplayLease;

 public:
  bool has_numeric_updates() const {
    return numeric_;
  }
  size_t value_count() const {
    return value_ranges_.size();
  }

 private:
  struct Node {
    std::shared_ptr<KernelNodeParams> params;
    std::vector<KernelPointerSlot> slots;
    std::vector<KernelScalarSlot> scalars;
    std::optional<std::array<size_t, 3>> grid;
  };
  void validate_values(c10::ArrayRef<int64_t> values) const;
  std::shared_ptr<KernelParamCache> cache_;
  uint64_t generation_ = 0;
  size_t pointer_count_ = 0;
  bool numeric_ = false;
  std::vector<std::pair<int64_t, int64_t>> value_ranges_;
  std::vector<Node> nodes_;
};

enum class InputReleaseKind { Allocate, Kernel, Drop };

struct InputReleaseStep {
  InputReleaseKind kind;
  size_t index;
};

struct InputReleasePlan {
  std::vector<InputReleaseStep> steps;
  std::vector<size_t> candidates;
  std::vector<std::vector<size_t>> eligible_inputs;
};

// Internal, serialized adoption of an unshared private capture. The enclosing
// owner drains its managed stream before close and retains this lease with all
// execution resources if completion or checked teardown fails.
class TORCH_CUDA_CPP_API GraphReplayLease {
 public:
  GraphReplayLease(
      std::shared_ptr<CUDAGraph> graph,
      std::shared_ptr<KernelPointerUpdateBatch> batch,
      c10::DeviceIndex device);
  ~GraphReplayLease();
  GraphReplayLease(const GraphReplayLease&) = delete;
  GraphReplayLease& operator=(const GraphReplayLease&) = delete;

  void replay(c10::ArrayRef<uintptr_t> pointers,
              c10::cuda::CUDACachingAllocator::PendingGraphInputs* pending = nullptr);
  InputReleasePlan prepare_input_release(
      std::vector<InputReleaseStep> steps, const std::vector<uintptr_t>& nodes,
      size_t input_count, size_t allocation_count) const;
  void validate_values(c10::ArrayRef<int64_t> values) const;
  // The boxed owner validates values before work and keeps them immutable under
  // its lock through this call. No other caller may supply unchecked results.
  void replay(c10::ArrayRef<uintptr_t> pointers, c10::ArrayRef<int64_t> values);
  // The serialized owner checks eligibility before entering non-retryable release.
  bool check_capture_pool_retirement() const;
  void retire_capture_pool();
  void close();

 private:
  std::shared_ptr<CUDAGraph> graph_;
  std::shared_ptr<KernelPointerUpdateBatch> batch_;
};

} // namespace detail
} // namespace at::cuda
