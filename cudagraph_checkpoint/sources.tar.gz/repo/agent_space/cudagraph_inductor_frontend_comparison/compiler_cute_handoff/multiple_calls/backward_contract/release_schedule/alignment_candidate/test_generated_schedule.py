import json
from unittest import mock

import activation_schedule
import generated_forward_backward_fixture as fixture
from torch._inductor import config
from torch._inductor.runtime.cudagraph_arg_mapping import AlignmentCopy, KernelCallRecord, OwnedBuffer
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class TestGeneratedReleaseSchedule(TestCase):
    @parametrize("split_kernels", (False, True))
    def test_compiler_release_schedule(self, device, split_kernels):
        collect = fixture.collect_saved_inputs
        checks = TestCase()
        schedules = []

        def observe(origin, wrapper, records, metadata):
            saved = collect(origin, wrapper, records, metadata)
            checks.assertIsNotNone(saved)
            schedule = activation_schedule.collect_release_schedule(saved, wrapper, records)
            checks.assertIsNotNone(schedule, "Expected the actual generated backward release order")
            checks.assertEqual(schedule.input_names, saved.input_names)
            calls = tuple(step for step in schedule.steps if type(step) is KernelCallRecord)
            allocations = tuple(step for step in schedule.steps if type(step) is OwnedBuffer)
            drops = tuple(step for step in schedule.steps if type(step) is activation_schedule.DropInput)
            checks.assertEqual(calls, records.calls)
            checks.assertEqual(allocations, records.allocations)
            copies = tuple(step for step in schedule.steps if type(step) is AlignmentCopy)
            checks.assertEqual(copies, records.alignment_copies)
            checks.assertEqual(tuple(step.input_index for step in drops), saved.candidate_indices)
            for step in drops:
                checks.assertEqual(step.after_call, schedule.input_uses[step.input_index][-1])
            schedules.append(schedule)
            return saved

        with config.patch(max_fusion_size=1 if split_kernels else 64), mock.patch.object(
            fixture, "collect_saved_inputs", side_effect=observe
        ):
            fixture.TestGeneratedForwardBackwardCUDA.test_final_box_provenance_cuda(self)

        self.assertEqual(len(schedules), 1)
        schedule = schedules[0]
        if split_kernels:
            self.assertGreater(sum(type(step) is KernelCallRecord for step in schedule.steps), 1)
        steps = []
        for step in schedule.steps:
            if type(step) is OwnedBuffer:
                steps.append(["allocate", step.source.name])
            elif type(step) is AlignmentCopy:
                steps.append(["normalize_input", step.input_index, step.before_call])
            elif type(step) is KernelCallRecord:
                steps.append(["call", step.occurrence])
            else:
                steps.append(["drop_reference", step.input_index, step.after_call])
        print("BACKWARD_RELEASE_SCHEDULE " + json.dumps({
            "input_names": schedule.input_names,
            "input_uses": schedule.input_uses,
            "steps": steps,
            "split_kernels": split_kernels,
            "native_release": False,
        }, sort_keys=True))


instantiate_device_type_tests(TestGeneratedReleaseSchedule, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
