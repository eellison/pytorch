import handoff_cpu_fixture
from torch.testing._internal.common_utils import run_tests


class TestInductorHandoff(handoff_cpu_fixture.TestInductorHandoff):
    pass


import forward_preservation_fixture


class TestForwardPreservation(forward_preservation_fixture.TestForwardPreservation):
    pass


if __name__ == "__main__":
    run_tests()
