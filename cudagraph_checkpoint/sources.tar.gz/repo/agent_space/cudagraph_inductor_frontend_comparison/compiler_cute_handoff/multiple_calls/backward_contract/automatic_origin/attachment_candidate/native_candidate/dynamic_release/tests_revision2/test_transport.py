from contextlib import contextmanager
import functools
import gc
from types import SimpleNamespace
from unittest import mock
import weakref

import torch
from compiler_saved_inputs import transport
from compiler_saved_inputs.classification import BackwardInput, ClassificationDeclined, SavedActivations
from compiler_saved_inputs.handoff import FinalSavedInputs
from compiler_saved_inputs.origins import ForwardOrigins, SavedTensorOrigin
from torch._dynamo import config as dynamo_config
from torch._dynamo.exc import BackendCompilerFailed
from torch._functorch import config as aot_config
from torch._inductor import compile_fx as compiler, config
from torch._inductor.runtime.cudagraph_arg_mapping import WrapperCallRecords
from torch._inductor.virtualized import V
from torch._subclasses.fake_tensor import FakeTensorMode
from torch.fx import Graph, GraphModule
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


class TestSavedInputTransport(TestCase):
    @contextmanager
    def scope(self):
        with config.patch(
            cudagraph_saved_input_schedule=True, force_disable_caches=True, save_args=False,
            graph_partition=False, cpp_wrapper=False, fx_wrapper=False, **{"trace.enabled": False},
        ), aot_config.patch(enable_autograd_cache=False, bundled_autograd_cache=False), dynamo_config.patch(
            repro_after=None, caching_precompile=False,
        ), mock.patch.object(compiler, "fx_compile_mode", compiler.FxCompileMode.NORMAL), mock.patch.object(
            compiler, "fx_compile_async", False,
        ), mock.patch.object(compiler, "fx_compile_progressive", False), V.set_aot_compilation(False):
            yield

    def graph(self):
        graph = Graph()
        activation = graph.placeholder("activation")
        graph.placeholder("tangent")
        graph.output((activation,))
        return GraphModule(torch.nn.Module(), graph)

    def classification(self, candidate=True):
        return SavedActivations((
            BackwardInput(0, "activation", "activation" if candidate else "input_alias", 1, 0),
            BackwardInput(1, "tangent", "tangent"),
        ))

    @parametrize("shape", ("raw", "region_none", "region_name", "args", "kwargs", "wrapped"))
    def test_exact_standard_inner_shapes(self, shape):
        original = compiler.compile_fx_inner
        variants = {
            "raw": original,
            "region_none": functools.partial(original, compile_region_name=None),
            "region_name": functools.partial(original, compile_region_name="named"),
            "args": functools.partial(original, object(), compile_region_name=None),
            "kwargs": functools.partial(original, compile_region_name=None, is_backward=True),
            "wrapped": functools.wraps(original)(lambda *args, **kwargs: None),
        }
        with self.scope():
            self.assertEqual(transport.eligible(variants[shape]), shape in ("raw", "region_none"))

    @parametrize("case", (
        "disabled", "cache", "autograd", "bundle", "precompile", "save", "repro", "debug",
        "partition", "cpp", "fx", "aot", "serialize", "subprocess", "async", "progressive",
    ))
    def test_ineligible_scope_omits_capture(self, case):
        settings = {
            "disabled": (config, {"cudagraph_saved_input_schedule": False}),
            "cache": (config, {"force_disable_caches": False}),
            "autograd": (aot_config, {"enable_autograd_cache": True}),
            "bundle": (aot_config, {"bundled_autograd_cache": True}),
            "precompile": (dynamo_config, {"caching_precompile": True}),
            "save": (config, {"save_args": True}),
            "repro": (dynamo_config, {"repro_after": "aot"}),
            "debug": (config, {"trace.enabled": True}),
            "partition": (config, {"graph_partition": True}),
            "cpp": (config, {"cpp_wrapper": True}),
            "fx": (config, {"fx_wrapper": True}),
        }
        with self.scope(), mock.patch.object(transport, "capture_forward_origins") as capture:
            self.assertTrue(transport.eligible(compiler.compile_fx_inner))
            if case in settings:
                module, values = settings[case]
                changed = module.patch(values)
            elif case == "aot":
                changed = V.set_aot_compilation(True)
            elif case in ("serialize", "subprocess"):
                changed = mock.patch.object(compiler, "fx_compile_mode", compiler.FxCompileMode[case.upper()])
            else:
                changed = mock.patch.object(compiler, "fx_compile_" + case, True)
            with changed:
                self.assertFalse(transport.eligible(compiler.compile_fx_inner))
                state = transport.SavedInputCapture(compiler.compile_fx_inner)
                state.forward(self.graph(), is_inference=False)
                self.assertIsNone(state.origins)
            capture.assert_not_called()

    def test_inference_does_not_capture(self):
        with self.scope(), mock.patch.object(transport, "capture_forward_origins") as capture:
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.forward(self.graph(), is_inference=True)
            self.assertIsNone(state.origins)
            capture.assert_not_called()

    @parametrize("failure", (False, True))
    def test_exact_binding_and_cleanup_around_one_compile(self, failure):
        graph = self.graph()
        marker = object()
        graph.meta["unrelated"] = marker
        classification = self.classification()
        error = RuntimeError("backward compiler failed")
        calls = []
        with self.scope(), mock.patch.object(transport, "join_backward_origins", return_value=classification):
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.origins = ForwardOrigins(())
            try:
                with state.backward(graph):
                    origin = graph.meta[transport.ORIGIN_KEY]
                    self.assertIsNone(state.origins)
                    self.assertIs(origin.module, graph)
                    self.assertIs(origin.graph, graph.graph)
                    self.assertEqual(origin.targets, ("activation", "tangent"))
                    self.assertEqual(origin.names, origin.targets)
                    self.assertEqual(origin.placeholders, tuple(node for node in graph.graph.nodes if node.op == "placeholder"))
                    self.assertIs(origin.classification, classification)
                    calls.append("compiled")
                    if failure:
                        raise error
            except RuntimeError as caught:
                self.assertTrue(failure)
                self.assertIs(caught, error)
            self.assertEqual(calls, ["compiled"])
            self.assertNotIn(transport.ORIGIN_KEY, graph.meta)
            self.assertIs(graph.meta["unrelated"], marker)
            self.assertIsNone(state.origins)

    def test_lazy_scope_change_releases_forward_facts_before_compile(self):
        with self.scope(), mock.patch.object(transport, "join_backward_origins") as join:
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.origins = ForwardOrigins(())
            reference = weakref.ref(state.origins)
            graph = self.graph()
            with config.patch(save_args=True), state.backward(graph):
                self.assertIsNone(reference())
                self.assertIsNone(state.origins)
                self.assertNotIn(transport.ORIGIN_KEY, graph.meta)
            join.assert_not_called()

    @parametrize("stage", ("forward", "backward"))
    def test_typed_decline_omits_optional_origin(self, stage):
        graph = self.graph()
        with self.scope(), mock.patch.object(
            transport, "capture_forward_origins", side_effect=ClassificationDeclined("unsupported forward")
            if stage == "forward" else None, return_value=ForwardOrigins(()),
        ), mock.patch.object(transport, "join_backward_origins", side_effect=ClassificationDeclined("unsupported backward")):
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.forward(graph, is_inference=False)
            with state.backward(graph):
                self.assertNotIn(transport.ORIGIN_KEY, graph.meta)
                self.assertIsNone(state.origins)

    @parametrize("stage", ("forward", "backward"))
    def test_unexpected_classification_error_propagates(self, stage):
        graph = self.graph()
        error = ValueError("unexpected classifier failure")
        with self.scope():
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.origins = ForwardOrigins(())
            hook = "capture_forward_origins" if stage == "forward" else "join_backward_origins"
            with mock.patch.object(transport, hook, side_effect=error):
                with self.assertRaisesRegex(ValueError, "unexpected classifier failure") as caught:
                    if stage == "forward":
                        state.forward(graph, is_inference=False)
                    else:
                        with state.backward(graph):
                            self.fail("Unexpected entry after join failure")
            self.assertIs(caught.exception, error)
            self.assertIsNone(state.origins)
            self.assertNotIn(transport.ORIGIN_KEY, graph.meta)

    def test_reserved_entry_is_not_overwritten(self):
        graph = self.graph()
        marker = graph.meta[transport.ORIGIN_KEY] = object()
        with self.scope(), mock.patch.object(transport, "join_backward_origins", return_value=self.classification()):
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.origins = ForwardOrigins(())
            with self.assertRaisesRegex(RuntimeError, "already present"):
                with state.backward(graph):
                    self.fail("Unexpected overwrite")
            self.assertIs(graph.meta[transport.ORIGIN_KEY], marker)
            self.assertIsNone(state.origins)

    def test_zero_candidates_do_not_install_an_origin(self):
        graph = self.graph()
        with self.scope(), mock.patch.object(transport, "join_backward_origins", return_value=self.classification(False)) as join:
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.origins = ForwardOrigins(())
            reference = weakref.ref(state.origins)
            with state.backward(graph):
                join.reset_mock()
                self.assertIsNone(reference())
                self.assertNotIn(transport.ORIGIN_KEY, graph.meta)

    def test_forward_compiler_failure_clears_successful_capture(self):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        states = []
        error = RuntimeError("forward compiler stopped before codegen")

        class TrackedCapture(transport.SavedInputCapture):
            def __init__(self, inner_compile):
                super().__init__(inner_compile)
                states.append(self)

        def fail_forward(*args, **kwargs):
            self.assertEqual(len(states), 1)
            self.assertIs(type(states[0].origins), ForwardOrigins)
            raise error

        with self.scope(), mock.patch.object(transport, "SavedInputCapture", TrackedCapture), mock.patch.object(
            compiler, "compile_fx_forward", side_effect=fail_forward,
        ) as forward, mock.patch.object(
            compiler, "fx_codegen_and_compile", side_effect=AssertionError("Unexpected code generation"),
        ) as codegen:
            compiled = torch.compile(lambda value: value.sin() * 2, fullgraph=True)
            with self.assertRaisesRegex(BackendCompilerFailed, "forward compiler stopped before codegen") as caught:
                compiled(torch.ones(4, requires_grad=True))
            self.assertIs(caught.exception.inner_exception, error)
            self.assertEqual(forward.call_count, 1)
            codegen.assert_not_called()
            self.assertEqual(len(states), 1)
            self.assertIsNone(states[0].origins)

    @parametrize("absence", ("origin", "metadata", "unsupported_version", "handoff", "candidates"))
    def test_missing_optional_facts_never_call_schedule(self, absence):
        graph = self.graph()
        records = WrapperCallRecords(5 if absence == "unsupported_version" else 3, 0, ("activation", "tangent"), (), ())
        saved = FinalSavedInputs(records.input_names, self.classification(absence != "candidates"))
        with self.scope(), mock.patch.object(transport, "join_backward_origins", return_value=self.classification()):
            state = transport.SavedInputCapture(compiler.compile_fx_inner)
            state.origins = ForwardOrigins(())
            with state.backward(graph), V.set_graph_handler(SimpleNamespace(module=graph)), mock.patch.object(
                transport, "collect_saved_inputs", return_value=None if absence == "handoff" else saved,
            ), mock.patch.object(transport, "collect_release_schedule") as schedule:
                if absence == "origin":
                    graph.meta.pop(transport.ORIGIN_KEY)
                metadata = None if absence == "metadata" else object()
                self.assertIsNone(transport.collect_optional_schedule(object(), records, metadata))
                schedule.assert_not_called()

    def test_completed_join_releases_fake_and_graph_owners(self):
        graph = self.graph()
        graph_ref = weakref.ref(graph)
        with FakeTensorMode():
            value = torch.empty(4)
        value_ref = weakref.ref(value)
        state = transport.SavedInputCapture(compiler.compile_fx_inner)
        state.origins = ForwardOrigins((SavedTensorOrigin(
            1, 0, "activation", value, StorageWeakRef(value.untyped_storage()), "activation",
        ),))
        origins_ref = weakref.ref(state.origins)
        del value
        with self.scope(), mock.patch.object(transport, "join_backward_origins", return_value=self.classification()) as join:
            with state.backward(graph):
                # Mock argument recording is not part of the transport lifetime.
                join.reset_mock()
                self.assertIsNone(origins_ref())
                self.assertIsNone(value_ref())
            self.assertNotIn(transport.ORIGIN_KEY, graph.meta)
        del graph
        gc.collect()
        self.assertIsNone(graph_ref())


instantiate_parametrized_tests(TestSavedInputTransport)


if __name__ == "__main__":
    run_tests()
