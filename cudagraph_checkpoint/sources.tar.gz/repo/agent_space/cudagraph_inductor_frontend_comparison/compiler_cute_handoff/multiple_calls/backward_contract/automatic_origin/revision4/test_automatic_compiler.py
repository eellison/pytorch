from dataclasses import asdict
import functools
import json
from unittest import mock

import activation_schedule
from compiler_metadata_handoff import metadata as generated_metadata
from generated_forward_backward_fixture import SavedSine
from handoff import AOTInputOrigins, collect_saved_inputs
from origins import capture_forward_origins, join_backward_origins
import torch
from torch._functorch import config as aot_config
from torch._inductor import compile_fx as compiler, config
from torch._inductor.runtime.cudagraph_arg_mapping import AlignmentCopy, KernelCallRecord, OwnedBuffer
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
from torch.utils.checkpoint import checkpoint, create_selective_checkpoint_contexts


SIGMOID_CONTEXT = functools.partial(create_selective_checkpoint_contexts, [torch.ops.aten.sigmoid.default])


def sigmoid_weighted(value, weight):
    return value.sigmoid() * weight


class SavedActivation(SavedSine):
    def __init__(self, device, activation):
        super().__init__(device)
        self.activation = activation

    def forward(self, value):
        if self.activation == "sine":
            return value.sin() * self.weight
        return checkpoint(sigmoid_weighted, value, self.weight, use_reentrant=False, context_fn=SIGMOID_CONTEXT)


class TestAutomaticCompilerOrigins(TestCase):
    @parametrize("activation", ("sine", "sigmoid"))
    def test_real_compile_callbacks_reach_release_schedule(self, device, activation):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        forward_compiler = compiler.compile_fx_forward
        backward_compiler = compiler.compile_fx_backward
        collect = generated_metadata.collect_metadata
        forward_origins = None
        compilations = [0, 0]
        observations = []
        checks = TestCase()

        def forward(graph, examples, **kwargs):
            nonlocal forward_origins
            checks.assertFalse(kwargs["is_inference"])
            forward_origins = capture_forward_origins(graph)
            compilations[0] += 1
            return forward_compiler(graph, examples, **kwargs)

        def backward(graph, examples, **kwargs):
            classification = join_backward_origins(forward_origins, graph)
            placeholders = tuple(node for node in graph.graph.nodes if node.op == "placeholder")
            origin = AOTInputOrigins(
                graph, graph.graph, placeholders, tuple(node.name for node in placeholders),
                tuple(node.target for node in placeholders), classification,
            )
            compilations[1] += 1

            def final(wrapper, records):
                metadata = collect(wrapper, records)
                saved = collect_saved_inputs(origin, wrapper, records, metadata)
                checks.assertIsNotNone(saved)
                checks.assertEqual(saved.classification, classification)
                schedule = activation_schedule.collect_release_schedule(saved, wrapper, records)
                if activation == "sine":
                    checks.assertEqual(saved.candidate_indices, ())
                    checks.assertIsNone(schedule)
                    drops = ()
                else:
                    checks.assertEqual(len(saved.candidate_indices), 1)
                    checks.assertIsNotNone(schedule)
                    checks.assertEqual(schedule.input_names, records.input_names)
                    checks.assertEqual(tuple(step for step in schedule.steps if type(step) is KernelCallRecord), records.calls)
                    checks.assertEqual(tuple(step for step in schedule.steps if type(step) is OwnedBuffer), records.allocations)
                    checks.assertEqual(tuple(step for step in schedule.steps if type(step) is AlignmentCopy), records.alignment_copies)
                    drops = tuple(step for step in schedule.steps if type(step) is activation_schedule.DropInput)
                    checks.assertEqual(tuple(step.input_index for step in drops), saved.candidate_indices)
                    for drop in drops:
                        checks.assertEqual(drop.after_call, schedule.input_uses[drop.input_index][-1])
                observations.append({
                    "classification": asdict(classification),
                    "candidate_indices": saved.candidate_indices,
                    "records_version": records.version,
                    "backward_calls": len(records.calls),
                    "allocations": len(records.allocations),
                    "outputs": len(records.outputs),
                    "alignment_copies": [asdict(copy) for copy in records.alignment_copies],
                    "schedule_present": schedule is not None,
                    "drops": [asdict(drop) for drop in drops],
                })
                return metadata

            with mock.patch.object(generated_metadata, "collect_metadata", new=final):
                return backward_compiler(graph, examples, **kwargs)

        model = SavedActivation(device, activation)
        value = torch.linspace(-0.8, 0.9, 4096, device=device).reshape(32, 128).requires_grad_()
        expected_value = value.detach().clone().requires_grad_()
        expected_weight = model.weight.detach().clone().requires_grad_()
        with aot_config.patch(enable_autograd_cache=False, donated_buffer=False), config.patch(
            graph_partition=False, cpp_wrapper=False, fx_graph_cache=False, force_disable_caches=True,
            allow_buffer_reuse=False, inplace_buffers=False, max_fusion_size=1,
            cudagraph_policy=None, use_static_triton_launcher=True, **{"triton.cudagraphs": False},
        ), mock.patch.object(compiler, "compile_fx_forward", new=forward), mock.patch.object(
            compiler, "compile_fx_backward", new=backward
        ):
            compiled = torch.compile(model, fullgraph=True, dynamic=False)
            actual = compiled(value)
            hidden = expected_value.sin() if activation == "sine" else expected_value.sigmoid()
            expected = hidden * expected_weight
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            actual_gradients = torch.autograd.grad(actual, (value, model.weight), tangent)
            expected_gradients = torch.autograd.grad(expected, (expected_value, expected_weight), tangent)
            self.assertEqual(actual_gradients, expected_gradients)

        self.assertEqual(compilations, [1, 1])
        self.assertEqual(len(observations), 1)
        self.assertGreater(observations[0]["backward_calls"], 1)
        print("AUTOMATIC_COMPILER_ORIGINS " + json.dumps({
            "activation": activation, "compilations": compilations, **observations[0],
            "checkpoint_policy": "sigmoid_must_save" if activation == "sigmoid" else None,
            "native_release": False, "emitted_annotation": False,
        }, sort_keys=True))


instantiate_device_type_tests(TestAutomaticCompilerOrigins, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
