from dataclasses import asdict
import functools
import json
import sys
import threading
import weakref
from unittest import mock

import fx_adapter.extraction as fx_extraction
import fx_adapter.lowering as fx_lowering
import retained_ir.prototype as retained_reader
import compiler_policy_handoff.policy as policy_module
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from compiler_saved_inputs.schedule import DropInput
from selected_kernel import SelectedKernel
import torch
from torch._functorch import config as aot_config
from torch._inductor import config
from torch._inductor.output_code import CompiledFxGraph
from torch._inductor.runtime import cudagraph_boxed_replay as replay
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import KernelCallRecord, OwnedBuffer
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
from torch.utils.checkpoint import checkpoint, create_selective_checkpoint_contexts


SIGMOID_CONTEXT = functools.partial(create_selective_checkpoint_contexts, [torch.ops.aten.sigmoid.default])


def sigmoid_weighted(value, weight):
    return value.sigmoid() * weight


class SavedFanout(torch.nn.Module):
    def __init__(self, device):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.linspace(0.5, 1.0, 4096, device=device).reshape(32, 128))

    def forward(self, value, residual):
        shared = value.sin() + residual.cos()
        return checkpoint(sigmoid_weighted, shared, self.weight, use_reentrant=False, context_fn=SIGMOID_CONTEXT)


class NativeObservation:
    def __init__(self, installation):
        self.artifact = installation.artifact
        self.original_code = installation.original.__code__
        self.pending = {}
        self.calls = []
        self.frames = {}
        self.errors = []
        self.forbidden_files = {policy_module.__file__, preparation.__file__, replay.__file__,
                                fx_extraction.__file__, fx_lowering.__file__, retained_reader.__file__}

    def profile(self, frame, event, result):
        try:
            code = frame.f_code
            if event == "call" and (code is self.original_code or code.co_filename in self.forbidden_files):
                name = (code.co_filename, code.co_name)
                self.frames[name] = self.frames.get(name, 0) + 1
            if code is not CompiledFxGraph.__call__.__code__ or frame.f_locals.get("self") is not self.artifact:
                return
            thread = threading.get_ident()
            if event == "call":
                if thread in self.pending:
                    raise AssertionError("Nested backward artifact invocation")
                # Never retain the box, a Tensor, the frame, or its locals dictionary.
                self.pending[thread] = tuple(
                    (index, value.data_ptr(), StorageWeakRef(value.untyped_storage()))
                    for index, value in enumerate(frame.f_locals["inputs"])
                    if isinstance(value, torch.Tensor)
                )
            elif event == "return":
                inputs = self.pending.pop(thread)
                if result is None:
                    return
                if type(result) not in (tuple, list) or any(type(value) is not torch.Tensor for value in result):
                    raise AssertionError("Expected complete generated backward Tensor outputs")
                self.calls.append({
                    "inputs": [(index, pointer, weak.expired()) for index, pointer, weak in inputs],
                    "output_pointers": [value.data_ptr() for value in result],
                })
        except BaseException as error:
            self.errors.append(f"{type(error).__name__}: {error}")

    def __enter__(self):
        if sys.getprofile() is not None or threading.getprofile() is not None:
            raise AssertionError("Native observation requires an unprofiled test process")
        threading.setprofile_all_threads(self.profile)
        return self

    def __exit__(self, kind, error, traceback):
        threading.setprofile_all_threads(None)
        if error is not None and self.errors:
            error.add_note("Native observation errors: " + "; ".join(self.errors))


class TestNativeFrontendSavedRelease(TestCase):
    @parametrize("frontend", ("fx", "retained"))
    @parametrize("mode", ("release", "disabled", "retain_graph"))
    def test_generated_backward_release(self, device, frontend, mode):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        policy = NativeCUDAGraphPolicy(frontend=frontend)
        self.addCleanup(policy.close)
        self.enterContext(torch._dynamo.config.patch(caching_precompile=False, repro_after=None))
        self.enterContext(aot_config.patch(enable_autograd_cache=False, bundled_autograd_cache=False, donated_buffer=False))
        self.enterContext(config.patch(
            cudagraph_saved_input_schedule=mode != "disabled", cudagraph_policy=policy,
            graph_partition=False, cpp_wrapper=False, fx_graph_cache=False, force_disable_caches=True,
            allow_buffer_reuse=False, inplace_buffers=False, max_fusion_size=1, realize_reads_threshold=0,
            normalize_static_input_alignment=True, use_static_triton_launcher=True,
            use_fast_triton_launcher=True, **{"triton.cudagraphs": False},
        ))
        model = SavedFanout(device)
        compiled = torch.compile(model, fullgraph=True, dynamic=False)
        bridge_calls, reader_records, bound_records = [], {}, {}
        make_replay = replay._make_replay
        fx_lower, ir_bind, native_bind = fx_lowering.lower_fx, retained_reader.bind_selected, preparation.make_boxed_replay

        def observe_fx(*args, **kwargs):
            program = fx_lower(*args, **kwargs)
            reader_records[id(program.records)] = ("fx", weakref.ref(program.records))
            return program

        def observe_ir(*args, **kwargs):
            bound = ir_bind(*args, **kwargs)
            reader_records[id(bound.program.records)] = ("retained", weakref.ref(bound.program.records))
            return bound

        def observe_binding(graph, records, *args, **kwargs):
            reader, reference = reader_records[id(records)]
            if reference() is not records or reader != frontend or records.version != 3:
                raise AssertionError("Native binder did not receive the selected reader's actual V3 records")
            schedule = kwargs.get("release_schedule")
            if schedule is not None and (schedule.input_names != records.input_names
                                         or schedule.outputs != records.outputs):
                raise AssertionError("Projected schedule differs from the reader records")
            entry = native_bind(graph, records, *args, **kwargs)
            bound_records[id(entry)] = (id(records), records.version, reader)
            return entry

        self.enterContext(mock.patch.object(fx_lowering, "lower_fx", new=observe_fx))
        self.enterContext(mock.patch.object(retained_reader, "bind_selected", new=observe_ir))
        self.enterContext(mock.patch.object(preparation, "make_boxed_replay", new=observe_binding))

        def observe_bridge(*args, **kwargs):
            entry = make_replay(*args, **kwargs)
            bridge_calls.append((id(entry), kwargs.get("release_steps")))
            return entry

        self.enterContext(mock.patch.object(replay, "_make_replay", new=observe_bridge))
        held, expected_held = [], []

        def invoke(iteration, observer=None):
            value = torch.linspace(-0.8, 0.9, 4096, device=device).reshape(32, 128).add(iteration / 32).requires_grad_()
            residual = torch.linspace(-0.6, 0.7, 4096, device=device).reshape(32, 128).sub(iteration / 64).requires_grad_()
            expected_value = value.detach().clone().requires_grad_()
            expected_residual = residual.detach().clone().requires_grad_()
            expected_weight = model.weight.detach().clone().requires_grad_()
            expected = (expected_value.sin() + expected_residual.cos()).sigmoid() * expected_weight
            actual = compiled(value, residual)
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            expected_gradients = torch.autograd.grad(expected, (expected_value, expected_residual, expected_weight), tangent)
            retains = (True, False) if observer is not None and mode == "retain_graph" else (False,)
            for retain in retains:
                if observer is None:
                    gradients = torch.autograd.grad(actual, (value, residual, model.weight), tangent, retain_graph=retain)
                else:
                    before = len(observer.calls)
                    with observer:
                        gradients = torch.autograd.grad(actual, (value, residual, model.weight), tangent, retain_graph=retain)
                    self.assertEqual(observer.errors, [])
                    self.assertEqual(observer.pending, {})
                    self.assertEqual(len(observer.calls), before + 1)
                    observer.calls[-1]["retain_graph"] = retain
                self.assertEqual(gradients, expected_gradients)
                held.append((actual, gradients))
                expected_held.append((expected.detach(), tuple(value.detach() for value in expected_gradients)))

        invoke(0)
        backwards = tuple(installation for installation in policy.installations
                          if installation.artifact.fx_kwargs["is_backward"])
        self.assertEqual(len(backwards), 1, "Actual backward metadata did not reach the native policy")
        backward, = backwards
        self.assertEqual(backward.status, "ready", backward.decline)
        self.assertIsNone(backward.decline)
        entry = backward.entry
        self.assertIs(type(entry), torch._C._CUDAGraphBoxedReplay)
        self.assertFalse(entry.closed)
        self.assertFalse(entry.failed)
        self.assertIs(backward.artifact.current_callable, entry)
        records = backward.original._cudagraph_call_records
        self.assertEqual(records.version, 3)
        projected_identity, projected_version, checked_frontend = bound_records[id(entry)]
        self.assertNotEqual(projected_identity, id(records))
        self.assertEqual(projected_version, 3)
        self.assertEqual(checked_frontend, frontend)
        self.assertGreater(len(records.calls), 1)
        self.assertEqual(len(records.outputs), 3)
        schedule = backward.metadata.release_schedule
        early_pairs, drops = [], ()
        if mode == "disabled":
            self.assertIsNone(schedule)
        else:
            self.assertIsNotNone(schedule)
            self.assertEqual(schedule.input_names, records.input_names)
            self.assertEqual(schedule.outputs, records.outputs)
            self.assertEqual(tuple(step for step in schedule.steps if type(step) is OwnedBuffer), records.allocations)
            self.assertEqual(tuple(step for step in schedule.steps if type(step) is KernelCallRecord), records.calls)
            drops = tuple(step for step in schedule.steps if type(step) is DropInput)
            self.assertTrue(drops)
            for position, drop in enumerate(schedule.steps):
                if type(drop) is not DropInput:
                    continue
                self.assertEqual(drop.after_call, schedule.input_uses[drop.input_index][-1])
                for later in schedule.steps[position + 1:]:
                    if type(later) is OwnedBuffer and later in records.outputs:
                        early_pairs.append((drop.input_index, records.outputs.index(later)))
            self.assertTrue(early_pairs, "Actual saved-input drop must precede an output allocation")
        matching_bridge, = (row for row in bridge_calls if row[0] == id(entry))
        if schedule is None:
            self.assertIsNone(matching_bridge[1])
        else:
            self.assertIsNotNone(matching_bridge[1])
            self.assertEqual(tuple(index for kind, index in matching_bridge[1] if kind == "drop"),
                             tuple(drop.input_index for drop in drops))
        launchers = []
        for record in records.calls:
            selected = SelectedKernel.from_warmed(backward.original.__globals__[record.kernel_global])
            runner = selected.identity[2].__globals__["runner"]
            self.assertIs(type(runner), torch._C._FastCudaLauncher)
            launchers.append(type(runner).__name__)
        observer = NativeObservation(backward)
        installation_count, bridge_count = len(policy.installations), len(bridge_calls)
        for iteration in (1, 2, 3):
            invoke(iteration, observer)
            self.assertEqual(len(policy.installations), installation_count)
            self.assertEqual(len(bridge_calls), bridge_count)
            self.assertIs(backward.artifact.current_callable, entry)
            self.assertIs(backward.metadata.release_schedule, schedule)
            self.assertEqual(backward.status, "ready")
            self.assertFalse(entry.failed)
        self.assertEqual(observer.frames, {})
        reuse = []
        for call_index, call in enumerate(observer.calls):
            self.assertEqual(len(call["output_pointers"]), len(records.outputs))
            inputs = {index: (pointer, expired) for index, pointer, expired in call["inputs"]}
            self.assertEqual(tuple(inputs), tuple(range(len(records.input_names))))
            for drop in drops:
                self.assertEqual(inputs[drop.input_index][1], not call["retain_graph"])
            for input_index, output_index in early_pairs:
                pointer, expired = inputs[input_index]
                if pointer == call["output_pointers"][output_index]:
                    self.assertTrue(expired)
                    self.assertFalse(call["retain_graph"])
                    reuse.append((call_index, input_index, output_index))
        torch.cuda.synchronize()
        self.assertEqual(held, expected_held)
        forward_states = [installation.status for installation in policy.installations
                          if not installation.artifact.fx_kwargs["is_backward"]]
        policy.close()
        self.assertTrue(entry.closed)
        self.assertEqual(held, expected_held)
        print("NATIVE_FRONTEND_SAVED_RELEASE " + json.dumps({
            "frontend": frontend, "reader_version": projected_version, "reader_supplied_native_records": True,
            "mode": mode, "backward_calls": len(records.calls), "input_names": records.input_names,
            "allocation_names": [allocation.source.name for allocation in records.allocations],
            "output_names": [output.source.name for output in records.outputs],
            "alignment_copies": [asdict(copy) for copy in records.alignment_copies],
            "drops": [asdict(drop) for drop in drops], "early_output_pairs": early_pairs,
            "native_backward_hits": len(observer.calls), "native_entry": type(entry).__name__,
            "release_steps": matching_bridge[1], "launchers": launchers,
            "observations": observer.calls, "observed_reuse": reuse, "watched_host_frames": [],
            "reuse_observed": bool(reuse),
            "installations": installation_count, "bridge_constructions": bridge_count,
            "forward_installation_states": forward_states,
            "closed": entry.closed, "held_outputs_correct_after_close": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestNativeFrontendSavedRelease, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
