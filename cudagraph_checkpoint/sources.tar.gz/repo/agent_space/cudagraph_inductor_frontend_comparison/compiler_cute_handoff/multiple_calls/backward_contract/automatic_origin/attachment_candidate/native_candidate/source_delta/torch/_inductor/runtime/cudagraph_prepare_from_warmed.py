from dataclasses import dataclass, field, replace
from inspect import CO_ASYNC_GENERATOR, CO_COROUTINE, CO_GENERATOR, CO_VARARGS, CO_VARKEYWORDS
import struct
from types import FunctionType, MethodType
from typing import Any, TYPE_CHECKING

import torch
from torch.cuda._utils import _check_cuda_bindings
from torch.utils._debug_mode import get_active_debug_mode

from .cudagraph_arg_mapping import (
    bind_alignment_copies, bind_fixed_grid, bind_grid_recipe, bind_launcher_arguments, bind_wrapper_allocations, bind_wrapper_arguments, BufferSource,
    CallArgument, ExpressionSource, InputSource, IntegerSource, IntExpr, KernelCallRecord,
    FIXED_GRID_ARGUMENTS, pointwise_expression_inputs, WrapperCallRecords,
)
from .cudagraph_boxed_replay import _NumericProgram, make_boxed_replay
from .cudagraph_launch_association import RecordedKernelLaunch, UnsupportedCapture
from .static_triton_launcher import StaticallyLaunchedCudaKernel
from .triton_compat import autograd_profiler
from .triton_heuristics import CachingAutotuner
from .triton_parameter_analysis import (
    ANALYSIS_VERSION, KernelAnalysis, PointerFormal, SelectedUserKernelFacts, user_kernel_controls_supported,
)


if TYPE_CHECKING:
    from ..output_code import CompiledFxGraph


@dataclass(frozen=True)
class _SelectedCall:
    record: KernelCallRecord
    kernel: CachingAutotuner
    selected: FunctionType
    cached: FunctionType
    module: StaticallyLaunchedCudaKernel
    function: int
    arguments: tuple[CallArgument, ...]
    scratch: tuple[bytes, ...]
    grid_recipe: tuple[IntExpr, IntExpr, IntExpr] | None = None
    user_facts: SelectedUserKernelFacts | None = None

    def check(self) -> None:
        if (
            len(self.kernel.launchers) != 1 or self.kernel.launchers[0] is not self.selected
            or self.kernel._cached_launcher is not self.cached
            or self.module.function != self.function
            or autograd_profiler._is_profiler_enabled or get_active_debug_mode()
            or (self.user_facts is None and self.grid_recipe is not None and (
                getattr(self.selected, "_cudagraph_grid_recipe", None) is not self.grid_recipe
                or getattr(self.cached, "_cudagraph_grid_recipe", None) is not self.grid_recipe
            ))
        ):
            raise UnsupportedCapture("Selected launcher changed during preparation")
        if self.user_facts is not None and (
            self.module.cudagraph_user_facts is not self.user_facts
            or type(self.module._cudagraph_user_loaded) is not tuple
            or len(self.module._cudagraph_user_loaded) != 3
            or self.module._cudagraph_user_loaded[0] is not self.user_facts
            or self.module._cudagraph_user_loaded[1:] != (self.module.module, self.function)
            or self.module.cudagraph_formal_args is not self.user_facts.arguments
            or self.module.hash != self.user_facts.analysis.compiled_hash
            or self.kernel.fn.src != self.user_facts.source
            or bind_launcher_arguments(
                self.user_facts.arguments, self.module.arg_names,
                [*(arg.formal for arg in self.record.arguments), *FIXED_GRID_ARGUMENTS],
                [arg.formal for arg in self.user_facts.arguments if arg.abi_index is not None],
                grid_args=FIXED_GRID_ARGUMENTS,
            ) != getattr(self.selected, "_cudagraph_arg_info", None)
            or getattr(self.selected, "_cudagraph_grid_args", None) != FIXED_GRID_ARGUMENTS
            or getattr(self.cached, "_cudagraph_grid_args", None) != FIXED_GRID_ARGUMENTS
            or self.grid_recipe is not None and bind_fixed_grid(self.record) != self.grid_recipe
            or bind_wrapper_arguments(self.record, getattr(self.selected, "_cudagraph_arg_info", None)) != self.arguments
            or not user_kernel_controls_supported()
        ):
            raise UnsupportedCapture("Selected user-kernel facts changed during preparation")


def _selected_calls(wrapper: FunctionType, records: WrapperCallRecords) -> tuple[_SelectedCall, ...]:
    calls = []
    buffers = set()
    initialized = set()
    copies = bind_alignment_copies(records)
    for index, record in enumerate(records.calls):
        if (
            type(record) is not KernelCallRecord or type(record.occurrence) is not int
            or record.occurrence != index or type(record.kernel_global) is not str
            or type(record.formals) is not tuple or type(record.arguments) is not tuple
            or any(type(formal) is not str for formal in record.formals)
            or record.grid_type not in ("Grid1D", "Grid2D", "Grid3D", "FixedGrid")
        ):
            raise UnsupportedCapture("Unsupported compiler call record")
        kernel = wrapper.__globals__.get(record.kernel_global)
        if (
            type(kernel) is not CachingAutotuner
            or type(kernel.launchers) not in (list, tuple) or len(kernel.launchers) != 1
            or not kernel._cache_eligible or kernel._plugins
            or type(kernel.run) is not MethodType or kernel.run.__func__ is not CachingAutotuner.run
        ):
            raise UnsupportedCapture("Preparation requires an already warmed generated kernel")
        selected, cached = kernel.launchers[0], kernel._cached_launcher
        if type(selected) is not FunctionType or type(cached) is not FunctionType:
            raise UnsupportedCapture("Preparation requires an already cached launcher")
        runner = selected.__globals__.get("runner")
        module = runner.__self__ if type(runner) is MethodType else None
        mapping = getattr(selected, "_cudagraph_arg_info", None)
        if (
            type(module) is not StaticallyLaunchedCudaKernel or module.device_agnostic
            or module.module is None or type(module.function) is not int or module.function <= 0
            or getattr(selected, "_is_static", None) is not True
            or getattr(cached, "_cudagraph_arg_info", None) is not mapping
            or getattr(cached, "config", None) is not getattr(selected, "config", None)
            or getattr(getattr(selected, "config", None), "pre_hook", None) is not None
            or getattr(getattr(selected, "config", None), "ir_override", None) is not None
            or getattr(selected, "_expected_positional_count", None)
            != len(record.arguments) + (3 if record.grid_type == "FixedGrid" else 0)
            or kernel.inductor_meta.get("grid_type") != record.grid_type
            or (cached is not selected and (
                cached.__code__ is not selected.__code__
                or type(cached.__globals__.get("runner")) is not torch._C._FastCudaLauncher
                or getattr(cached, "_static_kernel_owner", None) is not module
            ))
        ):
            raise UnsupportedCapture("Unsupported selected static or fast launcher")
        bound = bind_wrapper_arguments(record, mapping)
        if bound is None:
            raise UnsupportedCapture("Compiler and selected argument correspondence differs")
        user_facts = None
        grid_recipe = None
        if record.grid_type == "FixedGrid":
            user_facts = module.cudagraph_user_facts
            pointers = [(abi, arg) for abi, arg in enumerate(bound) if arg.triton_type.startswith("*")]
            if (records.version not in (3, 4) or type(user_facts) is not SelectedUserKernelFacts
                    or type(user_facts.analysis) is not KernelAnalysis
                    or type(user_facts.analysis.analyzer_version) is not int
                    or user_facts.analysis.analyzer_version != ANALYSIS_VERSION
                    or user_facts.analysis.supported is not True
                    or type(user_facts.analysis.pointer_formals) is not tuple
                    or kernel.inductor_meta.get("cudagraph_user_kernel") is not True
                    or tuple(kernel.inductor_meta.get("extra_launcher_args", ())) != FIXED_GRID_ARGUMENTS
                    or tuple(kernel.inductor_meta.get("fixed_grid", ())) != FIXED_GRID_ARGUMENTS
                    or len(user_facts.analysis.pointer_formals) != len(pointers)
                    or len({arg.source for _, arg in pointers}) != len(pointers)):
                raise UnsupportedCapture("Missing complete selected user-kernel facts")
            if records.version == 3:
                if any(type(value) is not int for value in record.launcher_grid) or len(pointers) != len(bound):
                    raise UnsupportedCapture("V3 user calls require literal grids and pointer-only ABI")
            else:
                scalars = [arg for arg in bound if type(arg.source) is ExpressionSource]
                indices = {row.boxed_index for row in records.integer_inputs}
                grid_recipe = bind_fixed_grid(record)
                if (len(indices) != 1 or len(scalars) != 1 or len(pointers) + 1 != len(bound)
                        or set(pointwise_expression_inputs(scalars[0].source.expression) or ()) != indices
                        or grid_recipe is None):
                    raise UnsupportedCapture("Dynamic user call lost its scalar or grid source")
                for axis in grid_recipe:
                    expression = axis.args[0] if axis.op == "ceildiv" else axis
                    if expression.op != "constant" and not set(
                        pointwise_expression_inputs(expression) or ()
                    ).issubset(indices):
                        raise UnsupportedCapture("User grid has an undeclared boxed source")
            for (abi_index, argument), pointer in zip(pointers, user_facts.analysis.pointer_formals):
                source = argument.source
                if type(pointer) is not PointerFormal:
                    raise UnsupportedCapture("Unsupported selected user pointer fact")
                alignment = pointer.required_alignment
                if (pointer.name != argument.formal or type(pointer.ttir_index) is not int
                        or pointer.ttir_index != abi_index or type(pointer.read) is not bool
                        or type(pointer.written) is not bool or type(alignment) is not int
                        or not 0 < alignment <= 16 or alignment & (alignment - 1)
                        or type(source) not in (InputSource, BufferSource)
                        or type(source) is InputSource and (pointer.written or copies is None or source.index not in copies)
                        or type(source) is BufferSource and pointer.read and source not in initialized
                        or pointer.written and source in initialized):
                    raise UnsupportedCapture("User pointer effects exceed the fresh-buffer/alignment contract")
            initialized.update(arg.source for (_, arg), pointer in zip(pointers, user_facts.analysis.pointer_formals)
                               if pointer.written)
        else:
            provenance = kernel.inductor_meta.get("cudagraph_parameter_provenance", {})
            initialized.update(arg.source for arg in bound if type(arg.source) is BufferSource
                               and type(provenance.get(arg.formal)) is tuple
                               and len(provenance[arg.formal]) == 3 and provenance[arg.formal][1] is True)
        if records.version == 4 and user_facts is None:
            grid_recipe = getattr(selected, "_cudagraph_grid_recipe", None)
            if (
                getattr(cached, "_cudagraph_grid_recipe", None) is not grid_recipe
                or bind_grid_recipe(record, mapping, grid_recipe) is None
            ):
                raise UnsupportedCapture("Dynamic preparation requires the selected compiler grid recipe")
        for arg in bound:
            source = arg.source
            if type(source) is InputSource:
                if type(source.index) is not int or not 0 <= source.index < len(records.input_names):
                    raise UnsupportedCapture("Compiler input index is out of range")
            elif type(source) is BufferSource:
                if type(source.name) is not str or not source.name:
                    raise UnsupportedCapture("Unsupported compiler buffer name")
                buffers.add(source)
            elif type(source) is ExpressionSource:
                indices = pointwise_expression_inputs(source.expression)
                if records.version != 4 or indices is None or not set(indices).issubset(
                    row.boxed_index for row in records.integer_inputs
                ):
                    raise UnsupportedCapture("Compiler expression has no declared integer input")
        scratch = []
        for present, size in ((module.has_global_scratch, module.global_scratch_size),
                              (module.has_profile_scratch, module.profile_scratch_size)):
            if type(present) is not bool or type(size) is not int or size != 0:
                raise UnsupportedCapture("Preparation requires empty launcher-owned scratch")
            if present:
                scratch.append(bytes(struct.calcsize("P")))
        call = _SelectedCall(record, kernel, selected, cached, module, module.function,
                             bound, tuple(scratch), grid_recipe, user_facts)
        if user_facts is not None:
            call.check()
        calls.append(call)
    if any(output.source not in buffers for output in records.outputs):
        raise UnsupportedCapture("Every output must occur in the selected kernel ABI")
    if any(call.user_facts is not None for call in calls) and any(
        output.source not in initialized for output in records.outputs
    ):
        raise UnsupportedCapture("Every returned buffer must have a selected writer")
    if records.version in (3, 4) and buffers != {layout.source for layout in records.allocations}:
        raise UnsupportedCapture("Every allocation must occur in the selected kernel ABI")
    return tuple(calls)


def _check_frontend_source(wrapper, records, calls, attachment):
    from compiler_metadata_handoff.metadata import _attachment_matches, _check_attachment

    _check_attachment(wrapper, attachment)
    for call in calls:
        call.check()
    for call in calls:
        if wrapper.__globals__.get(call.record.kernel_global) is not call.kernel:
            raise RuntimeError("Original selected kernel global changed during preparation")
    if attachment.records is not records or not _attachment_matches(wrapper, attachment):
        raise RuntimeError("Original frontend records changed during preparation")


def _bind_frontend_records(source, calls, projections, records):
    if (type(calls) is not tuple or type(projections) is not tuple
            or len(calls) != len(source.calls) or len(projections) != len(calls)
            or type(records) is not WrapperCallRecords or type(records.version) is not int
            or records.version != source.version or type(records.device_index) is not int
            or records.device_index != source.device_index
            or type(records.input_names) is not tuple or len(records.input_names) != len(source.input_names)
            or type(records.calls) is not tuple or len(records.calls) != len(calls)
            or bind_wrapper_allocations(records) is None or bind_alignment_copies(records) is None
            or tuple(row.boxed_index for row in records.integer_inputs)
            != tuple(row.boxed_index for row in source.integer_inputs)
            or records.alignment_copies != source.alignment_copies):
        raise UnsupportedCapture("Frontend records changed the original boxed or normalization contract")
    renamed, adapted = {}, []
    for index, (original, projection, record) in enumerate(zip(calls, projections, records.calls)):
        if projection.compiler_call is not original or original.record is not source.calls[index]:
            raise RuntimeError("Frontend projection lost its original selected call")
        try:
            projection.bind_call(record, renamed)
        except ValueError as error:
            raise UnsupportedCapture("Frontend call differs from the original selected operands") from error
        bound = bind_wrapper_arguments(record, projection.arguments)
        if bound is None:
            raise UnsupportedCapture("Frontend call lost its selected ABI")
        adapted.append(replace(original, record=record, arguments=bound))
    if set(renamed) != {layout.source for layout in source.allocations}:
        raise UnsupportedCapture("Frontend buffers do not cover the original allocations")
    allocations = tuple(replace(layout, source=renamed[layout.source]) for layout in source.allocations)
    outputs = tuple(replace(layout, source=renamed[layout.source]) for layout in source.outputs)
    if records.allocations != allocations or records.outputs != outputs:
        raise UnsupportedCapture("Frontend layouts or output order differ from the original compiler records")
    return tuple(adapted)


def _project_frontend_records(wrapper, example_inputs, records, calls, frontend):
    from compiler_metadata_handoff.metadata import _check_attachment
    from host_program import HostProgram
    from selected_kernel import SelectedKernel

    attachment = wrapper.__dict__.get("_cudagraph_frontend_attachment")
    metadata = _check_attachment(wrapper, attachment)
    _check_frontend_source(wrapper, records, calls, attachment)
    if records.version != 4:
        raise UnsupportedCapture("The selected frontend requires V4 compiler records")
    names = tuple(call.record.kernel_global for call in calls)
    if len(set(names)) != len(names):
        raise UnsupportedCapture("The selected frontend requires unique kernel globals")
    projections = tuple(SelectedKernel.from_compiler_call(call) for call in calls)
    selections = dict(zip(names, projections))
    if frontend == "fx":
        from fx_adapter.contract import FXTraceDeclined
        from fx_adapter.extraction import trace_generated_fx
        from fx_adapter.lowering import lower_fx

        try:
            program = lower_fx(trace_generated_fx(wrapper, metadata.inputs, example_inputs, selections))
        except FXTraceDeclined as error:
            raise UnsupportedCapture(str(error)) from error
    else:
        from retained_ir.prototype import bind_selected, reconstruct_ir, RetentionDeclined

        if metadata.retained_ir is None:
            raise UnsupportedCapture("Retained compiler frontend is unavailable")
        try:
            program = bind_selected(reconstruct_ir(metadata.retained_ir), selections).program
        except RetentionDeclined as error:
            raise UnsupportedCapture(str(error)) from error
    if type(program) is not HostProgram:
        raise RuntimeError("Frontend reader returned an unexpected program type")
    adapted = _bind_frontend_records(records, calls, projections, program.records)
    _check_frontend_source(wrapper, records, calls, attachment)
    return program.records, adapted, attachment


@dataclass
class _Preparation:
    records: WrapperCallRecords
    calls: tuple[_SelectedCall, ...]
    originals: tuple[torch.Tensor | int, ...]
    normalized: list[torch.Tensor | int]
    borrows: list[Any] = field(default_factory=list)
    launches: list[RecordedKernelLaunch] = field(default_factory=list)
    buffers: dict[BufferSource, torch.Tensor] = field(default_factory=dict)
    outputs: tuple[torch.Tensor, ...] = ()
    graph: Any = None
    instantiated: bool = False
    stream: Any = None
    capture_stream: Any = None
    entry: Any = None
    expression_values: dict[IntExpr, int] = field(default_factory=dict)
    source_calls: tuple[_SelectedCall, ...] = ()

    def abort(self) -> None:
        try:
            if self.entry is not None:
                self.entry.close()
            else:
                if self.stream is not None:
                    self.stream.synchronize()
                if self.capture_stream is not None:
                    self.capture_stream.synchronize()
                if self.graph is not None:
                    if not self.instantiated:
                        _failed_preparations.append(self)
                        return
                    batch = self.graph._prepare_kernel_pointer_updates((), 0)
                    cleanup = self.graph._make_replay_owner(batch, self.stream, (self,))
                    cleanup.close()
            self.borrows.clear()
        except BaseException:
            _failed_preparations.append(self)


# Public reset warns on destroy failures, so it cannot justify releasing borrows.
_failed_preparations: list[_Preparation] = []


class _KernelObserver:
    def __init__(self, preparation: _Preparation, name: str) -> None:
        self.preparation = preparation
        self.name = name

    def run(self, *args: Any, stream: int, **kwargs: Any) -> Any:
        state = self.preparation
        index = len(state.launches)
        if index >= len(state.calls):
            raise UnsupportedCapture("Wrapper launched an unrecorded kernel")
        call = state.calls[index]
        if (
            call.record.kernel_global != self.name or kwargs
            or len(args) != len(call.record.arguments) + (3 if call.record.grid_type == "FixedGrid" else 0)
            or type(stream) is not int or stream != state.capture_stream.cuda_stream
        ):
            raise UnsupportedCapture("Wrapper call differs from its compiler occurrence")
        if call.record.grid_type == "FixedGrid":
            grid = (tuple(state.expression_values[axis] for axis in call.grid_recipe)
                    if call.grid_recipe is not None else call.record.launcher_grid)
            if any(type(value) is not int for value in args[-3:]) or args[-3:] != grid:
                raise UnsupportedCapture("Wrapper grid differs from its recorded suffix")
        call.check()
        if state.source_calls:
            state.source_calls[index].check()
        for argument in call.record.arguments:
            value, source = args[argument.call_arg_index], argument.source
            if type(source) is IntegerSource:
                if type(value) is not int or value != source.value:
                    raise UnsupportedCapture("Wrapper integer differs from its compiler literal")
            elif type(source) is ExpressionSource:
                if type(value) is not int or value != state.expression_values.get(source.expression):
                    raise UnsupportedCapture("Wrapper integer differs from its compiler expression")
            elif type(source) is InputSource:
                if value is not state.normalized[source.index]:
                    raise UnsupportedCapture("Wrapper input differs from its recorded normalized source")
            elif type(source) is BufferSource:
                if type(value) is not torch.Tensor:
                    raise UnsupportedCapture("Compiler buffer is not an owning Tensor")
                previous = state.buffers.setdefault(source, value)
                if previous is not value:
                    raise UnsupportedCapture("Compiler buffer source changed identity")
            else:
                raise UnsupportedCapture("Unsupported wrapper argument source")
        values = tuple(
            struct.pack({"i32": "i", "i64": "q"}[arg.triton_type], args[arg.call_arg_index])
            if type(arg.source) in (IntegerSource, ExpressionSource)
            else struct.pack("P", args[arg.call_arg_index].data_ptr())
            for arg in call.arguments
        ) + call.scratch
        before = torch._C._cuda_get_capture_frontier(stream)
        result = call.kernel.run(*args, stream=stream)
        after = torch._C._cuda_get_capture_frontier(stream)
        call.check()
        if state.source_calls:
            state.source_calls[index].check()
        state.launches.append(RecordedKernelLaunch(stream, before, after, call.function, values))
        return result


def prepare_from_warmed(
    wrapper: FunctionType, example_inputs: list[torch.Tensor | int] | tuple[torch.Tensor | int, ...],
    *, frontend: str = "records", release_schedule: Any = None,
) -> Any:
    if type(frontend) is not str or frontend not in ("records", "fx", "retained"):
        raise UnsupportedCapture("Unknown compiler frontend")
    if release_schedule is not None and frontend != "records":
        raise UnsupportedCapture("Saved-input release currently requires the compiler records frontend")
    records = wrapper.__dict__.get("_cudagraph_call_records") if type(wrapper) is FunctionType else None
    if (
        type(wrapper) is not FunctionType or wrapper.__closure__ is not None
        or wrapper.__code__.co_argcount != 1 or wrapper.__code__.co_kwonlyargcount
        or wrapper.__code__.co_flags & (CO_VARARGS | CO_VARKEYWORDS | CO_GENERATOR | CO_COROUTINE | CO_ASYNC_GENERATOR)
        or wrapper.__defaults__ is not None or wrapper.__kwdefaults__ is not None
        or type(records) is not WrapperCallRecords or records.version not in (2, 3, 4)
        or type(records.device_index) is not int or records.device_index < 0
        or type(records.input_names) is not tuple
        or any(type(name) is not str for name in records.input_names)
        or len(set(records.input_names)) != len(records.input_names)
        or type(records.calls) is not tuple or not records.calls
        or type(records.outputs) is not tuple or type(records.alignment_copies) is not tuple
        or type(example_inputs) not in (list, tuple) or len(example_inputs) != len(records.input_names)
    ):
        raise UnsupportedCapture("Preparation requires a generated boxed wrapper with compiler records")
    if bind_wrapper_allocations(records) is None:
        raise UnsupportedCapture("Preparation requires complete compiler buffer layouts")
    expression_values = {}
    if records.version == 4:
        program = _NumericProgram(records, example_inputs)
        for call in records.calls:
            for argument in call.arguments:
                if type(argument.source) is ExpressionSource:
                    expression = argument.source.expression
                    expression_values[expression] = program.values[program.add(expression)]
            if call.grid_type == "FixedGrid":
                grid = bind_fixed_grid(call)
                if grid is None:
                    raise UnsupportedCapture("User grid has no compiler expression")
                for expression in grid:
                    expression_values[expression] = program.values[program.add(expression)]
    copies = bind_alignment_copies(records)
    if copies is None:
        raise UnsupportedCapture("Preparation requires supported recorded alignment copies")
    normalize = wrapper.__globals__.get("copy_if_misaligned")
    if copies and normalize is not torch._C._dynamo.guards.copy_if_misaligned:
        raise UnsupportedCapture("Recorded alignment requires the canonical native builtin")
    calls = _selected_calls(wrapper, records)
    source_records, source_calls, attachment = records, (), None
    if frontend != "records":
        source_calls = calls
        records, calls, attachment = _project_frontend_records(wrapper, example_inputs, records, calls, frontend)
    from torch.cuda import graphs

    if autograd_profiler._is_profiler_enabled or get_active_debug_mode() or any((
        graphs._global_capture_start_hooks, graphs._global_capture_end_hooks,
        graphs._global_instantiate_hooks, graphs._global_replay_start_hooks,
        graphs._global_replay_end_hooks, graphs._global_destroy_hooks,
    )):
        raise UnsupportedCapture("Instrumented graph preparation is unsupported")
    if torch.version.hip is not None or torch.version.cuda is None or tuple(map(int, torch.version.cuda.split("."))) < (12, 8):
        raise UnsupportedCapture("Native boxed preparation requires NVIDIA CUDA 12.8 or later")
    try:
        from cuda.bindings import runtime
    except ImportError as error:
        raise UnsupportedCapture("Graph upload requires cuda.bindings") from error
    state = _Preparation(records, calls, tuple(example_inputs), list(example_inputs),
                         expression_values=expression_values, source_calls=source_calls)
    try:
        modules = {id(call.module): call.module for call in calls}
        for module in modules.values():
            state.borrows.append(module._borrow_for_cudagraph())
        with torch.cuda.device(records.device_index):
            state.stream = torch.cuda.current_stream()
            state.capture_stream = torch.cuda.Stream()
            for index in copies:
                state.normalized[index] = normalize(state.originals[index])
            scope = wrapper.__globals__.copy()
            for call in calls:
                scope[call.record.kernel_global] = _KernelObserver(state, call.record.kernel_global)
            code = attachment.code if attachment is not None else wrapper.__code__
            captured_call = FunctionType(code, scope, wrapper.__name__)
            state.graph = torch.cuda.CUDAGraph(keep_graph=True)
            if attachment is not None:
                _check_frontend_source(wrapper, source_records, source_calls, attachment)
            with torch.cuda.graph(state.graph, stream=state.capture_stream):
                state.outputs = captured_call(state.normalized.copy())
            if (
                len(state.launches) != len(calls) or type(state.outputs) is not tuple
                or len(state.outputs) != len(records.outputs)
                or any(value is not state.buffers.get(output.source)
                       for value, output in zip(state.outputs, records.outputs))
            ):
                raise UnsupportedCapture("Captured outputs or occurrences differ from compiler records")
            if attachment is not None:
                _check_frontend_source(wrapper, source_records, source_calls, attachment)
            state.graph.instantiate()
            state.instantiated = True
            _check_cuda_bindings(runtime.cudaGraphUpload(state.graph.raw_cuda_graph_exec(), state.stream.cuda_stream))
            state.stream.synchronize()
            if records.version in (3, 4):
                state.capture_stream.synchronize()
            options = {"example_inputs": state.normalized} if records.version == 4 else {}
            if release_schedule is not None:
                options["release_schedule"] = release_schedule
            state.entry = make_boxed_replay(
                state.graph, records, tuple(call.selected for call in calls), tuple(state.launches),
                state.buffers, state.stream, copy_if_misaligned=normalize, **options,
            )
            if attachment is not None:
                _check_frontend_source(wrapper, source_records, source_calls, attachment)
            if records.version in (3, 4):
                state.entry._retire_capture_pool()
            state.borrows.clear()
            return state.entry
    except BaseException:
        state.abort()
        raise


def _publish_prepared(compiled_graph, expected_callable, entry) -> bool:
    if compiled_graph.current_callable is not expected_callable:
        entry.close()
        return False
    compiled_graph.current_callable = entry
    return True


def install_from_warmed(
    compiled_graph: "CompiledFxGraph", example_inputs: list[torch.Tensor | int] | tuple[torch.Tensor | int, ...]
) -> Any:
    r"""install_from_warmed(compiled_graph, example_inputs) -> callable

    Replace the current callable after an ordinary warm call has completed.

    The caller must serialize installation, calls and teardown, keep the bound
    stream and instrumentation mode fixed, and retain any callable needed for
    later restoration. Eligibility is checked by :func:`prepare_from_warmed`.
    """
    from ..output_code import CompiledFxGraph

    if type(compiled_graph) is not CompiledFxGraph:
        raise UnsupportedCapture("Installation requires a CompiledFxGraph")
    original = compiled_graph.current_callable
    entry = prepare_from_warmed(original, example_inputs)
    if not _publish_prepared(compiled_graph, original, entry):
        raise UnsupportedCapture("Compiled graph callable changed during preparation")
    return entry
