# Frontend release review requirements

This is a source-only design review of the first stage in
[the extension plan](../next_frontend_release.md): genuine V3 records through FX
and retained readers, sharing one cold release-schedule projection. No mutable
candidate source was read, and no framework, build or GPU work was run.
The later V4 schedule and native numeric-release stages are outside this change.

No fundamental design blocker was found. Acceptance requires the complete
reader event order to match the original schedule and requires the projected
drops to remain those of the original attached schedule. Existing independent
allocation/call checks alone are insufficient.

## One positive fixture for the shared join

Use three distinct boxed inputs with identical literal layouts. Inputs 0 and 1
are read by call 0; input 2 first appears at call 1. Let call 0 write allocation
A and call 1 read A/input 2 and write B. A and B have identical layouts and are
returned in order (A, B). Only input 0 is the saved-input release candidate.

The original schedule is:

~~~text
Allocate(A), Invoke(0), DropInput(0, after_call=0),
Normalize(input=2, before_call=1), Allocate(B), Invoke(1)
~~~

The reader omits the drop and may use different buffer and input labels. Its
allocation map must be the existing checked injective map, for example
A -> reader_tmp and B -> reader_out. Projecting the schedule must preserve the
drop index, its position between call 0 and normalization, the input-use tuple,
and output order/layouts. The original immutable schedule remains unchanged.
Renaming input labels to boxed_0/boxed_1/boxed_2 is a positive control: labels
must not become a second source of AOT boxed-position authority.

Exercise this fixture through both reader routes. Test structural mutations at
the shared cold join once; also route at least the allocation-order rejection
through each reader to prove neither route bypasses that join. There is no need
to multiply every shared validation case by every frontend.

## Minimal negative matrix

Each mutation starts from the accepted fixture and changes only the stated
fact. Preserve equal layouts where specified so an unrelated shape check
cannot be the reason for rejection.

| Case | Concrete mutation | Required observation |
| --- | --- | --- |
| Allocation interleaving | Move Allocate(B) before Invoke(0), leaving the allocation list (A, B), call list (0, 1), operands and outputs unchanged. All buffers still exist before their uses. | Cold correspondence rejects before capture/native construction. This distinguishes full event order from separate list equality. |
| Normalization interleaving | Swap Normalize(2, 1) and Allocate(B) within the same call interval. Keep both call lists and the normalization before_call value unchanged. | The complete non-drop sequence differs and is rejected. A before_call check alone must not accept it. |
| Boxed source correspondence | Swap InputSource(0) and InputSource(1) in call 0. Both inputs have identical layouts and the same use list. | Existing selected-call binding rejects the operand change; names, shape equality and recomputed use lists must not hide it. |
| Buffer correspondence | Map both A and B to the same reader buffer, or substitute a different buffer at B's first occurrence while retaining an otherwise valid allocation table. | Existing injective source mapping/complete allocation coverage rejects it. Reuse that map for schedule projection; do not create an independent name-based map. |
| Outputs | Swap the equally shaped outputs (B, A); separately alter one output layout while leaving the referenced source unchanged. | Ordered source/layout equality rejects before capture. Checking an output set or just output count is insufficient. |
| Drop authority and placement | Retarget DropInput(0, 0) to input 1, which has the same last use; separately move the original drop after Allocate(B), keeping after_call=0. | A projection must produce exactly the original attached drop target and position. A supplied schedule differing from that authority must not be accepted merely because the generic schedule validator accepts its last-use bounds. Lock these values in the positive result assertion as well. |
| Unsupported host instruction | Insert a Reinterpret instruction, including an otherwise legal fresh singleton rename. | Release projection declines rather than deleting the instruction or inferring a new alias/drop policy. Existing non-release support remains covered by its existing tests. |
| Original identity changes | Have a reader return valid-looking data after replacing the original attachment or selected kernel global; alternatively pass a projection tied to another selected call with the same ABI. | Existing original-identity checks fail and no entry is published. Unexpected invalidation propagates; it must not become a successful ordinary-result fallback. |

Check that rejected structural correspondence does not call capture or the
native constructor. Use the existing sentinel/mock boundary for this, not
extra production instrumentation. For expected UnsupportedCapture through the
cold policy, require exactly one completed ordinary invocation, a decline and
no native entry. For unexpected reader/identity errors, require propagation
and no retry. Reuse existing tests for already-covered malformed counts,
out-of-range indices, ABI/grid mismatch and duplicate outputs rather than
duplicating that entire matrix.

The drop-authority row is an acceptance condition on the new API boundary:
if the shared projector accepts a release_schedule argument, its source must
be the original attachment's checked schedule. An independently valid schedule
is not evidence of the original AOT candidate classification. Projection may
construct the renamed result but must not rediscover candidates or place drops
using reader object expiry.

## Reader and metadata boundaries

| Boundary | Small concrete control |
| --- | --- |
| Genuine static V3 | Both readers construct V3 directly from checked V3 source records. Require empty integer_inputs, literal allocation/input layouts, literal scalar call operands, and a V3 retained export/reconstruct round trip. Review construction as well as the result: constructing V4 and retagging it afterward is not acceptable. |
| V3 cannot carry symbolic facts | Parameterize an injected integer-input declaration, an IntExpr in a layout, and an ExpressionSource in a call. Each must decline V3 admission; a warm integer value or constant-valued expression must not be substituted to make it pass. Keep existing exact-version/type validation. |
| Retained payload belongs to its records | Pair V3 metadata with an independently valid retained payload whose output order, call operand or record version differs. Require exact retained.records equality rejection. Extending the V3 branch must not accidentally skip the existing payload equality check. |
| Existing V4 remains V4 | Reuse a genuine symbolic V4 fixture with an integer boxed slot and its original IntExpr tree. With no schedule, both readers retain that version, slot and expression despite concrete warm hints. Existing narrowed-domain/additional-guard rejections still apply to FX. |
| Numeric release is still unavailable | A V4 source with a supplied release schedule still declines before native construction. Stage one must not relax numeric-release guards or plumb pending input state through a numeric replay path. |
| Exact Parameter input | A generated backward box containing an exact torch.nn.Parameter can use the checked compiler-bound FX route when its source/input contract is unchanged. An arbitrary Tensor subclass remains rejected. Avoid replacing the exact-type check with a global isinstance allowance; keep any new allowance tied to checked compiler provenance. |

These are boundary families, not a request to duplicate existing tests. Preserve
the existing release-absent path, cache/scope gates, records frontend behavior
and V4 reader regressions. No new validation should run on a published native
hit.

## Qualification handoff

The root owns execution. Static FX and retained release-on, release-off and
retain-graph controls should use actual generated V3 metadata and emitted
reader events, require native admission for backward, preserve repeated output
correctness and verify the cold projection is not called on native hits.
A passing source review or schedule projection is not allocator reuse evidence;
reuse and memory/performance statements retain the existing evidence limits.

## Reviewed baseline

The plan SHA256 is
f66448c356c592a153b482c4acf220687745c5f63703716b25019bf69fedda1a.
The selected baseline is NC/qualification3/manifest.json SHA256
6c3ea0910999133a169fd58cbd0777d64a2f567a36a7a3915addf6693c8de6bc.
All source pins selected below were checked against that manifest and its
gpu_dependencies.json. Candidate frontend_release/source_delta was excluded.

- cudagraph_prepare_from_warmed.py: _bind_frontend_records (241), _project_frontend_records (275), _check_frontend_source (228), prepare_from_warmed (418).
- selected_kernel.py: SelectedKernel.bind_call (75), especially unchanged boxed sources and injective buffer mapping.
- fx_adapter/lowering.py: _lower_fx (54), direct V4 construction (205).
- fx_adapter/extraction.py: _trace_generated_fx (223), exact Tensor/Parameter gate (253).
- retained_ir/prototype.py: retain_wrapper (93), validate (173), bind_selected (252), immutable transport (289).
- host_program.py: explicit Allocate/Normalize/Invoke/Reinterpret event types.
- compiler_metadata_handoff/metadata.py: _check_v3_records (41), _check_metadata (56), _check_release_schedule (117), collect_metadata (161).
- compiler_saved_inputs/schedule.py: final live-IR walk and exact original drop positions.
- cudagraph_arg_mapping.py: V3 literal and V4 symbolic allocation/copy boundaries.
- cudagraph_boxed_replay.py and compiler_policy_handoff/policy.py: unchanged static-only release and one-call cold policy.
