from dataclasses import asdict
import json
from unittest import mock

import activation_schedule
from compiler_metadata_handoff import metadata as generated_metadata
from generated_forward_backward_fixture import SavedSine
from handoff import AOTInputOrigins, collect_saved_inputs
from origins import capture_forward_origins, join_backward_origins
import torch
from torch._functorch import config as aot_config
from torch._inductor import compile_fx as compiler, config
from torch._inductor.runtime.cudagraph_arg_mapping import KernelCallRecord
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import run_tests, TestCase


class TestAutomaticCompilerOrigins(TestCase):
    def test_real_compile_callbacks_reach_release_schedule(self, device):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        forward_compiler = compiler.compile_fx_forward
        backward_compiler = compiler.compile_fx_backward
        collect = generated_metadata.collect_metadata
        forward_origins = None
        compilations = [0, 0]
        schedules = []
        classifications = []
        checks = TestCase()

        def forward(graph, examples, **kwargs):
            nonlocal forward_origins
            checks.assertFalse(kwargs["is_inference"])
            forward_origins = capture_forward_origins(graph)
            compilations[0] += 1
            return forward_compiler(graph, examples, **kwargs)

        def backward(graph, examples, **kwargs):
            classification = join_backward_origins(forward_origins, graph)
            placeholders = tuple(node for node in graph.graph.nodes if node.op == "placeholder")
            origin = AOTInputOrigins(
                graph, graph.graph, placeholders, tuple(node.name for node in placeholders),
                tuple(node.target for node in placeholders), classification,
            )
            classifications.append(classification)
            compilations[1] += 1

            def final(wrapper, records):
                metadata = collect(wrapper, records)
                saved = collect_saved_inputs(origin, wrapper, records, metadata)
                checks.assertIsNotNone(saved)
                schedule = activation_schedule.collect_release_schedule(saved, wrapper, records)
                checks.assertIsNotNone(schedule)
                checks.assertEqual(saved.classification, classification)
                checks.assertEqual(schedule.input_names, records.input_names)
                checks.assertEqual(tuple(step for step in schedule.steps if type(step) is KernelCallRecord), records.calls)
                schedules.append(schedule)
                return metadata

            with mock.patch.object(generated_metadata, "collect_metadata", new=final):
                return backward_compiler(graph, examples, **kwargs)

        model = SavedSine(device)
        value = torch.linspace(-0.8, 0.9, 4096, device=device).reshape(32, 128).requires_grad_()
        expected_value = value.detach().clone().requires_grad_()
        expected_weight = model.weight.detach().clone().requires_grad_()
        with aot_config.patch(enable_autograd_cache=False, donated_buffer=False), config.patch(
            graph_partition=False, cpp_wrapper=False, fx_graph_cache=False, force_disable_caches=True,
            allow_buffer_reuse=False, inplace_buffers=False, max_fusion_size=1,
            cudagraph_policy=None, use_static_triton_launcher=True, **{"triton.cudagraphs": False},
        ), mock.patch.object(compiler, "compile_fx_forward", new=forward), mock.patch.object(
            compiler, "compile_fx_backward", new=backward
        ):
            compiled = torch.compile(model, fullgraph=True, dynamic=False)
            actual = compiled(value)
            expected = expected_value.sin() * expected_weight
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            actual_gradients = torch.autograd.grad(actual, (value, model.weight), tangent)
            expected_gradients = torch.autograd.grad(expected, (expected_value, expected_weight), tangent)
            self.assertEqual(actual_gradients, expected_gradients)

        self.assertEqual(compilations, [1, 1])
        self.assertEqual(len(schedules), 1)
        self.assertEqual(len(classifications[0].candidate_indices), 1)
        schedule = schedules[0]
        calls = tuple(step for step in schedule.steps if type(step) is KernelCallRecord)
        self.assertGreater(len(calls), 1)
        drops = tuple(step for step in schedule.steps if type(step) is activation_schedule.DropInput)
        self.assertEqual(tuple(step.input_index for step in drops), classifications[0].candidate_indices)
        print("AUTOMATIC_COMPILER_ORIGINS " + json.dumps({
            "compilations": compilations, "classification": asdict(classifications[0]),
            "backward_calls": len(calls), "drops": [asdict(step) for step in drops],
            "native_release": False, "emitted_annotation": False,
        }, sort_keys=True))


instantiate_device_type_tests(TestAutomaticCompilerOrigins, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
