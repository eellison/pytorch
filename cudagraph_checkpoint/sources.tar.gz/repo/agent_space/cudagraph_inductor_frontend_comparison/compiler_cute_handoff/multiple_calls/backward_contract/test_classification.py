import copy
from dataclasses import asdict
import json
from unittest import mock

import torch
from torch._functorch import config
from torch._functorch._aot_autograd import graph_compile
from torch._functorch._aot_autograd.descriptors import SavedForBackwardsAOTOutput
from torch._functorch.aot_autograd import aot_module
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests,
    parametrize,
    run_tests,
    TestCase,
)

from classification import ClassificationDeclined, classify_saved_activations


class ActivationModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.linspace(0.5, 1.0, 4))

    def forward(self, value):
        weighted = value.view(value.shape[0], -1) * self.weight.view(1, -1)
        hidden = weighted.sin()
        return hidden.square(), hidden


def storage_id(value):
    return StorageWeakRef(value.untyped_storage()).cdata if isinstance(value, torch.Tensor) else None


class CallbackCapture:
    def __init__(self):
        self.forward = None
        self.backward = None
        self.provenance = None
        self.forward_storage = ()
        self.backward_boxes = []
        self.compiler_calls = [0, 0]

    def compile_forward(self, graph, examples):
        self.forward = graph
        self.compiler_calls[0] += 1

        def boxed(args):
            if type(args) is not list:
                raise AssertionError("Expected AOT's actual boxed forward list")
            result = graph.forward(*args)
            self.forward_storage = tuple(storage_id(value) for value in result)
            return result

        boxed._boxed_call = True
        return boxed

    def compile_backward(self, graph, examples):
        self.backward = graph
        self.compiler_calls[1] += 1
        self.provenance = classify_saved_activations(self.forward, graph)

        def boxed(args):
            if type(args) is not list:
                raise AssertionError("Expected AOT's actual boxed backward list")
            self.backward_boxes.append(tuple(storage_id(value) for value in args))
            return graph.forward(*args)

        boxed._boxed_call = True
        return boxed


class TestSavedActivationClassification(TestCase):
    def capture(self, *, dynamic=False, donated=False, retained=False):
        capture = CallbackCapture()
        model = ActivationModel()
        reference = copy.deepcopy(model)
        value = torch.linspace(-0.8, 0.9, 12).reshape(3, 4).requires_grad_()
        expected_value = value.detach().clone().requires_grad_()
        donation_calls = []
        original = graph_compile.collect_bw_donated_buffer_idxs

        def donated_indices(*args):
            result = original(*args)
            donation_calls.append(tuple(result))
            return result

        with config.patch(donated_buffer=donated, enable_autograd_cache=False), mock.patch.object(
            graph_compile, "collect_bw_donated_buffer_idxs", side_effect=donated_indices
        ):
            compiled = aot_module(model, capture.compile_forward, capture.compile_backward, dynamic=dynamic)
            actual = compiled(value)
            expected = reference(expected_value)
            self.assertEqual(actual, expected)
            tangents = tuple(torch.ones_like(result) for result in actual)
            expected_grads = torch.autograd.grad(expected, (expected_value, reference.weight), tangents)
            actual_grads = torch.autograd.grad(actual, (value, model.weight), tangents, retain_graph=retained)
            self.assertEqual(actual_grads, expected_grads)
            if retained:
                self.assertEqual(torch.autograd.grad(actual, (value, model.weight), tangents), expected_grads)
        self.assertEqual(capture.compiler_calls, [1, 1])
        self.assertEqual(len(donation_calls), 1 if donated else 0)
        return capture, donation_calls

    @parametrize("dynamic", (False, True))
    @parametrize("donated", (False, True))
    def test_real_callbacks_and_boxed_indices(self, dynamic, donated):
        capture, _ = self.capture(dynamic=dynamic, donated=donated)
        proof = capture.provenance
        self.assertTrue(proof.candidate_indices)
        self.assertIn("input_alias", {row.kind for row in proof.inputs})
        self.assertIn("output_alias", {row.kind for row in proof.inputs})
        self.assertIn("tangent", {row.kind for row in proof.inputs})
        placeholders = [node for node in capture.backward.graph.nodes if node.op == "placeholder"]
        fw_output = next(node for node in capture.forward.graph.nodes if node.op == "output").args[0]
        self.assertEqual(len(placeholders), len(proof.inputs))
        self.assertEqual(len(capture.backward_boxes), 1)
        self.assertEqual(len(capture.backward_boxes[0]), len(placeholders))
        for row in proof.inputs:
            self.assertEqual(placeholders[row.boxed_index].name, row.name)
            if row.forward_output is not None:
                saved = fw_output[row.forward_output]
                self.assertIs(placeholders[row.boxed_index].meta["val"], saved.meta["val"])
                observed = capture.backward_boxes[0][row.boxed_index]
                self.assertEqual(observed, capture.forward_storage[row.forward_output])
        alias_nodes = [fw_output[row.forward_output] for row in proof.inputs if row.kind == "input_alias"]
        self.assertTrue(any(node.op != "placeholder" for node in alias_nodes), "Expected an excluded saved view")
        if dynamic:
            self.assertIn("symbol", {row.kind for row in proof.inputs})
            activations = [row for row in proof.inputs if row.kind == "activation"]
            self.assertTrue(any(row.boxed_index != row.saved_index for row in activations))
        self.assertEqual(json.loads(json.dumps(asdict(proof)))["inputs"], [asdict(row) for row in proof.inputs])

    def test_donation_flag_does_not_change_provenance(self):
        disabled, no_donation = self.capture(donated=False)
        enabled, donation = self.capture(donated=True)
        self.assertEqual(disabled.provenance, enabled.provenance)
        self.assertEqual(no_donation, [])
        self.assertTrue(donation[0])

    def test_retained_backward_keeps_same_classification_without_donation(self):
        capture, donation = self.capture(retained=True, donated=False)
        self.assertTrue(capture.provenance.candidate_indices)
        self.assertEqual(donation, [])
        self.assertEqual(len(capture.backward_boxes), 2)
        for index in capture.provenance.candidate_indices:
            self.assertEqual(capture.backward_boxes[0][index], capture.backward_boxes[1][index])
        self.assertEqual(classify_saved_activations(capture.forward, capture.backward), capture.provenance)

    @parametrize("damage", (
        "descriptors", "ordinal", "value", "identity", "name", "real_tensor", "opaque_input", "mutation"
    ))
    def test_incomplete_authority_declines(self, damage):
        capture, _ = self.capture()
        forward, backward = copy.deepcopy((capture.forward, capture.backward))
        self.assertEqual(classify_saved_activations(forward, backward), capture.provenance)
        row = next(row for row in capture.provenance.inputs if row.kind == "activation")
        output = next(node for node in forward.graph.nodes if node.op == "output")
        saved = output.args[0][row.forward_output]
        placeholder = [node for node in backward.graph.nodes if node.op == "placeholder"][row.boxed_index]
        if damage == "descriptors":
            output.meta.pop("desc")
            message = "complete final AOT output descriptors"
        elif damage == "ordinal":
            descriptors = list(output.meta["desc"])
            descriptors[row.forward_output] = SavedForBackwardsAOTOutput(-1)
            output.meta["desc"] = descriptors
            message = "ordinals are not canonical"
        elif damage == "value":
            placeholder.meta.pop("val")
            message = "Missing final AOT value metadata"
        elif damage == "identity":
            value = saved.meta["val"]
            with value.fake_mode:
                placeholder.meta["val"] = torch.empty_strided(
                    value.shape, value.stride(), device=value.device, dtype=value.dtype
                )
            self.assertIsNot(placeholder.meta["val"], value)
            message = "identity/name association"
        elif damage == "name":
            placeholder.name += "_lost"
            message = "identity/name association"
        elif damage == "real_tensor":
            placeholder.meta["val"] = torch.empty(3, 4)
            message = "storage provenance"
        elif damage == "opaque_input":
            next(node for node in forward.graph.nodes if node.op == "placeholder").meta["val"] = object()
            message = "opaque boundary storage provenance"
        else:
            node = next(node for node in forward.graph.nodes if node.op == "call_function")
            node.target = torch.ops.aten.transpose_.default
            message = "Metadata mutation"
        with self.assertRaisesRegex(ClassificationDeclined, message):
            classify_saved_activations(forward, backward)
        self.assertTrue(capture.provenance.candidate_indices)


instantiate_parametrized_tests(TestSavedActivationClassification)


if __name__ == "__main__":
    run_tests()
