The direct, unpartitioned Python-wrapper path already preserves input order. It needs one explicit cold association with AOT's saved-activation classification, not a general argument remapper.

The selected source chain is:

- `GraphLowering.placeholder` consumes placeholders in interpreter order and appends every qualified target to `graph_input_names` (`graph.py:1306-1389`). `graph.run(*example_inputs)` receives the backward compiler arguments directly (`compile_fx.py:1831`).
- `PythonWrapperCodegen.write_args` emits the unpacking of that exact sequence from `args`, then clears the box (`wrapper.py:2105-2109`, called at 2158). `compiler_inputs` enumerates the same names into `InputContract` slots (`collector.py:30-75`).
- `collect_cudagraph_call_records` enumerates those names into `InputSource(index)` (`wrapper.py:3309-3380`). `GeneratedMetadata` checks the input kinds, arity, integer slots, and records attachment, but contains no AOT origin or saved-activation role (`metadata.py:21-33, 76-101`).

Thus final call arguments already identify final boxed slots exactly. The missing fact is which of those slots came from the previously classified saved activations. Names, static-input indices, and donation indices do not establish that fact. Inductor reruns FakeTensor propagation before post-grad passes (`compile_fx.py:1658-1687`), so recovering the original AOT FakeTensor identities after propagation is not the contract.

The smallest initial handoff is:

1. In the actual AOT backward compiler callback, classify the paired final AOT graphs, then capture the exact ordered backward placeholder objects with the data-only classification. This association exists only during cold compilation.
2. At final wrapper metadata collection, require the same complete placeholder objects in the same order, and require their qualified targets to equal the wrapper and records input-name sequence. Reject a replacement, reorder, missing slot, partition, or unsupported wrapper from this optional handoff. The identity map from AOT ordinal to final boxed ordinal is then checked, not assumed.
3. Emit an optional tuple of saved-activation input indices alongside the existing generated metadata, under the same original function/code/records attachment. Require each index to name a tensor slot. Retain no FX node, graph, FakeTensor, or storage owner in that emitted result. An absent annotation means optional reclamation is disabled.

The annotation is admitted only with the fresh cold association that established it. Cache loading can bypass lowering (`compile_fx.py:1240`) and reconstruct a generated callable from its saved source (`output_code.py:1040-1064`); it does not re-establish AOT provenance. Cache hits lacking the association remain ordinary execution with optional reclamation disabled. Cache keying/transport is deferred, as are transformations that replace placeholders. No post-propagation identity recovery, pointer matching, or runtime alias scan is needed.

The next fixture can compile a small real AOT CUDA backward for `value.sin() * weight`, with a same-shaped Parameter, static dimensions, donation disabled, graph partitioning disabled, and caches disabled. Observe the final wrapper IR without replay or release. Require the real internal saved sine to map to its recorded `InputSource`, while the original value, Parameter, and tangent remain excluded; compare the actual AOT backward box and generated-wrapper box and check ordinary gradients. Copied-graph controls should replace or reorder a placeholder and require the optional annotation to decline. The current exact `InputBuffer` gates also exclude `DonatedBuffer` (`graph.py:1367`, `collector.py:61`, `wrapper.py:3373`); there is no need to broaden them for this fixture. Earlier CPU14 classification remains donation-independent.

This establishes origin transport only. Last-use scheduling and stream-safe selective release remain separate work. Unexpected errors still propagate; this proposal adds no recovery path.

Source authority: `consolidated/qualification2/manifest.json` (6140f90f), its pinned consolidated `compiler_input_contract`, `compiler_metadata_handoff`, `compile_fx.py`, `wrapper.py`, and `output_code.py`; immediate `graph.py` and `codecache.py` hooks are the execution-pinned installed sources (46500fd5 and f711e8b6). No implementation or framework execution was performed.
