from contextlib import contextmanager, nullcontext
from dataclasses import replace
import gc
import pickle
from types import SimpleNamespace
from unittest import mock
import weakref

import torch
import transport_fixture
from compiler_saved_inputs import transport
from compiler_saved_inputs.handoff import same_aot_inputs
from compiler_saved_inputs.origins import ForwardOrigins
from torch._functorch import config as aot_config
from torch._inductor import compile_fx as compiler, config
from torch._inductor.codecache import FxGraphCachePickler
from torch._inductor.runtime.cudagraph_arg_mapping import WrapperCallRecords
from torch._inductor.virtualized import V
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


Fixture = transport_fixture.TestSavedInputTransport


class TestLocalFxSavedInputs(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())
        self.assertIsNone(transport._active_origin.get())

    def tearDown(self):
        self.assertIsNone(transport._active_origin.get())
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    @contextmanager
    def scope(self):
        with Fixture.scope(self), config.patch(
            force_disable_caches=False, fx_graph_cache=True, fx_graph_remote_cache=False,
        ), aot_config.patch(enable_remote_autograd_cache=False):
            yield

    @contextmanager
    def bound(self, graph, classification=None):
        state = transport.SavedInputCapture(compiler.compile_fx_inner)
        state.origins = ForwardOrigins(())
        if classification is None:
            classification = Fixture.classification(self)
        with mock.patch.object(transport, "join_backward_origins", return_value=classification):
            with state.backward(graph):
                yield

    @parametrize("case", ("local_off", "fx_remote", "fx_remote_auto", "aot_remote", "aot_remote_auto", "aot_local"))
    def test_local_cache_gate_is_explicit(self, case):
        settings = {
            "local_off": (config, {"fx_graph_cache": False}),
            "fx_remote": (config, {"fx_graph_remote_cache": True}),
            "fx_remote_auto": (config, {"fx_graph_remote_cache": None}),
            "aot_remote": (aot_config, {"enable_remote_autograd_cache": True}),
            "aot_remote_auto": (aot_config, {"enable_remote_autograd_cache": None}),
            "aot_local": (aot_config, {"enable_autograd_cache": True}),
        }
        with self.scope():
            self.assertTrue(transport.eligible(compiler.compile_fx_inner))
            module, values = settings[case]
            with module.patch(values):
                self.assertFalse(transport.eligible(compiler.compile_fx_inner))

    @parametrize("remote", (False, True))
    def test_forced_cache_disable_preserves_previous_scope(self, remote):
        with Fixture.scope(self), config.patch(fx_graph_cache=False, fx_graph_remote_cache=remote), aot_config.patch(
            enable_remote_autograd_cache=remote,
        ):
            self.assertTrue(transport.eligible(compiler.compile_fx_inner))

    def test_primitive_key_and_pickle_do_not_keep_live_origins(self):
        keys, data, payloads = [], [], []
        for _ in range(2):
            graph = Fixture.graph(self)
            graph_ref = weakref.ref(graph)
            with self.scope(), self.bound(graph):
                origin_ref = weakref.ref(transport._active_origin.get())
                with transport.saved_input_cache_key(graph):
                    data.append(graph.meta[transport.ORIGIN_KEY])
                    keys.append(FxGraphCachePickler(graph).get_key(graph))
                    self.assertEqual(graph.__reduce__()[1][0]["meta"][transport.ORIGIN_KEY], data[-1])
                    payloads.append(pickle.dumps(graph))
                    leaves = [data[-1]]
                    while leaves:
                        value = leaves.pop()
                        if type(value) is tuple:
                            leaves.extend(value)
                        else:
                            self.assertIn(type(value), (str, int, type(None)))
                self.assertIsNotNone(origin_ref())
            self.assertIsNone(origin_ref())
            del graph
            gc.collect()
            self.assertIsNone(graph_ref())
        self.assertEqual(data[0], data[1])
        self.assertEqual(keys[0], keys[1])
        for payload in payloads:
            restored = pickle.loads(payload)
            self.assertNotIn(transport.ORIGIN_KEY, restored.meta)
            self.assertIsNone(transport._active_origin.get())
            with self.scope(), transport.saved_input_cache_key(restored):
                self.assertEqual(restored.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)

    @parametrize("change", ("candidate_alias", "other_alias", "boxed_order"))
    def test_classification_changes_cache_identity(self, change):
        graph = Fixture.graph(self)
        original = Fixture.classification(self)
        rows = original.inputs
        if change == "candidate_alias":
            changed = replace(original, inputs=(replace(rows[0], kind="input_alias"), rows[1]))
        elif change == "other_alias":
            changed = replace(original, inputs=(rows[0], replace(rows[1], kind="input_alias", forward_output=2, saved_index=1)))
        else:
            changed = replace(original, inputs=(replace(rows[0], boxed_index=1), replace(rows[1], boxed_index=0)))
        keys = []
        with self.scope():
            for classification in (original, changed):
                with self.bound(graph, classification), transport.saved_input_cache_key(graph):
                    keys.append(FxGraphCachePickler(graph).get_key(graph))
        self.assertNotEqual(*keys)

    @parametrize("inner", ("eligible", "absent", "no_candidates", "disabled"))
    @parametrize("failure", (False, True))
    def test_nested_backward_scopes_restore_exact_outer_origin(self, inner, failure):
        graph = Fixture.graph(self)
        inner_graph = Fixture.graph(self) if inner == "eligible" else graph
        error = RuntimeError("inner compiler failed")
        state = transport.SavedInputCapture(compiler.compile_fx_inner)
        if inner != "absent":
            state.origins = ForwardOrigins(())
        classification = Fixture.classification(self, inner != "no_candidates")
        with self.scope(), self.bound(graph):
            outer = transport._active_origin.get()
            outer_key = graph.meta[transport.ORIGIN_KEY]
            with mock.patch.object(transport, "join_backward_origins", return_value=classification):
                try:
                    with config.patch(cudagraph_saved_input_schedule=False) if inner == "disabled" else nullcontext():
                        with state.backward(inner_graph):
                            if inner == "eligible":
                                self.assertIsNot(transport._active_origin.get(), outer)
                                self.assertTrue(same_aot_inputs(transport._active_origin.get(), inner_graph))
                            else:
                                self.assertIsNone(transport._active_origin.get())
                                with transport.saved_input_cache_key(inner_graph):
                                    self.assertEqual(inner_graph.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)
                            if failure:
                                raise error
                except RuntimeError as caught:
                    self.assertTrue(failure)
                    self.assertIs(caught, error)
            self.assertIs(transport._active_origin.get(), outer)
            self.assertEqual(graph.meta[transport.ORIGIN_KEY], outer_key)
            with transport.saved_input_cache_key(graph):
                self.assertEqual(graph.meta[transport.ORIGIN_KEY], outer_key)

    @parametrize("damage", ("graph", "name", "target", "order", "metadata", "disabled"))
    def test_stale_origin_stays_disabled_after_source_is_restored(self, damage):
        graph = Fixture.graph(self)
        records = WrapperCallRecords(3, 0, ("activation", "tangent"), (), ())
        with self.scope(), self.bound(graph):
            origin = transport._active_origin.get()
            first, second = origin.placeholders
            original_graph = graph.graph
            if damage == "graph":
                graph.graph = Fixture.graph(self).graph
                changed = nullcontext()
            elif damage in ("name", "target"):
                changed = mock.patch.object(first, damage, "changed")
            elif damage == "metadata":
                changed = mock.patch.dict(graph.meta, {transport.ORIGIN_KEY: transport._NO_ORIGIN})
            elif damage == "disabled":
                changed = config.patch(cudagraph_saved_input_schedule=False)
            else:
                changed = nullcontext()
                second.append(first)
            try:
                with changed, transport.saved_input_cache_key(graph):
                    self.assertEqual(graph.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)
                    self.assertIsNone(transport._active_origin.get())
            finally:
                if damage == "graph":
                    graph.graph = original_graph
                elif damage == "order":
                    second.prepend(first)
            self.assertTrue(same_aot_inputs(origin, graph))
            self.assertIsNone(transport._active_origin.get())
            with V.set_graph_handler(SimpleNamespace(module=graph)), mock.patch.object(
                transport, "collect_saved_inputs", side_effect=AssertionError("Stale origin reached handoff"),
            ), mock.patch.object(transport, "collect_release_schedule") as schedule:
                self.assertIsNone(transport.collect_optional_schedule(object(), records, object()))
                schedule.assert_not_called()
            with transport.saved_input_cache_key(graph):
                self.assertEqual(graph.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)

    def test_copied_primitive_cannot_authorize_another_graph(self):
        graph, other = Fixture.graph(self), Fixture.graph(self)
        with self.scope(), self.bound(graph):
            origin = transport._active_origin.get()
            other.meta[transport.ORIGIN_KEY] = graph.meta[transport.ORIGIN_KEY]
            with transport.saved_input_cache_key(other):
                self.assertEqual(other.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)
            self.assertIs(transport._active_origin.get(), origin)
            self.assertFalse(same_aot_inputs(origin, other))
            with transport.saved_input_cache_key(graph):
                self.assertNotEqual(graph.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)

    def test_key_failure_restores_absence(self):
        graph = Fixture.graph(self)
        error = RuntimeError("cache key failed")
        with self.scope():
            with self.assertRaisesRegex(RuntimeError, "cache key failed") as caught:
                with transport.saved_input_cache_key(graph):
                    self.assertEqual(graph.meta[transport.ORIGIN_KEY], transport._NO_ORIGIN)
                    raise error
            self.assertIs(caught.exception, error)
            self.assertNotIn(transport.ORIGIN_KEY, graph.meta)
            self.assertIsNone(transport._active_origin.get())


instantiate_parametrized_tests(TestLocalFxSavedInputs)

if __name__ == "__main__":
    run_tests()
