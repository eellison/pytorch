from dataclasses import fields, is_dataclass, replace
from types import SimpleNamespace
from unittest import mock

import sympy
import torch
import frontend_readers_fixture
import static_metadata_fixture
from compiler_metadata_handoff.metadata import (
    _check_metadata, _check_release_schedule, collect_metadata, MetadataDeclined,
    read_metadata,
)
from compiler_saved_inputs.classification import BackwardInput, SavedActivations
from compiler_saved_inputs.handoff import AOTInputOrigins, FinalSavedInputs
from compiler_saved_inputs import schedule, transport
from fx_adapter.extraction import trace_generated_fx
from fx_adapter.lowering import lower_fx
from host_program import Allocate, Invoke, Normalize
from retained_ir.prototype import bind_selected, reconstruct_ir, retain_wrapper
from torch._inductor import config, ir
from torch._inductor.codegen.common import ArgName, SizeArg, TensorArg
from torch._inductor.codegen.wrapper import (
    AllocateLine, EnterDeviceContextManagerLine, ExitDeviceContextManagerLine, FreeLine,
    InputAlignmentLine, KernelCallLine, PythonWrapperCodegen, TritonCallArgument,
)
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, ExpressionSource, IntExpr, pointwise_product,
)
from torch._inductor.sizevars import SizeVarAllocator
from torch._inductor.virtualized import ops, V
from torch.fx.experimental.symbolic_shapes import ShapeEnv
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)
from torch.utils._sympy.value_ranges import ValueRanges


class SymbolicCompilerFixture:
    """Real typed V4 wrapper; AOT classification and inherited domain are CPU fixture facts."""

    def __init__(self, test, *, integer_first=False):
        test.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True,
                                       allow_buffer_reuse=False, inplace_buffers=False))
        self.extent = sympy.Symbol("width", integer=True, positive=True)
        environment = ShapeEnv()
        environment.var_to_range[self.extent] = ValueRanges(1, 64)
        self.layout = ir.FixedLayout(torch.device("cuda:0"), torch.float32,
                                     (32, self.extent), (self.extent, 1))
        self.activation = ir.InputBuffer(name="activation", layout=self.layout)
        self.weight = ir.InputBuffer(name="weight", layout=self.layout)
        self.temp = self.computation("temp", ("activation",))
        self.output = self.computation("output", ("temp", "weight"))
        names = ("width", "activation", "weight") if integer_first else ("activation", "width", "weight")
        self.integer_index = names.index("width")
        self.activation_index = names.index("activation")
        self.weight_index = names.index("weight")
        scheduler_nodes = [SimpleNamespace(node=node) for node in (self.temp, self.output)]
        self.graph = SimpleNamespace(
            name="symbolic_release_fixture", sizevars=SizeVarAllocator(environment),
            graph_inputs={"activation": ir.TensorBox.create(self.activation), "width": self.extent,
                          "weight": ir.TensorBox.create(self.weight)},
            graph_input_names=list(names), graph_outputs=[self.output], cpp_wrapper=False, aot_mode=False,
            partition_maps=None, effectful_ops={}, mutated_inputs=set(), constants={},
            operations=[self.temp, self.output],
            scheduler=SimpleNamespace(current_node=scheduler_nodes[0], nodes=scheduler_nodes),
            is_unspec_arg=lambda name: False, get_allocation_size=lambda node: node.get_size(),
        )
        self.wrapper = PythonWrapperCodegen.__new__(PythonWrapperCodegen)
        self.wrapper._multistream_alignment_copies = set()
        test.enterContext(V.set_graph_handler(self.graph))
        self.allocate_temp = AllocateLine(self.wrapper, self.temp)
        self.graph.scheduler.current_node = scheduler_nodes[1]
        self.allocate_output = AllocateLine(self.wrapper, self.output)
        self.first = self.call("first", (self.activation,), self.temp)
        self.second = self.call("second", (self.temp, self.weight), self.output)
        self.free_activation = FreeLine(self.wrapper, self.activation)
        self.wrapper.lines = [
            EnterDeviceContextManagerLine(0, None), self.allocate_temp,
            InputAlignmentLine("activation"), self.first, self.free_activation,
            self.allocate_output, InputAlignmentLine("weight"), self.second,
            FreeLine(self.wrapper, self.temp), FreeLine(self.wrapper, self.weight),
            ExitDeviceContextManagerLine(),
        ]
        # The unchanged handoff separately proves real AOT placeholder association.
        kinds = {"activation": "activation", "weight": "input_alias", "width": "scalar"}
        self.saved = FinalSavedInputs(names, SavedActivations(tuple(
            BackwardInput(index, name, kinds[name]) for index, name in enumerate(names)
        )))
        self.records = self.wrapper.collect_cudagraph_call_records()
        test.assertIsNotNone(self.records)
        test.assertEqual(self.records.version, 4)

    def computation(self, name, inputs):
        def body(index):
            offset = index[0] * self.extent + index[1]
            left = ops.load(inputs[0], offset)
            right = ops.load(inputs[1], offset) if len(inputs) == 2 else ops.constant(1, self.layout.dtype)
            return ops.sin(ops.add(left, right))
        data = ir.Pointwise(device=self.layout.device, dtype=self.layout.dtype,
                            inner_fn=body, ranges=self.layout.size)
        return ir.ComputedBuffer(name=name, layout=self.layout, data=data)

    def call(self, name, inputs, output):
        buffers = (*inputs, output)
        formals = tuple(f"ptr{index}" for index in range(len(buffers))) + ("xnumel",)
        values = tuple(node.get_name() for node in buffers) + (32 * self.extent,)
        signatures = tuple(TensorArg(formal, node.get_name(), torch.float32)
                           for formal, node in zip(formals, buffers)) + (SizeArg("xnumel", 32 * self.extent),)
        return KernelCallLine(
            self.wrapper, name, values, (), (), [], True,
            {"signature": dict(zip(formals, ("*fp32",) * len(buffers) + ("i32",))), "constants": {}},
            {"grid_type": "Grid1D", "cudagraph_formal_indices": dict(zip(formals, range(len(formals)))),
             "cudagraph_parameter_provenance": {
                 formal: (node.get_name(), node is output, 16) for formal, node in zip(formals, buffers)}},
            self.layout.device, self.graph.name, name,
            cudagraph_args=tuple(TritonCallArgument(ArgName(formal), signature)
                                 for formal, signature in zip(formals, signatures, strict=True)),
        )

    def collect(self):
        return schedule.collect_release_schedule(self.saved, self.wrapper, self.records)

    def example_inputs(self, width=13, *, device="meta"):
        values = {"width": width, "activation": torch.empty_strided((32, width), (width, 1), device=device),
                  "weight": torch.empty_strided((32, width), (width, 1), device=device)}
        return [values[name] for name in self.records.input_names]


def _symbolic_call(args):
    activation, width, weight = args
    args.clear()
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        temp = empty_strided_cuda((32, width), (width, 1), torch.float32)
        activation = copy_if_misaligned(activation)
        first.run(activation, temp, 32 * width, stream=get_raw_stream(0))
        del activation
        output = empty_strided_cuda((32, width), (width, 1), torch.float32)
        weight = copy_if_misaligned(weight)
        second.run(temp, weight, output, 32 * width, stream=get_raw_stream(0))
    return (output,)


class TestSymbolicReleaseSchedule(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())
        self.enterContext(config.patch(cudagraph_saved_input_schedule=False))

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    @parametrize("integer_first", (False, True))
    def test_live_v4_preserves_full_box_expressions_and_early_drop(self, integer_first):
        fixture = SymbolicCompilerFixture(self, integer_first=integer_first)
        guards = tuple(fixture.graph.sizevars.shape_env.guards)
        result = fixture.collect()
        self.assertIsNotNone(result)
        extent = IntExpr("boxed", fixture.integer_index)
        self.assertEqual(result.input_names, fixture.records.input_names)
        self.assertEqual(result.input_uses[fixture.integer_index], ())
        self.assertEqual(result.input_uses[fixture.activation_index], (0,))
        self.assertEqual(result.input_uses[fixture.weight_index], (1,))
        self.assertEqual(result.steps, (
            fixture.records.allocations[0], AlignmentCopy(fixture.activation_index, 0), fixture.records.calls[0],
            schedule.DropInput(fixture.activation_index, 0), fixture.records.allocations[1],
            AlignmentCopy(fixture.weight_index, 1), fixture.records.calls[1],
        ))
        self.assertEqual(tuple((layout.size, layout.stride) for layout in fixture.records.allocations),
                         (((32, extent), (extent, 1)),) * 2)
        for call in fixture.records.calls:
            self.assertEqual(call.arguments[-1].source, ExpressionSource(pointwise_product((32, extent))))
        self.assertEqual(tuple(fixture.graph.sizevars.shape_env.guards), guards)

    def test_v4_metadata_and_retained_roundtrip_keep_only_data(self):
        fixture = SymbolicCompilerFixture(self)
        metadata = collect_metadata(fixture.wrapper, fixture.records)
        self.assertIsNotNone(metadata)
        metadata = replace(metadata, release_schedule=fixture.collect())
        _check_metadata(metadata, fixture.records)
        artifact, _ = static_metadata_fixture.load_source(fixture.records, metadata)
        _, restored = read_metadata(artifact)
        self.assertEqual(restored, metadata)
        self.assertEqual(reconstruct_ir(restored.retained_ir).records, fixture.records)
        pending = [restored]
        while pending:
            value = pending.pop()
            if is_dataclass(value):
                pending.extend(getattr(value, field.name) for field in fields(value))
            elif type(value) is tuple:
                pending.extend(value)
            else:
                self.assertIn(type(value), (str, int, bool, type(None), torch.dtype))

    @parametrize("frontend", ("fx", "retained"))
    def test_symbolic_readers_preserve_expressions_at_two_hints(self, frontend):
        fixture = SymbolicCompilerFixture(self)
        metadata = collect_metadata(fixture.wrapper, fixture.records)
        retained = retain_wrapper(fixture.wrapper, fixture.records)
        kernels = frontend_readers_fixture.selections(retained)
        programs = []
        for width in (13, 31):
            if frontend == "fx":
                trace = trace_generated_fx(_symbolic_call, metadata.inputs, fixture.example_inputs(width), kernels)
                program = lower_fx(trace, record_version=fixture.records.version)
            else:
                program = bind_selected(reconstruct_ir(metadata.retained_ir), kernels).program
            programs.append(program)
            self.assertEqual(program.records.version, 4)
            self.assertEqual(tuple(row.boxed_index for row in program.records.integer_inputs), (1,))
            self.assertEqual(tuple((layout.size, layout.stride) for layout in program.records.allocations),
                             tuple((layout.size, layout.stride) for layout in fixture.records.allocations))
            self.assertEqual(tuple(call.arguments[-1].source for call in program.records.calls),
                             tuple(call.arguments[-1].source for call in fixture.records.calls))
            self.assertEqual(tuple(type(event) for event in program.events),
                             (Allocate, Normalize, Invoke, Allocate, Normalize, Invoke))
        self.assertEqual(programs[0], programs[1])

    def test_integer_candidate_cannot_become_a_reference_drop(self):
        fixture = SymbolicCompilerFixture(self)
        self.assertIsNotNone(fixture.collect())
        rows = list(fixture.saved.classification.inputs)
        rows[fixture.integer_index] = replace(rows[fixture.integer_index], kind="activation")
        fixture.saved = replace(fixture.saved, classification=SavedActivations(tuple(rows)))
        self.assertIsNone(fixture.collect())

    @parametrize("after_call", (-1, 0))
    def test_integer_drop_is_rejected_even_with_empty_pointer_uses(self, after_call):
        fixture = SymbolicCompilerFixture(self)
        original = fixture.collect()
        _check_release_schedule(original, fixture.records)
        changed = replace(original, steps=(schedule.DropInput(fixture.integer_index, after_call), *original.steps))
        with self.assertRaisesRegex(MetadataDeclined, "boxed integer"):
            _check_release_schedule(changed, fixture.records)

    @parametrize("damage", ("boxed_origin", "constant_scalar", "constant_stride", "symbol_name"))
    def test_records_cannot_replace_the_live_symbolic_source(self, damage):
        fixture = SymbolicCompilerFixture(self)
        self.assertIsNotNone(fixture.collect())
        records = fixture.records
        if damage in ("boxed_origin", "constant_scalar"):
            call = records.calls[0]
            expression = IntExpr("boxed", fixture.weight_index) if damage == "boxed_origin" else IntExpr("constant", 416)
            argument = replace(call.arguments[-1], source=ExpressionSource(expression))
            records = replace(records, calls=(replace(call, arguments=(*call.arguments[:-1], argument)), records.calls[1]))
        elif damage == "constant_stride":
            layout = replace(records.allocations[0], stride=(13, 1))
            records = replace(records, allocations=(layout, records.allocations[1]))
        else:
            records = replace(records, integer_inputs=(replace(records.integer_inputs[0], symbol="other"),))
        self.assertIsNone(schedule.collect_release_schedule(fixture.saved, fixture.wrapper, records))

    def test_unexpected_live_collector_failure_propagates(self):
        fixture = SymbolicCompilerFixture(self)
        error = RuntimeError("unexpected symbolic collector failure")
        with mock.patch.object(PythonWrapperCodegen, "collect_cudagraph_call_records", side_effect=error), \
                self.assertRaisesRegex(RuntimeError, "unexpected symbolic collector failure") as caught:
            fixture.collect()
        self.assertIs(caught.exception, error)

    def test_optional_transport_passes_exact_v4_records_to_live_collection(self):
        fixture = SymbolicCompilerFixture(self)
        metadata = collect_metadata(fixture.wrapper, fixture.records)
        expected = fixture.collect()
        # Real callback association has separate coverage; isolate this version gate.
        origin = AOTInputOrigins(None, None, (), (), (), fixture.saved.classification)
        fixture.graph.module = SimpleNamespace(meta={transport.ORIGIN_KEY: origin})
        with mock.patch.object(transport, "eligible", return_value=True), \
                mock.patch.object(transport, "collect_saved_inputs", return_value=fixture.saved) as join, \
                mock.patch.object(transport, "collect_release_schedule", wraps=schedule.collect_release_schedule) as collect:
            result = transport.collect_optional_schedule(fixture.wrapper, fixture.records, metadata)
        self.assertEqual(result, expected)
        join.assert_called_once_with(origin, fixture.wrapper, fixture.records, metadata)
        collect.assert_called_once_with(fixture.saved, fixture.wrapper, fixture.records)


instantiate_parametrized_tests(TestSymbolicReleaseSchedule)


if __name__ == "__main__":
    run_tests()
