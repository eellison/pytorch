# Dynamic saved-input release candidate

This extends optional backward saved-input release to symbolic allocation sizes.
It builds on the static native release implementation and the FX/retained reader
projection in `../frontend_release`. Work here is an isolated candidate.

The compiler keeps its actual symbolic layouts and scalar expressions, attaches
the original last-use release schedule, and excludes integer boxed inputs from
Tensor drops. Both readers use the existing complete event-order correspondence
check. Native replay evaluates current sizes before consuming the input box and
carries pending backing through the existing graph enqueue protocol. Allocation
claims use current byte sizes.

Current state: native build and CPU211/GPU23 qualification passed both audits.
See RESULTS.md. Direct numeric release is qualified; generated dynamic backward
requires the physical None-output support under output_slots/.

See `compiler_design.md`, `native_design.md`, and the exact source review receipts.
`qualification1` deliberately uses the previous native installation for CPU
compiler and constructor-bridge controls; it does not establish native dynamic
release support. qualification3 supplies the new native build and direct GPU evidence.
