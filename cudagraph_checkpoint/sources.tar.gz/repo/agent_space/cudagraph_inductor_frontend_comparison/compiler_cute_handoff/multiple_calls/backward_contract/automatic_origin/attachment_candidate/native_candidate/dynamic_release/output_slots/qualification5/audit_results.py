import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    review = json.loads((ROOT / "execution_review.json").read_text())
    manifest = json.loads((ROOT / "manifest.json").read_text())
    expected_sources = review["files"] | {str(ROOT / "execution_review.json"): digest(ROOT / "execution_review.json")}
    helpers = json.loads((ROOT / "run_cpu_helpers.json").read_text())
    pins, counts, results = {}, {}, {}
    for suite, directory in (("cpu", "cpu_attempt1"), ("public", "gpu_attempt1")):
        attempt = ROOT / "attempts" / directory
        result = json.loads((attempt / "result.json").read_text())
        sources = json.loads((attempt / "sources.json").read_text())
        if not all(result.get(key) is True for key in ("accepted", "sources_unchanged", "identities_checked")):
            raise RuntimeError("Execution did not pass: " + suite)
        if (result["exit_code"] != 0 or result["suite"] != suite
                or result["cuda_initialized"] is not (suite == "public")
                or sorted(row["id"] for row in result["cases"]) != sorted(review["cases"][suite])
                or any(row["result"] != "ok" for row in result["cases"])
                or sources != expected_sources):
            raise RuntimeError("Execution inventory or source association changed: " + suite)
        if (result["loaded_modules"] != {name: row["path"] for name, row in manifest["modules"].items()}
                or result["loaded_test_helpers"] != {name: row["path"] for name, row in helpers[suite].items()}
                or result["manifest_sha256"] != digest(ROOT / "manifest.json")
                or result["native_source"] != manifest["native"]["torch_python"]
                or result["native_extension"] != manifest["native"]["extension"]):
            raise RuntimeError("Loaded implementation differs from the candidate")
        for index, (path, sha) in enumerate(sources.items()):
            saved = attempt / "sources" / f"{index:03d}_{Path(path).name}"
            if digest(path) != sha or digest(saved) != sha:
                raise RuntimeError("Source snapshot changed: " + path)
        counts[suite] = len(result["cases"])
        results[suite] = result
        for path in (attempt / "result.json", attempt / "sources.json", ROOT / f"{directory}.log"):
            pins[str(path)] = digest(path)
    if counts != {"cpu": 252, "public": 44}:
        raise RuntimeError("Unexpected qualification counts")
    previous = json.loads((ROOT.parent / "qualification4/manifest.json").read_text())
    if manifest["modules"] != previous["modules"]:
        raise RuntimeError("Python modules changed during native qualification")
    dependencies = json.loads((ROOT / "gpu_dependencies.json").read_text())
    loaded_dependencies = {name: row["path"] for key in ("frontend_modules", "fixture_modules", "fixture_support_modules")
                           for name, row in dependencies[key].items()}
    for result in results.values():
        if result["loaded_dependencies"] != loaded_dependencies:
            raise RuntimeError("Execution did not load the qualified readers")
    build = json.loads((ROOT.parent / "evidence/build_result.json").read_text())
    if (not build["accepted"] or not build["source_restored"] or not build["previous_install_preserved"]
            or not build["native_parent_install_preserved"]
            or manifest["native"]["files"] != {str(ROOT.parent / "install_attempt1" / name): sha
                                               for name, sha in build["installed_native_hashes"].items()}):
        raise RuntimeError("Native qualification lacks the accepted isolated build")
    prerequisite = results["public"]["cpu_result"]
    if (Path(prerequisite["path"]) != ROOT / "attempts/cpu_attempt1/result.json"
            or prerequisite["sha256"] != digest(prerequisite["path"])):
        raise RuntimeError("GPU run lacks the matching CPU prerequisite")
    for path, sha in manifest["native"]["files"].items():
        if digest(path) != sha:
            raise RuntimeError("Native binary changed: " + path)
    bridge = [row for row in results["cpu"]["cases"] if row["id"].startswith("__main__.TestReleaseBridge.")]
    if len(bridge) != 10:
        raise RuntimeError("Missing release bridge cases")
    reports = []
    for line in (ROOT / "gpu_attempt1.log").read_text().splitlines():
        for marker in ("NATIVE_SAVED_RELEASE ", "NATIVE_FRONTEND_SAVED_RELEASE "):
            if marker in line:
                reports.append(json.loads(line.split(marker, 1)[1]))
    expected_reports = {(frontend, mode) for frontend in ("records", "fx", "retained")
                        for mode in ("release", "disabled", "retain_graph")}
    if len(reports) != 9 or {(row.get("frontend", "records"), row["mode"]) for row in reports} != expected_reports:
        raise RuntimeError("Missing generated backward release reports")
    for row in reports:
        if row.get("frontend", "records") != "records":
            if row["reader_version"] != 3 or row["reader_supplied_native_records"] is not True:
                raise RuntimeError("Reader did not supply actual static records to native replay")
        expected_hits = 6 if row["mode"] == "retain_graph" else 3
        if (row["backward_calls"] != 4 or row["native_backward_hits"] != expected_hits
                or len(row["observations"]) != expected_hits or row["watched_host_frames"]
                or row["native_entry"] != "_CUDAGraphBoxedReplay" or not row["closed"]
                or not row["held_outputs_correct_after_close"]
                or row["launchers"] != ["_FastCudaLauncher"] * 4):
            raise RuntimeError("Native generated backward contract did not pass")
        if row["mode"] == "disabled":
            if row["drops"] or row["early_output_pairs"] or row["observed_reuse"] or row["release_steps"] is not None:
                raise RuntimeError("Disabled replay received release work")
            continue
        if row["drops"] != [{"after_call": 1, "input_index": 3}] or [3, 1] not in row["early_output_pairs"]:
            raise RuntimeError("Actual saved-input last use changed")
        expected_calls = (1, 3, 5) if row["mode"] == "retain_graph" else (0, 1, 2)
        if row["observed_reuse"] != [[call, 3, 1] for call in expected_calls]:
            raise RuntimeError("Missing the observed later-output storage reuse")
        for index, call in enumerate(row["observations"]):
            inputs = {slot: (pointer, expired) for slot, pointer, expired in call["inputs"]}
            pointer, expired = inputs[3]
            retained = row["mode"] == "retain_graph" and index % 2 == 0
            if call["retain_graph"] != retained or expired == retained:
                raise RuntimeError("Saved activation lifetime differs from retain_graph")
            if (pointer == call["output_pointers"][1]) != (index in expected_calls):
                raise RuntimeError("Reported storage reuse differs from the actual pointers")
    numeric_reports = [json.loads(line.split("NUMERIC_RELEASE_CONTROL ", 1)[1])
                       for line in (ROOT / "gpu_attempt1.log").read_text().splitlines()
                       if "NUMERIC_RELEASE_CONTROL " in line]
    if (len(numeric_reports) != 5
            or {row.get("backing") for row in numeric_reports if "backing" in row} != {"matching", "larger"}
            or {row.get("fault") for row in numeric_reports if "fault" in row} !=
               {"integer_drop", "drop_before_use", "node_order"}):
        raise RuntimeError("Missing direct numeric-release controls")
    for row in numeric_reports:
        if "backing" in row:
            if (row["capture_size"] != 128 or row["initial_claim"] is not True
                    or row["held_outputs_after_close"] is not True
                    or [call["size"] for call in row["calls"]] != [257, 65, 512, 33]):
                raise RuntimeError("Dynamic size sequence or initial claim differs")
            for call in row["calls"]:
                matching = row["backing"] == "matching"
                if (call["claimed"] is not matching or call["output_bytes"] != call["size"] * 8
                        or call["backing_bytes"] != call["size"] * (8 if matching else 16)):
                    raise RuntimeError("Current byte-size claim control differs")
        elif not all(row[key] is True for key in
                     ("rejected_before_replay", "valid_dynamic_replay_claimed", "held_output_after_close")):
            raise RuntimeError("Cold rejection did not preserve a valid replay")
    slot_reports = [json.loads(line.split("NATIVE_OUTPUT_SLOTS ", 1)[1])
                    for line in (ROOT / "gpu_attempt1.log").read_text().splitlines()
                    if "NATIVE_OUTPUT_SLOTS " in line]
    if len(slot_reports) != 4 or {(row["numeric"], row["release"]) for row in slot_reports} != {
            (False, False), (False, True), (True, False), (True, True)}:
        raise RuntimeError("Missing native physical output-slot combinations")
    for row in slot_reports:
        expected_sizes = [128, 257, 33] if row["numeric"] else [128] * 3
        if (row["slots"] != [None, 1, None, 0, None] or not row["held_outputs_after_close"]
                or [call["size"] for call in row["calls"]] != expected_sizes
                or any(call["claimed"] is not row["release"] for call in row["calls"])):
            raise RuntimeError("Output-slot replay or actual reuse differs")
    dynamic_reports = [json.loads(line.split("DYNAMIC_FRONTEND_SAVED_RELEASE ", 1)[1])
                       for line in (ROOT / "gpu_attempt1.log").read_text().splitlines()
                       if "DYNAMIC_FRONTEND_SAVED_RELEASE " in line]
    if (len(dynamic_reports) != 9
            or {(row["frontend"], row["mode"]) for row in dynamic_reports} != expected_reports):
        raise RuntimeError("Missing real dynamic backward frontend/mode combinations")
    for row in dynamic_reports:
        hits = 8 if row["mode"] == "retain_graph" else 4
        if (row["reader_version"] != 4 or not row["selected_records_reached_native"]
                or row["outer_compilations"] != 1 or row["widths"] != [13, 2, 7, 35, 36]
                or row["native_backward_hits"] != hits or len(row["observations"]) != hits
                or row["watched_host_frames"] or row["native_entry"] != "_CUDAGraphBoxedReplay"
                or not row["closed"] or not row["held_outputs_correct_after_close"]
                or row["launchers"] != ["_FastCudaLauncher"] * row["backward_calls"]
                or len(row["integer_indices"]) != 1):
            raise RuntimeError("Real dynamic backward native contract differs")
        output_kinds = [name is None for name in row["output_names"]]
        if not any(output_kinds) or sum(not value for value in output_kinds) != 3:
            raise RuntimeError("Dynamic backward lacks complete physical gradient slots")
        integer_index, = row["integer_indices"]
        observed_reuse = []
        for index, call in enumerate(row["observations"]):
            retained = row["mode"] == "retain_graph" and index % 2 == 0
            width = (2, 7, 35, 36)[index // 2 if row["mode"] == "retain_graph" else index]
            if (call["retain_graph"] != retained or call["width"] != width
                    or call["integers"] != [[integer_index, width]]
                    or [pointer is None for pointer in call["output_pointers"]] != output_kinds
                    or call["output_shapes"] != [None if kind else [32, width] for kind in output_kinds]):
                raise RuntimeError("Physical output slots or dynamic integer correspondence differs")
            inputs = {slot: (pointer, expired) for slot, pointer, expired in call["inputs"]}
            for drop in row["drops"]:
                if inputs[drop["input_index"]][1] is retained:
                    raise RuntimeError("Saved input lifetime differs from retain_graph")
            for input_index, output_index in row["early_output_pairs"]:
                pointer, expired = inputs[input_index]
                if pointer == call["output_pointers"][output_index]:
                    if not expired or retained:
                        raise RuntimeError("Storage was reused before its owner expired")
                    observed_reuse.append([index, input_index, output_index])
        if observed_reuse != row["observed_reuse"] or bool(observed_reuse) != row["reuse_observed"]:
            raise RuntimeError("Reported reuse does not match observed pointers")
        if row["mode"] == "disabled":
            if row["drops"] or row["early_output_pairs"] or row["release_steps"] is not None or observed_reuse:
                raise RuntimeError("Disabled release received a schedule")
        elif not row["drops"] or not row["early_output_pairs"] or row["release_steps"] is None:
            raise RuntimeError("Enabled release did not retain compiler last-use drops")
    for name in ("manifest.json", "execution_review.json", "run_cpu_helpers.json", "audit_results.py"):
        pins[str(ROOT / name)] = digest(ROOT / name)
    result = {
        "accepted": True, "counts": counts, "source_files": len(expected_sources),
        "saved_copies_checked": len(expected_sources) * 2, "native_changed": True,
        "scope": "Native physical Tensor/None outputs and real V4 dynamic generated backward through records, FX and retained IR, with optional release, disabled release and retained-graph controls. No new performance or peak-memory claim.",
        "files": pins, "bridge_cases": bridge, "native_release_reports": reports, "numeric_release_reports": numeric_reports,
        "slot_reports": slot_reports, "dynamic_reports": dynamic_reports,
    }
    (ROOT / "evidence_review.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("accepted", "counts", "source_files", "native_changed")}))


if __name__ == "__main__":
    main()
