import handoff_cpu_fixture
from torch.testing._internal.common_utils import run_tests


class TestInductorHandoff(handoff_cpu_fixture.TestInductorHandoff):
    pass


if __name__ == "__main__":
    run_tests()
