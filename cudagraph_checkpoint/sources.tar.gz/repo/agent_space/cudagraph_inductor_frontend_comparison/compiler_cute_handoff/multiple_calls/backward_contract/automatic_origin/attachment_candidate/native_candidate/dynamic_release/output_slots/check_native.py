import ast
import inspect
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from build_native import digest, ROOT, write


def proof():
    evidence = ROOT / "evidence"
    manifest = json.loads((evidence / "source_manifest.json").read_text())
    build = json.loads((evidence / "build_result.json").read_text())
    if (not build["accepted"] or not build["source_restored"] or not build["previous_install_preserved"]
            or not build["native_parent_install_preserved"]
            or build["manifest_sha256"] != digest(evidence / "source_manifest.json")
            or os.environ.get("CUDA_VISIBLE_DEVICES") != "" or "torch" in sys.modules):
        raise RuntimeError("Expected an accepted build and fresh CPU-only import")
    source, target = Path(manifest["source_root"]), Path(manifest["install_root"])
    for name, sha in manifest["source_files"].items():
        path = ROOT / "source_delta" / name if name in manifest["delta_files"] else source / name
        if digest(path) != sha:
            raise RuntimeError("Native build source changed: " + name)
    for name, sha in manifest["base_source_files"].items():
        if digest(source / name) != sha:
            raise RuntimeError("Accepted source was not restored: " + name)
    for name in manifest["restored_absent_files"]:
        if (source / name).exists() or (source / name).is_symlink():
            raise RuntimeError("New native header was not removed: " + name)
    for name, sha in manifest["scaffold_hashes"].items():
        if digest(ROOT / name) != sha:
            raise RuntimeError("Native build scaffold changed: " + name)
    for name, sha in manifest["native_review_hashes"].items():
        if digest(ROOT / name) != sha:
            raise RuntimeError("Frozen native review changed: " + name)
    for name, sha in manifest["native_parent_receipts"].items():
        if digest(Path(name)) != sha:
            raise RuntimeError("Qualified parent receipt changed after build: " + name)
    for name, sha in manifest["native_parent_install_hashes"].items():
        if digest(Path(manifest["native_parent_install_root"]) / name) != sha:
            raise RuntimeError("Qualified parent installation changed after build: " + name)
    for name, sha in build["installed_native_hashes"].items():
        if digest(target / name) != sha:
            raise RuntimeError("Native library changed after build: " + name)
    for name, sha in build["generated_source_hashes"].items():
        if digest(evidence / "generated_source" / name) != sha:
            raise RuntimeError("Saved generated source changed: " + name)
    if digest(target / "torch/version.py") != build["installed_version_sha256"]:
        raise RuntimeError("Installed version source changed")

    import torch
    import torchgen

    if (Path(torch.__file__) != source / "torch/__init__.py"
            or not Path(torch._C.__file__).is_relative_to(target)
            or Path(torchgen.__file__) != source / "torchgen/__init__.py"
            or torch.version.git_version != manifest["head"] or torch.cuda.is_initialized()):
        raise RuntimeError("Unexpected Python/native import identity")
    bindings = {}
    for owner, names in ((torch._C, ("_cuda_make_boxed_dispatch",)),
                         (torch._C._CUDAGraph, ("_make_boxed_replay",)),
                         (torch._C._CUDAGraphBoxedDispatch, ("__call__", "append", "invalidate", "close",
                                                           "_boxed_call", "closed", "failed", "invalidated"))):
        for name in names:
            value = getattr(owner, name)
            if isinstance(value, property):
                if value.fset is not None:
                    raise RuntimeError("Dispatcher state must be read-only")
                value = value.fget
            if not inspect.isbuiltin(getattr(value, "__func__", value)):
                raise RuntimeError("Replay entry is not native: " + name)
            bindings[owner.__name__ + "." + name] = type(value).__name__
    signature = torch._C._CUDAGraph._make_boxed_replay.__doc__.splitlines()[0]
    if not re.search(r"\brelease_plan: (?:object|typing\.Any) = None\)", signature):
        raise RuntimeError("Native boxed constructor lacks the final optional release_plan: " + signature)

    names = {Path(name).name for name in manifest["native_files"]}
    mapped = set()
    for line in Path("/proc/self/maps").read_text().splitlines():
        path = Path(line.rsplit(maxsplit=1)[-1])
        if path.name in names:
            if not path.is_relative_to(target):
                raise RuntimeError("Torch library escaped the native candidate: " + str(path))
            mapped.add(str(path))
    required = {str(target / name) for name in manifest["native_files"]
                if Path(name).name in {"_C.cpython-312-aarch64-linux-gnu.so", "libc10.so", "libc10_cuda.so",
                                      "libtorch.so", "libtorch_cpu.so", "libtorch_cuda.so", "libtorch_python.so"}}
    if not required <= mapped:
        raise RuntimeError("Required Torch libraries are not mapped")
    stub = target / "torch/_C/__init__.pyi"
    if digest(stub) != build["installed_stub_sha256"]:
        raise RuntimeError("Installed stub changed")
    tree = ast.parse(stub.read_text())
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    if not {"_CUDAGraph", "_CUDAGraphBoxedReplay", "_CUDAGraphBoxedDispatch"} <= classes.keys():
        raise RuntimeError("Native graph declarations were not installed")
    methods = [node for node in classes["_CUDAGraph"].body
               if isinstance(node, ast.FunctionDef) and node.name == "_make_boxed_replay"]
    expected_annotation = ast.parse(
        'tuple[tuple[tuple[Literal["allocate", "kernel", "drop"], _int], ...], tuple[_int, ...]] | None',
        mode="eval",
    ).body
    if (len(methods) != 1 or methods[0].args.args[-1].arg != "release_plan"
            or not isinstance(methods[0].args.defaults[-1], ast.Constant)
            or methods[0].args.defaults[-1].value is not None
            or ast.dump(methods[0].args.args[-1].annotation) != ast.dump(expected_annotation)):
        raise RuntimeError("Installed release_plan stub differs from the primitive tuple contract")

    output_indices = [argument for argument in methods[0].args.args if argument.arg == "output_indices"]
    output_annotation = ast.parse("tuple[_int | None, ...] | None", mode="eval").body
    if (len(output_indices) != 1
            or ast.dump(output_indices[0].annotation) != ast.dump(output_annotation)):
        raise RuntimeError("Installed output_indices stub differs from the physical output-slot contract")
    return_annotation = ast.parse("tuple[Tensor | None, ...]", mode="eval").body
    for name in ("_CUDAGraphBoxedReplay", "_CUDAGraphBoxedDispatch"):
        calls = [node for node in classes[name].body
                 if isinstance(node, ast.FunctionDef) and node.name == "__call__"]
        if len(calls) != 1 or ast.dump(calls[0].returns) != ast.dump(return_annotation):
            raise RuntimeError("Installed boxed return stub omits physical None slots: " + name)
    dispatch = [node for node in tree.body
                if isinstance(node, ast.FunctionDef) and node.name == "_cuda_make_boxed_dispatch"]
    miss_annotation = ast.parse(
        "Callable[[list[Tensor | _int]], tuple[Tensor | None, ...]]", mode="eval",
    ).body
    if (len(dispatch) != 1 or dispatch[0].args.args[-1].arg != "on_miss"
            or ast.dump(dispatch[0].args.args[-1].annotation) != ast.dump(miss_annotation)):
        raise RuntimeError("Installed miss-handler stub omits physical None slots")
    if torch.cuda.is_initialized():
        raise RuntimeError("Native import check initialized CUDA")
    return {
        "torch_python": torch.__file__, "torch_extension": torch._C.__file__, "torchgen": torchgen.__file__,
        "native_bindings": bindings, "release_plan_signature": signature,
        "output_indices_annotation": ast.unparse(output_annotation),
        "boxed_return_annotation": ast.unparse(return_annotation),
        "miss_handler_annotation": ast.unparse(miss_annotation),
        "installed_native_hashes": build["installed_native_hashes"],
        "installed_stub_sha256": build["installed_stub_sha256"],
        "installed_version_sha256": build["installed_version_sha256"],
        "native_libraries": sorted(mapped), "cuda_initialized": False,
        "source_manifest_sha256": digest(evidence / "source_manifest.json"),
    }


def main():
    current = proof()
    if sys.argv[1:] == ["--child"]:
        print(json.dumps(current))
        return
    if sys.argv[1:]:
        raise RuntimeError("Usage: check_native.py [--child]")
    child = subprocess.run([sys.executable, str(Path(__file__)), "--child"], text=True, capture_output=True)
    (ROOT / "evidence/import_child.stderr").write_text(child.stderr)
    if child.returncode or json.loads(child.stdout) != current:
        raise RuntimeError("Fresh child import does not match parent")
    result = {
        "accepted": True, "proof": current, "fresh_child": True,
        "checker_sha256": digest(Path(__file__)), "launcher_sha256": digest(ROOT / "python.sh"),
        "loader_sha256": digest(ROOT / "runtime_site/sitecustomize.py"),
    }
    write(ROOT / "evidence/fresh_import.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
