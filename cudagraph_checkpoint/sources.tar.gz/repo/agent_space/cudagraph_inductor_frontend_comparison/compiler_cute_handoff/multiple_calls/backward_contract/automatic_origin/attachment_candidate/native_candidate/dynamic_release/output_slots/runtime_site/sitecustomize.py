import importlib
import os
from pathlib import Path
import site
import sys


root = Path(__file__).resolve().parents[1]
repo = Path("/data/eellison/src/pytorch")
source = repo / "agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1/source"
target = root / "install_attempt1"
if (os.environ.get("LANDING_RUNTIME") != "new" or "torch" in sys.modules
        or os.environ.get("TORCH_WT") or os.environ.get("WT_PRELUDE")):
    raise SystemExit("Expected a fresh explicitly selected dispatcher runtime")
if not (target / "_editable_skbc_torch.pth").is_file():
    raise SystemExit("The selected native installation is not ready")
for finder in tuple(sys.meta_path):
    if type(finder).__name__ == "ScikitBuildRedirectingFinder" and "torch" in finder.known_source_files:
        sys.meta_path.remove(finder)
        sys.modules.pop(type(finder).__module__, None)
sys.path[:] = [path for path in sys.path if path not in (str(repo), str(target))]
sys.path.insert(0, str(target))
importlib.invalidate_caches()
site.addsitedir(str(target))
finders = [finder for finder in sys.meta_path
           if type(finder).__name__ == "ScikitBuildRedirectingFinder" and "torch" in finder.known_source_files]
if len(finders) != 1:
    raise SystemExit("Expected one isolated Torch editable finder")
finder = finders[0]
if (Path(finder.dir).resolve() != target or finder.rebuild_flag
        or finder.known_source_files["torch"] != str(source / "torch/__init__.py")
        or any(not Path(path).resolve().is_relative_to(source) for path in finder.known_source_files.values())
        or any(not (target / path).resolve().is_relative_to(target) for path in finder.known_wheel_files.values())):
    raise SystemExit("Editable source/native pairing escaped the selected candidate")
for paths in finder.submodule_search_locations.values():
    for path in paths:
        resolved = (target / path).resolve()
        if not resolved.is_relative_to(source) and not resolved.is_relative_to(target):
            raise SystemExit("Editable search path escaped the selected candidate")
