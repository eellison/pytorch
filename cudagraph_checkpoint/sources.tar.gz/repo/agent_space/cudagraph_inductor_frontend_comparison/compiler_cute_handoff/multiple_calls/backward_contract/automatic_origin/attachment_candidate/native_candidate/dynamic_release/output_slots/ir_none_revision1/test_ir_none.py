from dataclasses import replace
from types import FunctionType

import frontend_readers_fixture
import output_slots_fixture
import static_metadata_fixture
import sympy
import torch
from compiler_metadata_handoff.metadata import attach_metadata, collect_metadata, read_metadata
from fx_adapter.extraction import trace_generated_fx
from fx_adapter.lowering import lower_fx
from retained_ir.prototype import bind_selected, reconstruct_ir
from torch._inductor import config, ir
from torch._inductor.runtime.cudagraph_arg_mapping import bind_wrapper_allocations
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)


class OtherNone(ir.NoneAsConstantBuffer):
    pass


class TestIRNoneOutputSlots(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())
        self.enterContext(config.patch(cudagraph_saved_input_schedule=False))

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    @parametrize("version", (3, 4))
    @parametrize("frontend", ("fx", "retained"))
    def test_actual_none_ir_preserves_reader_slots(self, version, frontend):
        fixture = output_slots_fixture.TestCompilerOutputSlots.fixture(self, version)
        fixture.graph.graph_outputs = [ir.NoneAsConstantBuffer(), fixture.output, None, ir.NoneAsConstantBuffer()]
        records = fixture.wrapper.collect_cudagraph_call_records()
        self.assertIsNotNone(records)
        self.assertEqual(records, fixture.records)
        self.assertEqual(bind_wrapper_allocations(records), (records.allocations, (None, 1, None, None)))
        fixture.records = records
        release = fixture.collect()
        self.assertIsNotNone(release)
        self.assertIs(release.outputs, records.outputs)
        metadata = collect_metadata(fixture.wrapper, records)
        self.assertIsNotNone(metadata)
        metadata = replace(metadata, release_schedule=release)
        artifact, _ = static_metadata_fixture.load_source(records, metadata)
        _, restored = read_metadata(artifact)
        self.assertEqual(restored, metadata)
        retained = reconstruct_ir(restored.retained_ir)
        self.assertEqual(retained.records, records)
        kernels = frontend_readers_fixture.selections(retained)
        donor = output_slots_fixture._symbolic_slots if version == 4 else output_slots_fixture._static_slots
        namespace = {}
        function = FunctionType(donor.__code__, namespace, donor.__name__)
        namespace[function.__name__] = function
        function._cudagraph_call_records = records
        attach_metadata(function, metadata)
        examples = (fixture.example_inputs() if version == 4 else
                    [torch.empty_strided((32, 128), (128, 1), device="meta") for _ in range(2)])
        if frontend == "fx":
            trace = trace_generated_fx(function, metadata.inputs, examples, kernels, source_records=records)
            self.assertEqual(tuple(value is None for value in trace.outputs), (True, False, True, True))
            program = lower_fx(trace, record_version=version)
        else:
            program = bind_selected(retained, kernels).program
        self.assertEqual(program.records.version, version)
        self.assertEqual(bind_wrapper_allocations(program.records)[1], (None, 1, None, None))
        self.assertEqual(tuple((row.size, row.stride) for row in program.records.allocations),
                         tuple((row.size, row.stride) for row in records.allocations))
        self.assertEqual(program.records.integer_inputs, records.integer_inputs)

    @parametrize("version", (3, 4))
    @parametrize("damage", ("scalar_ir", "subclass", "all_none"))
    def test_other_ir_cannot_create_owned_output_slots(self, version, damage):
        fixture = output_slots_fixture.TestCompilerOutputSlots.fixture(self, version)
        self.assertIsNotNone(bind_wrapper_allocations(fixture.records))
        if damage == "scalar_ir":
            outputs = [ir.ShapeAsConstantBuffer(sympy.Integer(0)), fixture.output]
        elif damage == "subclass":
            outputs = [OtherNone(), fixture.output]
        else:
            outputs = [ir.NoneAsConstantBuffer(), None, ir.NoneAsConstantBuffer()]
        fixture.graph.graph_outputs = outputs
        records = fixture.wrapper.collect_cudagraph_call_records()
        if version == 4:
            self.assertIsNone(records)
        else:
            self.assertIsNotNone(records)
            self.assertIsNone(records.outputs)
            self.assertIsNone(bind_wrapper_allocations(records))


instantiate_parametrized_tests(TestIRNoneOutputSlots)

if __name__ == "__main__":
    run_tests()
