# Local FX cache checkpoint

**280 CPU and 11 CUDA tests pass**, with root and independent evidence audits. This is a focused extension of the earlier output-slots qualification (252 CPU / 44 CUDA); suite counts overlap.

Both generated-host FX and retained Inductor IR now restore a compiler-produced dynamic backward release schedule through a real local FX cache miss/save and subsequent hit/load. Each frontend uses two separate compiled artifacts, metadata attachments, policies and native entries. The first entry closes before the second compilation. Both entries warm at width 13 and replay at widths 2, 7, 35 and 36, preserving numerical gradients and held outputs after both entries close.

The compiler releases saved input 4 after kernel 1 and preserves the physical output tuple (None, buf3, buf2, buf0). The cache cases verify input storage expiry, exact reader records reaching native replay, symbolic allocations and no watched host Python frames on native hits. They do not measure pointer reuse or performance. The nine inherited dynamic controls separately cover release, disabled release and retained-graph behavior through original records, FX and retained IR.

Three cold compiler files changed. Live AOT graph provenance lives in a callback-scoped ContextVar. The cache key contains versioned primitive input positions, names, targets and classifications. Exact graph/placeholder identity is rechecked before lookup; stale provenance stays disabled for that compilation. Deserialization reconstructs the attachment for the actual loaded function. Native C++ replay and its binaries are unchanged.

Scope remains synchronous local FX caching with remote FX and local/remote AOT caches disabled. Forward remains ordinary Inductor in this workload. No new peak-memory or performance result is claimed. Qualification uses the pinned CUDA 13 / GB300 environment.

The first CPU attempt is preserved: 277 passed, with two fixture errors and one stale fixture failure. Three test setup corrections produced the passing second attempt without production changes.

- [Selected sources](qualification2/manifest.json)
- [Root audit](qualification2/evidence_review.json)
- [Independent audit](qualification2/evidence_independent_review.json)
- [CPU log](qualification2/cpu_attempt1.log)
- [CUDA log](qualification2/gpu_attempt1.log)
- [Preserved first attempt](qualification1/evidence_independent_review.json)
