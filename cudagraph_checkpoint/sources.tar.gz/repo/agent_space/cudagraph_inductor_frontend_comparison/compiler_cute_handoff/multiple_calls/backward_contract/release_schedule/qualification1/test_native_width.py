import generated_schedule_fixture
from torch.testing._internal.common_utils import run_tests


class TestGeneratedReleaseScheduleCUDA(generated_schedule_fixture.TestGeneratedReleaseScheduleCUDA):
    pass


if __name__ == "__main__":
    run_tests()
