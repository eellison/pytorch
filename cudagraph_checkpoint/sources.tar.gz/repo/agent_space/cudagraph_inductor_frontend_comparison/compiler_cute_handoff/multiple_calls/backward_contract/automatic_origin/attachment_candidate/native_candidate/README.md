# Optional saved-input release prototype

The isolated native build and static compiler-records integration are qualified: [CPU154/GPU12](qualification3/RESULTS.md), plus [four direct CUDA safety controls](controls_qualification2/RESULTS.md) on the same implementation. The [two stream/policy controls](streams_qualification1/RESULTS.md) also pass. See the [aggregate result](RESULTS.md); frontend release extensions are the next candidate.

The compiler attaches an optional immutable schedule for classified saved backward tensors. It preserves actual allocation, kernel and input-drop order. The cold Python bridge turns this into primitive tuples and associates actual captured nodes. Native construction checks complete linear graph dependencies and pointer-slot uses, then prepares the allocation/drop program.

During replay, normalization precedes pending-input protection. Only selected saved owners are dropped. The caching allocator observes actual final deleters; live owners or aliases naturally prevent a claim. Matching freed backing can satisfy a later allocation only when the native plan proves old uses precede new ones. Unclaimed backing remains protected through graph submission. Outputs are constructed after enqueue.

The feature is optional. This qualified increment is static V3 through compiler records, with fresh compilation/caches disabled and supported native caching-allocator policy. Existing FX/retained frontend replay remains supported without release. The [next frontend plan](next_frontend_release.md) separates their static integration from symbolic V4 metadata and native numeric release.

Source and evidence:

- [Eight native C++/header/stub files](native_source_review.json), [independent native source review](native_source_independent_review.json), and [native diff](native.diff).
- [Three cold Python bridge files](python_source_independent_review.json).
- [Selected Python/native manifest](qualification3/manifest.json).
- [Build/import result](evidence/build_result.json) and [independent build audit](evidence/build_independent_review.json).

The build uses a separate installation at `install_attempt1`, reuses the locked incremental build directory, and restores the prior source contents. The current qualification launchers select that exact installation and the explicit frontend source manifest. No source has been committed or submitted upstream.
