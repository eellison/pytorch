import activation_schedule_fixture
from torch.testing._internal.common_utils import run_tests


class TestActivationReleaseSchedule(activation_schedule_fixture.TestActivationReleaseSchedule):
    pass


if __name__ == "__main__":
    run_tests()
