import dynamic_frontend_release_fixture
import local_fx_cache_fixture
from torch.testing._internal.common_utils import run_tests


class TestDynamicFrontendSavedReleaseCUDA(dynamic_frontend_release_fixture.TestDynamicFrontendSavedReleaseCUDA):
    pass


class TestLocalFXSavedReleaseCUDA(local_fx_cache_fixture.TestLocalFXSavedReleaseCUDA):
    pass


if __name__ == "__main__":
    run_tests()
