import copy
from dataclasses import asdict, replace
import gc
import json
from unittest import mock
import weakref

import torch
from torch._functorch._aot_autograd.descriptors import SavedForBackwardsAOTOutput, TangentAOTInput
from torch._inductor.compile_fx import fake_tensor_prop
from torch._subclasses.fake_tensor import FakeTensor
from torch.fx import GraphModule
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)

import backward_classification_fixture as fixture
from classification import ClassificationDeclined, classify_saved_activations
from origins import capture_forward_origins, join_backward_origins


class TestCompactForwardOrigins(TestCase):
    def capture(self, *, dynamic=False, propagate=False, donated=False, retained=False):
        class CompactCapture(fixture.CallbackCapture):
            def __init__(self):
                super().__init__()
                self.origins = None
                self.compact = None
                self.before = ()
                self.after = ()

            def compile_forward(self, graph, examples):
                self.origins = capture_forward_origins(graph)
                # The graph copy belongs only to the independent test oracle.
                oracle = GraphModule(graph, copy.deepcopy(graph.graph))
                boxed = super().compile_forward(graph, examples)
                self.forward = oracle
                self.before = tuple(node.meta.get("val") for node in graph.graph.nodes)
                if propagate:
                    with torch.no_grad():
                        fake_tensor_prop(graph, examples)
                self.after = tuple(node.meta.get("val") for node in graph.graph.nodes)
                return boxed

            def compile_backward(self, graph, examples):
                self.compact = join_backward_origins(self.origins, graph)
                return super().compile_backward(graph, examples)

        with mock.patch.object(fixture, "CallbackCapture", CompactCapture):
            return fixture.TestSavedActivationClassification.capture(
                self, dynamic=dynamic, donated=donated, retained=retained,
            )

    @parametrize("dynamic", (False, True))
    @parametrize("propagate", (False, True))
    def test_real_callbacks_match_original_classifier(self, dynamic, propagate):
        capture, _ = self.capture(dynamic=dynamic, propagate=propagate)
        self.assertEqual(capture.compact, capture.provenance)
        self.assertTrue(capture.compact.candidate_indices)
        self.assertIn("input_alias", {row.kind for row in capture.compact.inputs})
        self.assertIn("output_alias", {row.kind for row in capture.compact.inputs})
        self.assertTrue(all(type(row.value) is FakeTensor for row in capture.origins.saved))
        if propagate:
            self.assertTrue(any(isinstance(before, torch.Tensor) and before is not after
                                for before, after in zip(capture.before, capture.after, strict=True)))
        decoded = json.loads(json.dumps(asdict(capture.compact)))
        self.assertEqual(len(decoded["inputs"]), len(capture.provenance.inputs))

    def test_donation_and_retained_backward_do_not_define_origins(self):
        donated, donation = self.capture(donated=True)
        retained, no_donation = self.capture(retained=True)
        self.assertTrue(donation[0])
        self.assertEqual(no_donation, [])
        self.assertEqual(len(retained.backward_boxes), 2)
        self.assertEqual(donated.compact, retained.compact)
        self.assertEqual(retained.compact, retained.provenance)

    def test_forward_replacements_cannot_change_captured_origins(self):
        capture, _ = self.capture()
        forward, backward = copy.deepcopy((capture.forward, capture.backward))
        self.assertEqual(classify_saved_activations(forward, backward), capture.provenance)
        row = next(row for row in capture.provenance.inputs if row.kind == "activation")
        output = next(node for node in forward.graph.nodes if node.op == "output")
        saved = output.args[0][row.forward_output]
        placeholder = tuple(node for node in backward.graph.nodes if node.op == "placeholder")[row.boxed_index]
        placeholder.meta = saved.meta
        self.assertEqual(classify_saved_activations(forward, backward), capture.provenance)
        original_metadata = placeholder.meta
        origins = capture_forward_origins(forward)
        self.assertIsNot(saved.meta, original_metadata)
        self.assertIs(placeholder.meta, original_metadata)
        saved.meta["val"] = object()
        output.meta["desc"] = None
        self.assertEqual(join_backward_origins(origins, backward), capture.provenance)

    def test_compact_origins_do_not_keep_forward_graph_or_nodes(self):
        capture, _ = self.capture()
        forward = GraphModule(capture.forward, copy.deepcopy(capture.forward.graph))
        module_ref, graph_ref = weakref.ref(forward), weakref.ref(forward.graph)
        node_refs = tuple(weakref.ref(node) for node in forward.graph.nodes)
        origins = capture_forward_origins(forward)
        self.assertEqual(join_backward_origins(origins, capture.backward), capture.provenance)
        del forward
        gc.collect()
        self.assertIsNone(module_ref())
        self.assertIsNone(graph_ref())
        self.assertTrue(all(reference() is None for reference in node_refs))
        self.assertEqual(join_backward_origins(origins, capture.backward), capture.provenance)

    @parametrize("damage", ("descriptors", "ordinal", "opaque_input", "mutation"))
    def test_invalid_forward_declines_without_detaching_metadata(self, damage):
        capture, _ = self.capture()
        forward, backward = copy.deepcopy((capture.forward, capture.backward))
        self.assertEqual(classify_saved_activations(forward, backward), capture.provenance)
        output = next(node for node in forward.graph.nodes if node.op == "output")
        if damage == "descriptors":
            output.meta.pop("desc")
            message = "complete final AOT output descriptors"
        elif damage == "ordinal":
            row = next(row for row in capture.provenance.inputs if row.kind == "activation")
            descriptors = list(output.meta["desc"])
            descriptors[row.forward_output] = SavedForBackwardsAOTOutput(-1)
            output.meta["desc"] = descriptors
            message = "ordinals are not canonical"
        elif damage == "opaque_input":
            next(node for node in forward.graph.nodes if node.op == "placeholder").meta["val"] = object()
            message = "opaque boundary storage provenance"
        else:
            next(node for node in forward.graph.nodes if node.op == "call_function").target = torch.ops.aten.transpose_.default
            message = "Metadata mutation"
        nodes = tuple(forward.graph.nodes)
        metadata = tuple(node.meta for node in nodes)
        with self.assertRaisesRegex(ClassificationDeclined, message):
            capture_forward_origins(forward)
        for node, saved in zip(nodes, metadata, strict=True):
            self.assertIs(node.meta, saved)

    @parametrize("damage", ("name", "same_storage_view", "value", "real_tensor", "tangent", "mutation"))
    def test_changed_backward_authority_declines(self, damage):
        capture, _ = self.capture()
        forward, backward = copy.deepcopy((capture.forward, capture.backward))
        self.assertEqual(classify_saved_activations(forward, backward), capture.provenance)
        origins = capture_forward_origins(forward)
        self.assertEqual(join_backward_origins(origins, backward), capture.provenance)
        row = next(row for row in capture.provenance.inputs if row.kind == "activation")
        placeholder = tuple(node for node in backward.graph.nodes if node.op == "placeholder")[row.boxed_index]
        message = "identity/name association"
        if damage == "name":
            placeholder.name += "_changed"
        elif damage == "same_storage_view":
            value = placeholder.meta["val"]
            with value.fake_mode:
                placeholder.meta["val"] = value.view_as(value)
            self.assertIsNot(placeholder.meta["val"], value)
            self.assertEqual(placeholder.meta["val"].untyped_storage()._cdata, value.untyped_storage()._cdata)
        elif damage == "value":
            placeholder.meta.pop("val")
            message = "Missing final AOT value metadata"
        elif damage == "real_tensor":
            placeholder.meta["val"] = torch.empty(3, 4)
            message = "storage provenance"
        elif damage == "tangent":
            tangent = next(node for node in backward.graph.nodes if type(node.meta.get("desc")) is TangentAOTInput)
            placeholder.meta["desc"] = tangent.meta["desc"]
            message = "unexpectedly joined a tangent"
        else:
            next(node for node in backward.graph.nodes if node.op == "call_function").target = torch.ops.aten.transpose_.default
            message = "Metadata mutation"
        with self.assertRaisesRegex(ClassificationDeclined, message):
            join_backward_origins(origins, backward)

    def test_backward_output_alias_remains_excluded(self):
        capture, _ = self.capture()
        forward, backward = copy.deepcopy((capture.forward, capture.backward))
        self.assertEqual(classify_saved_activations(forward, backward), capture.provenance)
        origins = capture_forward_origins(forward)
        row = next(row for row in capture.provenance.inputs if row.kind == "activation")
        placeholder = tuple(node for node in backward.graph.nodes if node.op == "placeholder")[row.boxed_index]
        output = next(node for node in backward.graph.nodes if node.op == "output")
        output.args = ((*output.args[0], placeholder),)
        actual = join_backward_origins(origins, backward)
        self.assertEqual(actual, classify_saved_activations(forward, backward))
        self.assertEqual(actual.inputs[row.boxed_index].kind, "output_alias")

    def test_saved_storage_identity_is_checked(self):
        capture, _ = self.capture()
        origins = capture.origins
        first = origins.saved[0]
        other = next(row for row in origins.saved if row.storage != first.storage)
        damaged = replace(origins, saved=(replace(first, storage=other.storage), *origins.saved[1:]))
        with self.assertRaisesRegex(ClassificationDeclined, "storage changed after forward capture"):
            join_backward_origins(damaged, capture.backward)


instantiate_parametrized_tests(TestCompactForwardOrigins)


if __name__ == "__main__":
    run_tests()
