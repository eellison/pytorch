from dataclasses import asdict
import json
import sys
import traceback
from unittest import mock

import torch
from compiler_metadata_handoff import metadata as generated_metadata
from torch._functorch import config as aot_config
from torch._functorch.aot_autograd import aot_module
from torch._inductor import config
from torch._inductor.compile_fx import compile_fx_inner
from torch._inductor.output_code import CompiledFxGraph
from torch._inductor.runtime.cudagraph_arg_mapping import InputSource
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import run_tests, TestCase

from handoff import capture_aot_inputs, collect_saved_inputs


class SavedSine(torch.nn.Module):
    def __init__(self, device):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.linspace(0.5, 1.0, 4096, device=device).reshape(32, 128))

    def forward(self, value):
        return value.sin() * self.weight


class TestGeneratedBackward(TestCase):
    def test_final_box_provenance(self, device):
        model = SavedSine(device)
        value = torch.linspace(-0.8, 0.9, 4096, device=device).reshape(32, 128).requires_grad_()
        expected_value = value.detach().clone().requires_grad_()
        expected_weight = model.weight.detach().clone().requires_grad_()
        forward_graph = None
        forward_storage = ()
        compilations = [0, 0]
        final_rows = []
        backward_boxes = []
        generated_boxes = []
        record_sources = []
        collect = generated_metadata.collect_metadata

        def compile_forward(graph, examples):
            nonlocal forward_graph
            forward_graph = graph
            compilations[0] += 1

            # Keep original AOT metadata intact: only backward uses Inductor here.
            def boxed(args):
                nonlocal forward_storage
                self.assertIs(type(args), list)
                result = graph.forward(*args)
                forward_storage = tuple(StorageWeakRef(item.untyped_storage()).cdata
                                        if isinstance(item, torch.Tensor) else None for item in result)
                return result

            boxed._boxed_call = True
            return boxed

        def compile_backward(graph, examples):
            compilations[1] += 1
            origin = capture_aot_inputs(forward_graph, graph)
            self.assertIsNotNone(origin)

            def collect_final(wrapper, records):
                metadata = collect(wrapper, records)
                result = collect_saved_inputs(origin, wrapper, records, metadata)
                self.assertIsNotNone(result, "Expected supported final static backward metadata")
                self.assertTrue(result.candidate_indices)
                self.assertEqual(result.input_names, records.input_names)
                self.assertEqual(metadata.inputs.kinds, ("tensor",) * len(result.input_names))
                sources = tuple(arg.source.index for call in records.calls for arg in call.arguments
                                if type(arg.source) is InputSource)
                self.assertTrue(set(result.candidate_indices).issubset(sources))
                final_rows.append(result)
                record_sources.append(sources)
                return metadata

            with mock.patch.object(generated_metadata, "collect_metadata", side_effect=collect_final):
                artifact = compile_fx_inner(graph, examples, is_backward=True, is_inference=False)
            self.assertIs(type(artifact), CompiledFxGraph)
            original = artifact._cudagraph_original_callable
            code = original.__code__
            self.assertEqual(len(final_rows), 1)
            self.assertIs(original._cudagraph_frontend_metadata.inputs,
                          original._cudagraph_frontend_attachment.metadata.inputs)
            self.assertEqual(original._cudagraph_call_records.input_names, final_rows[0].input_names)

            def boxed(args):
                self.assertIs(type(args), list)
                identities = tuple(id(item) for item in args)
                storage = tuple(StorageWeakRef(item.untyped_storage()).cdata for item in args)
                backward_boxes.append(storage)
                previous = sys.getprofile()
                failures = []
                observations = []

                def observe(frame, event, result):
                    if event != "call" or frame.f_code is not code:
                        return
                    try:
                        generated_args = frame.f_locals["args"]
                        self.assertIs(generated_args, args)
                        self.assertEqual(tuple(id(item) for item in generated_args), identities)
                        observations.append(tuple(StorageWeakRef(item.untyped_storage()).cdata
                                                  for item in generated_args))
                    except BaseException as error:
                        if not failures:
                            failures.append("".join(traceback.format_exception(error)))

                try:
                    sys.setprofile(observe)
                    try:
                        result = artifact(args)
                    finally:
                        sys.setprofile(previous)
                except BaseException as error:
                    for failure in failures:
                        error.add_note("Deferred backward-box observation failure:\n" + failure)
                    raise
                if failures:
                    self.fail(failures[0])
                self.assertEqual(observations, [storage])
                self.assertEqual(args, [])
                generated_boxes.extend(observations)
                return result

            boxed._boxed_call = True
            return boxed

        with aot_config.patch(donated_buffer=False, enable_autograd_cache=False), config.patch(
            graph_partition=False, cpp_wrapper=False, fx_graph_cache=False, force_disable_caches=True,
            allow_buffer_reuse=False, inplace_buffers=False,
            cudagraph_policy=None, use_static_triton_launcher=True, **{"triton.cudagraphs": False},
        ):
            compiled = aot_module(model, compile_forward, compile_backward, dynamic=False)
            actual = compiled(value)
            expected = expected_value.sin() * expected_weight
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            actual_grads = torch.autograd.grad(actual, (value, model.weight), tangent)
            expected_grads = torch.autograd.grad(expected, (expected_value, expected_weight), tangent)
            self.assertEqual(actual_grads, expected_grads)

        self.assertEqual(compilations, [1, 1])
        self.assertEqual(len(final_rows), 1)
        self.assertEqual(len(backward_boxes), 1)
        self.assertEqual(generated_boxes, backward_boxes)
        final = final_rows[0]
        excluded = {StorageWeakRef(item.untyped_storage()).cdata for item in (value, model.weight, tangent)}
        self.assertEqual(len(final.candidate_indices), 1)
        self.assertIn("input_alias", {row.kind for row in final.classification.inputs})
        self.assertIn("tangent", {row.kind for row in final.classification.inputs})
        for row in final.classification.inputs:
            observed = backward_boxes[0][row.boxed_index]
            if row.forward_output is not None:
                self.assertEqual(observed, forward_storage[row.forward_output])
            if row.kind == "activation":
                self.assertNotIn(observed, excluded)
            if observed in excluded:
                self.assertNotIn(row.boxed_index, final.candidate_indices)
        print("BACKWARD_HANDOFF " + json.dumps({
            "scope": "eager AOT forward; generated static unpartitioned backward; no release",
            "compilations": compilations, "final": asdict(final),
            "recorded_input_sources": record_sources[0], "same_box_and_order": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestGeneratedBackward, globals(), only_for=("cuda",))


if __name__ == "__main__":
    run_tests()
