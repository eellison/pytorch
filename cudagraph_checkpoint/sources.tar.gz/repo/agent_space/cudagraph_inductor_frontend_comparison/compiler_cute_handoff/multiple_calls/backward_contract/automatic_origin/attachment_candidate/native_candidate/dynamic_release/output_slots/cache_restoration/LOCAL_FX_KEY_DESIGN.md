# Local FX cache key for saved-input schedules

Source-only proposal. No framework imports, tests, builds, or production edits.

## Minimal representation

Keep the current live `AOTInputOrigins` for exact source checking. It is not a
cache key. Use a versioned primitive tuple for the optional annotation:

```
("saved-input-origin", 1, names, targets,
 ((boxed_index, name, kind, forward_output, saved_index), ...))
```

These are the existing `SavedActivations.inputs` fields plus the exact ordered
placeholder names and targets. Include all classifications, not only candidate
indices: input/output aliases and tangents must not acquire activation semantics
because their graph shapes match. The representation contains no addresses,
FakeTensor/storage identities, GraphModule, Graph, or Node objects. Its version
must change if the classification/key contract changes.

Use an explicit no-origin value, for example
`("saved-input-origin", 1, None)`, when this compilation cannot attach a schedule.
Disabled compilation already differs through the normal Inductor config key;
it must never receive an eligible-origin discriminator. Different no-release
reasons may share a no-release key. They must not share an eligible key.

## Recommended transport change

1. Keep the live origin in one callback-scoped ContextVar. The backward callback
   installs it and resets its token in finally, preserving nested scope cleanup.
   Store only the primitive discriminator in the reserved gm.meta entry. The
   existing final cleanup restores absence of that entry.
2. Immediately before the existing FxGraphCache.prepare_key call, validate the
   scoped origin against the current module, graph, exact placeholder objects,
   names, targets, order, and current supported scope. A foreign or missing origin
   gives no annotation for that graph. A stale origin for the current graph
   disables annotation for the remaining compilation; it cannot simply get a
   no-origin key while remaining eligible at the later collector.
3. collect_optional_schedule reads the scoped carrier and uses the existing
   collect_saved_inputs final wrapper/records/metadata join. Factor only the
   exact live graph/placeholder check shared by this join and the cache boundary.
   Do not reconstruct source authority from the primitive tuple or cached names.
4. On a hit, keep the existing generated-source restoration and attach_metadata
   binding. No old callable attachment or native installation owner is restored.
   There is no new cache-specific native path.

This needs a small transport/handoff delta and one compile_fx call site. The
existing FxGraphCache pickler can hash the primitive gm.meta entry without a
custom reducer, new global owner registry, graph copy, or extra cache API.

A temporary key-only replacement of gm.meta's live carrier is less robust:
CompiledFxGraph also deepcopies gm when wrap_inductor_compiled_regions is enabled,
then serializes that copy later. Keeping gm.meta data-only avoids that second
leak rather than adding a serialization exception.

## Scope gates

Preserve the existing cache-disabled supported route. Add only a fresh,
synchronous NORMAL local FX cache route: local FX on, effective remote FX off,
local and remote AOT caches off, bundled/caching_precompile off, and all existing
saveargs/repro/async/subprocess/AOT/partition exclusions unchanged. Recheck at the
lazy backward and cache boundaries.

Remote AOT is independent of enable_autograd_cache. Previously
force_disable_caches suppressed both. Requiring only local AOT off after lifting
that flag is insufficient. Prefer explicit false remote flags for the initial
bounded subset, or use their actual effective selection helpers.

## Required controls

- Independently obtained equivalent real AOT classifications produce equal keys
  despite different live object identities. Activation versus same-shaped input
  alias, missing origins, disabled scope, and changed boxed positions cannot hit
  the release-bearing entry.
- Replaced/reordered placeholder objects before lookup disable annotation even
  when generated Python text is unchanged. A matching primitive tuple is never
  accepted as a replacement for the live carrier.
- A real local FX miss/save then hit/load exercises generated-source attachment
  and normal policy installation. Count FX cache events, not merely PyCodeCache
  loads. Preserve numerical results and independent entry cleanup.
- Exception cleanup and artifact serialization retain no live origin carrier.
  Include the existing original-graph serialization mode or explicitly keep it
  outside the first executed fixture.

PyCodeCache can reuse a loaded module in one process. The essential invariant is
that restored metadata binds the exact function actually returned by that load,
not that every FX hit necessarily creates a new Python function. A fresh-module
serialization control can separately establish fresh attachment construction.

## Selected source anchors

Paths below are relative to the repository. AC is
agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate;
DR is AC/native_candidate/dynamic_release; CON is
agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/consolidated/python;
WARM is agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1/source.

- DR/source_delta/compiler_saved_inputs/transport.py:21,59,90: current gates,
  temporary live origin, final collector.
- AC/source_delta/compiler_saved_inputs/classification.py:21,30: primitive rows.
- AC/source_delta/compiler_saved_inputs/handoff.py:16,53: live source carrier and
  final exact placeholder/wrapper join.
- AC/source_delta/torch/_inductor/compile_fx.py:1228,3354,3414: FX lookup boundary
  and paired AOT callback scope.
- WARM/torch/_inductor/codecache.py:717,770,1523,1812,2408: fast hash pickler,
  graph/config key, and actual prepare_key.
- WARM/torch/fx/graph_module.py:1053: GraphModule reduction copies module metadata.
- CON/torch/_inductor/output_code.py:762,1007,1041: copied original graph,
  serialization cleanup, and callable rebinding.
- WARM/torch/_functorch/_aot_autograd/autograd_cache.py:115,136: independent remote
  and local AOT gates; WARM/torch/_functorch/aot_autograd.py:1215 selects both.
- WARM/torch/_inductor/utils.py:4264: effective remote FX cache selection.
