# Literal output slots

Use the existing physical output tuple: `WrapperCallRecords.outputs` and
`ReleaseSchedule.outputs` become `tuple[OwnedBuffer | None, ...]`. V3 still means
literal layouts and V4 still means compiler-derived symbolic layouts. Every
allocation remains a concrete, unique `OwnedBuffer`; `None` is never an allocation,
pointer, input source, release step, or invented Tensor. Preserve repeated literal
`None` slots and their positions. Repeated Tensor aliases remain unsupported, as
do arbitrary scalar/object outputs and programs with no owned Tensor output.

The source is the final wrapper's `get_graph_outputs()`. Its exact literal `None`
rows pass through; every other row must satisfy the existing exact ComputedBuffer,
allocation identity, layout and uniqueness checks. AOT's non-Tensor primal gradient
then stays in its original physical backward position. Do not infer slots from AOT
names, drop integer-primal positions manually, or wrap the generated/native callable.

`bind_wrapper_allocations` returns explicit `tuple[int | None, ...]` for V3/V4,
preserving that physical order. Version 2 remains unchanged because its output list
also defines its allocations. The outer `output_indices=None` retains its existing
legacy meaning; a tuple element `None` means one literal output. Dirac's native
design uses the same existing argument, constructs `Py_None` only for those slots,
and checks variant Tensor/None patterns cold. No allocator or hit validation change
is needed for output reconstruction.

The FX extraction clone must retain literal `None` in the actual returned tuple.
Lowering resolves only Tensor rows to checked buffer sources and keeps `None` rows
in place. Keep the mixed CuTe program's current all-Tensor output contract. Retained
IR independently checks its output tuple against the final live wrapper and exact
allocated nodes; its existing tuple/JSON-null encoding already preserves these
slots. Reconstructed records still undergo full validation and attachment equality.

Shared preparation renames only owned output sources, comparing the full projected
tuple, including every `None`. Selected ABI/write checks apply only to Tensor rows.
Capture compares each physical return slot with either its exact captured buffer
or literal `None`; slot count, order and source identities remain mandatory. The
release projection keeps the original DropInput objects, full event order, integer
exclusion and exact physical output tuple. Passing output indices through the bridge
requires no second schema, output wrapper, inferred values, or extra hit checks.

Focused CPU controls should use real typed V3/V4 wrapper collection: leading,
interior, trailing and repeated `None`; distinct owned output order; actual FX and
retained round trips; shared projection/capture correspondence; unchanged symbolic
expressions and release authority; exact native constructor arguments with a CPU
stand-in. Negatives cover changed slot positions, unexpected literals, absent or
duplicate Tensor sources, all-None outputs, and version-2 None rows. Existing
all-Tensor controls remain unchanged. Actual torch.compile dynamic backward/native
qualification follows separately with its original None slots observed, full
gradients checked, and fallback still rejected.
