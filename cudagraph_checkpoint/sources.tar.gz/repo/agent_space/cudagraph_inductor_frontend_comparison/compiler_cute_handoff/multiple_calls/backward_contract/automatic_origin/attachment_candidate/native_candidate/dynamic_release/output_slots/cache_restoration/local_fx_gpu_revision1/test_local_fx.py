from dataclasses import asdict
import json
import weakref
from unittest import mock

import dynamic_frontend_release_fixture as fixture
import fx_adapter.lowering as fx_lowering
import retained_ir.prototype as retained_reader
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from compiler_saved_inputs.schedule import DropInput
import torch
from torch._dynamo.utils import counters
from torch._functorch import config as aot_config
from torch._inductor import config
from torch._inductor.codecache import FxGraphCache
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import IntExpr, OwnedBuffer
from torch._inductor.utils import fresh_cache
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class TestLocalFXSavedRelease(TestCase):
    @parametrize("frontend", ("fx", "retained"))
    def test_backward_miss_save_then_hit_load(self, device, frontend):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        self.enterContext(fresh_cache())
        self.enterContext(torch._dynamo.config.patch(caching_precompile=False, repro_after=None))
        self.enterContext(aot_config.patch(enable_autograd_cache=False, enable_remote_autograd_cache=False,
                                           bundled_autograd_cache=False, donated_buffer=False))
        self.enterContext(config.patch(
            cudagraph_saved_input_schedule=True, graph_partition=False, cpp_wrapper=False,
            fx_graph_cache=True, fx_graph_remote_cache=False, force_disable_caches=False,
            allow_buffer_reuse=False, inplace_buffers=False, max_fusion_size=1, realize_reads_threshold=0,
            normalize_static_input_alignment=True, use_static_triton_launcher=True,
            use_fast_triton_launcher=True, **{"triton.cudagraphs": False},
        ))
        load, save = FxGraphCache.load_with_key, FxGraphCache._save_graph
        fx_lower, ir_bind, native_bind = fx_lowering.lower_fx, retained_reader.bind_selected, preparation.make_boxed_replay
        events, readers, bindings = [], {}, {}
        phase = 0

        def observe_load(key, *args, **kwargs):
            result = load(key, *args, **kwargs)
            if kwargs["is_backward"]:
                graph, info = result
                events.append((phase, "load", key, info["cache_state"],
                               None if graph is None else weakref.ref(graph), args[2], args[3]))
            return result

        def observe_save(key, graph, *args, **kwargs):
            result = save(key, graph, *args, **kwargs)
            if graph.fx_kwargs["is_backward"]:
                events.append((phase, "save", key, None, weakref.ref(graph), args[1], args[2]))
            return result

        def observe_fx(*args, **kwargs):
            program = fx_lower(*args, **kwargs)
            readers[id(program.records)] = weakref.ref(program.records)
            return program

        def observe_ir(*args, **kwargs):
            bound = ir_bind(*args, **kwargs)
            readers[id(bound.program.records)] = weakref.ref(bound.program.records)
            return bound

        def observe_binding(graph, records, *args, **kwargs):
            if readers[id(records)]() is not records:
                raise AssertionError("Native binder lost the reader's exact records")
            entry = native_bind(graph, records, *args, **kwargs)
            bindings[id(entry)] = (records, kwargs.get("release_schedule"))
            return entry

        for owner, name, observer in ((FxGraphCache, "load_with_key", observe_load),
                                       (FxGraphCache, "_save_graph", observe_save),
                                       (fx_lowering, "lower_fx", observe_fx),
                                       (retained_reader, "bind_selected", observe_ir),
                                       (preparation, "make_boxed_replay", observe_binding)):
            self.enterContext(mock.patch.object(owner, name, new=observer))
        held, expected_held, runs = [], [], []
        compilations = counters["stats"]["unique_graphs"]

        def invoke(compiled, iteration, width, observer=None):
            shape = (32, width)
            value = torch.linspace(-0.8, 0.9, 32 * width, device=device).reshape(shape).add(iteration / 32).requires_grad_()
            residual = torch.linspace(-0.6, 0.7, 32 * width, device=device).reshape(shape).sub(iteration / 64).requires_grad_()
            weight = torch.linspace(0.5, 1.0, 32 * width, device=device).reshape(shape).requires_grad_()
            inputs = (value, residual, weight)
            for argument in inputs:
                torch._dynamo.mark_static(argument, 0)
            expected_inputs = tuple(argument.detach().clone().requires_grad_() for argument in inputs)
            expected = (expected_inputs[0].sin() + expected_inputs[1].cos()).sigmoid() * expected_inputs[2]
            actual = compiled(*inputs)
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            expected_gradients = torch.autograd.grad(expected, expected_inputs, tangent)
            if observer is None:
                gradients = torch.autograd.grad(actual, inputs, tangent)
            else:
                before = len(observer.calls)
                with observer:
                    gradients = torch.autograd.grad(actual, inputs, tangent)
                self.assertEqual(observer.errors, [])
                self.assertEqual(observer.pending, {})
                self.assertEqual(len(observer.calls), before + 1)
                observer.calls[-1]["width"] = width
            self.assertEqual(gradients, expected_gradients)
            held.append((actual, gradients))
            expected_held.append((expected.detach(), tuple(gradient.detach() for gradient in expected_gradients)))

        for phase in (0, 1):
            torch._dynamo.reset()
            policy = NativeCUDAGraphPolicy(frontend=frontend)
            self.addCleanup(policy.close)
            with config.patch(cudagraph_policy=policy):
                self.assertNotIn("cudagraph_policy", config.save_config_portable(
                    ignore_private_configs=False, readonly_values=True))
                compiled = torch.compile(fixture.SavedFanout(), fullgraph=True, dynamic=True)
                invoke(compiled, phase, 13)
                backwards = tuple(item for item in policy.installations if item.artifact.fx_kwargs["is_backward"])
                self.assertEqual(len(backwards), 1)
                backward, = backwards
                self.assertEqual(backward.status, "ready", backward.decline)
                self.assertIsNone(backward.decline)
                artifact, original, entry = backward.artifact, backward.original, backward.entry
                self.assertIs(type(entry), torch._C._CUDAGraphBoxedReplay)
                self.assertIs(artifact.current_callable, entry)
                records, schedule = original._cudagraph_call_records, backward.metadata.release_schedule
                self.assertEqual(records.version, 4)
                self.assertIsNotNone(schedule)
                self.assertEqual(schedule.outputs, records.outputs)
                self.assertEqual(len(records.integer_inputs), 1)
                integer_index = records.integer_inputs[0].boxed_index
                extent = IntExpr("boxed", integer_index)
                for layout in records.allocations:
                    self.assertEqual((layout.size, layout.stride), ((32, extent), (extent, 1)))
                self.assertEqual(sum(row is not None for row in records.outputs), 3)
                self.assertTrue(any(row is None for row in records.outputs))
                projected, projected_schedule = bindings[id(entry)]
                self.assertIsNot(projected, records)
                self.assertEqual(projected.version, 4)
                self.assertEqual(tuple(row is None for row in projected.outputs), tuple(row is None for row in records.outputs))
                self.assertEqual(tuple(row.boxed_index for row in projected.integer_inputs), (integer_index,))
                self.assertEqual(projected_schedule.input_uses, schedule.input_uses)
                self.assertEqual(projected_schedule.outputs, projected.outputs)
                drops = tuple(step for step in schedule.steps if type(step) is DropInput)
                self.assertTrue(drops)
                self.assertEqual(schedule.input_uses[integer_index], ())
                for old, new in zip(drops, (step for step in projected_schedule.steps if type(step) is DropInput), strict=True):
                    self.assertIs(old, new)
                    self.assertEqual(old.after_call, schedule.input_uses[old.input_index][-1])
                self.assertTrue(any(type(step) is DropInput and any(
                    type(later) is OwnedBuffer and later in records.outputs for later in schedule.steps[index + 1:])
                    for index, step in enumerate(schedule.steps)))
                current_events = [row for row in events if row[0] == phase]
                expected_events = [("load", "miss"), ("save", None)] if phase == 0 else [("load", "hit")]
                self.assertEqual([(row[1], row[3]) for row in current_events], expected_events)
                key = current_events[0][2]
                self.assertTrue(all(row[2] == key and row[5] is True and row[6] is None for row in current_events))
                self.assertIs(current_events[-1][4](), artifact)
                self.assertEqual(artifact._fx_graph_cache_key, key)
                observer = fixture.NativeObservation(backward)
                event_count, binding_count, installation_count = len(events), len(bindings), len(policy.installations)
                for iteration, width in enumerate((2, 7, 35, 36), start=1):
                    invoke(compiled, iteration, width, observer)
                    self.assertEqual(len(events), event_count)
                    self.assertEqual(len(bindings), binding_count)
                    self.assertEqual(len(policy.installations), installation_count)
                    self.assertIs(artifact.current_callable, entry)
                    self.assertIs(backward.metadata.release_schedule, schedule)
                    self.assertFalse(entry.failed)
                self.assertEqual(observer.frames, {})
                for call in observer.calls:
                    self.assertEqual(call["integers"], ((integer_index, call["width"]),))
                    self.assertEqual(call["output_shapes"], [None if row is None else (32, call["width"]) for row in records.outputs])
                    self.assertEqual(tuple(pointer is None for pointer in call["output_pointers"]),
                                     tuple(row is None for row in records.outputs))
                    inputs = {index: expired for index, pointer, expired in call["inputs"]}
                    for drop in drops:
                        self.assertTrue(inputs[drop.input_index])
                runs.append((policy, artifact, original, entry, backward.metadata, key))
                self.assertEqual(counters["stats"]["unique_graphs"] - compilations, phase + 1)
            policy.close()
            self.assertTrue(entry.closed)
            torch.cuda.synchronize()
            self.assertEqual(held, expected_held)

        first, second = runs
        self.assertIsNot(first[0], second[0])
        self.assertIsNot(first[1], second[1])
        self.assertIsNot(first[2], second[2])
        self.assertIsNot(first[2].__globals__, second[2].__globals__)
        self.assertIsNot(first[2]._cudagraph_frontend_attachment, second[2]._cudagraph_frontend_attachment)
        self.assertIsNot(first[2]._cudagraph_call_records, second[2]._cudagraph_call_records)
        self.assertIsNot(first[3], second[3])
        self.assertEqual(first[4], second[4])
        self.assertEqual(first[5], second[5])
        self.assertEqual(first[1].source_code, second[1].source_code)
        self.assertTrue(all(row[3].closed for row in runs))
        self.assertEqual(held, expected_held)
        print("LOCAL_FX_SAVED_RELEASE " + json.dumps({
            "scope": "actual backward local FX cache and native replay", "frontend": frontend,
            "backward_key": first[5], "backward_cache_events": [[row[0], row[1], row[3]] for row in events],
            "local_fx": True, "remote_fx": False, "local_aot": False, "remote_aot": False,
            "outer_compilations": 2, "records_version": 4, "integer_indices": [integer_index],
            "output_names": [None if row is None else row.source.name for row in records.outputs],
            "drops": [asdict(drop) for drop in drops], "widths_per_lifetime": [13, 2, 7, 35, 36],
            "native_backward_hits_per_lifetime": 4, "exact_reader_records_reached_native": True,
            "distinct_artifacts_attachments_entries": True, "held_outputs_correct_after_both_close": True,
            "watched_host_frames": [], "full_forward_native_claim": False,
        }, sort_keys=True))


instantiate_device_type_tests(TestLocalFXSavedRelease, globals(), only_for="cuda")

if __name__ == "__main__":
    run_tests()
