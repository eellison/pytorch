"""Project recorded host events and existing SymInt expressions into replay records."""

import sympy
import torch
from generated_python.prototype import _Integer, _Tensor, _Trace, TraceDeclined
from host_program import HostProgram
from torch._inductor.runtime.cudagraph_arg_mapping import (
    bind_alignment_copies,
    bind_wrapper_allocations,
    BufferSource,
    InputSource,
    IntegerInput,
    IntExpr,
    OwnedBuffer,
    pointwise_product,
    WrapperCallRecords,
)
from torch.utils._sympy.functions import CeilDiv, FloorDiv
from torch.utils._sympy.numbers import int_oo

from .contract import (
    AllocateEvent,
    CuTeInvokeEvent,
    FXTrace,
    FXTraceDeclined,
    InvokeEvent,
    LayoutEvent,
    NormalizeEvent,
    ReinterpretEvent,
)


def lower_fx(trace: FXTrace, *, record_version=4) -> HostProgram:
    return _lower_fx(trace, record_version=record_version)


def lower_mixed_fx(checked, trace):
    from compiler_cute_handoff.program import bind_mixed_program
    from .extraction import _check_mixed

    if type(trace) is not FXTrace:
        raise FXTraceDeclined("Expected a local symbolic host trace")
    _check_mixed(checked, trace.selections)
    if (trace.compiler_binding is not checked or trace.contract is not checked.inputs
            or type(trace.events) is not tuple or type(trace.outputs) is not tuple
            or type(trace.placeholders) is not tuple):
        raise FXTraceDeclined("Mixed FX trace lost its original compiler binding")
    program = _lower_fx(trace, checked)
    result = bind_mixed_program(checked, program)
    _check_mixed(checked, trace.selections)
    return result


def _lower_fx(trace, compiler=None, *, record_version=4):
    if type(trace) is not FXTrace:
        raise FXTraceDeclined("Expected a local symbolic host trace")
    if trace.compiler_binding is not compiler:
        raise FXTraceDeclined("Mixed FX events require their checked compiler binding")
    if type(record_version) is not int or record_version not in (3, 4):
        raise FXTraceDeclined("Unsupported generated record version")
    if record_version == 3 and (trace.contract.integer_ranges or trace.symbol_sources
            or any(kind != "tensor" for kind in trace.contract.kinds)
            or any(type(value) is not int or value < 0 for row in trace.contract.tensor_inputs
                   for value in (*row.size, *row.stride))):
        raise FXTraceDeclined("V3 tracing requires literal Tensor inputs")
    environment = trace.shape_env
    if environment.guards or environment.deferred_runtime_asserts:
        guards = tuple(str(guard.expr) for guard in environment.guards)
        raise FXTraceDeclined(f"Additional local guards need a compiled dispatch owner: {guards}")
    ranges = {row.index: row for row in trace.contract.integer_ranges}
    for symbol, source in trace.symbol_sources.items():
        if source.op != "boxed" or source.value not in ranges:
            raise FXTraceDeclined("Symbol has no inherited boxed source")
        declared = ranges[source.value]
        actual = environment.var_to_range[symbol]
        if (actual.lower > declared.lower
                or (declared.upper is None and actual.upper not in (int_oo, sympy.oo))
                or (declared.upper is not None and actual.upper < declared.upper)):
            raise FXTraceDeclined("Tracing narrowed an inherited integer domain")

    def runtime_expression(value):
        if type(value) is int:
            return value
        if type(value) is torch.SymInt:
            if value.node.shape_env is not environment:
                raise FXTraceDeclined("Symbolic value belongs to another tracing environment")
            value = value.node.expr
        if not isinstance(value, sympy.Expr):
            raise FXTraceDeclined("Expected an integer expression at the host boundary")
        if not value.free_symbols.issubset(trace.symbol_sources):
            raise FXTraceDeclined("Symbolic expression has no input-source substitution")
        if isinstance(value, sympy.Integer):
            return int(value)
        if isinstance(value, sympy.Symbol):
            return trace.symbol_sources[value]
        if isinstance(value, sympy.Mul):
            result = pointwise_product(tuple(runtime_expression(arg) for arg in value.args))
            if result is not None:
                return result
        if isinstance(value, (CeilDiv, FloorDiv)):
            numerator, denominator = value.args
            if isinstance(denominator, sympy.Integer) and denominator > 0:
                if isinstance(value, FloorDiv):
                    numerator = sympy.expand(numerator - denominator + 1)
                numerator = runtime_expression(numerator)
                if type(numerator) is int:
                    return -(-numerator // int(denominator))
                return IntExpr("ceildiv", args=(numerator, IntExpr("constant", int(denominator))))
        raise FXTraceDeclined("Symbolic expression exceeds the current native recipe")

    def dimensions(values):
        return tuple(runtime_expression(value) for value in values)

    events = []
    cute_index = 0
    state = _Trace(trace.contract.device_index, trace.selections)
    state.in_device = True
    tensors = {}
    tensor_inputs = {row.index: row for row in trace.contract.tensor_inputs}
    if len(trace.placeholders) != len(trace.contract.kinds):
        raise FXTraceDeclined("Trace inputs differ from the boxed compiler contract")
    for index, value in enumerate(trace.placeholders):
        if trace.contract.kinds[index] == "integer":
            if runtime_expression(value) != IntExpr("boxed", index):
                raise FXTraceDeclined("Symbolic input lost its boxed integer source")
        else:
            descriptor = tensor_inputs[index]
            tensors[id(value)] = _Tensor(InputSource(index), descriptor.dtype,
                                         descriptor.size, descriptor.stride)

    def tensor(value):
        if id(value) not in tensors:
            raise FXTraceDeclined("Tensor has no recorded allocation or input source")
        return tensors[id(value)]

    def argument(value):
        if isinstance(value, torch.Tensor):
            return tensor(value)
        value = runtime_expression(value)
        return _Integer(value) if type(value) is IntExpr else value

    try:
        for event in trace.events:
            if type(event) is AllocateEvent:
                if event.device != torch.device("cuda", trace.contract.device_index):
                    raise FXTraceDeclined("Allocation differs from the fixed CUDA contract")
                if id(event.tensor) in tensors:
                    raise FXTraceDeclined("Allocation reused a preceding Tensor identity")
                tensors[id(event.tensor)] = state.allocate(
                    dimensions(event.size), dimensions(event.stride), event.dtype,
                )
                if compiler is not None:
                    value = tensors[id(event.tensor)]
                    events.append(OwnedBuffer(value.source, value.dtype, value.size, value.stride))
            elif type(event) is ReinterpretEvent:
                if compiler is not None:
                    raise FXTraceDeclined("Mixed FX programs do not support allocation aliases")
                tensors[id(event.tensor)] = state.reinterpret(
                    tensor(event.source), dimensions(event.size), dimensions(event.stride),
                    runtime_expression(event.offset),
                )
            elif type(event) is LayoutEvent:
                state.check_layout(tensor(event.tensor), dimensions(event.size),
                                   dimensions(event.stride), event.label)
            elif type(event) is NormalizeEvent:
                state.normalize(tensor(event.tensor))
                if compiler is not None:
                    events.append(state.copies[-1])
            elif type(event) is InvokeEvent:
                if event.kernel_name not in trace.selections:
                    raise FXTraceDeclined("Invocation lost its selected provider identity")
                state.launch(event.kernel_name, tuple(argument(arg) for arg in event.arguments), state, {})
                if compiler is not None:
                    events.append(state.calls[-1])
            elif type(event) is CuTeInvokeEvent and compiler is not None:
                from compiler_cute_handoff.descriptor import CuTeCall, TensorFact

                if cute_index == len(compiler.cute.calls):
                    raise FXTraceDeclined("Trace added a CuTe invocation")
                call = compiler.cute.calls[cute_index]
                if (type(event.entry_global) is not str or event.entry_global != call.entry_global
                        or type(event.operands) is not tuple or len(event.operands) != 2):
                    raise FXTraceDeclined("CuTe invocation lost its exact emitted entry or operands")
                operands = tuple(tensor(value) for value in event.operands)
                events.append(CuTeCall(call.entry_key, event.entry_global, call.provider_kind, call.formals,
                    tuple(TensorFact(value.source, value.dtype, str(torch.device("cuda", trace.contract.device_index)),
                                     value.size, value.stride) for value in operands)))
                cute_index += 1
            else:
                raise FXTraceDeclined("Unsupported recorded host event")

        outputs = tuple(tensor(value) for value in trace.outputs)
        if any(type(value.source) is not BufferSource or not value.valid for value in outputs):
            raise FXTraceDeclined("Wrapper must return the recorded owning buffers")
        allocations = tuple(OwnedBuffer(value.source, value.dtype, value.size, value.stride)
                            for value in state.allocations)
        by_source = {layout.source: layout for layout in allocations}
        if compiler is not None:
            from compiler_cute_handoff.envelope import Release
            from compiler_cute_handoff.program import MixedHostProgram

            if cute_index != len(compiler.cute.calls):
                raise FXTraceDeclined("Trace omitted a CuTe invocation")
            returned = tuple(by_source[value.source] for value in outputs)
            output_sources = {value.source for value in outputs}
            sources = tuple(InputSource(index) for index, kind in enumerate(trace.contract.kinds) if kind == "tensor")
            sources += tuple(value.source for value in allocations)
            events.extend(Release(source) for source in sources if source not in output_sources)
            return MixedHostProgram(1, trace.contract, tuple(events), returned)
        integers = tuple(IntegerInput(f"boxed_{index}", index)
                         for index, kind in enumerate(trace.contract.kinds) if kind == "integer")
        records = WrapperCallRecords(
            record_version, trace.contract.device_index,
            tuple(f"boxed_{index}" for index in range(len(trace.contract.kinds))),
            tuple(state.calls), tuple(state.copies), tuple(by_source[value.source] for value in outputs),
            allocations, integers,
        )
        if bind_wrapper_allocations(records) is None or bind_alignment_copies(records) is None:
            raise FXTraceDeclined("Host events exceed the current runtime contract")
        return HostProgram(records, tuple(state.events), tuple(state.assertions))
    except TraceDeclined as error:
        raise FXTraceDeclined(str(error)) from error
