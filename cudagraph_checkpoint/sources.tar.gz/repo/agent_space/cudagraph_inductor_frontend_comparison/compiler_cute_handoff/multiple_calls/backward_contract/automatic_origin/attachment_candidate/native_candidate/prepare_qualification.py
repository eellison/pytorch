"""Freeze the reviewed native build and frontend sources for CPU/GPU qualification."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
REPO = Path("/data/eellison/src/pytorch")
OLD = ROOT / "qualification2"
NEW = ROOT / "qualification3"


def digest(path):
    with Path(path).open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with path.open("x") as file:
        json.dump(value, file, indent=2)
        file.write("\n")


def main():
    build = read(ROOT / "evidence/build_result.json")
    proof = read(ROOT / "evidence/fresh_import.json")
    if not build["accepted"] or not proof["accepted"]:
        raise RuntimeError("Native build and fresh import must pass first")
    if proof["proof"]["installed_native_hashes"] != build["installed_native_hashes"]:
        raise RuntimeError("Build and import differ")
    source_manifest = ROOT / "evidence/source_manifest.json"
    if (build["manifest_sha256"] != digest(source_manifest)
            or proof["proof"]["source_manifest_sha256"] != digest(source_manifest)):
        raise RuntimeError("Build and import lack the current source manifest")
    built = read(source_manifest)
    for group, directory in (("delta_files", ROOT / "source_delta"),
                             ("scaffold_hashes", ROOT), ("native_review_hashes", ROOT)):
        for name, sha in built[group].items():
            if digest(directory / name) != sha:
                raise RuntimeError("Reviewed build source changed: " + name)
    fixture = ROOT / "gpu_tests/test_native_release.py"
    if digest(fixture) != "cbb062a79dfa223da17a7c1af9fd8b8df2f2c06379bc240770383d35a96b1083":
        raise RuntimeError("Reviewed GPU fixture changed")
    NEW.mkdir(exist_ok=False)
    manifest = read(OLD / "manifest.json")
    target = ROOT / "install_attempt1"
    manifest["native"]["installation"] = str(target)
    manifest["native"]["extension"] = str(target / "torch/_C.cpython-312-aarch64-linux-gnu.so")
    manifest["native"]["files"] = {str(target / name): sha for name, sha in build["installed_native_hashes"].items()}
    manifest["native"]["receipts"] = {str(ROOT / "evidence" / name): digest(ROOT / "evidence" / name)
                                    for name in ("source_manifest.json", "build_result.json", "fresh_import.json")}
    manifest["scope"] = "Reviewed static saved-input release native build with the qualified compiler and cold Python bridge."
    write(NEW / "manifest.json", manifest)
    dependencies = read(OLD / "gpu_dependencies.json")
    source_manifest = ROOT / "evidence/source_manifest.json"
    dependencies["gpu"]["source_manifest"] = {"path": str(source_manifest), "sha256": digest(source_manifest)}
    write(NEW / "gpu_dependencies.json", dependencies)
    helpers = read(OLD / "run_cpu_helpers.json")
    helpers["public"]["native_release_fixture"] = {"path": str(fixture), "sha256": digest(fixture)}
    write(NEW / "run_cpu_helpers.json", helpers)
    for name in ("run_tests.py", "test_cpu.py"):
        (NEW / name).write_text((OLD / name).read_text())
    gpu = (OLD / "test_native_width.py").read_text()
    gpu = "import native_release_fixture\n" + gpu
    gpu = gpu.replace('if __name__ == "__main__":',
                      'class TestNativeSavedReleaseCUDA(native_release_fixture.TestNativeSavedReleaseCUDA):\n    pass\n\n\nif __name__ == "__main__":')
    (NEW / "test_native_width.py").write_text(gpu)
    review = read(OLD / "execution_review.json")
    review["scope"] = "CPU154 plus GPU12: native saved-input release and unchanged Inductor/user Triton/CuTe controls."
    review["cases"]["public"].extend(
        "__main__.TestNativeSavedReleaseCUDA.test_generated_backward_release_mode_" + mode + "_cuda"
        for mode in ("release", "disabled", "retain_graph")
    )
    paths = [NEW / name for name in ("manifest.json", "gpu_dependencies.json", "run_cpu_helpers.json",
                                    "run_tests.py", "test_cpu.py", "test_native_width.py")]
    paths += [ROOT / name for name in ("native_source_review.json", "native_source_independent_review.json",
                                      "build_native.py", "build_candidate.sh", "build_site/sitecustomize.py",
                                      "python.sh", "runtime_site/sitecustomize.py", "check_native.py",
                                      "evidence/source_manifest.json", "evidence/build_result.json", "evidence/fresh_import.json",
                                      "gpu_tests/test_native_release.py", "gpu_tests/test_inventory.json", "prepare_qualification.py")]
    native_review = read(ROOT / "native_source_review.json")
    paths += [REPO / row["path"] for row in native_review["native_files"]]
    review["files"].update({str(path): digest(path) for path in paths})
    review["revision"] = "Fresh native build, unchanged CPU154 inventory, three actual backward native release GPU cases."
    write(NEW / "execution_review.json", review)
    print(json.dumps({"root": str(NEW), "sources": len(review["files"]),
                      "cases": {suite: len(cases) for suite, cases in review["cases"].items()}}))


if __name__ == "__main__":
    main()
