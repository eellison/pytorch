"""Preserve AOT metadata before compiling the original forward module."""

import copy
from dataclasses import dataclass

from torch.fx import GraphModule


@dataclass(frozen=True, eq=False)
class PreservedForward:
    snapshot: GraphModule
    compilation: GraphModule


def preserve_aot_forward(forward: GraphModule) -> PreservedForward:
    """Keep an analysis graph and isolate metadata writes on the compiler input.

    FX graph copying preserves the exact metadata values while copying each
    node's metadata dictionary. The original module remains the compilation
    carrier so its attributes and hooks do not need to be reconstructed.
    """
    if not isinstance(forward, GraphModule):
        raise TypeError("Expected the original AOT forward GraphModule")
    snapshot = GraphModule(forward, copy.deepcopy(forward.graph))
    # AOT can share these dictionaries with backward placeholders.
    for node in forward.graph.nodes:
        node.meta = node.meta.copy()
    return PreservedForward(snapshot, forward)
