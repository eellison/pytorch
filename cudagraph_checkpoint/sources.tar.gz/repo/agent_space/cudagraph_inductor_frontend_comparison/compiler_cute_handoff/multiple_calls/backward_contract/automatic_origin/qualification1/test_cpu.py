import compact_origin_fixture
from torch.testing._internal.common_utils import run_tests


class TestCompactForwardOrigins(compact_origin_fixture.TestCompactForwardOrigins):
    pass


if __name__ == "__main__":
    run_tests()
