#include <torch/csrc/python_headers.h>

#include <pybind11/chrono.h>
#include <pybind11/stl.h>

#include <torch/csrc/Dtype.h>
#include <torch/csrc/autograd/python_variable.h>
#include <torch/csrc/jit/python/pybind_utils.h>
#include <torch/csrc/cuda/Stream.h>
#include <torch/csrc/utils/object_ptr.h>
#include <torch/csrc/utils/pybind.h>

#include <ATen/EmptyTensor.h>
#include <ATen/cuda/CUDAGraph.h>
#include <ATen/cuda/CUDAGraphParams.h>
#include <ATen/cuda/CUDAContextLight.h>
#include <c10/core/ScalarTypeToTypeMeta.h>
#include <c10/cuda/CUDACachingAllocatorPendingGraph.h>
#include <c10/util/safe_numerics.h>

#include <algorithm>
#include <cstring>
#include <limits>
#include <mutex>
#include <string>

#if !defined(USE_ROCM) && defined(CUDA_VERSION) && CUDA_VERSION >= 12080
#include <c10/cuda/driver_api.h>
#endif

// Cargo culted partially from csrc/distributed/c10d/init.cpp
// and partially from csrc/cuda/Stream.cpp.
// THCPStream_init is also declared at global scope.

// Because THCPGraph_init is forward declared in the only consumer
// (csrc/Module.cpp) I don't think we need a Graph.h.

template <typename T>
using shared_ptr_class_ = py::class_<T, std::shared_ptr<T>>;

struct PythonKernelPointerUpdates {
  PythonKernelPointerUpdates(
      std::shared_ptr<at::cuda::detail::KernelPointerUpdateBatch> batch,
      size_t count)
      : batch(std::move(batch)), pointers(count), referenced(count) {}

  std::shared_ptr<at::cuda::detail::KernelPointerUpdateBatch> batch;
  std::vector<uintptr_t> pointers;
  std::vector<bool> referenced;
};

namespace {

void unpack_pointer_values(py::handle pointers, std::vector<uintptr_t>& values) {
  if (!PyTuple_CheckExact(pointers.ptr())) {
    throw py::type_error("Pointer values must be an exact tuple of integers");
  }
  if (static_cast<size_t>(PyTuple_GET_SIZE(pointers.ptr())) != values.size()) {
    throw py::value_error("Pointer count differs from the prepared bindings");
  }
  for (size_t index = 0; index < values.size(); ++index) {
    auto value = PyTuple_GET_ITEM(pointers.ptr(), index);
    if (!PyLong_CheckExact(value)) {
      throw py::type_error("Pointer values must be exact integers");
    }
    auto pointer = PyLong_AsUnsignedLongLong(value);
    if (PyErr_Occurred()) {
      throw py::error_already_set();
    }
    if (pointer > std::numeric_limits<uintptr_t>::max()) {
      PyErr_SetString(PyExc_OverflowError, "Pointer value is out of range");
      throw py::error_already_set();
    }
    values[index] = static_cast<uintptr_t>(pointer);
  }
}

std::vector<at::cuda::detail::KernelPointerBinding> unpack_pointer_bindings(
    PyObject* bindings, bool exact_nodes, bool allow_fields = false) {
  if (!PyTuple_CheckExact(bindings)) {
    throw py::type_error("Pointer bindings must be an exact tuple");
  }
  std::vector<at::cuda::detail::KernelPointerBinding> values;
  values.reserve(PyTuple_GET_SIZE(bindings));
  for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(bindings); ++index) {
    auto* row = PyTuple_GET_ITEM(bindings, index);
    const bool field = allow_fields && PyTuple_CheckExact(row) && PyTuple_GET_SIZE(row) == 4;
    if (!PyTuple_CheckExact(row) || PyTuple_GET_SIZE(row) != (field ? 4 : 3) ||
        !(exact_nodes ? PyLong_CheckExact(PyTuple_GET_ITEM(row, 0)) : PyLong_Check(PyTuple_GET_ITEM(row, 0))) ||
        !PyLong_CheckExact(PyTuple_GET_ITEM(row, 1)) || !PyLong_CheckExact(PyTuple_GET_ITEM(row, 2)) ||
        (field && !PyLong_CheckExact(PyTuple_GET_ITEM(row, 3)))) {
      throw py::type_error(allow_fields
          ? "Pointer bindings must contain (node, argument, pointer_index) or "
            "(node, argument, byte_offset, pointer_index) integer tuples"
          : "Pointer bindings must contain (node, argument, pointer_index) integer tuples");
    }
    auto node = PyLong_AsVoidPtr(PyTuple_GET_ITEM(row, 0));
    if (PyErr_Occurred()) {
      throw py::error_already_set();
    }
    auto argument = PyLong_AsLongLong(PyTuple_GET_ITEM(row, 1));
    if (PyErr_Occurred()) {
      throw py::error_already_set();
    }
    size_t pointer_index = PyLong_AsSize_t(PyTuple_GET_ITEM(row, field ? 3 : 2));
    if (PyErr_Occurred()) {
      throw py::error_already_set();
    }
    std::optional<size_t> byte_offset;
    if (field) {
      byte_offset = PyLong_AsSize_t(PyTuple_GET_ITEM(row, 2));
      if (PyErr_Occurred()) {
        throw py::error_already_set();
      }
    }
    values.push_back({reinterpret_cast<uintptr_t>(node), argument, pointer_index, byte_offset});
  }
  return values;
}

uintptr_t current_replay_context() {
#if !defined(USE_ROCM) && defined(CUDA_VERSION) && CUDA_VERSION >= 12080
  auto* api = c10::cuda::DriverAPI::get();
  TORCH_CHECK(api->cuCtxGetCurrent_, "Native graph ownership requires CUDA context queries");
  CUcontext context = nullptr;
  C10_CUDA_DRIVER_CHECK(api->cuCtxGetCurrent_(&context));
  TORCH_CHECK(context, "Native graph ownership requires a current CUDA context");
  return reinterpret_cast<uintptr_t>(context);
#else
  TORCH_CHECK(false, "Native graph ownership requires NVIDIA CUDA 12.8 or later");
#endif
}

int64_t unpack_nonnegative_integer(PyObject* value, const char* name) {
  if (!PyLong_CheckExact(value)) {
    throw py::type_error(std::string(name) + " must be an exact integer");
  }
  auto result = PyLong_AsLongLong(value);
  if (PyErr_Occurred()) {
    throw py::error_already_set();
  }
  if (result < 0) {
    throw py::value_error(std::string(name) + " must be nonnegative");
  }
  return result;
}

std::vector<int64_t> unpack_static_dimensions(PyObject* values) {
  if (!PyTuple_CheckExact(values)) {
    throw py::type_error("Output sizes and strides must be exact tuples");
  }
  std::vector<int64_t> result;
  result.reserve(PyTuple_GET_SIZE(values));
  for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(values); ++index) {
    result.push_back(unpack_nonnegative_integer(PyTuple_GET_ITEM(values, index), "Output dimension"));
  }
  return result;
}

std::vector<size_t> unpack_input_indices(PyObject* values, size_t input_count) {
  if (!PyTuple_CheckExact(values)) {
    throw py::type_error("Input indices must be an exact tuple");
  }
  std::vector<size_t> result;
  result.reserve(PyTuple_GET_SIZE(values));
  for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(values); ++index) {
    auto value = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(values, index), "Input index"));
    if (value >= input_count || std::find(result.begin(), result.end(), value) != result.end()) {
      throw py::value_error("Input indices must be distinct and in range");
    }
    result.push_back(value);
  }
  return result;
}

struct BoxedBufferLayout {
  caffe2::TypeMeta dtype;
  std::vector<int64_t> size;
  std::vector<int64_t> stride;
  size_t nbytes;
};

struct BoxedLayoutValue {
  size_t buffer;
  size_t dimension;
  size_t value;
  bool stride;
};

struct BoxedNumericPlan {
  enum class Op { Constant, Boxed, CeilDiv, Multiply };
  struct Instruction {
    Op op;
    int64_t first;
    size_t second = 0;
  };

  BoxedNumericPlan(PyObject* plan, size_t input_count, size_t value_count) {
    if (!PyTuple_CheckExact(plan) || PyTuple_GET_SIZE(plan) != 2 ||
        !PyTuple_CheckExact(PyTuple_GET_ITEM(plan, 1))) {
      throw py::type_error("Numeric plan must contain integer input indices and an instruction tuple");
    }
    auto indices = unpack_input_indices(PyTuple_GET_ITEM(plan, 0), input_count);
    integer_inputs.resize(input_count);
    for (auto index : indices) {
      integer_inputs[index] = true;
    }
    for (size_t index = 0; index < input_count; ++index) {
      if (!integer_inputs[index]) {
        tensor_inputs.push_back(index);
      }
    }
    auto* program = PyTuple_GET_ITEM(plan, 1);
    if (static_cast<size_t>(PyTuple_GET_SIZE(program)) != value_count) {
      throw py::value_error("Numeric instruction count differs from the prepared batch");
    }
    std::vector<bool> loaded(input_count);
    instructions.reserve(value_count);
    for (size_t index = 0; index < value_count; ++index) {
      auto* row = PyTuple_GET_ITEM(program, index);
      if (!PyTuple_CheckExact(row) || PyTuple_GET_SIZE(row) < 2 ||
          !PyUnicode_CheckExact(PyTuple_GET_ITEM(row, 0))) {
        throw py::type_error("Numeric instructions must be tagged tuples");
      }
      auto* tag = PyTuple_GET_ITEM(row, 0);
      auto* first = PyTuple_GET_ITEM(row, 1);
      if (PyUnicode_CompareWithASCIIString(tag, "constant") == 0 && PyTuple_GET_SIZE(row) == 2) {
        if (!PyLong_CheckExact(first)) {
          throw py::type_error("Numeric constants must be exact integers");
        }
        auto value = PyLong_AsLongLong(first);
        if (PyErr_Occurred()) {
          throw py::error_already_set();
        }
        instructions.push_back({Op::Constant, value});
      } else if (PyUnicode_CompareWithASCIIString(tag, "boxed") == 0 && PyTuple_GET_SIZE(row) == 2) {
        auto input = static_cast<size_t>(unpack_nonnegative_integer(first, "Boxed integer index"));
        if (input >= input_count || !integer_inputs[input] || loaded[input]) {
          throw py::value_error("Boxed integer loads must name each declared input exactly once");
        }
        loaded[input] = true;
        instructions.push_back({Op::Boxed, static_cast<int64_t>(input)});
      } else if (PyUnicode_CompareWithASCIIString(tag, "ceildiv") == 0 && PyTuple_GET_SIZE(row) == 3) {
        auto left = unpack_nonnegative_integer(first, "Ceildiv operand");
        auto right = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(row, 2), "Ceildiv operand"));
        if (static_cast<uint64_t>(left) >= index || right >= index) {
          throw py::value_error("Ceildiv operands must precede their result");
        }
        instructions.push_back({Op::CeilDiv, left, right});
      } else if (PyUnicode_CompareWithASCIIString(tag, "multiply") == 0 && PyTuple_GET_SIZE(row) == 3) {
        auto left = unpack_nonnegative_integer(first, "Multiply operand");
        auto right = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(row, 2), "Multiply operand"));
        if (static_cast<uint64_t>(left) >= index || right >= index) {
          throw py::value_error("Multiply operands must precede their result");
        }
        instructions.push_back({Op::Multiply, left, right});
      } else {
        throw py::value_error("Unsupported numeric instruction or arity");
      }
    }
    if (loaded != integer_inputs) {
      throw py::value_error("Every declared integer input requires one boxed load");
    }
  }

  void evaluate(std::vector<THPObjectPtr>& inputs, std::vector<int64_t>& values) const {
    for (size_t index = 0; index < instructions.size(); ++index) {
      const auto& instruction = instructions[index];
      switch (instruction.op) {
        case Op::Constant:
          values[index] = instruction.first;
          break;
        case Op::Boxed: {
          auto* input = inputs[instruction.first].get();
          if (!PyLong_CheckExact(input)) {
            throw py::type_error("Declared boxed integer inputs must be exact integers");
          }
          values[index] = PyLong_AsLongLong(input);
          if (PyErr_Occurred()) {
            throw py::error_already_set();
          }
          break;
        }
        case Op::CeilDiv: {
          const auto left = values[instruction.first];
          const auto right = values[instruction.second];
          TORCH_CHECK_VALUE(left >= 0 && right > 0, "Ceildiv requires a nonnegative numerator and positive denominator");
          values[index] = left / right + (left % right != 0);
          break;
        }
        case Op::Multiply: {
          const auto left = values[instruction.first];
          const auto right = values[instruction.second];
          TORCH_CHECK_VALUE(left >= 0 && right >= 0, "Multiply requires nonnegative operands");
          uint64_t product = 0;
          TORCH_CHECK_VALUE(
              !c10::mul_overflows(static_cast<uint64_t>(left), static_cast<uint64_t>(right), &product) &&
                  product <= std::numeric_limits<int64_t>::max(),
              "Numeric multiplication overflowed int64");
          values[index] = static_cast<int64_t>(product);
          break;
        }
      }
    }
  }

  std::vector<bool> integer_inputs;
  std::vector<size_t> tensor_inputs;
  std::vector<Instruction> instructions;
};

struct BoxedReplayPlan {
  BoxedReplayPlan(
      PyObject* count,
      PyObject* inputs,
      PyObject* layouts,
      PyObject* prologue,
      PyObject* outputs,
      PyObject* numeric_plan,
      const PythonKernelPointerUpdates& updates)
      : input_count(unpack_nonnegative_integer(count, "Input count")),
        input_indices(unpack_input_indices(inputs, input_count)),
        has_explicit_output_indices(outputs != Py_None) {
    if ((numeric_plan != Py_None) != updates.batch->has_numeric_updates()) {
      throw py::value_error("Numeric batches require a numeric plan; pointer-only batches do not accept one");
    }
    if (numeric_plan != Py_None) {
      numeric = std::make_unique<BoxedNumericPlan>(numeric_plan, input_count, updates.batch->value_count());
      for (auto index : input_indices) {
        if (numeric->integer_inputs[index]) {
          throw py::value_error("Integer inputs cannot supply pointer bindings");
        }
      }
    }
    if (!PyTuple_CheckExact(layouts)) {
      throw py::type_error("Buffer layouts must be an exact tuple");
    }
    auto pointer_count = updates.pointers.size();
    if (input_count > pointer_count ||
        static_cast<size_t>(PyTuple_GET_SIZE(layouts)) != pointer_count - input_count) {
      throw py::value_error("Pointer count must equal input count plus allocation count");
    }
    std::vector<bool> supplied(pointer_count);
    for (auto index : input_indices) {
      supplied[index] = true;
    }
    std::fill(supplied.begin() + input_count, supplied.end(), true);
    if (supplied != updates.referenced) {
      throw py::value_error("Boxed inputs and allocations must cover exactly the prepared pointer indices");
    }
    buffers.reserve(PyTuple_GET_SIZE(layouts));
    for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(layouts); ++index) {
      auto* layout = PyTuple_GET_ITEM(layouts, index);
      if (!PyTuple_CheckExact(layout) || PyTuple_GET_SIZE(layout) != 3 ||
          !THPDtype_Check(PyTuple_GET_ITEM(layout, 0))) {
        throw py::type_error("Buffer layouts must contain dtype, size and stride tuples");
      }
      auto scalar = reinterpret_cast<THPDtype*>(PyTuple_GET_ITEM(layout, 0))->scalar_type;
      TORCH_CHECK_VALUE(!c10::isQIntType(scalar), "Quantized boxed buffers are unsupported");
      auto dtype = c10::scalarTypeToTypeMeta(scalar);
      auto* dimensions = PyTuple_GET_ITEM(layout, 1);
      auto* strides = PyTuple_GET_ITEM(layout, 2);
      auto has_tag = [](PyObject* fields) {
        if (PyTuple_CheckExact(fields)) {
          for (Py_ssize_t i = 0; i < PyTuple_GET_SIZE(fields); ++i) {
            if (PyTuple_CheckExact(PyTuple_GET_ITEM(fields, i))) {
              return true;
            }
          }
        }
        return false;
      };
      if (numeric && (has_tag(dimensions) || has_tag(strides))) {
        if (!PyTuple_CheckExact(dimensions) || !PyTuple_CheckExact(strides)) {
          throw py::type_error("Output sizes and strides must be exact tuples");
        }
        auto rank = PyTuple_GET_SIZE(dimensions);
        if ((rank != 1 && rank != 2) || PyTuple_GET_SIZE(strides) != rank) {
          throw py::value_error("Dynamic buffers require matching rank-one or rank-two sizes and strides");
        }
        auto unpack = [&](PyObject* fields, std::vector<std::optional<size_t>>& values) {
          std::vector<int64_t> result(rank);
          values.resize(rank);
          for (Py_ssize_t i = 0; i < rank; ++i) {
            auto* field = PyTuple_GET_ITEM(fields, i);
            if (!PyTuple_CheckExact(field)) {
              result[i] = unpack_nonnegative_integer(field, "Output dimension");
              continue;
            }
            if (PyTuple_GET_SIZE(field) != 2 || !PyUnicode_CheckExact(PyTuple_GET_ITEM(field, 0)) ||
                PyUnicode_CompareWithASCIIString(PyTuple_GET_ITEM(field, 0), "value") != 0) {
              throw py::value_error("Dynamic dimensions must be tagged value indices");
            }
            auto value = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(field, 1), "Dimension value index"));
            if (value >= numeric->instructions.size()) {
              throw py::value_error("Dimension value index is out of range");
            }
            values[i] = value;
          }
          return result;
        };
        std::vector<std::optional<size_t>> size_values, stride_values;
        auto size = unpack(dimensions, size_values);
        auto stride = unpack(strides, stride_values);
        if (stride_values.back() || stride.back() != 1 ||
            (rank == 2 && (stride_values[0] != size_values[1] ||
                           (!size_values[1] && stride[0] != size[1])))) {
          throw py::value_error("Dynamic buffers require contiguous sizes and strides");
        }
        auto buffer = static_cast<size_t>(index);
        for (size_t i = 0; i < static_cast<size_t>(rank); ++i) {
          if (size_values[i]) {
            layout_values.push_back({buffer, i, *size_values[i], false});
          } else if (size[i] <= 0) {
            throw py::value_error("Dynamic buffer extents must be positive");
          }
          if (stride_values[i]) {
            layout_values.push_back({buffer, i, *stride_values[i], true});
          }
        }
        dynamic_buffers.push_back(buffer);
        buffers.push_back({dtype, std::move(size), std::move(stride), 0});
        continue;
      }
      auto size = unpack_static_dimensions(dimensions);
      auto stride = unpack_static_dimensions(strides);
      uint64_t numel = 0;
      TORCH_CHECK_VALUE(
          !c10::safe_multiplies_u64(size, &numel) && numel <= std::numeric_limits<int64_t>::max(),
          "Boxed buffer element count overflowed");
      auto nbytes = at::detail::computeStorageNbytes(size, stride, dtype.itemsize());
      buffers.push_back({dtype, std::move(size), std::move(stride), nbytes});
    }
    if (outputs == Py_None) {
      output_indices.reserve(buffers.size());
      for (size_t index = 0; index < buffers.size(); ++index) {
        output_indices.push_back(index);
      }
    } else {
      if (!PyTuple_CheckExact(outputs)) {
        throw py::type_error("Output indices must be an exact tuple");
      }
      output_indices.reserve(PyTuple_GET_SIZE(outputs));
      for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(outputs); ++index) {
        auto value = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(outputs, index), "Output index"));
        if (value >= buffers.size() ||
            std::find(output_indices.begin(), output_indices.end(), value) != output_indices.end()) {
          throw py::value_error("Output indices must be distinct and in range");
        }
        output_indices.push_back(value);
      }
    }
    if (prologue != Py_None) {
      if (!PyTuple_CheckExact(prologue) || PyTuple_GET_SIZE(prologue) != 2) {
        throw py::type_error("Input prologue must contain indices and the native normalization builtin");
      }
      copy_indices = unpack_input_indices(PyTuple_GET_ITEM(prologue, 0), input_count);
      if (numeric) {
        for (auto index : copy_indices) {
          if (numeric->integer_inputs[index]) {
            throw py::value_error("Integer inputs cannot require alignment copies");
          }
        }
      }
      auto* builtin = PyTuple_GET_ITEM(prologue, 1);
      THPObjectPtr guards(PyImport_ImportModule("torch._C._dynamo.guards"));
      if (!guards) {
        throw py::error_already_set();
      }
      auto* definition = PyModule_Check(guards.get()) ? PyModule_GetDef(guards.get()) : nullptr;
      auto* method = definition ? definition->m_methods : nullptr;
      while (method && method->ml_name && std::strcmp(method->ml_name, "copy_if_misaligned") != 0) {
        ++method;
      }
      if (!definition || !definition->m_name || std::strcmp(definition->m_name, "torch._C._dynamo.guards") != 0 ||
          !method || !method->ml_name || method->ml_flags != METH_O ||
          Py_TYPE(builtin) != &PyCFunction_Type || PyCFunction_GET_FLAGS(builtin) != METH_O ||
          PyCFunction_GET_FUNCTION(builtin) != method->ml_meth || PyCFunction_GET_SELF(builtin) != guards.get() ||
          PyDict_GetItemString(PyModule_GetDict(guards.get()), "copy_if_misaligned") != builtin) {
        throw py::value_error("Input prologue requires the exact native copy_if_misaligned builtin");
      }
      copy_builtin = Py_NewRef(builtin);
      copy_function = method->ml_meth;
    }
  }

  size_t input_count;
  std::vector<size_t> input_indices;
  const bool has_explicit_output_indices;
  std::vector<BoxedBufferLayout> buffers;
  std::vector<BoxedLayoutValue> layout_values;
  std::vector<size_t> dynamic_buffers;
  std::vector<size_t> output_indices;
  std::vector<size_t> copy_indices;
  THPObjectPtr copy_builtin;
  PyCFunction copy_function = nullptr;
  std::unique_ptr<BoxedNumericPlan> numeric;
  std::optional<at::cuda::detail::InputReleasePlan> release;
};

struct BoxedInvocation {
  struct Buffer {
    c10::DataPtr data_ptr;
    c10::intrusive_ptr<c10::StorageImpl> storage;
  };

  explicit BoxedInvocation(const BoxedReplayPlan& plan)
      : originals(plan.input_count), normalized(plan.input_count), buffers(plan.buffers.size()) {
    if (plan.numeric) {
      values.resize(plan.numeric->instructions.size());
      layouts = plan.buffers;
    }
  }

  void clear() {
    result = nullptr;
    for (auto& buffer : buffers) {
      buffer.storage.reset();
      buffer.data_ptr.clear();
    }
    for (auto& input : normalized) {
      input = nullptr;
    }
    for (auto& input : originals) {
      input = nullptr;
    }
    pending.reset();
  }

  std::unique_ptr<c10::cuda::CUDACachingAllocator::PendingGraphInputs> pending;
  std::vector<THPObjectPtr> originals;
  std::vector<THPObjectPtr> normalized;
  std::vector<Buffer> buffers;
  std::vector<int64_t> values;
  std::vector<BoxedBufferLayout> layouts;
  THPObjectPtr result;
};

class PythonGraphReplayOwner {
 public:
  PythonGraphReplayOwner(
      std::shared_ptr<at::cuda::CUDAGraph> graph,
      const PythonKernelPointerUpdates& updates,
      PyObject* stream_object,
      PyObject* resources,
      c10::cuda::CUDAStream stream,
      std::unique_ptr<BoxedReplayPlan> boxed_plan = nullptr,
      std::unique_ptr<BoxedInvocation> invocation = nullptr,
      PyObject* release_plan = Py_None)
      : pointers_(updates.pointers.size()),
        stream_(stream),
        stream_owner_(Py_NewRef(stream_object)),
        resources_(Py_NewRef(resources)),
        boxed_plan_(std::move(boxed_plan)),
        invocation_(std::move(invocation)) {
    c10::cuda::CUDAGuard guard(stream_.device_index());
    context_ = current_replay_context();
    cudaStreamCaptureStatus capture;
    C10_CUDA_CHECK(cudaStreamIsCapturing(stream_.stream(), &capture));
    TORCH_CHECK(capture == cudaStreamCaptureStatusNone, "Cannot bind a capturing replay stream");
    lease_ = std::make_unique<at::cuda::detail::GraphReplayLease>(
        std::move(graph), updates.batch, stream_.device_index());
    if (release_plan != Py_None) {
      if (!boxed_plan_ || !boxed_plan_->has_explicit_output_indices ||
          !PyTuple_CheckExact(release_plan) || PyTuple_GET_SIZE(release_plan) != 2) {
        throw py::value_error("Input release requires a boxed allocation plan and exact (steps, nodes) tuple");
      }
      auto* steps = PyTuple_GET_ITEM(release_plan, 0);
      auto* nodes = PyTuple_GET_ITEM(release_plan, 1);
      if (!PyTuple_CheckExact(steps) || !PyTuple_CheckExact(nodes)) {
        throw py::type_error("Release steps and nodes must be exact tuples");
      }
      std::vector<at::cuda::detail::InputReleaseStep> operations;
      std::vector<uintptr_t> handles;
      for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(steps); ++index) {
        auto* step = PyTuple_GET_ITEM(steps, index);
        if (!PyTuple_CheckExact(step) || PyTuple_GET_SIZE(step) != 2 ||
            !PyUnicode_CheckExact(PyTuple_GET_ITEM(step, 0))) {
          throw py::type_error("Release operations require exact (kind, index) pairs");
        }
        auto* name = PyTuple_GET_ITEM(step, 0);
        at::cuda::detail::InputReleaseKind kind;
        if (PyUnicode_CompareWithASCIIString(name, "allocate") == 0) {
          kind = at::cuda::detail::InputReleaseKind::Allocate;
        } else if (PyUnicode_CompareWithASCIIString(name, "kernel") == 0) {
          kind = at::cuda::detail::InputReleaseKind::Kernel;
        } else if (PyUnicode_CompareWithASCIIString(name, "drop") == 0) {
          kind = at::cuda::detail::InputReleaseKind::Drop;
        } else {
          throw py::value_error("Unknown release operation");
        }
        operations.push_back({kind, static_cast<size_t>(unpack_nonnegative_integer(
            PyTuple_GET_ITEM(step, 1), "Release index"))});
      }
      for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(nodes); ++index) {
        handles.push_back(static_cast<uintptr_t>(unpack_nonnegative_integer(
            PyTuple_GET_ITEM(nodes, index), "Release node")));
      }
      auto prepared = lease_->prepare_input_release(
          std::move(operations), handles, boxed_plan_->input_count, boxed_plan_->buffers.size());
      if (boxed_plan_->numeric) {
        for (auto index : prepared.candidates) {
          if (boxed_plan_->numeric->integer_inputs[index]) {
            throw py::value_error("Integer inputs cannot be released as saved Tensor inputs");
          }
        }
      }
      boxed_plan_->release = std::move(prepared);
    }
  }

  void replay(py::handle pointers) {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock(), "Native graph replay owner is busy");
    TORCH_CHECK(!closed_ && !failed_, "Native graph replay owner is closed or failed");
    unpack_pointer_values(pointers, pointers_);
    TORCH_CHECK(
        c10::cuda::getCurrentCUDAStream(stream_.device_index()) == stream_,
        "Native graph replay requires its bound stream");
    enqueue_locked();
  }

  py::tuple call(py::handle inputs) {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock(), "Native graph replay owner is busy");
    TORCH_CHECK(!closed_ && !failed_, "Native graph replay owner is closed or failed");
    return boxed_plan_->numeric ? call_impl<true>(inputs) : call_impl<false>(inputs);
  }

  template <bool Numeric, bool Dispatched = false>
  py::tuple call_impl(
      py::handle inputs,
      std::vector<THPObjectPtr>* snapshot = nullptr,
      const std::atomic<bool>* invalidated = nullptr) {
    auto& plan = *boxed_plan_;
    c10::cuda::CUDAGuard guard(stream_.device_index());
    check_boxed_stream();
    THPObjectPtr result(PyTuple_New(plan.output_indices.size()));
    if (!result) {
      throw py::error_already_set();
    }
    check_boxed_stream();
    if constexpr (Dispatched) {
      TORCH_CHECK(!invalidated->load(), "Native boxed dispatch was invalidated during admission");
    }
    // Validate after result allocation, which can trigger GC and mutate a box.
    if (!PyList_CheckExact(inputs.ptr())) {
      throw py::type_error("Boxed graph inputs must be an exact list");
    }
    if (static_cast<size_t>(PyList_GET_SIZE(inputs.ptr())) != plan.input_count) {
      throw py::value_error("Boxed graph input count differs from preparation");
    }
    if constexpr (Numeric && !Dispatched) {
      for (auto index : plan.numeric->tensor_inputs) {
        if (!THPVariable_CheckExact(PyList_GET_ITEM(inputs.ptr(), index))) {
          throw py::type_error("Declared Tensor inputs must be Tensors or Parameters");
        }
      }
    } else if constexpr (!Dispatched) {
      for (size_t index = 0; index < plan.input_count; ++index) {
        if (!THPVariable_CheckExact(PyList_GET_ITEM(inputs.ptr(), index))) {
          throw py::type_error("Boxed graph inputs must be Tensors or Parameters");
        }
      }
    }
    auto& invocation = *invocation_;
    for (size_t index = 0; index < plan.input_count; ++index) {
      auto* value = PyList_GET_ITEM(inputs.ptr(), index);
      if constexpr (Dispatched) {
        if (value != (*snapshot)[index].get()) {
          throw py::value_error("Boxed inputs changed after native guard selection");
        }
        if constexpr (Numeric) {
          if (!plan.numeric->integer_inputs[index] && !THPVariable_CheckExact(value)) {
            throw py::type_error("Declared Tensor inputs must be Tensors or Parameters");
          }
        } else if (!THPVariable_CheckExact(value)) {
          throw py::type_error("Boxed graph inputs must be Tensors or Parameters");
        }
      } else {
        invocation.originals[index] = Py_NewRef(value);
      }
    }
    if constexpr (Dispatched) {
      invocation.originals.swap(*snapshot);
    }
    invocation.result = std::move(result);
    bool started = false;
    try {
      if constexpr (Numeric) {
        plan.numeric->evaluate(invocation.originals, invocation.values);
        lease_->validate_values(invocation.values);
        for (const auto& binding : plan.layout_values) {
          auto& layout = invocation.layouts[binding.buffer];
          auto& fields = binding.stride ? layout.stride : layout.size;
          fields[binding.dimension] = invocation.values[binding.value];
        }
        for (auto buffer : plan.dynamic_buffers) {
          auto& layout = invocation.layouts[buffer];
          for (auto extent : layout.size) {
            TORCH_CHECK_VALUE(extent > 0, "Dynamic buffer extent must be positive");
          }
          uint64_t numel = 0;
          TORCH_CHECK_VALUE(
              !c10::safe_multiplies_u64(layout.size, &numel) && numel <= std::numeric_limits<int64_t>::max(),
              "Boxed buffer element count overflowed");
          layout.nbytes = at::detail::computeStorageNbytes(layout.size, layout.stride, layout.dtype.itemsize());
        }
      }
      const auto& layouts = Numeric ? invocation.layouts : plan.buffers;
      if (PyList_SetSlice(inputs.ptr(), 0, PY_SSIZE_T_MAX, nullptr) != 0) {
        throw py::error_already_set();
      }
      for (auto index : plan.copy_indices) {
        started = may_have_work_ = true;
        invocation.normalized[index] = plan.copy_function(
            PyCFunction_GET_SELF(plan.copy_builtin.get()), invocation.originals[index].get());
        if (!invocation.normalized[index]) {
          throw py::error_already_set();
        }
        check_boxed_stream();
      }
      for (auto index : plan.input_indices) {
        auto& input = invocation.normalized[index] ? invocation.normalized[index] : invocation.originals[index];
        pointers_[index] = reinterpret_cast<uintptr_t>(THPVariable_Unpack(input.get()).data_ptr());
      }
      auto* allocator = at::cuda::getCUDADeviceAllocator();
      if (plan.release) {
        started = true;
        std::vector<c10::cuda::CUDACachingAllocator::PendingGraphInput> candidates;
        candidates.reserve(plan.release->candidates.size());
        bool supported = true;
        for (auto index : plan.release->candidates) {
          auto& original = invocation.originals[index];
          auto& normalized = invocation.normalized[index];
          auto& operand = normalized ? normalized : original;
          const auto& storage = THPVariable_Unpack(operand.get()).storage();
          candidates.push_back({&storage.data_ptr(), storage.nbytes(), 16});
          if (normalized && normalized.get() != original.get()) {
            const auto& source = THPVariable_Unpack(original.get()).storage().data_ptr();
            supported &= source.get_deleter() == allocator->raw_deleter() &&
                source.get_context() == source.get();
          }
        }
        if (supported) {
          invocation.pending = c10::cuda::CUDACachingAllocator::PendingGraphInputs::arm(
              candidates, c10::cuda::CUDACachingAllocator::get(), stream_);
        }
        if (invocation.pending) {
          for (auto index : plan.release->candidates) {
            auto& normalized = invocation.normalized[index];
            auto& original = invocation.originals[index];
            if (normalized && normalized.get() != original.get()) {
              c10::cuda::CUDACachingAllocator::recordStream(
                  THPVariable_Unpack(original.get()).storage().data_ptr(), stream_);
            }
          }
        }
      }
      auto allocate = [&](size_t index) {
        started = may_have_work_ = true;
        auto& buffer = invocation.buffers[index];
        if (invocation.pending && layouts[index].nbytes &&
            !plan.release->eligible_inputs[index].empty()) {
          auto claimed = invocation.pending->tryClaim(
              layouts[index].nbytes, 16, plan.release->eligible_inputs[index]);
          if (claimed) {
            buffer.data_ptr = std::move(*claimed);
          }
        }
        if (!buffer.data_ptr) {
          buffer.data_ptr = allocator->allocate(layouts[index].nbytes);
        }
        pointers_[plan.input_count + index] = reinterpret_cast<uintptr_t>(buffer.data_ptr.get());
        check_boxed_stream();
      };
      if (invocation.pending) {
        for (const auto& step : plan.release->steps) {
          if (step.kind == at::cuda::detail::InputReleaseKind::Allocate) {
            allocate(step.index);
          } else {
            invocation.normalized[step.index] = nullptr;
            invocation.originals[step.index] = nullptr;
            check_boxed_stream();
          }
        }
      } else {
        for (size_t index = 0; index < plan.buffers.size(); ++index) {
          allocate(index);
        }
      }
      check_boxed_stream();
      started = true;
      if constexpr (Numeric) {
        may_have_work_ = true;
        py::gil_scoped_release release;
        lease_->replay(pointers_, invocation.values, invocation.pending.get());
      } else if (invocation.pending) {
        may_have_work_ = true;
        py::gil_scoped_release release;
        lease_->replay(pointers_, invocation.pending.get());
      } else {
        enqueue_locked();
      }
      for (size_t index = 0; index < plan.output_indices.size(); ++index) {
        auto buffer_index = plan.output_indices[index];
        const auto& layout = layouts[buffer_index];
        auto& output = invocation.buffers[buffer_index];
        // Direct forwarding leaves data_ptr here if StorageImpl allocation fails.
        output.storage = c10::make_intrusive<c10::StorageImpl>(
            c10::StorageImpl::use_byte_size_t(), c10::SymInt(static_cast<int64_t>(layout.nbytes)),
            std::move(output.data_ptr), allocator, /*resizable=*/true);
        auto tensor = at::detail::make_tensor_base<c10::TensorImpl>(
            c10::Storage(output.storage), c10::DispatchKeySet(c10::DispatchKey::CUDA), layout.dtype);
        tensor.unsafeGetTensorImpl()->set_sizes_and_strides(layout.size, layout.stride);
        THPObjectPtr value(THPVariable_Wrap(std::move(tensor)));
        if (!value) {
          throw py::error_already_set();
        }
        PyTuple_SET_ITEM(invocation.result.get(), index, value.release());
      }
      result = invocation.result.release();
      invocation.clear();
      return py::reinterpret_steal<py::tuple>(result.release());
    } catch (...) {
      if (invocation.pending && !invocation.pending->finished() &&
          !invocation.pending->submission_started()) {
        try {
          invocation.pending->abortUnsubmitted();
        } catch (...) {
          quarantined_ = true;
        }
      }
      if (started) {
        failed_ = true;
      } else {
        invocation.clear();
      }
      throw;
    }
  }

  // The cold compiler caller proves complete pointer rebinding, unshared
  // capture/pool ownership and drained preparation work before this call.
  // Explicit output indices alone do not establish those obligations.
  void retire_capture_pool() {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock(), "Native graph replay owner is busy");
    TORCH_CHECK(!closed_ && !failed_, "Native graph replay owner is closed or failed");
    TORCH_CHECK(
        boxed_plan_ && boxed_plan_->has_explicit_output_indices,
        "Capture pool retirement requires explicit allocation output indices");
    TORCH_CHECK(!may_have_work_, "Capture pool retirement must precede replay, copies and allocations");
    c10::cuda::CUDAGuard guard(stream_.device_index());
    check_boxed_stream();
    TORCH_CHECK(current_replay_context() == context_, "Native graph replay context changed during pool retirement");
    bool releasing = false;
    try {
      py::gil_scoped_release release;
      if (!lease_->check_capture_pool_retirement()) {
        return;
      }
      releasing = true;
      lease_->retire_capture_pool();
    } catch (...) {
      if (releasing) {
        // Pool release can throw after decrementing a reference. Never retry it.
        failed_ = true;
        quarantined_ = true;
      }
      throw;
    }
  }

  void close() {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock(), "Native graph replay owner is busy");
    if (closed_) {
      return;
    }
    TORCH_CHECK(!quarantined_, "Native graph replay owner is quarantined");
    try {
      c10::cuda::CUDAGuard guard(stream_.device_index());
      TORCH_CHECK(current_replay_context() == context_, "Native graph replay context changed during close");
      {
        py::gil_scoped_release release;
        if (may_have_work_) {
          C10_CUDA_CHECK(cudaStreamSynchronize(stream_.stream()));
        }
        if (invocation_ && invocation_->pending && !invocation_->pending->finished()) {
          invocation_->pending->finishSubmitted();
        }
        lease_->close();
      }
      invocation_.reset();
      boxed_plan_.reset();
      resources_ = nullptr;
      stream_owner_ = nullptr;
      lease_.reset();
      closed_ = true;
    } catch (...) {
      failed_ = true;
      quarantined_ = true;
      throw;
    }
  }

  bool closed() const {
    return closed_.load();
  }

  bool failed() const {
    return failed_.load();
  }

 private:
  friend class PythonBoxedGraphDispatch;

  void check_boxed_stream() const {
    TORCH_CHECK(
        c10::cuda::current_device() == stream_.device_index() &&
            c10::cuda::getCurrentCUDAStream(stream_.device_index()) == stream_,
        "Native boxed graph replay requires its bound device and stream");
  }

  void enqueue_locked() {
    may_have_work_ = true;
    try {
      py::gil_scoped_release release;
      lease_->replay(pointers_);
    } catch (...) {
      failed_ = true;
      throw;
    }
  }

  std::unique_ptr<at::cuda::detail::GraphReplayLease> lease_;
  std::vector<uintptr_t> pointers_;
  c10::cuda::CUDAStream stream_;
  uintptr_t context_ = 0;
  THPObjectPtr stream_owner_;
  THPObjectPtr resources_;
  std::unique_ptr<BoxedReplayPlan> boxed_plan_;
  std::unique_ptr<BoxedInvocation> invocation_;
  std::mutex mutex_;
  bool may_have_work_ = false;
  std::atomic<bool> failed_{false};
  bool quarantined_ = false;
  std::atomic<bool> closed_{false};
};

void destroy_replay_owner(PythonGraphReplayOwner* owner) noexcept {
  if (!Py_IsInitialized() || !PyGILState_Check()) {
    return;
  }
  PyObject *type, *value, *traceback;
  PyErr_Fetch(&type, &value, &traceback);
  try {
    owner->close();
    delete owner;
  } catch (...) {
    // Unknown completion or teardown retains the lease, modules and buffers.
    PyErr_Clear();
  }
  PyErr_Restore(type, value, traceback);
}

class PythonBoxedGraphReplay {
 public:
  explicit PythonBoxedGraphReplay(std::shared_ptr<PythonGraphReplayOwner> owner)
      : owner_(std::move(owner)) {}

  py::tuple call(py::handle inputs) {
    return owner_->call(inputs);
  }

  void retire_capture_pool() {
    owner_->retire_capture_pool();
  }

  void close() {
    owner_->close();
  }

  bool closed() const {
    return owner_->closed();
  }

  bool failed() const {
    return owner_->failed();
  }

 private:
  friend class PythonBoxedGraphDispatch;

  std::shared_ptr<PythonGraphReplayOwner> owner_;
};

class PythonBoxedGraphDispatch {
 public:
  PythonBoxedGraphDispatch(py::handle variants, py::handle on_miss)
      : on_miss_(Py_NewRef(on_miss.ptr())) {
    if (!PyCallable_Check(on_miss.ptr())) {
      throw py::type_error("Native boxed dispatch requires a callable miss handler");
    }
    if (!PyTuple_CheckExact(variants.ptr()) || PyTuple_GET_SIZE(variants.ptr()) == 0) {
      throw py::type_error("Native boxed dispatch requires a nonempty exact variant tuple");
    }
    for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(variants.ptr()); ++index) {
      auto* row = PyTuple_GET_ITEM(variants.ptr(), index);
      if (!PyTuple_CheckExact(row) || PyTuple_GET_SIZE(row) != 2) {
        throw py::type_error("Dispatch variants must contain an entry and predicate");
      }
      append(py::cast<std::shared_ptr<PythonBoxedGraphReplay>>(py::handle(PyTuple_GET_ITEM(row, 0))),
             py::handle(PyTuple_GET_ITEM(row, 1)));
    }
  }

  void append(std::shared_ptr<PythonBoxedGraphReplay> entry, py::handle predicate) {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock(), "Native boxed dispatcher is busy");
    TORCH_CHECK(!closed_ && !failed_ && !invalidated_, "Native boxed dispatcher cannot accept variants");
    if (!entry) {
      throw py::type_error("Dispatch variants require a prepared boxed entry");
    }
    auto& owner = *entry->owner_;
    std::unique_lock entry_lock(owner.mutex_, std::try_to_lock);
    TORCH_CHECK(entry_lock.owns_lock(), "Native graph replay owner is busy");
    TORCH_CHECK(!owner.closed_ && !owner.failed_, "Dispatch entry is closed or failed");
    const auto& plan = *owner.boxed_plan_;
    std::vector<bool> integer_inputs(plan.input_count, false);
    if (plan.numeric) {
      integer_inputs = plan.numeric->integer_inputs;
    }
    if (!variants_.empty() &&
        (integer_inputs != integer_inputs_ || plan.output_indices.size() != output_count_ ||
         owner.stream_.device_index() != device_ || owner.stream_.stream() != stream_ ||
         owner.context_ != context_)) {
      throw py::value_error("Dispatch entries must share boxed input kinds, output arity, device, stream and context");
    }
    if (!PyTuple_CheckExact(predicate.ptr()) || PyTuple_GET_SIZE(predicate.ptr()) != 3 ||
        !PyLong_CheckExact(PyTuple_GET_ITEM(predicate.ptr(), 1)) ||
        PyTuple_GET_ITEM(predicate.ptr(), 2) == Py_None) {
      throw py::type_error("A predicate requires integer indices, a function address and a library owner");
    }
    auto indices = unpack_input_indices(PyTuple_GET_ITEM(predicate.ptr(), 0), plan.input_count);
    for (auto index : indices) {
      if (!integer_inputs[index]) {
        throw py::value_error("Predicate sources must be declared boxed integer inputs");
      }
    }
    auto address = PyLong_AsUnsignedLongLong(PyTuple_GET_ITEM(predicate.ptr(), 1));
    if (PyErr_Occurred()) {
      throw py::error_already_set();
    }
    if (address == 0 || address > std::numeric_limits<uintptr_t>::max()) {
      throw py::value_error("Predicate function address is out of range");
    }
    Variant variant{std::move(entry), std::move(indices), {},
                    reinterpret_cast<Predicate>(static_cast<uintptr_t>(address)),
                    THPObjectPtr(Py_NewRef(PyTuple_GET_ITEM(predicate.ptr(), 2)))};
    variant.values.resize(variant.indices.size());
    if (variants_.empty()) {
      originals_.resize(plan.input_count);
      integers_.resize(plan.input_count);
      integer_inputs_ = std::move(integer_inputs);
      for (size_t index = 0; index < integer_inputs_.size(); ++index) {
        if (integer_inputs_[index]) {
          integer_indices_.push_back(index);
        }
      }
      output_count_ = plan.output_indices.size();
      device_ = owner.stream_.device_index();
      stream_ = owner.stream_.stream();
      context_ = owner.context_;
    }
    variants_.push_back(std::move(variant));
  }

  py::object call(py::handle inputs) {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock() && !miss_active_, "Native boxed dispatcher is busy");
    TORCH_CHECK(!closed_ && !failed_, "Native boxed dispatcher is closed or failed");
    PythonGraphReplayOwner* selected = nullptr;
    try {
      if (!PyList_CheckExact(inputs.ptr())) {
        throw py::type_error("Boxed graph inputs must be an exact list");
      }
      if (static_cast<size_t>(PyList_GET_SIZE(inputs.ptr())) != originals_.size()) {
        throw py::value_error("Boxed graph input count differs from preparation");
      }
      // Pin before any Python allocation; guards and replay use these same objects.
      for (size_t index = 0; index < originals_.size(); ++index) {
        originals_[index] = Py_NewRef(PyList_GET_ITEM(inputs.ptr(), index));
      }
      for (auto index : integer_indices_) {
        auto* value = originals_[index].get();
        if (!PyLong_CheckExact(value)) {
          throw py::type_error("Declared boxed integer inputs must be exact integers");
        }
        integers_[index] = PyLong_AsLongLong(value);
        if (PyErr_Occurred()) {
          throw py::error_already_set();
        }
      }
      if (!invalidated_) {
        for (auto& variant : variants_) {
          for (size_t index = 0; index < variant.indices.size(); ++index) {
            variant.values[index] = integers_[variant.indices[index]];
          }
          auto matches = variant.predicate(variant.values.data(), nullptr);
          if (matches != 0 && matches != 1) {
            failed_ = true;
            throw py::value_error("Native predicate must return zero or one");
          }
          if (matches) {
            selected = variant.entry->owner_.get();
            std::unique_lock entry_lock(selected->mutex_, std::try_to_lock);
            TORCH_CHECK(entry_lock.owns_lock(), "Native graph replay owner is busy");
            TORCH_CHECK(!selected->closed_ && !selected->failed_, "Dispatch entry is closed or failed");
            return selected->boxed_plan_->numeric
                ? selected->call_impl<true, true>(inputs, &originals_, &invalidated_)
                : selected->call_impl<false, true>(inputs, &originals_, &invalidated_);
          }
        }
      }
      clear_snapshot();
    } catch (...) {
      clear_snapshot();
      if (selected && selected->failed_) {
        failed_ = true;
      }
      throw;
    }
    miss_active_ = true;
    lock.unlock();
    // The cold callback may append, but cannot recursively invoke or close us.
    THPObjectPtr result(PyObject_CallOneArg(on_miss_.get(), inputs.ptr()));
    miss_active_ = false;
    if (!result) {
      throw py::error_already_set();
    }
    return py::reinterpret_steal<py::object>(result.release());
  }

  void invalidate() {
    TORCH_CHECK(!closed_ && !failed_, "Native boxed dispatcher is closed or failed");
    invalidated_ = true;
  }

  void close() {
    std::unique_lock lock(mutex_, std::try_to_lock);
    TORCH_CHECK(lock.owns_lock() && !miss_active_, "Native boxed dispatcher is busy");
    if (closed_) {
      return;
    }
    invalidated_ = true;
    try {
      for (auto& variant : variants_) {
        variant.entry->close();
      }
      variants_.clear();
      on_miss_ = nullptr;
      closed_ = true;
    } catch (...) {
      // Keep every remaining entry and predicate library if draining fails.
      failed_ = true;
      throw;
    }
  }

  bool closed() const {
    return closed_.load();
  }

  bool failed() const {
    return failed_.load();
  }

  bool invalidated() const {
    return invalidated_.load();
  }

 private:
  using Predicate = int8_t (*)(int64_t*, double*);
  struct Variant {
    std::shared_ptr<PythonBoxedGraphReplay> entry;
    std::vector<size_t> indices;
    std::vector<int64_t> values;
    Predicate predicate;
    THPObjectPtr library;
  };

  void clear_snapshot() {
    for (auto& value : originals_) {
      value = nullptr;
    }
  }

  std::vector<Variant> variants_;
  std::vector<THPObjectPtr> originals_;
  std::vector<int64_t> integers_;
  std::vector<bool> integer_inputs_;
  std::vector<size_t> integer_indices_;
  size_t output_count_ = 0;
  c10::DeviceIndex device_ = -1;
  cudaStream_t stream_ = nullptr;
  uintptr_t context_ = 0;
  THPObjectPtr on_miss_;
  std::mutex mutex_;
  std::atomic<bool> miss_active_{false};
  std::atomic<bool> invalidated_{false};
  std::atomic<bool> failed_{false};
  std::atomic<bool> closed_{false};
};

void destroy_boxed_dispatcher(PythonBoxedGraphDispatch* dispatcher) noexcept {
  if (!Py_IsInitialized() || !PyGILState_Check()) {
    return;
  }
  PyObject *type, *value, *traceback;
  PyErr_Fetch(&type, &value, &traceback);
  try {
    dispatcher->close();
    delete dispatcher;
  } catch (...) {
    PyErr_Clear();
  }
  PyErr_Restore(type, value, traceback);
}

} // namespace

void THCPGraph_init(PyObject* module) {
  // Pybind11 patch notes say "py::module_" is more up-to-date syntax,
  // but CI linter and some builds prefer "module".
  auto torch_C_m = py::handle(module).cast<py::module>();

  torch_C_m.def("_graph_pool_handle", &::at::cuda::graph_pool_handle);

  torch_C_m.def(
      "_cuda_get_capture_frontier",
      torch::wrap_pybind_function([](uintptr_t stream) {
        auto snapshot = [&] {
          py::gil_scoped_release release;
          return at::cuda::detail::get_capture_frontier(stream);
        }();
        py::tuple dependencies(snapshot.dependencies.size());
        for (size_t index = 0; index < snapshot.dependencies.size(); ++index) {
          const auto& [node, edge] = snapshot.dependencies[index];
          dependencies[index] = py::make_tuple(
              node, py::bytes(reinterpret_cast<const char*>(edge.data()), edge.size()));
        }
        return py::make_tuple(snapshot.status, snapshot.capture_id, snapshot.graph, dependencies);
      }),
      py::arg("stream"));

  shared_ptr_class_<at::cuda::detail::KernelParamUpdateBatch>(
      torch_C_m, "_CUDAGraphKernelParamUpdates");
  shared_ptr_class_<PythonKernelPointerUpdates>(
      torch_C_m, "_CUDAGraphKernelPointerUpdates");
  shared_ptr_class_<PythonGraphReplayOwner>(torch_C_m, "_CUDAGraphReplayOwner")
      .def("replay", torch::wrap_pybind_function(&PythonGraphReplayOwner::replay), py::arg("pointers"))
      .def("close", torch::wrap_pybind_function(&PythonGraphReplayOwner::close))
      .def_property_readonly("closed", &PythonGraphReplayOwner::closed)
      .def_property_readonly("failed", &PythonGraphReplayOwner::failed);
  shared_ptr_class_<PythonBoxedGraphReplay>(torch_C_m, "_CUDAGraphBoxedReplay")
      .def("__call__", torch::wrap_pybind_function(&PythonBoxedGraphReplay::call), py::arg("inputs"))
      .def("_retire_capture_pool", torch::wrap_pybind_function(&PythonBoxedGraphReplay::retire_capture_pool))
      .def("close", torch::wrap_pybind_function(&PythonBoxedGraphReplay::close))
      .def_property_readonly("_boxed_call", [](const PythonBoxedGraphReplay&) { return true; })
      .def_property_readonly("closed", &PythonBoxedGraphReplay::closed)
      .def_property_readonly("failed", &PythonBoxedGraphReplay::failed);
  shared_ptr_class_<PythonBoxedGraphDispatch>(torch_C_m, "_CUDAGraphBoxedDispatch")
      .def("__call__", torch::wrap_pybind_function(&PythonBoxedGraphDispatch::call), py::arg("inputs"))
      .def("append", torch::wrap_pybind_function(&PythonBoxedGraphDispatch::append),
           py::arg("entry"), py::arg("predicate"))
      .def("invalidate", torch::wrap_pybind_function(&PythonBoxedGraphDispatch::invalidate))
      .def("close", torch::wrap_pybind_function(&PythonBoxedGraphDispatch::close))
      .def_property_readonly("_boxed_call", [](const PythonBoxedGraphDispatch&) { return true; })
      .def_property_readonly("closed", &PythonBoxedGraphDispatch::closed)
      .def_property_readonly("failed", &PythonBoxedGraphDispatch::failed)
      .def_property_readonly("invalidated", &PythonBoxedGraphDispatch::invalidated);
  torch_C_m.def(
      "_cuda_make_boxed_dispatch",
      torch::wrap_pybind_function([](py::handle variants, py::handle on_miss) {
        return std::shared_ptr<PythonBoxedGraphDispatch>(
            new PythonBoxedGraphDispatch(variants, on_miss), destroy_boxed_dispatcher);
      }),
      py::arg("variants"), py::arg("on_miss"));

  shared_ptr_class_<::at::cuda::CUDAGraph>(torch_C_m, "_CUDAGraph")
      .def(py::init<bool>(), py::arg("keep_graph") = false)
      .def(
          "capture_begin",
          [](::at::cuda::CUDAGraph& self,
             std::optional<c10::cuda::MempoolId_t> pool_opt,
             const std::string& capture_error_mode) {
            cudaStreamCaptureMode capture_mode{};
            c10::cuda::MempoolId_t pool = pool_opt.has_value()
                ? pool_opt.value()
                : c10::cuda::MempoolId_t{0, 0};
            if (capture_error_mode == "global") {
              capture_mode = cudaStreamCaptureModeGlobal;
            } else if (capture_error_mode == "thread_local") {
              capture_mode = cudaStreamCaptureModeThreadLocal;
            } else if (capture_error_mode == "relaxed") {
              capture_mode = cudaStreamCaptureModeRelaxed;
            } else {
              TORCH_CHECK(
                  false,
                  "Unknown capture error mode. Expected `global`, `thread_local`, or `relaxed`, got ",
                  capture_error_mode);
            }
            return self.capture_begin(pool, capture_mode);
          },
          py::arg("pool"),
          py::arg("capture_error_mode"),
          py::call_guard<py::gil_scoped_release>())
      .def(
          "capture_end",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::capture_end))
      .def(
          "capture_end_pre",
          torch::wrap_pybind_function_no_gil(
              &at::cuda::CUDAGraph::capture_end_pre))
      .def(
          "capture_end_post",
          torch::wrap_pybind_function_no_gil(
              &at::cuda::CUDAGraph::capture_end_post))
      .def(
          "instantiate",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::instantiate))
      .def_property_readonly(
          "_has_graph_exec", &at::cuda::CUDAGraph::has_graph_exec)
      .def("_check_not_owned", torch::wrap_pybind_function(&at::cuda::CUDAGraph::check_not_owned))
      .def(
          "_make_replay_owner",
          // Internal cold caller: an unshared private capture, no published
          // pool/raw handles, and preparation work already drained. The stream
          // is ATen-managed in the capture context; resources own modules/data.
          torch::wrap_pybind_function([](
              std::shared_ptr<at::cuda::CUDAGraph> graph,
              const PythonKernelPointerUpdates& updates,
              py::handle stream,
              py::handle resources) {
            if (updates.batch->has_numeric_updates()) {
              throw py::value_error("Numeric updates require a boxed numeric plan");
            }
            if (!THCPStreamClass ||
                !PyObject_TypeCheck(stream.ptr(), reinterpret_cast<PyTypeObject*>(THCPStreamClass))) {
              throw py::type_error("Native graph replay requires a CUDA stream");
            }
            if (!PyTuple_CheckExact(resources.ptr())) {
              throw py::type_error("Native graph replay resources must be an exact tuple");
            }
            auto bound_stream = reinterpret_cast<THCPStream*>(stream.ptr())->cuda_stream;
            return std::shared_ptr<PythonGraphReplayOwner>(
                new PythonGraphReplayOwner(std::move(graph), updates, stream.ptr(), resources.ptr(), bound_stream),
                destroy_replay_owner);
          }),
          py::arg("updates"), py::arg("stream"), py::arg("resources"))
      .def(
          "_make_boxed_replay",
          // Same private capture contract as _make_replay_owner. The compiler
          // binds input i and allocation r to pointer indices i and input_count + r.
          torch::wrap_pybind_function([](
              std::shared_ptr<at::cuda::CUDAGraph> graph,
              const PythonKernelPointerUpdates& updates,
              py::handle stream,
              py::handle resources,
              py::handle input_count,
              py::handle used_input_indices,
              py::handle output_layouts,
              py::handle prologue,
              py::handle output_indices,
              py::handle numeric_plan,
              py::handle release_plan) {
            if (!THCPStreamClass ||
                !PyObject_TypeCheck(stream.ptr(), reinterpret_cast<PyTypeObject*>(THCPStreamClass))) {
              throw py::type_error("Native graph replay requires a CUDA stream");
            }
            if (!PyTuple_CheckExact(resources.ptr())) {
              throw py::type_error("Native graph replay resources must be an exact tuple");
            }
            auto plan = std::make_unique<BoxedReplayPlan>(
                input_count.ptr(), used_input_indices.ptr(), output_layouts.ptr(),
                prologue.ptr(), output_indices.ptr(), numeric_plan.ptr(), updates);
            auto invocation = std::make_unique<BoxedInvocation>(*plan);
            auto bound_stream = reinterpret_cast<THCPStream*>(stream.ptr())->cuda_stream;
            auto owner = std::shared_ptr<PythonGraphReplayOwner>(
                new PythonGraphReplayOwner(std::move(graph), updates, stream.ptr(), resources.ptr(),
                                           bound_stream, std::move(plan), std::move(invocation), release_plan.ptr()),
                destroy_replay_owner);
            return std::make_shared<PythonBoxedGraphReplay>(std::move(owner));
          }),
          py::arg("updates"), py::arg("stream"), py::arg("resources"), py::arg("input_count"),
          py::arg("used_input_indices"), py::arg("output_layouts"), py::arg("prologue") = py::none(),
          py::arg("output_indices") = py::none(), py::arg("numeric_plan") = py::none(),
          py::arg("release_plan") = py::none())
      .def(
          "_prepare_kernel_params",
          torch::wrap_pybind_function([](at::cuda::CUDAGraph& self, py::handle updates) {
            if (!PyDict_Check(updates.ptr())) {
              throw py::type_error("kernel parameter updates must be dictionaries");
            }
            std::vector<at::cuda::detail::KernelNodeUpdate> values;
            values.reserve(PyDict_Size(updates.ptr()));
            Py_ssize_t node_position = 0;
            PyObject* node;
            PyObject* arguments;
            while (PyDict_Next(updates.ptr(), &node_position, &node, &arguments)) {
              if (!PyLong_Check(node)) {
                throw py::type_error("kernel node handles must be Python integers");
              }
              if (!PyDict_Check(arguments)) {
                throw py::type_error("kernel parameter updates must be dictionaries");
              }
              auto handle = PyLong_AsVoidPtr(node);
              if (PyErr_Occurred()) {
                throw py::error_already_set();
              }
              at::cuda::detail::KernelNodeUpdate update{reinterpret_cast<uintptr_t>(handle), {}};
              update.arguments.reserve(PyDict_Size(arguments));
              Py_ssize_t argument_position = 0;
              PyObject* index;
              PyObject* value;
              while (PyDict_Next(arguments, &argument_position, &index, &value)) {
                if (!PyLong_CheckExact(index)) {
                  throw py::type_error("Kernel argument index must be an int");
                }
                auto argument_index = PyLong_AsLongLong(index);
                if (PyErr_Occurred()) {
                  PyErr_Clear();
                  throw py::index_error("Kernel argument index is out of range");
                }
                if (!PyBytes_Check(value)) {
                  throw py::type_error("Kernel argument value must be bytes");
                }
                const auto* bytes = reinterpret_cast<const uint8_t*>(PyBytes_AS_STRING(value));
                update.arguments.push_back({
                    argument_index, std::vector<uint8_t>(bytes, bytes + PyBytes_GET_SIZE(value))});
              }
              values.push_back(std::move(update));
            }
            py::gil_scoped_release release;
            return self.prepare_kernel_params(std::move(values));
          }),
          py::arg("updates"))
      .def(
          "_apply_kernel_params",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::update_kernel_params),
          py::arg("updates"))
      .def(
          "_prepare_kernel_pointer_updates",
          torch::wrap_pybind_function([](at::cuda::CUDAGraph& self, py::handle bindings, py::handle pointer_count) {
            if (!PyTuple_CheckExact(bindings.ptr()) || !PyLong_CheckExact(pointer_count.ptr())) {
              throw py::type_error("Pointer bindings must be a tuple and pointer_count an int");
            }
            size_t count = PyLong_AsSize_t(pointer_count.ptr());
            if (PyErr_Occurred()) {
              throw py::error_already_set();
            }
            auto values = unpack_pointer_bindings(bindings.ptr(), false);
            py::gil_scoped_release release;
            auto batch = self.prepare_kernel_pointer_updates(values, count);
            auto result = std::make_shared<PythonKernelPointerUpdates>(std::move(batch), count);
            for (const auto& binding : values) {
              result->referenced[binding.pointer_index] = true;
            }
            return result;
          }),
          py::arg("bindings"), py::arg("pointer_count"))
      .def(
          "_prepare_kernel_replay_updates",
          torch::wrap_pybind_function([](
              at::cuda::CUDAGraph& self,
              py::handle pointer_bindings,
              py::handle pointer_count,
              py::handle scalar_bindings,
              py::handle grid_bindings,
              py::handle value_count) {
            auto pointers = unpack_pointer_bindings(pointer_bindings.ptr(), true, true);
            auto count = static_cast<size_t>(unpack_nonnegative_integer(pointer_count.ptr(), "Pointer count"));
            auto results = static_cast<size_t>(unpack_nonnegative_integer(value_count.ptr(), "Numeric value count"));
            if (!PyTuple_CheckExact(scalar_bindings.ptr()) || !PyTuple_CheckExact(grid_bindings.ptr())) {
              throw py::type_error("Scalar and grid bindings must be exact tuples");
            }
            std::vector<at::cuda::detail::KernelScalarBinding> scalars;
            scalars.reserve(PyTuple_GET_SIZE(scalar_bindings.ptr()));
            for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(scalar_bindings.ptr()); ++index) {
              auto* row = PyTuple_GET_ITEM(scalar_bindings.ptr(), index);
              const bool field = PyTuple_CheckExact(row) && PyTuple_GET_SIZE(row) == 5;
              if (!PyTuple_CheckExact(row) || PyTuple_GET_SIZE(row) != (field ? 5 : 4) ||
                  !PyLong_CheckExact(PyTuple_GET_ITEM(row, 0))) {
                throw py::type_error(
                    "Scalar bindings must contain (node, argument, width, value_index) or "
                    "(node, argument, byte_offset, width, value_index) tuples");
              }
              auto node = PyLong_AsVoidPtr(PyTuple_GET_ITEM(row, 0));
              if (PyErr_Occurred()) {
                throw py::error_already_set();
              }
              auto argument = unpack_nonnegative_integer(PyTuple_GET_ITEM(row, 1), "Scalar argument index");
              std::optional<size_t> byte_offset;
              if (field) {
                byte_offset = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(row, 2), "Scalar byte offset"));
              }
              const auto tail = field ? 3 : 2;
              auto width = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(row, tail), "Scalar width"));
              auto value = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(row, tail + 1), "Scalar value index"));
              scalars.push_back({reinterpret_cast<uintptr_t>(node), argument, width, value, byte_offset});
            }
            std::vector<at::cuda::detail::KernelGridBinding> grids;
            grids.reserve(PyTuple_GET_SIZE(grid_bindings.ptr()));
            for (Py_ssize_t index = 0; index < PyTuple_GET_SIZE(grid_bindings.ptr()); ++index) {
              auto* row = PyTuple_GET_ITEM(grid_bindings.ptr(), index);
              if (!PyTuple_CheckExact(row) || PyTuple_GET_SIZE(row) != 4 ||
                  !PyLong_CheckExact(PyTuple_GET_ITEM(row, 0))) {
                throw py::type_error("Grid bindings must contain (node, x_value, y_value, z_value) tuples");
              }
              auto node = PyLong_AsVoidPtr(PyTuple_GET_ITEM(row, 0));
              if (PyErr_Occurred()) {
                throw py::error_already_set();
              }
              std::array<size_t, 3> values;
              for (size_t axis = 0; axis < values.size(); ++axis) {
                values[axis] = static_cast<size_t>(unpack_nonnegative_integer(PyTuple_GET_ITEM(row, axis + 1), "Grid value index"));
              }
              grids.push_back({reinterpret_cast<uintptr_t>(node), values});
            }
            py::gil_scoped_release release;
            auto batch = self.prepare_kernel_replay_updates(pointers, count, std::move(scalars), std::move(grids), results);
            auto result = std::make_shared<PythonKernelPointerUpdates>(std::move(batch), count);
            for (const auto& binding : pointers) {
              result->referenced[binding.pointer_index] = true;
            }
            return result;
          }),
          py::arg("pointer_bindings"), py::arg("pointer_count"), py::arg("scalar_bindings"),
          py::arg("grid_bindings"), py::arg("value_count"))
      .def(
          "_replay_kernel_pointer_updates",
          torch::wrap_pybind_function([](at::cuda::CUDAGraph& self, PythonKernelPointerUpdates& updates, py::handle pointers) {
            unpack_pointer_values(pointers, updates.pointers);
            py::gil_scoped_release release;
            self.replay_kernel_pointer_updates(*updates.batch, updates.pointers);
          }),
          py::arg("updates"), py::arg("pointers"))
      .def(
          "_inspect_captured_kernel_nodes",
          torch::wrap_pybind_function([](at::cuda::CUDAGraph& self, py::tuple nodes) {
            std::vector<uintptr_t> handles;
            handles.reserve(nodes.size());
            for (auto node : nodes) {
              if (!PyLong_Check(node.ptr())) {
                throw py::type_error("kernel node handles must be Python integers");
              }
              auto handle = PyLong_AsVoidPtr(node.ptr());
              if (PyErr_Occurred()) {
                throw py::error_already_set();
              }
              handles.push_back(reinterpret_cast<uintptr_t>(handle));
            }
            auto snapshot = [&] {
              py::gil_scoped_release release;
              return self.inspect_captured_kernel_nodes(handles);
            }();
            py::tuple graph_nodes(snapshot.nodes.size());
            for (size_t index = 0; index < snapshot.nodes.size(); ++index) {
              graph_nodes[index] = py::int_(snapshot.nodes[index]);
            }
            py::tuple kernels(snapshot.kernels.size());
            for (size_t index = 0; index < snapshot.kernels.size(); ++index) {
              const auto& kernel = snapshot.kernels[index];
              py::tuple arguments(kernel.arguments.size());
              for (size_t slot = 0; slot < kernel.arguments.size(); ++slot) {
                const auto& argument = kernel.arguments[slot];
                arguments[slot] = py::make_tuple(
                    argument.offset, argument.size,
                    py::bytes(reinterpret_cast<const char*>(argument.value.data()), argument.value.size()));
              }
              kernels[index] = py::make_tuple(
                  kernel.node, kernel.function, kernel.kernel, kernel.context,
                  py::make_tuple(kernel.grid[0], kernel.grid[1], kernel.grid[2]),
                  py::make_tuple(kernel.block[0], kernel.block[1], kernel.block[2]),
                  kernel.shared_memory, kernel.packed, arguments);
            }
            return py::make_tuple(snapshot.graph, snapshot.capture_id, graph_nodes, kernels);
          }),
          py::arg("nodes"))
      .def(
          "register_generator_state",
          [](::at::cuda::CUDAGraph& self, py::handle /*raw_generator*/) {
            TORCH_WARN_DEPRECATION(
                "CUDAGraph.register_generator_state() is deprecated, and will be removed in a future PyTorch release. It is now a no-op and can be safely removed from your code.");
          },
          py::arg("generator"))
      .def(
          "replay",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::replay))
      .def(
          "reset",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::reset))
      .def(
          "pool",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::pool))
      .def(
          "pools",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::pools))
      .def(
          "_retain_pool",
          torch::wrap_pybind_function_no_gil(&at::cuda::CUDAGraph::retain_pool))
      .def(
          "enable_debug_mode",
          torch::wrap_pybind_function_no_gil(
              &::at::cuda::CUDAGraph::enable_debug_mode))
      .def(
          "raw_cuda_graph",
          [](::at::cuda::CUDAGraph& self) {
            cudaGraph_t graph = self.raw_cuda_graph();
            // We return a raw int here, since otherwise pybind11 will
            // try to return the underlying struct of cudaGraph_t
            // points to, which is opaque and therefore causes a
            // compile error.
            return reinterpret_cast<uintptr_t>(graph);
          },
          py::call_guard<py::gil_scoped_release>())
      .def(
          "raw_cuda_graph_exec",
          [](::at::cuda::CUDAGraph& self) {
            cudaGraphExec_t graph_exec = self.raw_cuda_graph_exec();
            // We return a raw int here, since otherwise pybind11 will
            // try to return the underlying struct of cudaGraphExec_t
            // points to, which is opaque and therefore causes a
            // compile error.
            return reinterpret_cast<uintptr_t>(graph_exec);
          },
          py::call_guard<py::gil_scoped_release>())
      .def_static(
          "get_currently_capturing_graph",
          torch::wrap_pybind_function_no_gil(
              &::at::cuda::CUDAGraph::get_currently_capturing_graph),
          py::return_value_policy::reference)
      .def(
          "begin_capture_to_if_node",
          torch::wrap_pybind_function_no_gil(
              &::at::cuda::CUDAGraph::begin_capture_to_if_node),
          py::arg("scalar_cuda_pred_tensor"))
      .def(
          "begin_capture_to_while_node",
          torch::wrap_pybind_function_no_gil(
              &::at::cuda::CUDAGraph::begin_capture_to_while_node),
          py::arg("scalar_cuda_pred_tensor"))
      .def(
          "end_capture_to_conditional_node",
          torch::wrap_pybind_function_no_gil(
              &::at::cuda::CUDAGraph::end_capture_to_conditional_node))
      .def(
          "set_conditional_handle_for_current_node",
          torch::wrap_pybind_function_no_gil(
              &::at::cuda::CUDAGraph::set_conditional_handle_for_current_node),
          py::arg("scalar_cuda_pred_tensor"));
}
