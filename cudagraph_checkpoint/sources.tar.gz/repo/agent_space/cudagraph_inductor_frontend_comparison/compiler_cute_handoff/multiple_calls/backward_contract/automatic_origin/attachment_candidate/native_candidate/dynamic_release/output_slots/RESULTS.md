# Dynamic backward replay with physical output slots

Qualification5 passes **252 CPU and 44 CUDA tests**. Root and independent audits accept the
complete run.

The actual generated backward has four Triton kernels. After warming at width
13, one native entry handles widths 2, 7, 35 and 36, with a static first dimension
of 32. This passes through the original compiler records, generated-host FX
tracing, and retained Inductor IR, each with release enabled, disabled, and
`retain_graph=True`.

All nine cases preserve the complete backward output tuple:
`(None, grad_value, grad_residual, grad_weight)`. The shape argument remains
boxed input 0. Symbolic layouts and launch expressions come from the compiler;
the selected reader's actual records reach the native binder.

With release enabled, saved input 4 is dropped after its last use by kernel 1.
Its storage is reused for physical output slot 2 on all four tested releasing
calls, for every frontend. Retained calls keep the saved storage alive; their
later non-retaining calls reuse it. Disabled release supplies no drop program.
Numerical gradients and held outputs remain correct after closing the replay
owner. The native hits enter none of the watched Python wrapper, preparation,
or frontend paths.

The other 35 GPU cases cover existing user-Triton/CuTe integration, static
backward release, direct dynamic CUDA kernels, and physical output slots.
The direct tests change kernel sizes/grids and allocation sizes, reject invalid
output indices before replay, preserve legacy tensor-only outputs, and check
dispatcher output-slot compatibility.

## Implementation

The compiler, readers and native constructor preserve literal None positions;
None is never an allocation or pointer source. Native output construction stays
after graph enqueue. The final compiler fix recognizes the exact
`ir.NoneAsConstantBuffer` node and lowers it to the existing primitive None slot.
This uses the IR node's defined semantics.

The native build changed the output-index representation and cold dispatcher
compatibility check. The final IR fix is Python-only and uses the same built
runtime. The build, source restoration, preserved predecessor installations, and
fresh parent/child imports passed independent review.

## Scope and evidence

This is a dynamic **backward** integration result. The forward remains ordinary
Inductor in this workload; its returned aliases and shape scalar are outside
this owned-output slice. Compiler caches are disabled. This run makes no new
performance or peak-memory claim and covers the pinned CUDA 13 / GB300
environment, with CuTe 4.6.2 regressions.

- Exact implementation: `qualification5/manifest.json` and `gpu_dependencies.json`.
- Results and snapshots: `qualification5/attempts/`.
- Root audit: `qualification5/evidence_review.json`.
- Independent audit: `qualification5/evidence_independent_review.json`.
- Build audit: `evidence/build_independent_review.json`.
- CPU sentinel regression: `ir_none_revision1/tests_revision2/test_ir_none.py`.
- Next cache work: `cache_restoration/CACHE_RESTORATION.md`.

Qualification3 retains its nine dynamic-admission failures: the collector
recognized Python None but missed Inductor's typed None sentinel. Diagnosis1
records the actual IR. Qualification4 retains the new CPU fixture's keyword-only
constructor and frontend-local symbol-name assertion mistakes; qualification5
corrects only that fixture. The final GPU fixtures and their numerical/lifetime
requirements are unchanged.

