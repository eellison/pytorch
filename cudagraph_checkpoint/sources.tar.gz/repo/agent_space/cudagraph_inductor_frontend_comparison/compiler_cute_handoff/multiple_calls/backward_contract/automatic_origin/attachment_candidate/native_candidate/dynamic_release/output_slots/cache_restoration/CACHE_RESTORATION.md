# Saved-input schedules and cache restoration

The selected code has the required callable rebinding mechanism, but cache-enabled
schedule collection is deliberately unsupported. Do not remove the cache gate on
the strength of a serialization test.

`compiler_saved_inputs.transport.eligible` requires `force_disable_caches=True`,
both AOT cache modes disabled, and no precompile/serialization mode. It rechecks
scope at the forward, lazy backward and final collection boundaries. Therefore an
ordinary supported FX/AOT cache hit cannot currently restore a newly collected
release schedule.

The existing serialization route is promising without a production change:

- `GeneratedMetadata` emits the data-only schedule in generated source. Executing
  that source calls `attach_metadata` for the exact new function, code, globals and
  record object; `read_metadata` requires that function to be the artifact's
  `_cudagraph_original_callable`.
- `CompiledFxGraph.prepare_for_serialization` clears both callable fields and
  `_cudagraph_installation_owner`. `after_deserialization` loads generated source,
  assigns both callable fields to `code_cache.call`, and clears the native owner.
  Restoring metadata must not restore an old native entry or borrow.
- Historical compiler-frontends evidence includes successful static/dynamic FX
  cache reloads and both FX/retained alternatives with distinct functions/entries
  and independent close. Those tests predate `ReleaseSchedule`; they do not qualify
  schedule caching. The selected serialization methods additionally clear the
  installation owner; their other statements match that earlier implementation.

## Smallest next task: real-artifact serialization regression

Extend the qualified actual compiled-backward fixture, initially for one supported
shape contract. Obtain the artifact and nonempty schedule from the real paired AOT
callbacks and final wrapper collector, with the existing cache-disabled gates.
Do not mock classification, construct a schedule, or manually attach records.

1. Copy that actual artifact, call its real `prepare_for_serialization`, then
   pickle/unpickle the copy. Require both callable fields and the installation
   owner to be empty, while the original artifact/entry remains usable.
2. Use an isolated real `PyCodeCache` load through `after_deserialization` so the
   generated source executes again. Require a distinct function/globals/attachment,
   both restored callable fields equal to that function, and exact reconstructed
   records, release steps, input ordinals and physical Tensor/None output slots.
3. Check the restored attachment binds its own function/code/records, and that
   transplanting the original attachment is rejected. No old native owner may be
   retained or installed by deserialization. Preserve the original fixture's
   forward/gradient and output-lifetime checks.

This proves serialization and exact source attachment only. It is not an FX cache
hit, AOT cache hit, or permission to enable release under either cache.

## Separate prerequisite for actual local FX cache support

Simply relaxing `eligible` is insufficient. The temporary `gm.meta[ORIGIN_KEY]`
contains `AOTInputOrigins.module is gm` and live graph/nodes. `GraphModule.__reduce__`
copies `meta`, while `FxGraphCachePickler` uses fast mode. That introduces a cyclic,
live compiler carrier into key hashing; no stable cache-key representation is
defined for it. This is a source finding, not an executed cache failure.

A later narrowly scoped change must keep that carrier out of serialization and
key on the relevant immutable current AOT classification/boxed correspondence,
including absence of release eligibility. Keep AOT/remote caches disabled first.
Then require a real miss followed by a real hit, equal authorized schedules with
fresh attachments/native owners, and a same-shaped incompatible-origin or disabled
control that cannot reuse the release artifact. The generated-source hash alone
is insufficient: FX lookup happens before source generation.

## Source locations

Paths are relative to the repository. `MC` means
`agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls`;
`AC` means `MC/backward_contract/automatic_origin/attachment_candidate`;
`DR` means `AC/native_candidate/dynamic_release`; `WARM` means
`agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1/source`.

- `DR/source_delta/compiler_saved_inputs/transport.py:21,78,90`: gates and temporary origin.
- `AC/source_delta/compiler_saved_inputs/handoff.py:16`: live `AOTInputOrigins` fields.
- `DR/source_delta/compiler_metadata_handoff/metadata.py:196,211,227,249`: emission and exact attachment.
- `MC/consolidated/python/torch/_inductor/output_code.py:1007,1041`: selected serialization/restoration.
- `AC/source_delta/torch/_inductor/compile_fx.py:1189,1227,1443`: cache lookup precedes compilation; policy runs after post-compile.
- `WARM/torch/_inductor/codecache.py:717,770,1523,2317` and `WARM/torch/fx/graph_module.py:1053`: hash and serialization behavior.
- `agent_space/cudagraph_inductor_frontend_comparison/compiler_metadata_handoff/test_metadata.py:239`: existing serializer test uses a CPU metadata fixture without a release schedule.
- `agent_space/cudagraph_inductor_frontend_comparison/compiler_frontend_policy/test_frontend.py:685,1442,1502` and adjacent `frontend_evidence_review.json` / `frontend_attempt1.log`: earlier qualified cache controls without saved-input release.

No production files changed and no framework, build or GPU execution was performed
for this assessment.
