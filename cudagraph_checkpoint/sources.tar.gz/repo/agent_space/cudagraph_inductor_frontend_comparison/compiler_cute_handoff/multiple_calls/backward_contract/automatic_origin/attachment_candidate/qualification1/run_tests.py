"""Run the backward-input checks with the qualified frontend bootstrap."""

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUNNER = ROOT.parents[3] / "consolidated/qualification3/run_tests.py"


if __name__ == "__main__":
    spec = importlib.util.spec_from_file_location("_backward_handoff_runner", RUNNER)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    runner.ROOT = ROOT
    runner.main()
