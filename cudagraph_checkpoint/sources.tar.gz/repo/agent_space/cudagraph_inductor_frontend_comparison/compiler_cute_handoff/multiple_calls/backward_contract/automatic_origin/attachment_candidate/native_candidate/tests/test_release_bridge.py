from dataclasses import replace
import struct
from types import FunctionType, SimpleNamespace
from unittest import mock

from compiler_metadata_handoff.metadata import GeneratedMetadata, read_metadata
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from compiler_saved_inputs.schedule import DropInput
from fx_adapter.contract import InputContract, TensorInput
import schedule_fixture
import static_metadata_fixture
import torch
from torch._inductor.runtime import cudagraph_boxed_replay as replay
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, InputSource, LauncherArgument
from torch._inductor.runtime.cudagraph_launch_association import RecordedKernelLaunch, UnsupportedCapture
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def no_launch(*args, **kwargs):
    raise AssertionError("CPU bridge controls must not invoke a kernel")


class CapturedModule:
    has_global_scratch = False
    has_profile_scratch = False

    def __init__(self, function):
        self.function = function

    def run(self, *args, **kwargs):
        raise AssertionError("CPU bridge controls must not invoke a kernel")

    def _borrow_for_cudagraph(self):
        return self


class TestReleaseBridge(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, late_drop=False):
        fixture = schedule_fixture.CompilerFixture(self, copies=True, late_weight=True)
        if late_drop:
            fixture.wrapper.lines.remove(fixture.free_activation)
            fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.second), fixture.free_activation)
        return fixture

    def captured(self, records):
        buffers = {layout.source: torch.empty(layout.size, dtype=layout.dtype) for layout in records.allocations}
        inputs = (torch.empty(32, 128), torch.empty(32, 128))
        launches, selected, snapshots, nodes = [], [], [], []
        before = (1, 17, 29, ())
        for index, call in enumerate(records.calls):
            node, function = 100 + index, 200 + index
            module = CapturedModule(function)
            launcher = FunctionType(no_launch.__code__, {"runner": module.run})
            launcher._cudagraph_arg_info = tuple(
                LauncherArgument(arg.formal, arg.source_arg_index, arg.call_arg_index, arg.triton_type, slot, None)
                for slot, arg in enumerate(call.arguments)
            )
            selected.append(launcher)
            arguments, slots, offset = [], [], 0
            for arg in call.arguments:
                source = arg.source
                if type(source) is InputSource:
                    value = struct.pack("P", inputs[source.index].data_ptr())
                elif type(source) is BufferSource:
                    value = struct.pack("P", buffers[source].data_ptr())
                else:
                    value = struct.pack("i", source.value)
                arguments.append(value)
                slots.append((offset, len(value), value))
                offset += len(value)
            after = (1, 17, 29, ((node, bytes(8)),))
            launches.append(RecordedKernelLaunch(41, before, after, function, tuple(arguments)))
            snapshots.append((node, function, 0, 0, (1, 1, 1), (128, 1, 1), 0, False, tuple(slots)))
            nodes.append(node)
            before = after
        graph = SimpleNamespace(
            _inspect_captured_kernel_nodes=mock.Mock(return_value=(29, 17, tuple(nodes), tuple(snapshots))),
            _prepare_kernel_pointer_updates=mock.Mock(return_value=object()),
            _make_boxed_replay=mock.Mock(return_value=object()),
        )
        return graph, tuple(selected), tuple(launches), buffers, tuple(nodes)

    @parametrize("enabled", (False, True))
    @parametrize("late_drop", (False, True))
    def test_exact_order_reaches_native_constructor(self, enabled, late_drop):
        fixture = self.fixture(late_drop)
        graph, selected, launches, buffers, nodes = self.captured(fixture.records)
        normalize, stream = object(), object()
        with mock.patch.object(replay, "StaticallyLaunchedCudaKernel", CapturedModule):
            result = replay.make_boxed_replay(
                graph, fixture.records, selected, launches, buffers, stream,
                copy_if_misaligned=normalize, release_schedule=fixture.collect() if enabled else None,
            )
        self.assertIs(result, graph._make_boxed_replay.return_value)
        graph._make_boxed_replay.assert_called_once()
        args = graph._make_boxed_replay.call_args.args
        self.assertEqual(args[6], ((0, 1), normalize))
        self.assertEqual(args[7], (1,))
        if enabled:
            middle = (("allocate", 1), ("drop", 0)) if late_drop else (("drop", 0), ("allocate", 1))
            self.assertEqual(len(args), 10)
            self.assertIsNone(args[8])
            self.assertEqual(args[9], ((("allocate", 0), ("kernel", 0), *middle, ("kernel", 1)), nodes))
        else:
            self.assertEqual(len(args), 8)
        self.assertEqual(graph._make_boxed_replay.call_args.kwargs, {})

    @parametrize("enabled", (False, True))
    def test_generated_attachment_reaches_policy_preparation(self, enabled):
        fixture = self.fixture()
        inputs = InputContract(("tensor", "tensor"), tuple(
            TensorInput(index, torch.float32, (32, 128), (128, 1)) for index in range(2)
        ), ())
        metadata = GeneratedMetadata(1, inputs, None, fixture.collect() if enabled else None)
        artifact, namespace = static_metadata_fixture.load_source(fixture.records, metadata)
        original, restored = read_metadata(artifact)
        policy = NativeCUDAGraphPolicy()
        self.addCleanup(policy.close)
        policy.wrap_output(artifact)
        box = [object(), object()]
        snapshot = tuple(box)
        entry = static_metadata_fixture.PreparedEntry()
        with mock.patch.object(preparation, "prepare_from_warmed", return_value=entry) as prepare:
            result = artifact.current_callable(box)
        self.assertEqual(box, [])
        self.assertIs(result, namespace["outcomes"][0])
        expected = {"release_schedule": restored.release_schedule} if enabled else {}
        prepare.assert_called_once_with(original, snapshot, **expected)
        self.assertIs(artifact.current_callable, entry)

    @parametrize("frontend", ("fx", "retained"))
    def test_unsupported_projection_does_not_substitute_records(self, frontend):
        fixture = self.fixture()
        with mock.patch.object(preparation, "_selected_calls") as select:
            with self.assertRaisesRegex(UnsupportedCapture, "compiler records frontend"):
                preparation.prepare_from_warmed(no_launch, [], frontend=frontend, release_schedule=fixture.collect())
        select.assert_not_called()

    @parametrize("damage", ("drop_before_use", "missing_allocation"))
    def test_invalid_schedule_never_reaches_native(self, damage):
        fixture = self.fixture()
        schedule = fixture.collect()
        steps = list(schedule.steps)
        if damage == "drop_before_use":
            drop = next(step for step in steps if type(step) is DropInput)
            steps.remove(drop)
            steps.insert(0, drop)
        else:
            steps.remove(fixture.records.allocations[1])
        graph = SimpleNamespace(_make_boxed_replay=mock.Mock())
        with self.assertRaises(UnsupportedCapture):
            replay.make_boxed_replay(
                graph, fixture.records, (no_launch, no_launch), (), {}, object(),
                release_schedule=replace(schedule, steps=tuple(steps)),
            )
        graph._make_boxed_replay.assert_not_called()


instantiate_parametrized_tests(TestReleaseBridge)


if __name__ == "__main__":
    run_tests()
