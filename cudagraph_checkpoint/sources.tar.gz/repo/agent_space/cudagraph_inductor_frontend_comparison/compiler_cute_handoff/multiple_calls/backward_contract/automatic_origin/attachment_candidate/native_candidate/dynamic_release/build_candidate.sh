#!/usr/bin/env bash
set -euo pipefail
landing_root=/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release
warm_root=/data/eellison/src/pytorch/agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1
cd "$warm_root/source"
source /data/eellison/src/pytorch/agent_space/env.sh
test ! -e "$landing_root/install_attempt1"
test ! -e "$landing_root/evidence/pip_attempt1.log"
test -d "$warm_root/build"
mkdir -p "$landing_root/install_attempt1" "$landing_root/tmp" "$landing_root/ccache-tmp"
unset WT_PRELUDE CMAKE_ARGS SKBUILD_BUILD_DIR LANDING_RUNTIME
export TORCH_WT="$warm_root/source"
export PYTHONPATH="$landing_root/build_site"
export TORCH_CUSTOM_PYTHONPATH="$landing_root/build_site"
export CC=/opt/rh/gcc-toolset-13/root/usr/bin/cc
export CXX=/opt/rh/gcc-toolset-13/root/usr/bin/c++
export CUDAHOSTCXX=/opt/rh/gcc-toolset-13/root/usr/bin/c++
export CMAKE_CUDA_COMPILER=/usr/local/cuda-13.0/bin/nvcc
export CMAKE_GENERATOR=Ninja CMAKE_BUILD_TYPE=Release
export DEBUG=0 REL_WITH_DEB_INFO=0
export TORCH_CUDA_ARCH_LIST=10.3
export USE_CUDA=1 USE_CUDNN=1 USE_DISTRIBUTED=1 USE_NCCL=1 USE_SYSTEM_NCCL=1
export USE_CUSPARSELT=1 USE_MKLDNN=0 USE_XNNPACK=0 USE_MIMALLOC=0
export USE_EIGEN_SPARSE=0 USE_BUILTIN_RIPGREP=0 BUILD_TEST=0
export CUDNN_INCLUDE_DIR=/usr/include CUDNN_LIBRARY=/usr/lib64/libcudnn.so
export CUSPARSELT_INCLUDE_DIR=/usr/include/libcusparseLt/13
export CUSPARSELT_LIBRARY=/usr/lib64/libcusparseLt/13/libcusparseLt.so
export NCCL_INCLUDE_DIR=/usr/include NCCL_LIB_DIR=/usr/lib64
export MAX_JOBS=8 CMAKE_BUILD_PARALLEL_LEVEL=8 FLASH_ATTENTION_MAX_JOBS=4
export TMPDIR="$landing_root/tmp"
export CCACHE_DIR=/data/eellison/ccache CCACHE_READONLY=1 CCACHE_NOSTATS=1
export CCACHE_TEMPDIR="$landing_root/ccache-tmp"
pip install -e . -v --no-build-isolation --no-deps --no-index \
  --target "$landing_root/install_attempt1" \
  --config-settings="build-dir=$warm_root/build" \
  --config-settings=editable.rebuild=false \
  --config-settings=cmake.define.FLASH_ATTENTION_MAX_JOBS=4 \
  2>&1 | tee "$landing_root/evidence/pip_attempt1.log"
