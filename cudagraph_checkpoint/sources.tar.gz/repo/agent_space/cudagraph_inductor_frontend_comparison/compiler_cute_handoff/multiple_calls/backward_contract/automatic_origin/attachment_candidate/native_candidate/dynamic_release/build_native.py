"""Build the reviewed native release delta and restore the warm source tree."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time


ROOT = Path(__file__).resolve().parent
REPO = Path("/data/eellison/src/pytorch")
PREVIOUS = REPO / "agent_space/cudagraph_inductor_frontend_comparison/cute_bridge"
NATIVE_BASELINE = ROOT.parent
WARM = REPO / "agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1"
SOURCE = WARM / "source"
NEW_HEADER = "c10/cuda/CUDACachingAllocatorPendingGraph.h"
GENERATED = ("torch/_C/__init__.pyi", "torch/version.py")
DELTAS = {
    "c10/cuda/CUDACachingAllocator.cpp": "d0f998fe816cf161e81166431066c521120493be5a7ced34cc991b9562d5e3a4",
    NEW_HEADER: "491ef6197baadbfc9cec736762754c3ac1ea64de9dfcf5c0daaae61df2b5f2a1",
    "aten/src/ATen/cuda/CUDAGraph.cpp": "d60a4f78a5000d5c539acb2de7eef9c13b987f2a94111851351d0dcdc6fa1f59",
    "aten/src/ATen/cuda/CUDAGraph.h": "a5d5ef0f810cb7836b1ff7a85af3d23cd00bfcb8cebd79365d90d724517bece5",
    "aten/src/ATen/cuda/CUDAGraphParams.cpp": "57b32ac933d424fe03a4ef27bf6ae570c205de70c8c61a9ecead1dd42991c672",
    "aten/src/ATen/cuda/CUDAGraphParams.h": "7f5fd9667dcfc0633a696447cc02e807218ba9410755b2fd40c3edbb25e253d0",
    "torch/csrc/cuda/Graph.cpp": "8d8495748a8c981a242c889e1352e32cd5bd0b24fe4b9bcd846baf69e27709f8",
    "torch/_C/__init__.pyi.in": "008b1d3e3afcfdfa98a776904ed33d32db75f4123b239c8f1de5320a81a41a0a",
}
RECEIPTS = {
    "native_source_review.json": "d59bf677fedbc1566843c37bf78dc1f36155e1cfd5c3163a444d3e0101404fa2",
    "native_independent_review.json": "6f227a06114f16c6bf852a4b730cc5555053bd0261aee79b2b86c33aebbf8f22",
    "native_source_independent_review.json": "c28320447c2fbef44a1166585507a4a0faa5cc26b3acc812377beb431fc2863e",
}
BASELINE_RECEIPTS = {
    "evidence/source_manifest.json": "6992cdbea6fbd230645fd38c403d74f35a430a3b48ff76f80c8060b0b2c913a1",
    "evidence/build_result.json": "60af91f9d9d7e69bcb688b509a6a17afefb7c40c41ad49b8fff1f3ceb98c4ba3",
}
NATIVE_BASELINE_RECEIPTS = {
    "evidence/source_manifest.json": "8b464bfbc11ca282361df73ae0975e96b0240cbe1cbc6333cecd9fcdafa8f3c8",
    "evidence/build_result.json": "323084a62d72c1f02459f67ad4cf65a27d091937c02f1b4f9a084704a6fe5117",
}


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def write(path, value):
    with path.open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def main():
    with (WARM / "native_dispatch_build.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        build()


def build():
    for name, sha in BASELINE_RECEIPTS.items():
        if digest(PREVIOUS / name) != sha:
            raise RuntimeError("Qualified native baseline receipt changed: " + name)
    previous_manifest_path = PREVIOUS / "evidence/source_manifest.json"
    previous_result_path = PREVIOUS / "evidence/build_result.json"
    previous = json.loads(previous_manifest_path.read_text())
    previous_result = json.loads(previous_result_path.read_text())
    if (not previous_result["accepted"] or not previous_result["source_restored"]
            or previous_result["manifest_sha256"] != digest(previous_manifest_path)
            or Path(previous["source_root"]) != SOURCE
            or Path(previous["install_root"]) != PREVIOUS / "install_attempt1"):
        raise RuntimeError("Expected the qualified CuTe build and restored warm source")
    expected = {**previous["source_files"], **previous["restored_source_files"]}
    for name, sha in expected.items():
        if digest(SOURCE / name) != sha:
            raise RuntimeError("Accepted warm source changed: " + name)
    if (SOURCE / NEW_HEADER).exists() or (SOURCE / NEW_HEADER).is_symlink():
        raise RuntimeError("The new pending-input header must be absent before staging")
    for name, sha in RECEIPTS.items():
        if digest(ROOT / name) != sha:
            raise RuntimeError("Frozen native source review changed: " + name)
    peer = json.loads((ROOT / "native_source_independent_review.json").read_text())
    if not peer["accepted"] or {row["relative_source"]: row["sha256"] for row in peer["sources"]} != DELTAS:
        raise RuntimeError("Independent native review does not cover these exact deltas")
    for name, sha in DELTAS.items():
        if digest(ROOT / "source_delta" / name) != sha:
            raise RuntimeError("Reviewed native delta changed: " + name)
    old_install = PREVIOUS / "install_attempt1"
    old_hashes = previous_result["installed_native_hashes"]
    if set(old_hashes) != set(previous["native_files"]):
        raise RuntimeError("Previous installed native inventory differs from its manifest")
    for name, sha in old_hashes.items():
        if digest(old_install / name) != sha:
            raise RuntimeError("Accepted native installation changed: " + name)
    if digest(old_install / GENERATED[0]) != previous_result["installed_stub_sha256"]:
        raise RuntimeError("Accepted installed stub changed")
    for name, sha in NATIVE_BASELINE_RECEIPTS.items():
        if digest(NATIVE_BASELINE / name) != sha:
            raise RuntimeError("Qualified NC receipt changed: " + name)
    native_manifest = json.loads((NATIVE_BASELINE / "evidence/source_manifest.json").read_text())
    native_result = json.loads((NATIVE_BASELINE / "evidence/build_result.json").read_text())
    native_install = NATIVE_BASELINE / "install_attempt1"
    if (not native_result["accepted"] or not native_result["source_restored"]
            or not native_result["previous_install_preserved"]
            or native_result["manifest_sha256"] != digest(NATIVE_BASELINE / "evidence/source_manifest.json")
            or Path(native_manifest["source_root"]) != SOURCE
            or Path(native_manifest["install_root"]) != native_install
            or set(native_result["installed_native_hashes"]) != set(native_manifest["native_files"])):
        raise RuntimeError("Expected the qualified NC installation")
    native_hashes = {
        **native_result["installed_native_hashes"],
        GENERATED[0]: native_result["installed_stub_sha256"],
        GENERATED[1]: native_result["installed_version_sha256"],
    }
    for name, sha in native_hashes.items():
        if digest(native_install / name) != sha:
            raise RuntimeError("Qualified NC installation changed: " + name)
    if (ROOT / "install_attempt1").exists() or not (WARM / "build").is_dir():
        raise RuntimeError("Expected a fresh install target and existing warm build directory")

    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=False)
    backup = evidence / "accepted_source_backup"
    backup.mkdir()
    preserved = (*[name for name in DELTAS if name != NEW_HEADER], *GENERATED)
    before = {}
    for name in preserved:
        destination = backup / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(SOURCE / name, destination)
        before[name] = digest(destination)
    scaffold = ("build_native.py", "build_candidate.sh", "build_site/sitecustomize.py",
                "runtime_site/sitecustomize.py", "python.sh", "check_native.py")
    manifest = {
        "head": previous["head"], "source_root": str(SOURCE),
        "install_root": str(ROOT / "install_attempt1"),
        "source_files": {**previous["source_files"], **DELTAS}, "delta_files": DELTAS,
        "base_source_files": expected, "restored_source_files": before,
        "restored_absent_files": [NEW_HEADER], "generated_files": list(GENERATED),
        "native_files": previous["native_files"], "native_review_hashes": RECEIPTS,
        "scaffold_hashes": {name: digest(ROOT / name) for name in scaffold},
        "previous_manifest_sha256": digest(previous_manifest_path),
        "previous_build_result_sha256": digest(previous_result_path),
        "native_parent_install_root": str(native_install),
        "native_parent_install_hashes": native_hashes,
        "native_parent_receipts": {str(NATIVE_BASELINE / name): sha
                                   for name, sha in NATIVE_BASELINE_RECEIPTS.items()},
        "gpu_uuid": previous["gpu_uuid"], "gpu_guard": previous["gpu_guard"],
    }
    write(evidence / "source_manifest.json", manifest)
    result = {
        "accepted": False, "started_utc": datetime.now(timezone.utc).isoformat(),
        "manifest_sha256": digest(evidence / "source_manifest.json"),
        "build_script_sha256": digest(ROOT / "build_candidate.sh"),
        "build_controller_sha256": digest(Path(__file__)),
        "command": ["bash", str(ROOT / "build_candidate.sh")],
    }
    started = time.monotonic()
    try:
        for name in DELTAS:
            shutil.copyfile(ROOT / "source_delta" / name, SOURCE / name)
        with (evidence / "build.log").open("x") as log:
            child = subprocess.run(result["command"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        result["exit_code"] = child.returncode
        if child.returncode:
            raise RuntimeError("Native pip build failed; inspect evidence/build.log")
        for name, sha in manifest["source_files"].items():
            if digest(SOURCE / name) != sha:
                raise RuntimeError("Source changed during compilation: " + name)
        generated_hashes = {}
        for name in GENERATED:
            destination = evidence / "generated_source" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / name, destination)
            generated_hashes[name] = digest(destination)
        result["generated_source_hashes"] = generated_hashes
        result["installed_native_hashes"] = {
            name: digest(ROOT / "install_attempt1" / name) for name in previous["native_files"]
        }
        result["installed_stub_sha256"] = digest(ROOT / "install_attempt1" / GENERATED[0])
        result["installed_version_sha256"] = digest(ROOT / "install_attempt1" / GENERATED[1])
        result["accepted"] = True
    except Exception as error:
        result["error"] = repr(error)
    finally:
        restoration_errors = []
        for name in preserved:
            try:
                # Refresh mtimes so the next warm build cannot reuse this candidate's objects.
                shutil.copyfile(backup / name, SOURCE / name)
            except Exception as error:
                restoration_errors.append({"path": name, "error": repr(error)})
        try:
            (SOURCE / NEW_HEADER).unlink(missing_ok=True)
        except Exception as error:
            restoration_errors.append({"path": NEW_HEADER, "error": repr(error)})
        result["restoration_errors"] = restoration_errors
        result["source_restored"] = not restoration_errors and all(
            (SOURCE / name).is_file() and digest(SOURCE / name) == sha for name, sha in expected.items()
        ) and not (SOURCE / NEW_HEADER).exists() and not (SOURCE / NEW_HEADER).is_symlink()
        result["previous_install_preserved"] = all(
            digest(old_install / name) == sha for name, sha in old_hashes.items()
        ) and digest(old_install / GENERATED[0]) == previous_result["installed_stub_sha256"]
        result["native_parent_install_preserved"] = all(
            digest(native_install / name) == sha for name, sha in native_hashes.items()
        )
        result["accepted"] &= (result["source_restored"] and result["previous_install_preserved"]
                               and result["native_parent_install_preserved"])
        result["elapsed_seconds"] = time.monotonic() - started
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        write(evidence / "build_result.json", result)
    print(json.dumps(result, indent=2), flush=True)
    if not result["accepted"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
