import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

old = ROOT / "qualification4"
new = ROOT / "qualification5"
correction = ROOT / "ir_none_revision1/tests_revision2"
test = correction / "test_ir_none.py"
if not test.is_file() or new.exists():
    raise RuntimeError("Expected a frozen corrected fixture and fresh target")
new.mkdir()
names = ("manifest.json", "gpu_dependencies.json", "run_cpu_helpers.json",
         "run_tests.py", "test_cpu.py", "test_native_width.py")
for name in names:
    shutil.copyfile(old / name, new / name)
helpers = json.loads((new / "run_cpu_helpers.json").read_text())
helpers["cpu"]["ir_none_fixture"] = {"path": str(test), "sha256": digest(test)}
(new / "run_cpu_helpers.json").write_text(json.dumps(helpers, indent=2) + "\n")
review = json.loads((old / "execution_review.json").read_text())
review["revision"] = "Fixture-only IR constructor keyword and FX symbol-name correction; production unchanged from Q4."
paths = [new / name for name in names]
paths += [test, old / "execution_review.json", old / "attempts/cpu_attempt1/result.json", Path(__file__)]
paths += sorted(correction.glob("*.json")) + sorted(correction.glob("*.diff"))
for path in paths:
    review["files"][str(path)] = digest(path)
(new / "execution_review.json").write_text(json.dumps(review, indent=2) + "\n")
print(json.dumps({"root": str(new), "sources": len(review["files"]),
                  "cases": {key: len(value) for key, value in review["cases"].items()}}))

