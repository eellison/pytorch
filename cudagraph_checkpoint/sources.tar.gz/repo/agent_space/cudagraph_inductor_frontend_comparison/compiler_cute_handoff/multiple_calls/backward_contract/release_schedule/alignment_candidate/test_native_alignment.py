from contextlib import ExitStack
import json
import sys
from unittest import mock

import compiler_policy_handoff.policy as policy_module
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from selected_kernel import SelectedKernel
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._inductor import config
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import InputSource
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import run_tests, TestCase


class TestStaticLateAlignment(TestCase):
    def test_native_replay_normalizes_late_input(self, device):
        fixture = fixture_module.TestReductionGraphReplayCUDA("test_generated_reduction_replay_fast_True_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        policy = NativeCUDAGraphPolicy()
        self.addCleanup(policy.close)
        self.enterContext(config.patch(
            cudagraph_policy=policy, use_fast_triton_launcher=True, max_fusion_size=1,
            allow_buffer_reuse=False, inplace_buffers=False,
        ))

        def function(left, right):
            return (left.sin() * right,)

        compiled = torch.compile(function, fullgraph=True, dynamic=False)
        left = torch.randn(32, 128, device=device)
        right = torch.randn_like(left)
        boxed_ids = []
        prepare = preparation.prepare_from_warmed

        def observe(wrapper, inputs, **kwargs):
            boxed_ids.append(tuple(id(value) for value in inputs))
            return prepare(wrapper, inputs, **kwargs)

        with mock.patch.object(preparation, "prepare_from_warmed", new=observe):
            self.assertEqual(compiled(left, right), function(left, right))
        self.assertEqual(len(boxed_ids), 1)
        right_index = boxed_ids[0].index(id(right))
        self.assertEqual(len(policy.installations), 1)
        installation = policy.installations[0]
        original = installation.original
        entry = installation.entry
        self.assertIsNotNone(entry)
        records = original._cudagraph_call_records
        self.assertEqual(records.version, 3)
        self.assertGreater(len(records.calls), 1)
        copies = tuple(copy for copy in records.alignment_copies if copy.before_call > 0)
        self.assertTrue(copies)
        self.assertIn(right_index, tuple(copy.input_index for copy in copies))
        for copy in copies:
            first = next(index for index, call in enumerate(records.calls)
                         if any(argument.source == InputSource(copy.input_index) for argument in call.arguments))
            self.assertEqual(copy.before_call, first)
        kernels = tuple(value for value in original.__globals__.values() if type(value) is CachingAutotuner)
        self.assertTrue(kernels)
        for kernel in kernels:
            selection = SelectedKernel.from_warmed(kernel)
            module = selection.identity[3]
            fixture.modules[id(module)] = module
            self.assertIs(type(selection.identity[2].__globals__["runner"]), torch._C._FastCudaLauncher)
        frames = []
        forbidden = {policy_module.__file__, preparation.__file__}

        def profile(frame, event, result):
            if event == "call" and (frame.f_code is original.__code__ or frame.f_code.co_filename in forbidden):
                frames.append((frame.f_code.co_filename, frame.f_code.co_name))

        held, expected = [], []
        with ExitStack() as stack:
            for kernel in kernels:
                stack.enter_context(mock.patch.object(kernel, "run", side_effect=AssertionError("Unexpected eager kernel")))
            for offset in (0, 1, 0, 1):
                left = torch.randn(32, 128, device=device)
                right = torch.randn(4096 + offset, device=device)[offset:].view(32, 128)
                self.assertEqual(right.data_ptr() % 16, offset * right.element_size())
                expected.append(function(left, right))
                previous = sys.getprofile()
                try:
                    sys.setprofile(profile)
                    held.append(compiled(left, right))
                finally:
                    sys.setprofile(previous)
                self.assertEqual(held[-1], expected[-1])
                self.assertEqual(len(policy.installations), 1)
                self.assertIs(installation.artifact.current_callable, entry)
        self.assertEqual(frames, [])
        policy.close()
        self.assertEqual(held, expected)
        print("STATIC_LATE_ALIGNMENT " + json.dumps({
            "calls": len(records.calls), "copies": [(copy.input_index, copy.before_call) for copy in records.alignment_copies],
            "right_boxed_index": right_index, "native_hits": 4, "offsets": [0, 1, 0, 1], "generated_host_frames": frames,
        }, sort_keys=True))


instantiate_device_type_tests(TestStaticLateAlignment, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
