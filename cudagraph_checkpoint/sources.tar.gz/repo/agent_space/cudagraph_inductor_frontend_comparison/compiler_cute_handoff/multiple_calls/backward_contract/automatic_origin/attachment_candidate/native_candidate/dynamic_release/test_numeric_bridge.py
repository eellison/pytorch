import struct
from types import SimpleNamespace
from unittest import mock

from compiler_saved_inputs.schedule import DropInput
from release_bridge_fixture import CapturedModule
from symbolic_release_fixture import SymbolicCompilerFixture
import torch
from torch._inductor.runtime import cudagraph_boxed_replay as replay
from torch._inductor.runtime.cudagraph_arg_mapping import (
    BufferSource, ExpressionSource, InputSource, IntExpr, KernelCallRecord, OwnedBuffer,
)
from torch._inductor.runtime.cudagraph_launch_association import RecordedKernelLaunch, UnsupportedCapture
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


class TestNumericReleaseBridge(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    @parametrize("enabled", (False, True))
    @parametrize("integer_first", (False, True))
    def test_numeric_recipe_and_release_share_native_constructor(self, enabled, integer_first):
        fixture = SymbolicCompilerFixture(self, integer_first=integer_first)
        records = fixture.records
        inputs = fixture.example_inputs(13, device="cpu")
        numeric = replay._NumericProgram(records, inputs)
        buffers = {layout.source: torch.empty((32, 13)) for layout in records.allocations}
        calls, launches, snapshots, nodes = [], [], [], []
        before = (1, 17, 29, ())
        for index, record in enumerate(records.calls):
            node, function = 100 + index, 200 + index
            extent = record.arguments[-1].source.expression
            grid = (IntExpr("ceildiv", args=(extent, IntExpr("constant", 128))),
                    IntExpr("constant", 1), IntExpr("constant", 1))
            calls.append(replay._BoundCall(record.arguments, CapturedModule(function), grid))
            arguments, slots, offset = [], [], 0
            for argument in record.arguments:
                source = argument.source
                if type(source) is InputSource:
                    value = struct.pack("P", inputs[source.index].data_ptr())
                elif type(source) is BufferSource:
                    value = struct.pack("P", buffers[source].data_ptr())
                elif type(source) is ExpressionSource:
                    value = struct.pack("i", numeric.values[numeric.add(source.expression)])
                else:
                    raise AssertionError(f"Unexpected symbolic fixture argument: {source}")
                arguments.append(value)
                slots.append((offset, len(value), value))
                offset += len(value)
            concrete_grid = tuple(numeric.values[numeric.add(expression)] for expression in grid)
            after = (1, 17, 29, ((node, bytes(8)),))
            launches.append(RecordedKernelLaunch(41, before, after, function, tuple(arguments)))
            snapshots.append((node, function, 0, 0, concrete_grid, (128, 1, 1), 0, False, tuple(slots)))
            nodes.append(node)
            before = after
        graph = SimpleNamespace(
            _inspect_captured_kernel_nodes=mock.Mock(return_value=(29, 17, tuple(nodes), tuple(snapshots))),
            _prepare_kernel_pointer_updates=mock.Mock(),
            _prepare_kernel_replay_updates=mock.Mock(return_value=object()),
            _make_boxed_replay=mock.Mock(return_value=object()),
        )
        steps = []
        for step in fixture.collect().steps:
            if type(step) is OwnedBuffer:
                steps.append(("allocate", records.allocations.index(step)))
            elif type(step) is KernelCallRecord:
                steps.append(("kernel", step.occurrence))
            elif type(step) is DropInput:
                steps.append(("drop", step.input_index))
        with mock.patch.object(replay, "StaticallyLaunchedCudaKernel", CapturedModule):
            result = replay._make_replay(
                graph, len(inputs), records.allocations, (1,), (), tuple(calls), tuple(launches), buffers,
                object(), numeric=numeric, release_steps=tuple(steps) if enabled else None,
            )
        self.assertIs(result, graph._make_boxed_replay.return_value)
        graph._prepare_kernel_pointer_updates.assert_not_called()
        graph._prepare_kernel_replay_updates.assert_called_once()
        graph._make_boxed_replay.assert_called_once()
        args = graph._make_boxed_replay.call_args.args
        self.assertEqual(args[4], tuple(sorted((fixture.activation_index, fixture.weight_index))))
        self.assertEqual(args[7], (1,))
        self.assertEqual(args[8], ((fixture.integer_index,), tuple(numeric.instructions)))
        width_index = numeric.indices[IntExpr("boxed", fixture.integer_index)]
        self.assertEqual(args[5], ((torch.float32, (32, ("value", width_index)),
                                 (("value", width_index), 1)),) * 2)
        bindings = graph._prepare_kernel_replay_updates.call_args.args
        self.assertEqual(len(bindings[2]), 2)
        self.assertEqual(len(bindings[3]), 2)
        if enabled:
            self.assertEqual(len(args), 10)
            self.assertEqual(args[9], (tuple(steps), tuple(nodes)))
        else:
            self.assertEqual(len(args), 9)

    def test_release_requires_owned_allocation_outputs_before_native_binding(self):
        graph = SimpleNamespace(_make_boxed_replay=mock.Mock())
        with self.assertRaisesRegex(UnsupportedCapture, "allocation outputs"):
            replay._make_replay(graph, 2, (), None, (), (object(),), (object(),), {}, object(),
                                numeric=object(), release_steps=(("drop", 1),))
        graph._make_boxed_replay.assert_not_called()


instantiate_parametrized_tests(TestNumericReleaseBridge)


if __name__ == "__main__":
    run_tests()
