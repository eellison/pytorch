import generated_backward_fixture
from torch.testing._internal.common_utils import run_tests


class TestGeneratedBackwardCUDA(generated_backward_fixture.TestGeneratedBackwardCUDA):
    pass


if __name__ == "__main__":
    run_tests()
