import automatic_compiler_fixture
from torch.testing._internal.common_utils import run_tests


class TestAutomaticCompilerOriginsCUDA(automatic_compiler_fixture.TestAutomaticCompilerOriginsCUDA):
    pass


if __name__ == "__main__":
    run_tests()
