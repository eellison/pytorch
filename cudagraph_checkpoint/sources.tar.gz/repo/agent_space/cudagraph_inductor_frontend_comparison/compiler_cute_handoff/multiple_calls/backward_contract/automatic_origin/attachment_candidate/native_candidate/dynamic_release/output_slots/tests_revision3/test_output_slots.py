from dataclasses import replace
from types import FunctionType
from unittest import mock

import frontend_readers_fixture
import release_bridge_fixture
import release_projection_fixture
import schedule_fixture
import static_metadata_fixture
import symbolic_release_fixture
import torch
from compiler_metadata_handoff.metadata import (
    _check_release_schedule, attach_metadata, collect_metadata, MetadataDeclined, read_metadata,
)
from compiler_saved_inputs import schedule
from fx_adapter.extraction import trace_generated_fx
from fx_adapter.lowering import lower_fx
from retained_ir.prototype import (
    bind_selected, export_ir, reconstruct_ir, retain_wrapper, RetentionDeclined,
)
from torch._inductor import config
from torch._inductor.codegen.wrapper import FreeLine
from torch._inductor.runtime import cudagraph_boxed_replay as replay
from torch._inductor.runtime.cudagraph_arg_mapping import (
    bind_wrapper_allocations, BufferSource, InputSource, OwnedBuffer,
)
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)


def _static_slots(args):
    activation, weight = args
    args.clear()
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        temp = empty_strided_cuda((32, 128), (128, 1), torch.float32)
        activation = copy_if_misaligned(activation)
        first.run(activation, temp, 4096, stream=get_raw_stream(0))
        del activation
        output = empty_strided_cuda((32, 128), (128, 1), torch.float32)
        weight = copy_if_misaligned(weight)
        second.run(temp, weight, output, 4096, stream=get_raw_stream(0))
    return (None, output, None, None)


def _symbolic_slots(args):
    activation, width, weight = args
    args.clear()
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        temp = empty_strided_cuda((32, width), (width, 1), torch.float32)
        activation = copy_if_misaligned(activation)
        first.run(activation, temp, 32 * width, stream=get_raw_stream(0))
        del activation
        output = empty_strided_cuda((32, width), (width, 1), torch.float32)
        weight = copy_if_misaligned(weight)
        second.run(temp, weight, output, 32 * width, stream=get_raw_stream(0))
    return (None, output, None, None)


class TestCompilerOutputSlots(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())
        self.enterContext(config.patch(cudagraph_saved_input_schedule=False))

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, version, slots=(None, 1, None, None)):
        fixture = (symbolic_release_fixture.SymbolicCompilerFixture(self) if version == 4 else
                   schedule_fixture.CompilerFixture(self, late_weight=True, copies=True))
        nodes = (fixture.temp, fixture.output)
        fixture.graph.graph_outputs = [None if index is None else nodes[index] for index in slots]
        fixture.wrapper.lines = [line for line in fixture.wrapper.lines
                                 if not (type(line) is FreeLine and
                                         any(line.node is node for node in fixture.graph.graph_outputs))]
        fixture.records = fixture.wrapper.collect_cudagraph_call_records()
        self.assertIsNotNone(fixture.records)
        self.assertEqual(fixture.records.version, version)
        self.assertIsNotNone(bind_wrapper_allocations(fixture.records))
        return fixture

    @parametrize("version", (3, 4))
    @parametrize("pattern", ("leading", "interior", "trailing", "repeated"))
    def test_live_output_positions_and_schedule(self, version, pattern):
        slots = {"leading": (None, 1), "interior": (0, None, 1),
                 "trailing": (1, None), "repeated": (None, 1, None, None)}[pattern]
        fixture = self.fixture(version, slots)
        records = fixture.records
        self.assertEqual(records.outputs, tuple(None if index is None else records.allocations[index]
                                               for index in slots))
        self.assertEqual(bind_wrapper_allocations(records), (records.allocations, slots))
        result = fixture.collect()
        self.assertIsNotNone(result)
        self.assertIs(result.outputs, records.outputs)
        _check_release_schedule(result, records)
        self.assertEqual(tuple(step for step in result.steps if type(step) is OwnedBuffer), records.allocations)
        retained = retain_wrapper(fixture.wrapper, records)
        self.assertEqual(reconstruct_ir(export_ir(retained)), retained)

    @parametrize("version", (3, 4))
    @parametrize("frontend", ("fx", "retained"))
    def test_readers_and_attachment_preserve_physical_slots(self, version, frontend):
        fixture = self.fixture(version)
        metadata = collect_metadata(fixture.wrapper, fixture.records)
        self.assertIsNotNone(metadata)
        metadata = replace(metadata, release_schedule=fixture.collect())
        artifact, _ = static_metadata_fixture.load_source(fixture.records, metadata)
        _, restored = read_metadata(artifact)
        self.assertEqual(restored, metadata)
        retained = reconstruct_ir(restored.retained_ir)
        self.assertEqual(retained.records, fixture.records)
        kernels = frontend_readers_fixture.selections(retained)
        donor = _symbolic_slots if version == 4 else _static_slots
        namespace = {}
        function = FunctionType(donor.__code__, namespace, donor.__name__)
        namespace[function.__name__] = function
        function._cudagraph_call_records = fixture.records
        attach_metadata(function, metadata)
        examples = (fixture.example_inputs() if version == 4 else
                    [torch.empty_strided((32, 128), (128, 1), device="meta") for _ in range(2)])
        if frontend == "fx":
            trace = trace_generated_fx(function, metadata.inputs, examples, kernels, source_records=fixture.records)
            self.assertEqual(tuple(value is None for value in trace.outputs), (True, False, True, True))
            program = lower_fx(trace, record_version=version)
        else:
            program = bind_selected(retained, kernels).program
        self.assertEqual(program.records.version, version)
        self.assertEqual(bind_wrapper_allocations(program.records)[1], (None, 1, None, None))
        self.assertEqual(tuple((row.size, row.stride) for row in program.records.allocations),
                         tuple((row.size, row.stride) for row in fixture.records.allocations))
        self.assertEqual(tuple(row.boxed_index for row in program.records.integer_inputs),
                         tuple(row.boxed_index for row in fixture.records.integer_inputs))

    @parametrize("version", (3, 4))
    def test_valid_but_reordered_output_records_lose_live_authority(self, version):
        fixture = self.fixture(version)
        retain_wrapper(fixture.wrapper, fixture.records)
        outputs = fixture.records.outputs
        changed = replace(fixture.records, outputs=(outputs[1], None, None, None))
        self.assertIsNotNone(bind_wrapper_allocations(changed))
        with self.assertRaisesRegex(RetentionDeclined, "final compiler output slots"):
            retain_wrapper(fixture.wrapper, changed)
        self.assertIsNone(schedule.collect_release_schedule(fixture.saved, fixture.wrapper, changed))
        with self.assertRaisesRegex(MetadataDeclined, "generated wrapper"):
            _check_release_schedule(replace(fixture.collect(), outputs=changed.outputs), fixture.records)

    @parametrize("damage", ("integer", "boolean", "string", "duplicate", "all_none", "input", "unknown"))
    def test_invalid_output_rows_do_not_bind(self, damage):
        fixture = self.fixture(4)
        output = fixture.records.outputs[1]
        if damage in ("integer", "boolean", "string"):
            outputs = ({"integer": 0, "boolean": False, "string": "None"}[damage], output)
        elif damage == "duplicate":
            outputs = (output, None, output)
        elif damage == "all_none":
            outputs = (None, None)
        else:
            source = InputSource(0) if damage == "input" else BufferSource("missing")
            outputs = (None, replace(output, source=source))
        self.assertIsNone(bind_wrapper_allocations(replace(fixture.records, outputs=outputs)))

    @parametrize("damage", ("literal", "duplicate", "all_none"))
    def test_live_compiler_outputs_cannot_invent_owned_slots(self, damage):
        fixture = self.fixture(4)
        fixture.graph.graph_outputs = {"literal": [None, 0, fixture.output],
                                       "duplicate": [fixture.output, None, fixture.output],
                                       "all_none": [None, None]}[damage]
        self.assertIsNone(fixture.wrapper.collect_cudagraph_call_records())

    def test_version_two_still_requires_tensor_allocation_outputs(self):
        fixture = self.fixture(3)
        original = replace(fixture.records, version=2, outputs=fixture.records.allocations, allocations=None)
        self.assertIsNotNone(bind_wrapper_allocations(original))
        self.assertIsNone(bind_wrapper_allocations(replace(original, outputs=(None, *original.outputs))))

    @parametrize("enabled", (False, True))
    def test_physical_slots_reach_native_constructor(self, enabled):
        fixture = self.fixture(3)
        # Existing CPU capture-byte/module stand-ins; full bridge validation stays real.
        graph, selected, launches, buffers, nodes = release_bridge_fixture.TestReleaseBridge.captured(
            self, fixture.records)
        normalize = object()
        with mock.patch.object(replay, "StaticallyLaunchedCudaKernel", release_bridge_fixture.CapturedModule):
            result = replay.make_boxed_replay(
                graph, fixture.records, selected, launches, buffers, object(),
                copy_if_misaligned=normalize, release_schedule=fixture.collect() if enabled else None,
            )
        self.assertIs(result, graph._make_boxed_replay.return_value)
        graph._make_boxed_replay.assert_called_once()
        arguments = graph._make_boxed_replay.call_args.args
        self.assertEqual(arguments[6][0], tuple(copy.input_index for copy in fixture.records.alignment_copies))
        self.assertIs(arguments[6][1], normalize)
        self.assertEqual(arguments[7], (None, 1, None, None))
        if enabled:
            self.assertIsNone(arguments[8])
            self.assertEqual(arguments[9][1], nodes)
            self.assertEqual(tuple(step for step in arguments[9][0] if step[0] == "drop"), (("drop", 0),))


class TestOutputSlotProjection(TestCase):
    def setUp(self):
        super().setUp()
        self.fixture = release_projection_fixture.TestReleaseProjection()
        self.addCleanup(self.fixture.doCleanups)
        self.fixture.setUp()
        fixture = self.fixture
        outputs = (None, *fixture.source.outputs, None, None)
        fixture.source = replace(fixture.source, outputs=outputs)
        fixture.schedule = replace(fixture.schedule, outputs=outputs)
        fixture.program = replace(fixture.program, records=replace(
            fixture.program.records, outputs=(None, *fixture.program.records.outputs, None, None)))

    def test_full_projection_preserves_none_and_drop_positions(self):
        result, _ = self.fixture.project()
        self.assertEqual(result.outputs, self.fixture.program.records.outputs)
        self.assertEqual(tuple(row is None for row in result.outputs), (True, False, False, True, True))
        self.assertIs(result.steps[3], self.fixture.schedule.steps[3])
        self.assertIs(result.input_uses, self.fixture.schedule.input_uses)

    @parametrize("damage", ("move_none", "remove_none", "move_tensor"))
    def test_projection_rejects_physical_output_changes(self, damage):
        fixture = self.fixture
        self.assertIsNotNone(fixture.project()[0])
        outputs = fixture.program.records.outputs
        if damage == "move_none":
            changed = (outputs[1], None, outputs[2], None, None)
        elif damage == "remove_none":
            changed = outputs[:-1]
        else:
            changed = (None, outputs[2], outputs[1], None, None)
        records = replace(fixture.program.records, outputs=changed)
        self.assertIsNotNone(bind_wrapper_allocations(records))
        with self.assertRaisesRegex(UnsupportedCapture, "output order"):
            fixture.project(replace(fixture.program, records=records))


instantiate_parametrized_tests(TestCompilerOutputSlots)
instantiate_parametrized_tests(TestOutputSlotProjection)

if __name__ == "__main__":
    run_tests()
