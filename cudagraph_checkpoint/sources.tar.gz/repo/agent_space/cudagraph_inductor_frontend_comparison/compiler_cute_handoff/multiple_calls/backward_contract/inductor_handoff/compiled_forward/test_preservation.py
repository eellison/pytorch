from unittest import mock

import torch
from torch._inductor.compile_fx import fake_tensor_prop
from torch.fx import Graph
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)

import backward_classification_fixture as fixture
from classification import ClassificationDeclined, classify_saved_activations
from preservation import preserve_aot_forward


class TestForwardPreservation(TestCase):
    @parametrize("dynamic", (False, True))
    def test_real_forward_callback_survives_fake_propagation(self, dynamic):
        class PreservingCapture(fixture.CallbackCapture):
            def compile_forward(self, graph, examples):
                self.preserved = preserve_aot_forward(graph)
                boxed = super().compile_forward(self.preserved.compilation, examples)
                self.forward = self.preserved.snapshot
                self.before = tuple(node.meta.get("val") for node in graph.graph.nodes)
                with torch.no_grad():
                    fake_tensor_prop(graph, examples)
                self.after = tuple(node.meta.get("val") for node in graph.graph.nodes)
                return boxed

        with mock.patch.object(fixture, "CallbackCapture", PreservingCapture):
            capture, _ = fixture.TestSavedActivationClassification.capture(self, dynamic=dynamic)
        self.assertIs(capture.forward, capture.preserved.snapshot)
        self.assertIsNot(capture.forward, capture.preserved.compilation)
        self.assertTrue(capture.provenance.candidate_indices)
        self.assertEqual(classify_saved_activations(capture.forward, capture.backward), capture.provenance)
        self.assertTrue(any(isinstance(before, torch.Tensor) and before is not after
                            for before, after in zip(capture.before, capture.after, strict=True)))
        for node, value in zip(capture.forward.graph.nodes, capture.before, strict=True):
            self.assertIs(node.meta.get("val"), value)

    @parametrize("shared", (False, True))
    def test_replacing_compiler_metadata_preserves_original_join(self, shared):
        capture, _ = fixture.TestSavedActivationClassification.capture(self)
        original = capture.forward
        output = next(node for node in original.graph.nodes if node.op == "output")
        row = next(row for row in capture.provenance.inputs if row.kind == "activation")
        saved = output.args[0][row.forward_output]
        placeholder = tuple(node for node in capture.backward.graph.nodes if node.op == "placeholder")[row.boxed_index]
        if shared:
            # Recreate the dictionary sharing used by AOT placeholder extraction.
            placeholder.meta = saved.meta
        self.assertEqual(classify_saved_activations(original, capture.backward), capture.provenance)
        backward_metadata = placeholder.meta
        value = placeholder.meta["val"]
        preserved = preserve_aot_forward(original)
        self.assertIs(preserved.compilation, original)
        self.assertIsNot(saved.meta, backward_metadata)
        self.assertIs(saved.meta["val"], value)
        saved.meta["val"] = object()
        output.meta["desc"] = None
        self.assertIs(placeholder.meta, backward_metadata)
        self.assertIs(placeholder.meta["val"], value)
        self.assertEqual(classify_saved_activations(preserved.snapshot, capture.backward), capture.provenance)
        with self.assertRaisesRegex(ClassificationDeclined, "complete final AOT output descriptors"):
            classify_saved_activations(preserved.compilation, capture.backward)

    def test_compilation_keeps_original_module_and_snapshot_keeps_graph(self):
        capture, _ = fixture.TestSavedActivationClassification.capture(self)
        original = capture.forward
        graph = original.graph
        module_metadata = original.meta
        hooks = original._create_node_hooks
        preserved = preserve_aot_forward(original)
        self.assertIs(preserved.compilation, original)
        self.assertIs(preserved.compilation.graph, graph)
        self.assertIs(preserved.compilation.meta, module_metadata)
        self.assertIs(preserved.compilation._create_node_hooks, hooks)
        self.assertIsNot(preserved.snapshot.graph, graph)
        for source, copied in zip(graph.nodes, preserved.snapshot.graph.nodes, strict=True):
            self.assertIsNot(source, copied)
            self.assertEqual((source.op, source.target, source.name), (copied.op, copied.target, copied.name))
            self.assertIsNot(source.meta, copied.meta)
            self.assertIs(source.meta.get("val"), copied.meta.get("val"))
        output = next(node for node in graph.nodes if node.op == "output")
        output.args = ((),)
        self.assertEqual(classify_saved_activations(preserved.snapshot, capture.backward), capture.provenance)

    def test_copy_failure_propagates_without_detaching_original_metadata(self):
        capture, _ = fixture.TestSavedActivationClassification.capture(self)
        original = capture.forward
        nodes = tuple(original.graph.nodes)
        metadata = tuple(node.meta for node in nodes)
        error = RuntimeError("unexpected graph copy failure")
        with mock.patch.object(Graph, "node_copy", side_effect=error):
            with self.assertRaisesRegex(RuntimeError, "unexpected graph copy failure") as caught:
                preserve_aot_forward(original)
        self.assertIs(caught.exception, error)
        for node, saved in zip(nodes, metadata, strict=True):
            self.assertIs(node.meta, saved)
        self.assertEqual(classify_saved_activations(original, capture.backward), capture.provenance)

    def test_non_graph_module_is_not_optional_absence(self):
        with self.assertRaisesRegex(TypeError, "original AOT forward GraphModule"):
            preserve_aot_forward(None)


instantiate_parametrized_tests(TestForwardPreservation)


if __name__ == "__main__":
    run_tests()
