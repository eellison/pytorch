import ctypes
import json

import numeric_release_controls_fixture as controls
import torch
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, requires_cuda_python_bindings, run_tests, skipIfRocm, TestCase


@skipIfRocm
class TestNativeOutputSlots(TestCase):
    capture = controls.TestNumericReleaseControlsCUDA.capture

    def make_entry(self, graph, batch, stream, nodes, outputs, *, numeric=True, release=True):
        if numeric:
            count, inputs, layouts, program, steps = 2, (1,), controls.LAYOUTS, controls.NUMERIC, controls.STEPS
        else:
            batch = graph._prepare_kernel_pointer_updates(
                ((nodes[0], 0, 0), (nodes[0], 1, 1), (nodes[1], 0, 1), (nodes[1], 1, 2)), 3,
            )
            count, inputs, layouts, program = 1, (0,), ((torch.int64, (controls.CAPTURE_SIZE,), (1,)),) * 2, None
            steps = tuple((kind, 0 if kind == "drop" else index) for kind, index in controls.STEPS)
        plan = (steps, nodes) if release else None
        entry = graph._make_boxed_replay(batch, stream, (), count, inputs, layouts, None, outputs, program, plan)
        self.addCleanup(entry.close)
        return entry

    @requires_cuda_python_bindings
    @parametrize("numeric", (False, True))
    @parametrize("release", (False, True))
    def test_physical_none_slots(self, device, numeric, release):
        graph, batch, stream, nodes, source, buffers = self.capture(device)
        entry = self.make_entry(graph, batch, stream, nodes, (None, 1, None, 0, None), numeric=numeric, release=release)
        held, observations = [], []
        sizes = (controls.CAPTURE_SIZE, 257, 33) if numeric else (controls.CAPTURE_SIZE,) * 3
        for offset, count in enumerate(sizes):
            value = torch.arange(count, dtype=torch.int64, device=device).add_(offset)
            pointer, weak = value.data_ptr(), StorageWeakRef(value.untyped_storage())
            box = [count, value] if numeric else [value]
            del value
            output = entry(box)
            self.assertEqual(box, [])
            self.assertTrue(weak.expired())
            self.assertIs(type(output), tuple)
            self.assertEqual(len(output), 5)
            for index in (0, 2, 4):
                self.assertIsNone(output[index])
            expected = torch.arange(count, dtype=torch.int64, device=device) + offset + 1
            self.assertEqual(output[1], expected * 2)
            self.assertEqual(output[3], expected)
            self.assertNotEqual(output[1].data_ptr(), output[3].data_ptr())
            if release:
                self.assertEqual(output[1].data_ptr(), pointer, "None slots must preserve the actual pending claim")
            else:
                self.assertNotEqual(output[1].data_ptr(), pointer)
            self.assertFalse(entry.failed)
            held.append((output, (None, expected * 2, None, expected, None)))
            observations.append({"size": count, "claimed": output[1].data_ptr() == pointer})
        entry.close()
        self.assertTrue(entry.closed)
        for actual, expected in held:
            self.assertEqual(actual, expected)
        self.assertEqual(source, torch.arange(controls.CAPTURE_SIZE, dtype=torch.int64, device=device))
        for buffer in buffers:
            self.assertEqual(buffer, torch.full_like(buffer, -777))
        print("NATIVE_OUTPUT_SLOTS " + json.dumps({"numeric": numeric, "release": release,
              "slots": [None, 1, None, 0, None], "calls": observations, "held_outputs_after_close": True}))

    @requires_cuda_python_bindings
    @parametrize("fault", ("negative", "range", "duplicate", "bool"))
    def test_invalid_slot_is_cold(self, device, fault):
        graph, batch, stream, nodes, source, buffers = self.capture(device)
        before = graph._inspect_captured_kernel_nodes(nodes)
        bad, error, message = {
            "negative": ((None, -1), ValueError, "Output index must be nonnegative"),
            "range": ((None, 2), ValueError, "Output indices must be distinct and in range"),
            "duplicate": ((None, 1, None, 1), ValueError, "Output indices must be distinct and in range"),
            "bool": ((None, True), TypeError, "Output index must be an exact integer"),
        }[fault]
        with self.assertRaisesRegex(error, message):
            self.make_entry(graph, batch, stream, nodes, bad)
        self.assertEqual(graph._inspect_captured_kernel_nodes(nodes), before)
        entry = self.make_entry(graph, batch, stream, nodes, (None, 1))
        box = [257, torch.arange(257, dtype=torch.int64, device=device)]
        output = entry(box)
        self.assertEqual(box, [])
        self.assertIsNone(output[0])
        entry.close()
        self.assertEqual(output[1], (torch.arange(257, dtype=torch.int64, device=device) + 1) * 2)
        self.assertTrue(entry.closed)

    @requires_cuda_python_bindings
    @parametrize("explicit", (False, True))
    def test_legacy_tensor_outputs(self, device, explicit):
        graph, batch, stream, nodes, source, buffers = self.capture(device)
        entry = self.make_entry(graph, batch, stream, nodes, (0, 1) if explicit else None, release=False)
        box = [257, torch.arange(257, dtype=torch.int64, device=device)]
        output = entry(box)
        self.assertEqual(box, [])
        self.assertEqual(len(output), 2)
        entry.close()
        expected = torch.arange(257, dtype=torch.int64, device=device) + 1
        self.assertEqual(output, (expected, expected * 2))

    @requires_cuda_python_bindings
    @parametrize("same_pattern", (False, True))
    def test_dispatch_checks_slot_kinds_cold(self, device, same_pattern):
        graph, batch, stream, nodes, source, buffers = self.capture(device)
        first = self.make_entry(graph, batch, stream, nodes, (None, 0, None, 1))
        second_slots = (None, 1, None, 0) if same_pattern else (1, None, None, 0)
        second = self.make_entry(graph, batch, stream, nodes, second_slots)
        calls = []

        def unexpected_predicate(integers, doubles):
            calls.append("predicate")
            return 0

        # Cold append never executes this owned C-compatible predicate address.
        callback = ctypes.CFUNCTYPE(ctypes.c_int8, ctypes.POINTER(ctypes.c_int64), ctypes.POINTER(ctypes.c_double))(
            unexpected_predicate,
        )
        predicate = ((0,), ctypes.cast(callback, ctypes.c_void_p).value, callback)
        dispatcher = torch._C._cuda_make_boxed_dispatch(((first, predicate),), lambda box: calls.append("miss"))
        self.addCleanup(dispatcher.close)
        if same_pattern:
            dispatcher.append(second, predicate)
        else:
            with self.assertRaisesRegex(ValueError, "output slot kinds"):
                dispatcher.append(second, predicate)
            self.assertFalse(second.closed)
            self.assertFalse(second.failed)
        self.assertEqual(calls, [])
        self.assertFalse(dispatcher.failed)
        self.assertFalse(dispatcher.invalidated)
        dispatcher.close()
        self.assertTrue(dispatcher.closed)


instantiate_device_type_tests(TestNativeOutputSlots, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
