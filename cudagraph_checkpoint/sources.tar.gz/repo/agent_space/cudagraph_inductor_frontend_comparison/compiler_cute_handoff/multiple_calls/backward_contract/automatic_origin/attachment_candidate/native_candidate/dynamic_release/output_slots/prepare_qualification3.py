"""Prepare CPU242/GPU44 against the reviewed native output-slot build."""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OLD = ROOT / "qualification2"
NEW = ROOT / "qualification3"
HARNESS = ("manifest.json", "gpu_dependencies.json", "run_cpu_helpers.json",
           "run_tests.py", "test_cpu.py", "test_native_width.py")
REVIEWS = (
    "compiler_source_review.json", "compiler_independent_review.json",
    "native_source_review.json", "native_independent_review.json", "native_source_independent_review.json",
    "build_scaffold_source_review.json", "dynamic_frontend_source_review.json",
    "dynamic_frontend_independent_review.json", "tests_revision2/source_review.json",
    "tests_revision3/source_review.json", "tests_revision3/independent_review.json",
)


def digest(path):
    with Path(path).open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with path.open("x") as file:
        json.dump(value, file, indent=2)
        file.write("\n")


def main():
    if NEW.exists():
        raise RuntimeError("qualification3 already exists")
    build = read(ROOT / "evidence/build_result.json")
    imported = read(ROOT / "evidence/fresh_import.json")
    proof = imported["proof"]
    source_manifest = ROOT / "evidence/source_manifest.json"
    built = read(source_manifest)
    target = ROOT / "install_attempt1"
    if (not build["accepted"] or not imported["accepted"] or imported["fresh_child"] is not True
            or proof["cuda_initialized"] is not False):
        raise RuntimeError("An accepted build and fresh CUDA-uninitialized import are required")
    if (build["manifest_sha256"] != digest(source_manifest)
            or proof["source_manifest_sha256"] != digest(source_manifest)
            or proof["installed_native_hashes"] != build["installed_native_hashes"]
            or proof["installed_stub_sha256"] != build["installed_stub_sha256"]
            or proof["installed_version_sha256"] != build["installed_version_sha256"]
            or Path(built["install_root"]) != target):
        raise RuntimeError("Native build and import do not describe the selected output-slot installation")

    review = read(OLD / "execution_review.json")
    if len(review["cases"]["cpu"]) != 242 or len(review["cases"]["public"]) != 23:
        raise RuntimeError("Expected the unchanged CPU242/GPU23 donor inventory")
    files = review["files"]
    for name, expected in files.items():
        if digest(name) != expected:
            raise RuntimeError("Frozen donor source changed: " + name)
    for group, directory in (("delta_files", ROOT / "source_delta"),
                             ("scaffold_hashes", ROOT), ("native_review_hashes", ROOT)):
        for name, expected in built[group].items():
            path = directory / name
            if digest(path) != expected:
                raise RuntimeError("Reviewed native source changed: " + str(path))
            files[str(path)] = expected
    for name in REVIEWS:
        path = ROOT / name
        document = read(path)
        rows = document.get("files", {})
        rows = rows.items() if type(rows) is dict else ((row["path"], row["sha256"]) for row in rows)
        for filename, expected in rows:
            if digest(filename) != expected:
                raise RuntimeError("Reviewed candidate source changed: " + filename)
            if filename in files and files[filename] != expected:
                raise RuntimeError("Candidate source conflicts with frozen donor: " + filename)
            files[filename] = expected
        files[str(path)] = digest(path)

    direct = read(ROOT / "tests_revision2/native_test_inventory.json")
    dynamic = read(ROOT / "dynamic_frontend_inventory.json")
    direct_script = ROOT / "tests_revision2/test_native_output_slots.py"
    dynamic_script = ROOT / "test_dynamic_frontend_release.py"
    numeric_script = ROOT.parent / "gpu_tests/test_numeric_release_controls.py"
    if (Path(direct["script"]) != direct_script or Path(dynamic["script"]) != dynamic_script
            or len(direct["cases"]["public"]) != 12 or len(dynamic["cases"]["public"]) != 9
            or direct["helpers"] != [{"name": "numeric_release_controls_fixture", "path": str(numeric_script)}]
            or dynamic["helpers"]):
        raise RuntimeError("Expected the corrected GPU12 and exact dynamic GPU9 fixtures")
    public = [*review["cases"]["public"], *direct["cases"]["public"], *dynamic["cases"]["public"]]
    if len(public) != 44 or len(set(public)) != 44 or len(set(review["cases"]["cpu"])) != 242:
        raise RuntimeError("Qualification case IDs are not exact and unique")

    manifest = read(OLD / "manifest.json")
    if manifest["native"]["torch_python"] != proof["torch_python"]:
        raise RuntimeError("Fresh import changed the qualified Python source route")
    extension = target / "torch/_C.cpython-312-aarch64-linux-gnu.so"
    if Path(proof["torch_extension"]) != extension:
        raise RuntimeError("Fresh import did not load the selected native extension")
    manifest["native"]["installation"] = str(target)
    manifest["native"]["extension"] = str(extension)
    manifest["native"]["files"] = {str(target / name): sha for name, sha in build["installed_native_hashes"].items()}
    manifest["native"]["receipts"] = {str(ROOT / "evidence" / name): digest(ROOT / "evidence" / name)
                                    for name in ("source_manifest.json", "build_result.json", "fresh_import.json")}
    manifest["scope"] = "Native physical Tensor/None outputs with unchanged qualified Python and dependency routes."
    dependencies = read(OLD / "gpu_dependencies.json")
    dependencies["gpu"]["source_manifest"] = {"path": str(source_manifest), "sha256": digest(source_manifest)}
    helpers = read(OLD / "run_cpu_helpers.json")
    for alias, path in (("numeric_release_controls_fixture", numeric_script),
                        ("native_output_slots_fixture", direct_script),
                        ("dynamic_frontend_release_fixture", dynamic_script)):
        if alias in helpers["public"]:
            raise RuntimeError("New fixture alias already exists: " + alias)
        helpers["public"][alias] = {"path": str(path), "sha256": digest(path)}
        files[str(path)] = digest(path)

    gpu = (OLD / "test_native_width.py").read_text()
    marker = 'if __name__ == "__main__":'
    if gpu.count(marker) != 1:
        raise RuntimeError("Unexpected public aggregate entrypoint")
    gpu = "import native_output_slots_fixture\nimport dynamic_frontend_release_fixture\n" + gpu
    gpu = gpu.replace(marker,
        "class TestNativeOutputSlotsCUDA(native_output_slots_fixture.TestNativeOutputSlotsCUDA):\n    pass\n\n\n"
        "class TestDynamicFrontendSavedReleaseCUDA(dynamic_frontend_release_fixture.TestDynamicFrontendSavedReleaseCUDA):\n    pass\n\n\n"
        + marker)

    NEW.mkdir(exist_ok=False)
    write(NEW / "manifest.json", manifest)
    write(NEW / "gpu_dependencies.json", dependencies)
    write(NEW / "run_cpu_helpers.json", helpers)
    for name in ("run_tests.py", "test_cpu.py"):
        (NEW / name).write_bytes((OLD / name).read_bytes())
    (NEW / "test_native_width.py").write_text(gpu)
    paths = [NEW / name for name in HARNESS]
    paths += [OLD / "execution_review.json", Path(__file__).resolve(),
              ROOT / "tests_revision2/native_test_inventory.json", ROOT / "dynamic_frontend_inventory.json",
              ROOT / "evidence/source_manifest.json", ROOT / "evidence/build_result.json", ROOT / "evidence/fresh_import.json"]
    files.update({str(path): digest(path) for path in paths})
    review["cases"]["public"] = public
    review["scope"] = "CPU242 and GPU44: prior GPU23, corrected direct output-slot GPU12 and dynamic frontend GPU9."
    review["revision"] = "New reviewed native output-slot installation; Python/dependency routes and CPU242 unchanged."
    write(NEW / "execution_review.json", review)
    print(json.dumps({"root": str(NEW), "sources": len(files), "cases": {"cpu": 242, "public": 44}}))


if __name__ == "__main__":
    main()
