import output_slots_fixture
import numeric_bridge_fixture
import symbolic_release_fixture
import frontend_readers_fixture
import release_projection_fixture
import release_bridge_fixture
import dynamic_metadata_fixture
import release_metadata_fixture
import schedule_fixture
import static_metadata_fixture
import transport_fixture
from torch.testing._internal.common_utils import run_tests


class TestStaticMetadata(static_metadata_fixture.TestStaticMetadata):
    pass

class TestCompilerMetadata(dynamic_metadata_fixture.TestCompilerMetadata):
    pass

class TestActivationReleaseSchedule(schedule_fixture.TestActivationReleaseSchedule):
    pass

class TestReleaseMetadata(release_metadata_fixture.TestReleaseMetadata):
    pass

class TestSavedInputTransport(transport_fixture.TestSavedInputTransport):
    pass


class TestReleaseBridge(release_bridge_fixture.TestReleaseBridge):
    pass


class TestStaticFrontendReaders(frontend_readers_fixture.TestStaticFrontendReaders):
    pass


class TestReleaseProjection(release_projection_fixture.TestReleaseProjection):
    pass


class TestSymbolicReleaseSchedule(symbolic_release_fixture.TestSymbolicReleaseSchedule):
    pass


class TestNumericReleaseBridge(numeric_bridge_fixture.TestNumericReleaseBridge):
    pass


class TestCompilerOutputSlots(output_slots_fixture.TestCompilerOutputSlots):
    pass


class TestOutputSlotProjection(output_slots_fixture.TestOutputSlotProjection):
    pass


if __name__ == "__main__":
    run_tests()
