from dataclasses import replace
from types import FunctionType
from unittest import mock

import torch
import dynamic_metadata_fixture
import schedule_fixture
import static_metadata_fixture
from compiler_metadata_handoff.metadata import (
    attach_metadata, collect_metadata, MetadataDeclined, read_metadata,
)
from fx_adapter import extraction
from fx_adapter.contract import FXTraceDeclined
from fx_adapter.extraction import trace_generated_fx
from fx_adapter.lowering import lower_fx
from host_program import Allocate, Invoke, Normalize
from retained_ir.prototype import (
    bind_selected, CallSite, export_ir, reconstruct_ir, retain_wrapper, RetentionDeclined, validate,
)
from selected_kernel import SelectedKernel
from torch._inductor import config
from torch._inductor.runtime.cudagraph_arg_mapping import (
    ExpressionSource, IntExpr, LauncherArgument,
)
from torch._inductor.runtime.triton_heuristics import Grid1D
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)


def _static_call(args):
    activation, weight = args
    args.clear()
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        temp = empty_strided_cuda((32, 128), (128, 1), torch.float32)
        activation = copy_if_misaligned(activation)
        first.run(activation, temp, 4096, stream=get_raw_stream(0))
        del activation
        output = empty_strided_cuda((32, 128), (128, 1), torch.float32)
        weight = copy_if_misaligned(weight)
        second.run(temp, weight, output, 4096, stream=get_raw_stream(0))
    return (output,)


def _dynamic_call(args):
    rows, value = args
    args.clear()
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        output = empty_strided_cuda((rows,), (1,), torch.float32)
        kernel.run(value, output, rows, stream=get_raw_stream(0))
    return (output,)


def selections(retained):
    # Actual launcher argument/grid carriers, with no compiled kernel or CUDA owner.
    grid = Grid1D(inductor_meta={})
    grid.generate({"XBLOCK": 64})
    result = {}
    for event in retained.events:
        if type(event) is not CallSite:
            continue
        arguments = tuple(LauncherArgument(arg.formal, arg.source_arg_index, arg.call_arg_index,
                                           arg.triton_type, index, None)
                          for index, arg in enumerate(event.call.arguments))
        abi = "".join("O" if arg.triton_type.startswith("*") else "i" for arg in arguments)
        result[event.call.kernel_global] = SelectedKernel(
            arguments, grid.recipe, event.pointer_writes, abi, ("CPU reader fixture",))
    return result


class TestStaticFrontendReaders(TestCase):
    def setUp(self):
        super().setUp()
        self.assertFalse(torch.cuda.is_initialized())
        self.enterContext(config.patch(cudagraph_saved_input_schedule=False))
        for name in ("init", "_lazy_init"):
            self.enterContext(mock.patch.object(torch.cuda, name, side_effect=AssertionError("CUDA init attempted")))
        self.enterContext(mock.patch.object(torch._C, "_cuda_init", side_effect=AssertionError("CUDA init attempted")))

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self):
        fixture = schedule_fixture.CompilerFixture(self, late_weight=True, copies=True)
        self.assertEqual(fixture.records.version, 3)
        retained = retain_wrapper(fixture.wrapper, fixture.records)
        metadata = collect_metadata(fixture.wrapper, fixture.records)
        self.assertIsNotNone(metadata)
        self.assertEqual(reconstruct_ir(metadata.retained_ir), retained)
        namespace = {}
        function = FunctionType(_static_call.__code__, namespace, _static_call.__name__)
        namespace[function.__name__] = function
        function._cudagraph_call_records = fixture.records
        attach_metadata(function, metadata)
        examples = [torch.empty_strided((32, 128), (128, 1), device="meta") for _ in range(2)]
        return fixture, retained, metadata, function, examples, selections(retained)

    def test_v3_retained_and_release_transport_keep_actual_records(self):
        fixture, retained, metadata, _, _, kernels = self.fixture()
        metadata = replace(metadata, release_schedule=fixture.collect())
        artifact, namespace = static_metadata_fixture.load_source(fixture.records, metadata)
        _, restored = read_metadata(artifact)
        self.assertEqual(restored, metadata)
        self.assertEqual(reconstruct_ir(restored.retained_ir), retained)
        bound = bind_selected(retained, kernels)
        self.assertEqual(bound.program.records, fixture.records)
        self.assertEqual(tuple(type(event) for event in bound.program.events),
                         (Allocate, Normalize, Invoke, Allocate, Normalize, Invoke))
        self.assertEqual(tuple(event.call for event in bound.program.events if type(event) is Invoke),
                         fixture.records.calls)
        self.assertIs(namespace["call"], artifact.current_callable)

    @parametrize("parameter", (False, True))
    def test_v3_fx_construction_keeps_order_and_literal_layouts(self, parameter):
        fixture, _, metadata, function, examples, kernels = self.fixture()
        if parameter:
            examples[1] = torch.nn.Parameter(examples[1])
        originals = tuple(examples)
        trace = trace_generated_fx(function, metadata.inputs, examples, kernels, source_records=fixture.records)
        result = lower_fx(trace, record_version=fixture.records.version)
        self.assertEqual(result.records.version, 3)
        self.assertEqual(result.records.integer_inputs, ())
        self.assertEqual(tuple(type(event) for event in result.events),
                         (Allocate, Normalize, Invoke, Allocate, Normalize, Invoke))
        self.assertEqual(result.records.alignment_copies, fixture.records.alignment_copies)
        self.assertEqual(tuple(call.kernel_global for call in result.records.calls), ("first", "second"))
        self.assertEqual(tuple((row.size, row.stride) for row in result.records.allocations),
                         (((32, 128), (128, 1)), ((32, 128), (128, 1))))
        self.assertEqual(result.records.outputs, (result.records.allocations[1],))
        self.assertTrue(all(before is after for before, after in zip(originals, examples, strict=True)))

    @parametrize("kind", ("unbound_parameter", "tensor_subclass", "parameter_subclass"))
    def test_parameter_exception_requires_exact_type_and_compiler_binding(self, kind):
        fixture, _, metadata, function, examples, kernels = self.fixture()
        class TensorSubclass(torch.Tensor):
            pass
        class ParameterSubclass(torch.nn.Parameter):
            pass
        if kind == "unbound_parameter":
            examples[1] = torch.nn.Parameter(examples[1])
            records = None
        else:
            examples[1] = (examples[1].as_subclass(TensorSubclass) if kind == "tensor_subclass"
                           else ParameterSubclass(examples[1]))
            records = fixture.records
        with self.assertRaisesRegex(FXTraceDeclined, "exact boxed slots"):
            trace_generated_fx(function, metadata.inputs, examples, kernels, source_records=records)

    @parametrize("damage", ("equal_records", "equal_contract", "attachment", "code"))
    def test_changed_source_is_rejected_before_tracing(self, damage):
        fixture, _, metadata, function, examples, kernels = self.fixture()
        records, contract = fixture.records, metadata.inputs
        if damage == "equal_records":
            records = replace(records)
        elif damage == "equal_contract":
            contract = replace(contract)
        elif damage == "attachment":
            del function._cudagraph_frontend_attachment
        else:
            function.__code__ = _dynamic_call.__code__
        with mock.patch.object(extraction, "_trace_generated_fx") as trace, \
                self.assertRaisesRegex(FXTraceDeclined, "compiler"):
            trace_generated_fx(function, contract, examples, kernels, source_records=records)
        trace.assert_not_called()

    def test_source_is_rechecked_after_actual_fx_execution(self):
        fixture, _, metadata, function, examples, kernels = self.fixture()
        allocate = extraction._Extraction.allocate
        def change_attachment(state, *args):
            value = allocate(state, *args)
            function._cudagraph_frontend_metadata = replace(metadata)
            return value
        with mock.patch.object(extraction._Extraction, "allocate", new=change_attachment), \
                self.assertRaisesRegex(FXTraceDeclined, "changed during tracing"):
            trace_generated_fx(function, metadata.inputs, examples, kernels, source_records=fixture.records)

    def test_v4_stays_symbolic_and_cannot_be_lowered_as_v3(self):
        records, retained, metadata = dynamic_metadata_fixture.metadata_fixture()
        self.assertEqual(reconstruct_ir(export_ir(retained)), retained)
        trace = trace_generated_fx(_dynamic_call, metadata.inputs,
                                   [13, torch.empty(13, device="meta")], selections(retained))
        program = lower_fx(trace)
        self.assertEqual(program.records.version, records.version)
        self.assertEqual(program.records.allocations[0].size, (IntExpr("boxed", 0),))
        with self.assertRaisesRegex(FXTraceDeclined, "literal Tensor inputs"):
            lower_fx(trace, record_version=3)

    @parametrize("version", (2, 5, True))
    def test_invalid_target_version_is_not_relabelled(self, version):
        fixture, _, metadata, function, examples, kernels = self.fixture()
        trace = trace_generated_fx(function, metadata.inputs, examples, kernels, source_records=fixture.records)
        with self.assertRaisesRegex(FXTraceDeclined, "record version"):
            lower_fx(trace, record_version=version)

    def test_v3_symbolic_call_operand_is_not_accepted_as_literal(self):
        _, retained, _, _, _, _ = self.fixture()
        call = retained.records.calls[0]
        scalar = replace(call.arguments[-1], source=ExpressionSource(IntExpr("constant", 4096)))
        changed = replace(call, arguments=(*call.arguments[:-1], scalar))
        records = replace(retained.records, calls=(changed, retained.records.calls[1]))
        with self.assertRaisesRegex(RetentionDeclined, "literal compiler records"):
            validate(replace(retained, records=records))

    def test_v3_payload_must_match_actual_source_version(self):
        fixture, _, metadata, _, _, _ = self.fixture()
        _, dynamic, _ = dynamic_metadata_fixture.metadata_fixture()
        metadata = replace(metadata, retained_ir=export_ir(dynamic))
        artifact, _ = static_metadata_fixture.load_source(fixture.records, metadata)
        with self.assertRaisesRegex(MetadataDeclined, "differs from emitted call records"):
            read_metadata(artifact)

    def test_unexpected_retention_failure_propagates(self):
        fixture, _, _, _, _, _ = self.fixture()
        error = RuntimeError("unexpected retention failure")
        with mock.patch("retained_ir.prototype.retain_wrapper", side_effect=error), \
                self.assertRaisesRegex(RuntimeError, "unexpected retention failure") as caught:
            collect_metadata(fixture.wrapper, fixture.records)
        self.assertIs(caught.exception, error)


instantiate_parametrized_tests(TestStaticFrontendReaders)


if __name__ == "__main__":
    run_tests()
