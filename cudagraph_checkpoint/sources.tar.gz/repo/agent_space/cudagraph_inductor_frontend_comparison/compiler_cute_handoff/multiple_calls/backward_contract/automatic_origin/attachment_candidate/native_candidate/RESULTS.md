# Native saved-input release qualification

**154 distinct CPU checks and 18 distinct CUDA cases passed across three runs**, on one native build and the same compiler/runtime Python modules. Root and independent audits accepted every run. Repeated CPU prerequisites are counted once.

| Qualification | CUDA cases | Evidence |
| --- | ---: | --- |
| Generated backward and frontend regressions | 12 | [Results](qualification3/RESULTS.md) |
| Invalid order and retained owners/views | 4 | [Results](controls_qualification2/RESULTS.md) |
| Foreign stream and memory-history policy | 2 | [Results](streams_qualification1/RESULTS.md) |

Actual Inductor backward reuses a saved sigmoid activation's storage for a later gradient output on all three ordinary native hits. Retained graphs keep that storage alive; it becomes reusable on the releasing backward. Results and gradients are correct, and held outputs survive close.

Direct native controls prove actual unowned reuse, rejection of invalid release ordering, and protection of external owners/views. A bounded producer-stream pressure test keeps pending backing unavailable until graph work completes. Memory-history mode uses ordinary allocations after a positive reuse control.

The current release integration is optional static V3 compiler records with fresh/cache-disabled compilation and supported native caching-allocator policy. Existing FX/retained frontend replay passes without release; their release-schedule extension is the next candidate. There is no peak-memory or performance claim for this increment.

The first direct-control attempt retains four test-setup errors involving typed CUDA dependency arrays. A fixture-only correction passes; runtime sources did not change. The native build itself passed on its first attempt, preserving prior source contents and installation.

[Aggregate correspondence audit](qualification_aggregate.json), [implementation guide](README.md), and [next frontend plan](next_frontend_release.md).
