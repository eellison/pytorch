from dataclasses import asdict, replace
import json
from unittest import mock

import torch
from compiler_metadata_handoff.metadata import GeneratedMetadata, MetadataDeclined
from fx_adapter.contract import InputContract, TensorInput
from torch._inductor import config
from torch._inductor.codegen.wrapper import PythonWrapperCodegen
from torch._inductor.graph import GraphLowering
from torch._inductor.runtime.cudagraph_arg_mapping import (
    BufferSource, CallArgument, InputSource, KernelCallRecord, OwnedBuffer, WrapperCallRecords,
)
from torch._inductor.virtualized import V
from torch.testing._internal.common_utils import (
    instantiate_parametrized_tests, parametrize, run_tests, TestCase,
)

import backward_classification_fixture as fixture
from classification import ClassificationDeclined
import handoff


class TestInductorHandoff(TestCase):
    def setup_boundary(self):
        capture, _ = fixture.TestSavedActivationClassification.capture(self)
        origin = handoff.capture_aot_inputs(capture.forward, capture.backward)
        self.assertIsNotNone(origin)
        self.assertTrue(origin.classification.candidate_indices)
        values = tuple(node.meta["val"] for node in origin.placeholders)
        self.assertTrue(all(isinstance(value, torch.Tensor) for value in values))

        # Real AOT origins; explicit final-codegen carriers, with no CUDA execution.
        graph = GraphLowering.__new__(GraphLowering)
        graph.module = capture.backward
        graph.is_backward = True
        graph.cpp_wrapper = False
        graph.aot_mode = False
        graph.partition_maps = None
        graph.name = None
        graph.graph_input_names = list(origin.targets)
        wrapper = PythonWrapperCodegen.__new__(PythonWrapperCodegen)
        output = OwnedBuffer(BufferSource("out"), torch.float32, (1,), (1,))
        sources = (*map(InputSource, range(len(values))), output.source)
        arguments = tuple(CallArgument(f"p{index}", index, index, "*fp32", source)
                          for index, source in enumerate(sources))
        call = KernelCallRecord(0, "kernel", tuple(arg.formal for arg in arguments), arguments, "static", (1, 1, 1))
        records = WrapperCallRecords(3, 0, origin.targets, (call,), (), (output,), (output,))
        inputs = InputContract(
            ("tensor",) * len(values),
            tuple(TensorInput(index, value.dtype, tuple(value.shape), tuple(value.stride()))
                  for index, value in enumerate(values)), (), 0,
        )
        metadata = GeneratedMetadata(1, inputs, None)
        self.enterContext(config.patch(graph_partition=False))
        self.enterContext(V.set_graph_handler(graph))
        self.assertIsNotNone(handoff.collect_saved_inputs(origin, wrapper, records, metadata))
        return origin, graph, wrapper, records, metadata

    def test_exact_ordered_bridge_returns_only_data(self):
        origin, _, wrapper, records, metadata = self.setup_boundary()
        result = handoff.collect_saved_inputs(origin, wrapper, records, metadata)
        self.assertEqual(result.input_names, origin.targets)
        self.assertIs(result.classification, origin.classification)
        self.assertEqual(result.candidate_indices, origin.classification.candidate_indices)
        decoded = json.loads(json.dumps(asdict(result)))
        self.assertEqual(decoded["input_names"], list(origin.targets))
        self.assertEqual(len(decoded["classification"]["inputs"]), len(origin.placeholders))

    def test_later_fake_metadata_is_not_used_to_recover_origin(self):
        origin, _, wrapper, records, metadata = self.setup_boundary()
        for node in origin.placeholders:
            node.meta.clear()
        self.assertIsNotNone(handoff.collect_saved_inputs(origin, wrapper, records, metadata))

    @parametrize("damage", ("order", "replacement", "missing", "extra", "name", "target", "module", "graph"))
    def test_changed_origin_disables_annotation(self, damage):
        origin, graph, wrapper, records, metadata = self.setup_boundary()
        first, second = origin.placeholders[:2]
        if damage == "order":
            first.prepend(second)
        elif damage == "replacement":
            with origin.graph.inserting_before(first):
                replacement = origin.graph.placeholder(first.target)
            first.replace_all_uses_with(replacement)
            origin.graph.erase_node(first)
            replacement.name = origin.names[0]
            self.assertEqual(replacement.target, origin.targets[0])
        elif damage == "missing":
            first.replace_all_uses_with(second)
            origin.graph.erase_node(first)
        elif damage == "extra":
            with origin.graph.inserting_before(first):
                origin.graph.placeholder("extra")
        elif damage == "name":
            first.name += "_renamed"
        elif damage == "target":
            first.target += "_renamed"
        elif damage == "module":
            graph.module = object()
        else:
            replacement = torch.fx.Graph()
            replacement.output(None)
            origin.module.graph = replacement
        self.assertIsNone(handoff.collect_saved_inputs(origin, wrapper, records, metadata))

    @parametrize("damage", ("forward", "cpp", "aot", "partition", "subgraph", "names", "wrapper"))
    def test_unsupported_lowering_disables_annotation(self, damage):
        origin, graph, wrapper, records, metadata = self.setup_boundary()
        if damage == "forward":
            graph.is_backward = False
        elif damage == "cpp":
            graph.cpp_wrapper = True
        elif damage == "aot":
            graph.aot_mode = True
        elif damage == "partition":
            graph.partition_maps = [object()]
        elif damage == "subgraph":
            graph.name = "nested"
        elif damage == "names":
            graph.graph_input_names.reverse()
        else:
            wrapper = object()
        self.assertIsNone(handoff.collect_saved_inputs(origin, wrapper, records, metadata))

    @parametrize("damage", ("absent", "records_order", "arity", "tensor_slots", "calls"))
    def test_missing_or_inconsistent_final_metadata_disables_annotation(self, damage):
        origin, _, wrapper, records, metadata = self.setup_boundary()
        if damage == "absent":
            metadata = None
        elif damage == "records_order":
            records = replace(records, input_names=records.input_names[::-1])
        elif damage == "arity":
            records = replace(records, input_names=records.input_names[:-1])
        elif damage == "tensor_slots":
            metadata = replace(metadata, inputs=replace(metadata.inputs, tensor_inputs=()))
        else:
            records = replace(records, calls=())
        self.assertIsNone(handoff.collect_saved_inputs(origin, wrapper, records, metadata))

    def test_absent_cold_origin_disables_annotation(self):
        _, _, wrapper, records, metadata = self.setup_boundary()
        self.assertIsNone(handoff.collect_saved_inputs(None, wrapper, records, metadata))

    def test_expected_classification_decline_only(self):
        with mock.patch.object(handoff, "classify_saved_activations", side_effect=ClassificationDeclined("missing")):
            self.assertIsNone(handoff.capture_aot_inputs(None, None))
        error = RuntimeError("unexpected classifier failure")
        with mock.patch.object(handoff, "classify_saved_activations", side_effect=error):
            with self.assertRaisesRegex(RuntimeError, "unexpected classifier failure") as caught:
                handoff.capture_aot_inputs(None, None)
        self.assertIs(caught.exception, error)

    def test_unexpected_metadata_error_propagates(self):
        origin, _, wrapper, records, metadata = self.setup_boundary()
        with mock.patch.object(handoff, "_check_metadata", side_effect=MetadataDeclined("unsupported")):
            self.assertIsNone(handoff.collect_saved_inputs(origin, wrapper, records, metadata))
        error = RuntimeError("unexpected metadata failure")
        with mock.patch.object(handoff, "_check_metadata", side_effect=error):
            with self.assertRaisesRegex(RuntimeError, "unexpected metadata failure") as caught:
                handoff.collect_saved_inputs(origin, wrapper, records, metadata)
        self.assertIs(caught.exception, error)


instantiate_parametrized_tests(TestInductorHandoff)


if __name__ == "__main__":
    run_tests()
