from dataclasses import asdict
import functools
import json

from compiler_metadata_handoff.metadata import read_metadata
from compiler_saved_inputs.schedule import DropInput
import torch
from torch._functorch import config as aot_config
from torch._inductor import config
from torch._inductor.cudagraph_utils import CUDAGraphPolicy
from torch._inductor.output_code import CompiledFxGraph
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
from torch.utils.checkpoint import checkpoint, create_selective_checkpoint_contexts


SIGMOID_CONTEXT = functools.partial(create_selective_checkpoint_contexts, [torch.ops.aten.sigmoid.default])


def sigmoid_weighted(value, weight):
    return value.sigmoid() * weight


class SavedActivation(torch.nn.Module):
    def __init__(self, device, saved):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.linspace(0.5, 1.0, 4096, device=device).reshape(32, 128))
        self.saved = saved

    def forward(self, value):
        if self.saved:
            return checkpoint(sigmoid_weighted, value, self.weight, use_reentrant=False, context_fn=SIGMOID_CONTEXT)
        return value.sin() * self.weight


class RecordingPolicy(CUDAGraphPolicy):
    def __init__(self):
        self.artifacts = []

    def wrap_output(self, artifact):
        if type(artifact) is CompiledFxGraph:
            self.artifacts.append(artifact)
        return artifact


class TestGeneratedReleaseAttachment(TestCase):
    @parametrize("mode", ("saved", "rematerialized", "disabled", "late_disable"))
    def test_automatic_generated_metadata(self, device, mode):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        policy = RecordingPolicy()
        self.enterContext(torch._dynamo.config.patch(caching_precompile=False, repro_after=None))
        self.enterContext(aot_config.patch(enable_autograd_cache=False, bundled_autograd_cache=False, donated_buffer=False))
        self.enterContext(config.patch(
            cudagraph_saved_input_schedule=mode != "disabled", cudagraph_policy=policy,
            graph_partition=False, cpp_wrapper=False, fx_graph_cache=False, force_disable_caches=True,
            allow_buffer_reuse=False, inplace_buffers=False, max_fusion_size=1,
            use_static_triton_launcher=True, **{"triton.cudagraphs": False},
        ))
        model = SavedActivation(device, mode != "rematerialized")
        compiled = torch.compile(model, fullgraph=True, dynamic=False)
        for iteration in range(2):
            value = torch.linspace(-0.8, 0.9, 4096, device=device).reshape(32, 128).requires_grad_()
            expected_value = value.detach().clone().requires_grad_()
            expected_weight = model.weight.detach().clone().requires_grad_()
            actual = compiled(value)
            hidden = expected_value.sigmoid() if model.saved else expected_value.sin()
            expected = hidden * expected_weight
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            with config.patch(cudagraph_saved_input_schedule=mode not in ("disabled", "late_disable")):
                gradients = torch.autograd.grad(actual, (value, model.weight), tangent)
            self.assertEqual(gradients, torch.autograd.grad(expected, (expected_value, expected_weight), tangent))
        self.assertEqual(len(policy.artifacts), 2)
        backward, = (artifact for artifact in policy.artifacts if artifact.fx_kwargs["is_backward"])
        function, metadata = read_metadata(backward)
        records = function._cudagraph_call_records
        self.assertGreater(len(records.calls), 1)
        self.assertIs(backward.current_callable, function)
        schedule = metadata.release_schedule
        if mode == "saved":
            self.assertIsNotNone(schedule)
            self.assertEqual(schedule.input_names, records.input_names)
            self.assertEqual(schedule.outputs, records.outputs)
            drops = tuple(step for step in schedule.steps if type(step) is DropInput)
            self.assertEqual(len(drops), 1)
            drop, = drops
            self.assertEqual(records.input_names[drop.input_index], "sigmoid")
            self.assertEqual(drop.after_call, schedule.input_uses[drop.input_index][-1])
        else:
            self.assertIsNone(schedule)
            drops = ()
        self.assertIs(read_metadata(backward)[1], metadata)
        print("AUTOMATIC_RELEASE_ATTACHMENT " + json.dumps({
            "mode": mode, "compiled_artifacts": len(policy.artifacts), "invocations": 2,
            "input_names": records.input_names, "backward_calls": len(records.calls),
            "schedule_present": schedule is not None, "drops": [asdict(drop) for drop in drops],
            "emitted_annotation": mode == "saved", "native_release": False,
        }, sort_keys=True))


instantiate_device_type_tests(TestGeneratedReleaseAttachment, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
