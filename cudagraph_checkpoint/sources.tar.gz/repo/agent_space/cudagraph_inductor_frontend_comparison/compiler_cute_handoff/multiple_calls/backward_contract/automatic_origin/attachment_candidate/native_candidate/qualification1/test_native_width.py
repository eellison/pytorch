import generated_attachment_fixture
import invocation_public_fixture
import native_alignment_fixture
import user_frontend_fixture
from torch.testing._internal.common_utils import run_tests


class TestCompilerInvocationCUDA(invocation_public_fixture.TestCompilerInvocationCUDA):
    pass

class TestNativePolicyFrontendCUDA(user_frontend_fixture.TestNativePolicyFrontendCUDA):
    pass

class TestStaticLateAlignmentCUDA(native_alignment_fixture.TestStaticLateAlignmentCUDA):
    pass

class TestGeneratedReleaseAttachmentCUDA(generated_attachment_fixture.TestGeneratedReleaseAttachmentCUDA):
    pass


if __name__ == "__main__":
    run_tests()
