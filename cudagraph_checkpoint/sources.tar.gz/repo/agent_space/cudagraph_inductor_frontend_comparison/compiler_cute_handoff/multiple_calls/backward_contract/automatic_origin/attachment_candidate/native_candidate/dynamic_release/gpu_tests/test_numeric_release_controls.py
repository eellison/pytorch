import ctypes
import json
import struct

import torch
from torch.cuda._utils import _check_cuda_bindings
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, requires_cuda_python_bindings, run_tests, skipIfRocm, TestCase


PTX = b"""
.version 6.0
.target sm_50
.address_size 64
.visible .entry numeric_add(.param .u64 source, .param .u64 destination, .param .u32 count)
{
    .reg .pred %outside;
    .reg .u32 %block, %lane, %index, %count;
    .reg .u64 %src, %dst, %offset;
    .reg .s64 %value;
    ld.param.u32 %count, [count];
    mov.u32 %block, %ctaid.x;
    mov.u32 %lane, %tid.x;
    mad.lo.u32 %index, %block, 32, %lane;
    setp.ge.u32 %outside, %index, %count;
    @%outside bra DONE;
    ld.param.u64 %src, [source];
    ld.param.u64 %dst, [destination];
    mul.wide.u32 %offset, %index, 8;
    add.u64 %src, %src, %offset;
    add.u64 %dst, %dst, %offset;
    ld.global.s64 %value, [%src];
    add.s64 %value, %value, 1;
    st.global.s64 [%dst], %value;
DONE:
    ret;
}
.visible .entry numeric_double(.param .u64 source, .param .u64 destination, .param .u32 count)
{
    .reg .pred %outside;
    .reg .u32 %block, %lane, %index, %count;
    .reg .u64 %src, %dst, %offset;
    .reg .s64 %value;
    ld.param.u32 %count, [count];
    mov.u32 %block, %ctaid.x;
    mov.u32 %lane, %tid.x;
    mad.lo.u32 %index, %block, 32, %lane;
    setp.ge.u32 %outside, %index, %count;
    @%outside bra DONE;
    ld.param.u64 %src, [source];
    ld.param.u64 %dst, [destination];
    mul.wide.u32 %offset, %index, 8;
    add.u64 %src, %src, %offset;
    add.u64 %dst, %dst, %offset;
    ld.global.s64 %value, [%src];
    mul.lo.s64 %value, %value, 2;
    st.global.s64 [%dst], %value;
DONE:
    ret;
}
"""

CAPTURE_SIZE = 128
# Box slots are count and saved Tensor; values are count, 32, ceildiv(count, 32), 1.
NUMERIC = ((0,), (("boxed", 0), ("constant", 32), ("ceildiv", 0, 1), ("constant", 1)))
STEPS = (("allocate", 0), ("kernel", 0), ("drop", 1), ("allocate", 1), ("kernel", 1))
LAYOUTS = ((torch.int64, (("value", 0),), (1,)),) * 2


@skipIfRocm
class TestNumericReleaseControls(TestCase):
    def capture(self, device):
        from cuda.bindings import driver, runtime

        self.enterContext(torch.cuda.device(device))
        stream = torch.cuda.Stream(device=device)
        self.enterContext(torch.cuda.stream(stream))
        module = _check_cuda_bindings(driver.cuModuleLoadData(PTX))
        self.addCleanup(lambda: _check_cuda_bindings(driver.cuModuleUnload(module)))
        graph = torch.cuda.CUDAGraph(keep_graph=True)
        self.addCleanup(graph.reset)
        source = torch.arange(CAPTURE_SIZE, dtype=torch.int64, device=device)
        buffers = tuple(torch.full_like(source, -777) for _ in range(2))
        with torch.cuda.graph(graph, stream=stream):
            pass
        nodes = []
        for name, incoming, outgoing in ((b"numeric_add", source, buffers[0]),
                                         (b"numeric_double", buffers[0], buffers[1])):
            function = _check_cuda_bindings(driver.cuModuleGetFunction(module, name))
            arguments = (ctypes.c_void_p(incoming.data_ptr()), ctypes.c_void_p(outgoing.data_ptr()),
                         ctypes.c_uint32(CAPTURE_SIZE))
            pointers = (ctypes.c_void_p * 3)(*(ctypes.addressof(argument) for argument in arguments))
            params = driver.CUDA_KERNEL_NODE_PARAMS()
            params.func = function
            params.gridDimX, params.gridDimY, params.gridDimZ = CAPTURE_SIZE // 32, 1, 1
            params.blockDimX, params.blockDimY, params.blockDimZ = 32, 1, 1
            params.kernelParams = ctypes.addressof(pointers)
            dependencies = nodes[-1:]
            node = _check_cuda_bindings(driver.cuGraphAddKernelNode(
                graph.raw_cuda_graph(), dependencies, len(dependencies), params,
            ))
            nodes.append(node)
            snapshot = graph._inspect_captured_kernel_nodes((int(node),))[3][0]
            self.assertEqual(snapshot[1], int(function))
            self.assertEqual(snapshot[4:8], ((4, 1, 1), (32, 1, 1), 0, False))
            self.assertEqual(tuple((offset, size) for offset, size, _ in snapshot[8]),
                             ((0, 8), (8, 8), (16, 4)))
            self.assertEqual(tuple(bytes(data) for _, _, data in snapshot[8]),
                             (struct.pack("P", incoming.data_ptr()), struct.pack("P", outgoing.data_ptr()),
                              struct.pack("I", CAPTURE_SIZE)))
        graph.instantiate()
        _check_cuda_bindings(runtime.cudaGraphUpload(graph.raw_cuda_graph_exec(), stream.cuda_stream))
        stream.synchronize()
        nodes = tuple(int(node) for node in nodes)
        batch = graph._prepare_kernel_replay_updates(
            ((nodes[0], 0, 1), (nodes[0], 1, 2), (nodes[1], 0, 2), (nodes[1], 1, 3)), 4,
            tuple((node, 2, 4, 0) for node in nodes), tuple((node, 2, 3, 3) for node in nodes), len(NUMERIC[1]),
        )
        return graph, batch, stream, nodes, source, buffers

    def make_entry(self, graph, batch, stream, nodes, steps=STEPS):
        entry = graph._make_boxed_replay(batch, stream, (), 2, (1,), LAYOUTS, None, (1,), NUMERIC, (steps, nodes))
        self.addCleanup(entry.close)
        return entry

    def invoke(self, entry, device, count, backing_count, offset):
        value = torch.arange(backing_count, dtype=torch.int64, device=device).add_(offset)
        pointer, weak = value.data_ptr(), StorageWeakRef(value.untyped_storage())
        self.assertEqual(value.untyped_storage().nbytes(), backing_count * 8)
        box = [count, value]
        del value
        output, = entry(box)
        self.assertEqual(box, [])
        self.assertTrue(weak.expired())
        self.assertEqual(output.size(), (count,))
        self.assertEqual(output.stride(), (1,))
        self.assertEqual(output.untyped_storage().nbytes(), count * 8)
        self.assertEqual(output, (torch.arange(count, dtype=torch.int64, device=device) + offset + 1) * 2)
        self.assertFalse(entry.failed)
        return output, pointer

    @requires_cuda_python_bindings
    @parametrize("backing", ("matching", "larger"))
    def test_current_layout_bytes_control_reuse(self, device, backing):
        graph, batch, stream, nodes, source, buffers = self.capture(device)
        entry = self.make_entry(graph, batch, stream, nodes)
        first, pointer = self.invoke(entry, device, CAPTURE_SIZE, CAPTURE_SIZE, 0)
        self.assertEqual(first.data_ptr(), pointer, "The control must exercise a real pending claim")
        held = [(first, CAPTURE_SIZE, 0)]
        observations = []
        for offset, count in enumerate((257, 65, 512, 33), start=1):
            backing_count = count if backing == "matching" else count * 2
            output, pointer = self.invoke(entry, device, count, backing_count, offset)
            if backing == "matching":
                self.assertEqual(output.data_ptr(), pointer, "Current sizes must permit a same-byte claim")
            else:
                self.assertNotEqual(output.data_ptr(), pointer, "Larger input storage must not be claimed")
            observations.append({"size": count, "backing_bytes": backing_count * 8,
                                 "output_bytes": count * 8, "claimed": output.data_ptr() == pointer})
            held.append((output, count, offset))
        entry.close()
        self.assertTrue(entry.closed)
        for output, count, offset in held:
            self.assertEqual(output, (torch.arange(count, dtype=torch.int64, device=device) + offset + 1) * 2)
        self.assertEqual(source, torch.arange(CAPTURE_SIZE, dtype=torch.int64, device=device))
        for buffer in buffers:
            self.assertEqual(buffer, torch.full_like(buffer, -777))
        print("NUMERIC_RELEASE_CONTROL " + json.dumps({"backing": backing, "capture_size": CAPTURE_SIZE,
              "initial_claim": True, "calls": observations, "held_outputs_after_close": True}))

    @requires_cuda_python_bindings
    @parametrize("fault", ("integer_drop", "drop_before_use", "node_order"))
    def test_cold_numeric_release_proof(self, device, fault):
        graph, batch, stream, nodes, source, buffers = self.capture(device)
        before = graph._inspect_captured_kernel_nodes(nodes)
        wrong_nodes = nodes
        if fault == "integer_drop":
            invalid = (("allocate", 0), ("kernel", 0), ("drop", 0), ("allocate", 1), ("kernel", 1))
            message = "Integer inputs cannot be released as saved Tensor inputs"
        elif fault == "drop_before_use":
            invalid = (("allocate", 0), ("drop", 1), ("kernel", 0), ("allocate", 1), ("kernel", 1))
            message = "Input drop must be unique and follow its last captured use"
        else:
            invalid, wrong_nodes = STEPS, tuple(reversed(nodes))
            message = "Release call order differs from the captured kernel chain"
        with self.assertRaisesRegex(ValueError, message):
            self.make_entry(graph, batch, stream, wrong_nodes, invalid)
        self.assertEqual(graph._inspect_captured_kernel_nodes(nodes), before)
        entry = self.make_entry(graph, batch, stream, nodes)
        output, pointer = self.invoke(entry, device, 257, 257, 11)
        self.assertEqual(output.data_ptr(), pointer)
        entry.close()
        self.assertTrue(entry.closed)
        self.assertEqual(output, (torch.arange(257, dtype=torch.int64, device=device) + 12) * 2)
        self.assertEqual(source, torch.arange(CAPTURE_SIZE, dtype=torch.int64, device=device))
        for buffer in buffers:
            self.assertEqual(buffer, torch.full_like(buffer, -777))
        print("NUMERIC_RELEASE_CONTROL " + json.dumps({"fault": fault, "rejected_before_replay": True,
              "valid_dynamic_replay_claimed": True, "held_output_after_close": True}))


instantiate_device_type_tests(TestNumericReleaseControls, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
