from dataclasses import fields, is_dataclass, replace
import gc
from weakref import ref

from compiler_metadata_handoff.metadata import GeneratedMetadata, MetadataDeclined, read_metadata
from compiler_saved_inputs.schedule import DropInput
from fx_adapter.contract import InputContract, TensorInput
import schedule_fixture
import static_metadata_fixture
import torch
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


class TestReleaseMetadata(TestCase):
    def fixture(self):
        fixture = schedule_fixture.CompilerFixture(self, copies=True, late_weight=True)
        inputs = InputContract(("tensor", "tensor"), tuple(
            TensorInput(index, torch.float32, (32, 128), (128, 1)) for index in range(2)
        ), ())
        return fixture.records, GeneratedMetadata(1, inputs, None, fixture.collect())

    def test_generated_round_trip_keeps_only_data(self):
        records, metadata = self.fixture()
        artifact, namespace = static_metadata_fixture.load_source(records, metadata)
        function, restored = read_metadata(artifact)
        self.assertEqual(restored, metadata)
        self.assertIsNot(restored.release_schedule, metadata.release_schedule)
        pending = [restored]
        while pending:
            value = pending.pop()
            if is_dataclass(value):
                pending.extend(getattr(value, field.name) for field in fields(value))
            elif type(value) is tuple:
                pending.extend(value)
            else:
                self.assertIn(type(value), (str, int, float, bool, type(None), torch.dtype))
        weak = ref(function)
        del function, artifact, namespace
        gc.collect()
        self.assertIsNone(weak())
        self.assertEqual(restored, metadata)

    @parametrize("damage", (
        "names", "uses", "early_drop", "wrong_last_use", "duplicate_drop", "missing_drop",
        "calls", "copies", "copy_late", "allocation_late", "unknown_step", "outputs", "version",
    ))
    def test_modified_transport_declines(self, damage):
        records, metadata = self.fixture()
        schedule = metadata.release_schedule
        steps = list(schedule.steps)
        drop = next(step for step in steps if type(step) is DropInput)
        if damage == "names":
            schedule = replace(schedule, input_names=schedule.input_names[::-1])
        elif damage == "uses":
            schedule = replace(schedule, input_uses=((), ()))
        elif damage == "early_drop":
            steps.remove(drop)
            steps.insert(0, drop)
        elif damage == "wrong_last_use":
            steps[steps.index(drop)] = replace(drop, after_call=-1)
        elif damage == "duplicate_drop":
            steps.append(drop)
        elif damage == "missing_drop":
            steps.remove(drop)
        elif damage == "calls":
            steps[steps.index(records.calls[0])] = records.calls[1]
        elif damage == "copies":
            steps.remove(records.alignment_copies[0])
        elif damage == "copy_late":
            step = records.alignment_copies[0]
            steps.remove(step)
            steps.insert(steps.index(records.calls[0]) + 1, step)
        elif damage == "allocation_late":
            step = records.allocations[0]
            steps.remove(step)
            steps.insert(steps.index(records.calls[0]) + 1, step)
        elif damage == "unknown_step":
            steps.append("unrecognized host operation")
        elif damage == "outputs":
            schedule = replace(schedule, outputs=records.allocations)
        elif damage == "version":
            records = replace(records, version=4)
        metadata = replace(metadata, release_schedule=replace(schedule, steps=tuple(steps)))
        artifact, namespace = static_metadata_fixture.load_source(records, metadata)
        with self.assertRaises(MetadataDeclined):
            read_metadata(artifact)


instantiate_parametrized_tests(TestReleaseMetadata)


if __name__ == "__main__":
    run_tests()
