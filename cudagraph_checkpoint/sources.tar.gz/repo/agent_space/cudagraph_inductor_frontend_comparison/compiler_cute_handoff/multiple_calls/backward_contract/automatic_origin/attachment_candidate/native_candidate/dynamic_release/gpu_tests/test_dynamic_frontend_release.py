from dataclasses import asdict
import functools
import json
import sys
import threading
import weakref
from unittest import mock

import fx_adapter.extraction as fx_extraction
import fx_adapter.lowering as fx_lowering
import retained_ir.prototype as retained_reader
import compiler_policy_handoff.policy as policy_module
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from compiler_saved_inputs.schedule import DropInput
from compiler_metadata_handoff.metadata import _check_release_schedule
from selected_kernel import SelectedKernel
import torch
from torch._dynamo.utils import counters
from torch._functorch import config as aot_config
from torch._inductor import config
from torch._inductor.output_code import CompiledFxGraph
from torch._inductor.runtime import cudagraph_boxed_replay as replay
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import IntExpr, KernelCallRecord, OwnedBuffer
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
from torch.utils.checkpoint import checkpoint, create_selective_checkpoint_contexts


SIGMOID_CONTEXT = functools.partial(create_selective_checkpoint_contexts, [torch.ops.aten.sigmoid.default])


def sigmoid_weighted(value, weight):
    return value.sigmoid() * weight


class SavedFanout(torch.nn.Module):
    def forward(self, value, residual, weight):
        shared = value.sin() + residual.cos()
        return checkpoint(sigmoid_weighted, shared, weight, use_reentrant=False, context_fn=SIGMOID_CONTEXT)


class NativeObservation:
    def __init__(self, installation):
        self.artifact = installation.artifact
        self.original_code = installation.original.__code__
        self.pending = {}
        self.calls = []
        self.frames = {}
        self.errors = []
        self.forbidden_files = {policy_module.__file__, preparation.__file__, replay.__file__,
                                fx_extraction.__file__, fx_lowering.__file__, retained_reader.__file__}

    def profile(self, frame, event, result):
        try:
            code = frame.f_code
            if event == "call" and (code is self.original_code or code.co_filename in self.forbidden_files):
                name = (code.co_filename, code.co_name)
                self.frames[name] = self.frames.get(name, 0) + 1
            if code is not CompiledFxGraph.__call__.__code__ or frame.f_locals.get("self") is not self.artifact:
                return
            thread = threading.get_ident()
            if event == "call":
                if thread in self.pending:
                    raise AssertionError("Nested backward artifact invocation")
                # Never retain the box, a Tensor, the frame, or its locals dictionary.
                self.pending[thread] = (tuple(
                    (index, value.data_ptr(), StorageWeakRef(value.untyped_storage()))
                    for index, value in enumerate(frame.f_locals["inputs"])
                    if isinstance(value, torch.Tensor)
                ), tuple((index, value) for index, value in enumerate(frame.f_locals["inputs"])
                         if type(value) is int))
            elif event == "return":
                inputs, integers = self.pending.pop(thread)
                if result is None:
                    return
                if type(result) not in (tuple, list) or any(type(value) is not torch.Tensor for value in result):
                    raise AssertionError("Expected complete generated backward Tensor outputs")
                self.calls.append({
                    "inputs": [(index, pointer, weak.expired()) for index, pointer, weak in inputs],
                    "integers": integers,
                    "output_pointers": [value.data_ptr() for value in result],
                    "output_shapes": [tuple(value.shape) for value in result],
                })
        except BaseException as error:
            self.errors.append(f"{type(error).__name__}: {error}")

    def __enter__(self):
        if sys.getprofile() is not None or threading.getprofile() is not None:
            raise AssertionError("Native observation requires an unprofiled test process")
        threading.setprofile_all_threads(self.profile)
        return self

    def __exit__(self, kind, error, traceback):
        threading.setprofile_all_threads(None)
        if error is not None and self.errors:
            error.add_note("Native observation errors: " + "; ".join(self.errors))


class TestDynamicFrontendSavedRelease(TestCase):
    @parametrize("frontend", ("records", "fx", "retained"))
    @parametrize("mode", ("release", "disabled", "retain_graph"))
    def test_generated_backward_release(self, device, frontend, mode):
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)
        policy = NativeCUDAGraphPolicy(frontend=frontend)
        self.addCleanup(policy.close)
        self.enterContext(torch._dynamo.config.patch(caching_precompile=False, repro_after=None))
        self.enterContext(aot_config.patch(enable_autograd_cache=False, bundled_autograd_cache=False, donated_buffer=False))
        self.enterContext(config.patch(
            cudagraph_saved_input_schedule=mode != "disabled", cudagraph_policy=policy,
            graph_partition=False, cpp_wrapper=False, fx_graph_cache=False, force_disable_caches=True,
            allow_buffer_reuse=False, inplace_buffers=False, max_fusion_size=1, realize_reads_threshold=0,
            normalize_static_input_alignment=True, use_static_triton_launcher=True,
            use_fast_triton_launcher=True, **{"triton.cudagraphs": False},
        ))
        model = SavedFanout()
        outer_compilations = counters["stats"]["unique_graphs"]
        compiled = torch.compile(model, fullgraph=True, dynamic=True)
        bridge_calls, reader_records, bound_records = [], {}, {}
        make_replay = replay._make_replay
        fx_lower, ir_bind, native_bind = fx_lowering.lower_fx, retained_reader.bind_selected, preparation.make_boxed_replay

        def observe_fx(*args, **kwargs):
            program = fx_lower(*args, **kwargs)
            reader_records[id(program.records)] = ("fx", weakref.ref(program.records))
            return program

        def observe_ir(*args, **kwargs):
            bound = ir_bind(*args, **kwargs)
            reader_records[id(bound.program.records)] = ("retained", weakref.ref(bound.program.records))
            return bound

        def observe_binding(graph, records, *args, **kwargs):
            reader = "records"
            if frontend != "records":
                reader, reference = reader_records[id(records)]
                if reference() is not records or reader != frontend:
                    raise AssertionError("Native binder lost the selected reader's exact records")
            if records.version != 4:
                raise AssertionError("Dynamic binding requires original V4 records")
            schedule = kwargs.get("release_schedule")
            if schedule is not None:
                _check_release_schedule(schedule, records)
            entry = native_bind(graph, records, *args, **kwargs)
            # Compiler records and schedules contain data only, never Tensor owners.
            bound_records[id(entry)] = (records, schedule, reader)
            return entry

        self.enterContext(mock.patch.object(fx_lowering, "lower_fx", new=observe_fx))
        self.enterContext(mock.patch.object(retained_reader, "bind_selected", new=observe_ir))
        self.enterContext(mock.patch.object(preparation, "make_boxed_replay", new=observe_binding))

        def observe_bridge(*args, **kwargs):
            entry = make_replay(*args, **kwargs)
            numeric = kwargs.get("numeric")
            tape = None if numeric is None else (numeric.integer_indices, tuple(numeric.instructions))
            bridge_calls.append((id(entry), kwargs.get("release_steps"), tape))
            return entry

        self.enterContext(mock.patch.object(replay, "_make_replay", new=observe_bridge))
        held, expected_held = [], []

        def invoke(iteration, width, observer=None):
            shape = (32, width)
            value = torch.linspace(-0.8, 0.9, 32 * width, device=device).reshape(shape).add(iteration / 32).requires_grad_()
            residual = torch.linspace(-0.6, 0.7, 32 * width, device=device).reshape(shape).sub(iteration / 64).requires_grad_()
            weight = torch.linspace(0.5, 1.0, 32 * width, device=device).reshape(shape).requires_grad_()
            for argument in (value, residual, weight):
                torch._dynamo.mark_static(argument, 0)
            expected_value = value.detach().clone().requires_grad_()
            expected_residual = residual.detach().clone().requires_grad_()
            expected_weight = weight.detach().clone().requires_grad_()
            expected = (expected_value.sin() + expected_residual.cos()).sigmoid() * expected_weight
            actual = compiled(value, residual, weight)
            self.assertEqual(actual, expected)
            tangent = torch.ones_like(actual)
            expected_gradients = torch.autograd.grad(expected, (expected_value, expected_residual, expected_weight), tangent)
            retains = (True, False) if observer is not None and mode == "retain_graph" else (False,)
            for retain in retains:
                if observer is None:
                    gradients = torch.autograd.grad(actual, (value, residual, weight), tangent, retain_graph=retain)
                else:
                    before = len(observer.calls)
                    with observer:
                        gradients = torch.autograd.grad(actual, (value, residual, weight), tangent, retain_graph=retain)
                    self.assertEqual(observer.errors, [])
                    self.assertEqual(observer.pending, {})
                    self.assertEqual(len(observer.calls), before + 1)
                    observer.calls[-1]["retain_graph"] = retain
                    observer.calls[-1]["width"] = width
                self.assertEqual(gradients, expected_gradients)
                held.append((actual, gradients))
                expected_held.append((expected.detach(), tuple(value.detach() for value in expected_gradients)))

        invoke(0, 13)
        self.assertEqual(counters["stats"]["unique_graphs"] - outer_compilations, 1)
        backwards = tuple(installation for installation in policy.installations
                          if installation.artifact.fx_kwargs["is_backward"])
        self.assertEqual(len(backwards), 1, "Actual backward metadata did not reach the native policy")
        backward, = backwards
        self.assertEqual(backward.status, "ready", backward.decline)
        self.assertIsNone(backward.decline)
        entry = backward.entry
        self.assertIs(type(entry), torch._C._CUDAGraphBoxedReplay)
        self.assertFalse(entry.closed)
        self.assertFalse(entry.failed)
        self.assertIs(backward.artifact.current_callable, entry)
        records = backward.original._cudagraph_call_records
        self.assertEqual(records.version, 4)
        projected, projected_schedule, checked_frontend = bound_records[id(entry)]
        if frontend == "records":
            self.assertIs(projected, records)
        else:
            self.assertIsNot(projected, records)
            self.assertIs(reader_records[id(projected)][1](), projected)
        self.assertEqual(projected.version, 4)
        self.assertEqual(checked_frontend, frontend)
        self.assertEqual(len(records.integer_inputs), 1)
        integer_index = records.integer_inputs[0].boxed_index
        extent = IntExpr("boxed", integer_index)
        tensor_indices = tuple(index for index, kind in enumerate(backward.metadata.inputs.kinds) if kind == "tensor")
        self.assertEqual(backward.metadata.inputs.kinds[integer_index], "integer")
        self.assertEqual(tuple(row.boxed_index for row in projected.integer_inputs), (integer_index,))
        for layout in records.allocations:
            self.assertEqual((layout.size, layout.stride), ((32, extent), (extent, 1)))
        self.assertGreater(len(records.calls), 1)
        self.assertEqual(len(records.outputs), 3)
        schedule = backward.metadata.release_schedule
        early_pairs, drops = [], ()
        if mode == "disabled":
            self.assertIsNone(schedule)
            self.assertIsNone(projected_schedule)
        else:
            self.assertIsNotNone(schedule)
            self.assertIsNotNone(projected_schedule)
            self.assertEqual(projected_schedule.input_uses, schedule.input_uses)
            self.assertEqual(projected_schedule.outputs, projected.outputs)
            self.assertEqual(schedule.input_uses[integer_index], ())
            self.assertEqual(schedule.input_names, records.input_names)
            self.assertEqual(schedule.outputs, records.outputs)
            self.assertEqual(tuple(step for step in schedule.steps if type(step) is OwnedBuffer), records.allocations)
            self.assertEqual(tuple(step for step in schedule.steps if type(step) is KernelCallRecord), records.calls)
            drops = tuple(step for step in schedule.steps if type(step) is DropInput)
            self.assertTrue(drops)
            projected_drops = tuple(step for step in projected_schedule.steps if type(step) is DropInput)
            self.assertEqual(len(projected_drops), len(drops))
            for original_drop, projected_drop in zip(drops, projected_drops, strict=True):
                self.assertIs(original_drop, projected_drop)
                self.assertIn(original_drop.input_index, tensor_indices)
            for position, drop in enumerate(schedule.steps):
                if type(drop) is not DropInput:
                    continue
                self.assertEqual(drop.after_call, schedule.input_uses[drop.input_index][-1])
                for later in schedule.steps[position + 1:]:
                    if type(later) is OwnedBuffer and later in records.outputs:
                        early_pairs.append((drop.input_index, records.outputs.index(later)))
            self.assertTrue(early_pairs, "Actual saved-input drop must precede an output allocation")
        matching_bridge, = (row for row in bridge_calls if row[0] == id(entry))
        self.assertIsNotNone(matching_bridge[2])
        self.assertEqual(matching_bridge[2][0], (integer_index,))
        self.assertEqual(tuple(row[1] for row in matching_bridge[2][1] if row[0] == "boxed"), (integer_index,))
        if schedule is None:
            self.assertIsNone(matching_bridge[1])
        else:
            self.assertIsNotNone(matching_bridge[1])
            self.assertEqual(tuple(index for kind, index in matching_bridge[1] if kind == "drop"),
                             tuple(drop.input_index for drop in drops))
        launchers = []
        for record in records.calls:
            selected = SelectedKernel.from_warmed(backward.original.__globals__[record.kernel_global])
            runner = selected.identity[2].__globals__["runner"]
            self.assertIs(type(runner), torch._C._FastCudaLauncher)
            launchers.append(type(runner).__name__)
        observer = NativeObservation(backward)
        installation_count, bridge_count = len(policy.installations), len(bridge_calls)
        for iteration, width in enumerate((2, 7, 35, 36), start=1):
            invoke(iteration, width, observer)
            self.assertEqual(counters["stats"]["unique_graphs"] - outer_compilations, 1)
            self.assertEqual(len(policy.installations), installation_count)
            self.assertEqual(len(bridge_calls), bridge_count)
            self.assertIs(backward.artifact.current_callable, entry)
            self.assertIs(backward.metadata.release_schedule, schedule)
            self.assertEqual(backward.status, "ready")
            self.assertFalse(entry.failed)
        self.assertEqual(observer.frames, {})
        reuse = []
        for call_index, call in enumerate(observer.calls):
            self.assertEqual(len(call["output_pointers"]), len(records.outputs))
            inputs = {index: (pointer, expired) for index, pointer, expired in call["inputs"]}
            self.assertEqual(tuple(inputs), tensor_indices)
            self.assertEqual(call["integers"], ((integer_index, call["width"]),))
            self.assertEqual(call["output_shapes"], [(32, call["width"])] * len(records.outputs))
            for drop in drops:
                self.assertEqual(inputs[drop.input_index][1], not call["retain_graph"])
            for input_index, output_index in early_pairs:
                pointer, expired = inputs[input_index]
                if pointer == call["output_pointers"][output_index]:
                    self.assertTrue(expired)
                    self.assertFalse(call["retain_graph"])
                    reuse.append((call_index, input_index, output_index))
        torch.cuda.synchronize()
        self.assertEqual(held, expected_held)
        forward_states = [installation.status for installation in policy.installations
                          if not installation.artifact.fx_kwargs["is_backward"]]
        policy.close()
        self.assertTrue(entry.closed)
        self.assertEqual(held, expected_held)
        print("DYNAMIC_FRONTEND_SAVED_RELEASE " + json.dumps({
            "frontend": frontend, "reader_version": projected.version, "selected_records_reached_native": True,
            "outer_compilations": counters["stats"]["unique_graphs"] - outer_compilations,
            "widths": [13, 2, 7, 35, 36], "integer_indices": [integer_index], "tensor_indices": tensor_indices,
            "numeric_plan": matching_bridge[2],
            "mode": mode, "backward_calls": len(records.calls), "input_names": records.input_names,
            "allocation_names": [allocation.source.name for allocation in records.allocations],
            "output_names": [output.source.name for output in records.outputs],
            "alignment_copies": [asdict(copy) for copy in records.alignment_copies],
            "drops": [asdict(drop) for drop in drops], "early_output_pairs": early_pairs,
            "native_backward_hits": len(observer.calls), "native_entry": type(entry).__name__,
            "release_steps": matching_bridge[1], "launchers": launchers,
            "observations": observer.calls, "observed_reuse": reuse, "watched_host_frames": [],
            "reuse_observed": bool(reuse),
            "installations": installation_count, "bridge_constructions": bridge_count,
            "forward_installation_states": forward_states,
            "closed": entry.closed, "held_outputs_correct_after_close": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestDynamicFrontendSavedRelease, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
