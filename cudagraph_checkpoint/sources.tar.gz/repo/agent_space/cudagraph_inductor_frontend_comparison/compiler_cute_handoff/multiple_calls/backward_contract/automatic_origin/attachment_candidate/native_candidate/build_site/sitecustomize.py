"""Redirect torch's Python sources to the worktree in TORCH_WT (see pr-review/wt_python.py)."""
import os
from pathlib import Path
import sys

WT = os.environ.get("TORCH_WT", "").rstrip("/")
SRC = "/data/eellison/src/pytorch"
CANDIDATE = str(Path(__file__).resolve().parents[1])
WARM = "/data/eellison/src/pytorch/agent_space/cudagraph_input_reclamation/multi_input_backward/native_candidate/review1"
if WT:

    def sub(p):
        if isinstance(p, str) and any(p == base or p.startswith(base + "/") for base in (CANDIDATE, WARM)):
            return p
        if isinstance(p, str) and (p == SRC or p.startswith(SRC + "/")):
            return WT + p[len(SRC):]
        return p

    for f in sys.meta_path:
        if type(f).__name__ == "ScikitBuildRedirectingFinder":
            if f.rebuild_flag:
                raise SystemExit("Build source imports must not rebuild an existing installation")
            f.known_source_files = {k: sub(v) for k, v in f.known_source_files.items()}
            f.submodule_search_locations = {
                k: {sub(p) for p in v} for k, v in f.submodule_search_locations.items()
            }
            if isinstance(f.path, str):
                f.path = sub(f.path)
    sys.path[:] = [sub(p) for p in sys.path]
    sys.path.insert(0, WT)
