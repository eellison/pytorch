"""Optional cold transport between paired AOT callbacks and live wrapper IR."""

from contextlib import contextmanager
from functools import partial

from torch._dynamo import config as dynamo_config
from torch._functorch import config as aot_config
from torch._inductor import config
from torch._inductor.runtime.cudagraph_arg_mapping import WrapperCallRecords
from torch._inductor.virtualized import V

from .classification import ClassificationDeclined
from .handoff import AOTInputOrigins, collect_saved_inputs
from .origins import capture_forward_origins, ForwardOrigins, join_backward_origins
from .schedule import collect_release_schedule


ORIGIN_KEY = "_cudagraph_saved_input_origin"


def eligible(inner_compile):
    from torch._inductor import compile_fx as compiler

    standard = inner_compile is compiler.compile_fx_inner or (
        type(inner_compile) is partial and inner_compile.func is compiler.compile_fx_inner
        and not inner_compile.args and inner_compile.keywords.keys() == {"compile_region_name"}
        and inner_compile.keywords["compile_region_name"] is None
    )
    return bool(
        standard and config.cudagraph_saved_input_schedule and config.force_disable_caches
        and not aot_config.enable_autograd_cache and not aot_config.bundled_autograd_cache
        and not dynamo_config.caching_precompile and dynamo_config.repro_after is None
        and not config.save_args and not config.trace.enabled
        and not config.graph_partition and not config.cpp_wrapper and not config.fx_wrapper
        and not V.aot_compilation
        and compiler.fx_compile_mode is compiler.FxCompileMode.NORMAL
        and not compiler.fx_compile_async and not compiler.fx_compile_progressive
    )


class SavedInputCapture:
    def __init__(self, inner_compile):
        self.inner_compile = inner_compile
        self.origins: ForwardOrigins | None = None

    def clear(self):
        self.origins = None

    def forward(self, graph, *, is_inference):
        self.clear()
        if is_inference or not eligible(self.inner_compile):
            return
        try:
            self.origins = capture_forward_origins(graph)
        except ClassificationDeclined:
            pass

    @contextmanager
    def backward(self, graph):
        origins, self.origins = self.origins, None
        if origins is None or not eligible(self.inner_compile):
            del origins
            yield
            return
        try:
            classification = join_backward_origins(origins, graph)
        except ClassificationDeclined:
            classification = None
        del origins
        if classification is None or not classification.candidate_indices:
            yield
            return
        placeholders = tuple(node for node in graph.graph.nodes if node.op == "placeholder")
        targets = tuple(node.target for node in placeholders)
        if any(type(target) is not str for target in targets):
            yield
            return
        if ORIGIN_KEY in graph.meta:
            raise RuntimeError("Saved-input origin metadata is already present")
        origin = AOTInputOrigins(
            graph, graph.graph, placeholders, tuple(node.name for node in placeholders), targets, classification,
        )
        graph.meta[ORIGIN_KEY] = origin
        try:
            yield
        finally:
            graph.meta.pop(ORIGIN_KEY, None)


def collect_optional_schedule(wrapper, records, metadata):
    from torch._inductor import compile_fx as compiler

    if (not eligible(compiler.compile_fx_inner) or metadata is None
            or type(records) is not WrapperCallRecords or records.version != 3):
        return None
    origin = V.graph.module.meta.get(ORIGIN_KEY)
    if type(origin) is not AOTInputOrigins:
        return None
    saved = collect_saved_inputs(origin, wrapper, records, metadata)
    if saved is None or not saved.candidate_indices:
        return None
    return collect_release_schedule(saved, wrapper, records)
