import gc
import json
import sys
import traceback

import cutlass.cute as cute
from cutlass.base_dsl.jit_executor import ExecutionArgs, JitExecutor
from compiler_cute_handoff import callsite as callsite_module, conversion, invocation, policy as mixed, program, retained
from compiler_cute_handoff.callsite import _CompilerInvocation
from compiler_cute_handoff.envelope import bind_envelope
from compiler_cute_handoff.invocation import register_cute_entry
from cute_bridge import guard_export, lowering, preparation, provider, tracing
from cute_dispatch import cache, entry as ordinary
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from entry_signature import SignaturePolicy
from fx_adapter import extraction as fx_extraction, lowering as fx_lowering
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from selected_kernel import SelectedKernel
import conversion_workload_fixture as workload
import invocation_public_fixture
import shared_owner_fixture
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._inductor import config
from torch._inductor.output_code import CompiledFxGraph
from torch._inductor.runtime.cudagraph_arg_mapping import IntExpr
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
import width_artifact_fixture as width_fixture
import width_model_fixture


class TestCompilerInvocationCUDA(invocation_public_fixture.TestCompilerInvocationCUDA):
    pass


class TestSharedWidthOwnerCUDA(shared_owner_fixture.TestSharedWidthOwnerCUDA):
    pass


class TestNativeWidth(TestCase):
    @parametrize("frontend", ("fx", "retained"))
    def test_public_native_width(self, device, frontend):
        fixture = fixture_module.TestReductionGraphReplayCUDA("test_generated_reduction_replay_fast_True_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        self.enterContext(config.patch(use_fast_triton_launcher=True, fx_graph_cache=True, freezing=False,
            allow_buffer_reuse=False, inplace_buffers=False, normalize_static_input_alignment=True))
        layout = TensorPolicy((128, None), (0, 1))
        entry, kernel = width_fixture.make_fixture()
        owner = ObservedOrdinaryEntry(entry, kernel,
            policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout})
        self.addCleanup(owner.close)
        registration = register_cute_entry(owner, owned_executor=True)
        self.addCleanup(registration.close)
        policy = workload.RecordingPolicy(frontend)
        self.addCleanup(policy.close)
        self.enterContext(config.patch(cudagraph_policy=policy))
        compiled = torch.compile(width_model_fixture.WidthCuTe(registration.key), fullgraph=True, dynamic=True)
        previous = sys.getprofile()
        self.assertIsNone(previous)
        self.addCleanup(sys.setprofile, previous)
        watched = {
            "compile": type(cute.compile).__call__.__code__,
            "ordinary": OrdinaryEntry._invoke_owned.__code__,
            "compiler": OrdinaryEntry._invoke_compiler.__code__,
            "arguments": OrdinaryEntry._arguments.__code__,
            "convert": OrdinaryEntry._convert.__code__,
            "metadata": ordinary._metadata.__code__,
            "prepare": mixed.MixedInstallation._prepare_variant.__code__,
            "sdk": JitExecutor.__call__.__code__,
            "launch": JitExecutor.run_compiled_program.__code__,
            "generated": CachingAutotuner.run.__code__,
            "plan": conversion.build_conversion_plan.__code__,
            "fx_trace": fx_extraction.trace_mixed_fx.__code__,
            "fx_lower": fx_lowering.lower_mixed_fx.__code__,
            "retained": retained.reconstruct_mixed_ir.__code__,
        }
        forbidden = {module.__file__ for module in (
            mixed, invocation, program, retained, ordinary, cache, guard_export,
            lowering, preparation, provider, tracing, fx_extraction, fx_lowering,
            callsite_module, conversion,
        )}
        sdk_codes = (JitExecutor.__call__.__code__, JitExecutor.run_compiled_program.__code__,
                     ExecutionArgs.generate_execution_args.__code__)
        artifacts, reports, input_storages, output_storages = [], [], [], []

        def call(width, mode):
            value = torch.randn((128, width), device=device, dtype=torch.float32)
            torch._dynamo.mark_static(value, 0)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            counts, failures, frames = dict.fromkeys(watched, 0), [], []
            original_calls = 0

            def observe(frame, event, result):
                nonlocal original_calls
                try:
                    if event != "call":
                        return
                    code = frame.f_code
                    if code is CompiledFxGraph.__call__.__code__:
                        artifact = frame.f_locals["self"]
                        if not any(current is artifact for current in artifacts):
                            artifacts.append(artifact)
                    for name, watched_code in watched.items():
                        if code is watched_code:
                            counts[name] += 1
                    if mode == "native" and (code.co_filename in forbidden or code in sdk_codes
                                              or code in watched.values()):
                        frames.append((code.co_filename, code.co_name))
                    for _, original in policy.artifacts:
                        if code is original.__code__ and frame.f_globals is original.__globals__:
                            original_calls += 1
                            if mode == "native":
                                frames.append((code.co_filename, code.co_name))
                except BaseException as error:
                    if not failures:
                        failures.append("".join(traceback.format_exception(error)))

            try:
                sys.setprofile(observe)
                try:
                    result = compiled(value)
                finally:
                    sys.setprofile(previous)
            except BaseException as error:
                for failure in failures:
                    error.add_note("Deferred native width profiler failure:\n" + failure)
                raise
            if failures:
                self.fail(failures[0])
            expected = (value.sin() * 2 + (64 if width < 4 else 128),)
            self.assertIs(type(result), tuple)
            self.assertEqual(result, expected)
            output_storages.append(StorageWeakRef(result[0].untyped_storage()))
            expected_counts = dict.fromkeys(watched, 0)
            if mode == "first":
                expected_counts.update(compile=1, ordinary=1, arguments=1, convert=2, metadata=2,
                    prepare=1, launch=1, generated=1, plan=1,
                    fx_trace=int(frontend == "fx"), fx_lower=int(frontend == "fx"),
                    retained=int(frontend == "retained"))
            elif mode == "miss":
                expected_counts.update(compiler=1, prepare=1, sdk=1, launch=1, generated=1)
            self.assertEqual(counts, expected_counts)
            self.assertEqual(original_calls, int(mode != "native"))
            self.assertEqual(frames, [])
            reports.append({"width": width, "mode": mode, "counts": counts,
                            "original_calls": original_calls, "frames": frames})
            return result, expected

        held = [call(13, "first")]
        self.assertEqual(len(artifacts), 1)
        self.assertEqual(len(policy.artifacts), 1)
        artifact, = artifacts
        original = artifact._cudagraph_original_callable
        self.assertIs(policy.artifacts[0][0], artifact)
        self.assertIs(policy.artifacts[0][1], original)
        binding = bind_envelope(original)
        terminal, = binding.cute.calls
        callsite = original.__globals__[terminal.entry_global]
        self.assertIs(type(callsite), _CompilerInvocation)

        def close_invocation():
            policy.close()
            callsite.close()

        self.addCleanup(close_invocation)
        self.assertIs(callsite.check_binding(original, terminal), registration)
        self.assertEqual(callsite.status, "ready", callsite.decline)
        plan, prepared, selected = callsite.plan, owner._owned_executor, owner.selected
        self.assertIs(callsite._prepared, prepared)
        self.assertIs(prepared.selected, selected)
        self.assertIs(prepared.executor.jit_module, selected.jit_module)
        self.assertIsNone(owner._capture.decline)
        self.assertEqual(len(policy.installations), 1)
        installation, = policy.installations
        self.assertEqual(installation.status, "ready", installation.decline)
        self.assertEqual(installation._frontend, frontend)
        self.assertIs(artifact.current_callable, installation.entry)
        self.assertIs(type(installation.entry), torch._C._CUDAGraphBoxedDispatch)
        projection = installation._projection
        self.assertIs(type(projection), program.BoundMixedProgram)
        self.assertIs(projection.binding, installation._binding)
        self.assertIs(projection.binding.function(), original)
        self.assertEqual(projection.program.outputs, projection.records.outputs)
        width = terminal.operands[0].size[1]
        self.assertIs(type(width), IntExpr)
        self.assertEqual(width.op, "boxed")
        input_fact, = binding.inputs.tensor_inputs
        self.assertEqual(input_fact.size, (128, width))
        self.assertEqual(input_fact.stride, (width, 1))
        for records in (binding.records, projection.records):
            cute_call, = records.cute.calls
            self.assertEqual(len(records.allocations), 2)
            self.assertEqual({row.source for row in records.allocations}, {row.source for row in cute_call.operands})
            self.assertEqual(len(records.outputs), 1)
            self.assertEqual(records.outputs[0].source, cute_call.operands[1].source)
            for row in (*records.allocations, *cute_call.operands, *records.outputs):
                self.assertEqual(row.dtype, torch.float32)
                self.assertEqual(row.size, (128, width))
                self.assertEqual(row.stride, (width, 1))
        self.assertEqual(len(plan.operands), 2)
        for operand, fact in zip(plan.operands, terminal.operands, strict=True):
            self.assertEqual((operand.source, operand.size, operand.stride), (fact.source, fact.size, fact.stride))
            self.assertEqual((operand.shape_mask, operand.stride_mask), ((0, 1), (1, 0)))
        symbols = owner.metadata.symbols
        tensor_metadata = tuple(row for row in owner.metadata.params if row.kind == "Tensor")
        self.assertEqual(len(tensor_metadata), 2)
        for row in tensor_metadata:
            self.assertEqual(row.shape[0], ("constant", 128))
            self.assertEqual(row.strides[1], ("constant", 1))
            self.assertEqual((row.shape[1][0], row.strides[0][0]), ("symbol", "symbol"))
            self.assertEqual((symbols[row.shape[1][1]][1], symbols[row.strides[0][1]][1]), (32, 64))
        self.assertGreater(len(binding.records.generated_calls), 0)
        for name in dict.fromkeys(row.kernel_global for row in binding.records.generated_calls):
            selection = SelectedKernel.from_warmed(original.__globals__[name])
            _, launcher, cached, module = selection.identity
            self.assertIsNot(cached, launcher)
            self.assertIs(type(cached.__globals__["runner"]), torch._C._FastCudaLauncher)
            self.assertIs(cached._static_kernel_owner, module)
            fixture.modules[id(module)] = module
        held.append(call(2, "miss"))
        variants = tuple(installation.cache.variants)
        self.assertEqual(len(variants), 2)
        self.assertEqual({variant.owners[0].site.arm for variant in variants}, {False, True})
        for value in (7, 3, 35, 36):
            held.append(call(value, "native"))
            self.assertIs(callsite.plan, plan)
            self.assertIs(callsite._prepared, prepared)
            self.assertIs(owner._owned_executor, prepared)
            self.assertIs(owner.selected, selected)
            self.assertIs(installation._projection, projection)
            self.assertIs(original.__globals__[terminal.entry_global], callsite)
            self.assertEqual((len(artifacts), len(policy.artifacts)), (1, 1))
            self.assertEqual(len(installation.cache.variants), len(variants))
            for current, saved in zip(installation.cache.variants, variants, strict=True):
                self.assertIs(current, saved)
            binding.check()
            projection.check()
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        installation.close()
        self.assertIs(artifact.current_callable, original)
        self.assertEqual(owner._native_borrows, set())
        callsite.close()
        registration.close()
        for result, expected in held:
            self.assertEqual(result, expected)
        del result, expected
        held.clear()
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in output_storages))
        print("NATIVE_WIDTH_RESULT=" + json.dumps({"frontend": frontend, "observations": reports,
            "same_plan": True, "same_executor": True, "same_projection": True,
            "symbolic_size_and_stride": True, "actual_fast_launcher_verified": True,
            "single_outer_artifact": True, "single_cute_compilation": True,
            "variant_arms": [False, True], "input_storage_released": True,
            "outputs_survive_close": True, "output_storage_released": True}, sort_keys=True))


instantiate_device_type_tests(TestNativeWidth, globals(), only_for="cuda")


import multiple_native_fixture


class TestMultipleCuTeNativeCUDA(multiple_native_fixture.TestMultipleCuTeNativeCUDA):
    pass


import user_frontend_fixture
import residual_norm_fixture


class TestNativePolicyFrontendCUDA(user_frontend_fixture.TestNativePolicyFrontendCUDA):
    pass


class TestResidualNormCuTeCUDA(residual_norm_fixture.TestResidualNormCuTeCUDA):
    pass


import generated_schedule_fixture
import native_alignment_fixture


class TestGeneratedReleaseScheduleCUDA(generated_schedule_fixture.TestGeneratedReleaseScheduleCUDA):
    pass


class TestStaticLateAlignmentCUDA(native_alignment_fixture.TestStaticLateAlignmentCUDA):
    pass


if __name__ == "__main__":
    run_tests()
