import struct
from abc import ABC, abstractmethod
from dataclasses import dataclass
from types import FunctionType, MethodType
from typing import Any, Protocol

import torch

from .cudagraph_arg_mapping import (
    bind_alignment_copies, bind_fixed_grid, bind_grid_recipe, bind_wrapper_allocations, bind_wrapper_arguments, BufferSource, ExpressionSource,
    CallArgument, InputSource, IntegerInput, IntegerSource, IntExpr, KernelCallRecord, OwnedBuffer, WrapperCallRecords,
)
from .cudagraph_launch_association import associate_kernel_launches, RecordedKernelLaunch, UnsupportedCapture
from .static_triton_launcher import StaticallyLaunchedCudaKernel


class _NumericInputs(Protocol):
    input_names: tuple[str, ...]
    integer_inputs: tuple[IntegerInput, ...]


class _NumericProgram:
    def __init__(self, records: _NumericInputs, example_inputs: Any) -> None:
        if type(example_inputs) not in (list, tuple) or len(example_inputs) != len(records.input_names):
            raise UnsupportedCapture("Dynamic replay requires the actual boxed example inputs")
        self.integer_indices = tuple(row.boxed_index for row in records.integer_inputs)
        self.inputs: dict[int, int] = {}
        for index in self.integer_indices:
            value = example_inputs[index]
            if type(value) is not int or not 0 < value < 2 ** 63:
                raise UnsupportedCapture("Dynamic pointwise capture requires a positive int64 extent")
            self.inputs[index] = value
        self.instructions: list[tuple[str, int] | tuple[str, int, int]] = []
        self.values: list[int] = []
        self.indices: dict[IntExpr, int] = {}

    def add(self, expression: IntExpr) -> int:
        if type(expression) is not IntExpr or type(expression.args) is not tuple:
            raise UnsupportedCapture("Unsupported compiler integer expression")
        instruction: tuple[str, int] | tuple[str, int, int]
        if expression.op == "constant" and type(expression.value) is int and not expression.args:
            value = expression.value
            instruction = ("constant", value)
        elif expression.op == "boxed" and type(expression.value) is int and not expression.args:
            if expression.value not in self.inputs:
                raise UnsupportedCapture("Integer expression has no compiler boxed origin")
            value = self.inputs[expression.value]
            instruction = ("boxed", expression.value)
        elif expression.op == "multiply" and expression.value is None and len(expression.args) == 2:
            left, right = (self.add(arg) for arg in expression.args)
            if self.values[left] < 0 or self.values[right] < 0:
                raise UnsupportedCapture("Unsupported integer multiplication domain")
            value = self.values[left] * self.values[right]
            instruction = ("multiply", left, right)
        elif expression.op == "ceildiv" and expression.value is None and len(expression.args) == 2:
            left, right = (self.add(arg) for arg in expression.args)
            numerator, divisor = self.values[left], self.values[right]
            if numerator < 0 or divisor <= 0:
                raise UnsupportedCapture("Unsupported integer division domain")
            value = numerator // divisor + (numerator % divisor != 0)
            instruction = ("ceildiv", left, right)
        else:
            raise UnsupportedCapture("Unresolved compiler integer expression")
        if not -(2 ** 63) <= value < 2 ** 63:
            raise UnsupportedCapture("Compiler integer expression exceeds int64")
        previous = self.indices.get(expression)
        if previous is not None:
            return previous
        index = len(self.instructions)
        self.indices[expression] = index
        self.instructions.append(instruction)
        self.values.append(value)
        return index



@dataclass(frozen=True)
class _BoundCall:
    arguments: tuple[CallArgument, ...]
    module: StaticallyLaunchedCudaKernel
    grid: tuple[IntExpr, IntExpr, IntExpr] | None


class _KernelModule(ABC):
    @property
    @abstractmethod
    def function(self) -> int:
        pass

    @property
    @abstractmethod
    def parameter_layout(self) -> tuple[tuple[int, int], ...]:
        pass

    @abstractmethod
    def check(self) -> None:
        pass

    @abstractmethod
    def _borrow_for_cudagraph(self) -> object:
        pass


@dataclass(frozen=True)
class _PhysicalField:
    parameter: int
    byte_offset: int
    kind: str
    source: InputSource | BufferSource | IntegerSource | ExpressionSource


@dataclass(frozen=True)
class _PhysicalCall:
    fields: tuple[_PhysicalField, ...]
    module: _KernelModule
    grid: tuple[IntExpr, IntExpr, IntExpr]
    padding: tuple[tuple[int, int, int], ...]


def _bind_physical_call(call, launch, captured, input_count, buffer_owners, buffer_indices, numeric):
    if (not isinstance(call.module, _KernelModule) or type(call.fields) is not tuple or not call.fields
            or type(call.padding) is not tuple or numeric is None):
        raise UnsupportedCapture("Physical call requires an explicit owned module, fields and numeric plan")
    call.module.check()
    layout = call.module.parameter_layout
    if (call.module.function != launch.function or type(layout) is not tuple
            or layout != tuple((offset, width) for offset, width, _ in captured.snapshot[8])
            or len(launch.argument_bytes) != len(layout)):
        raise UnsupportedCapture("Physical call lost its selected function or actual CUDA parameter layout")
    coverage = [bytearray(width) for _, width in layout]
    pointers, scalars, inputs, buffers = [], [], set(), set()

    def span(parameter, offset, width):
        if (type(parameter) is not int or not 0 <= parameter < len(layout)
                or type(offset) is not int or type(width) is not int or offset < 0 or width <= 0
                or offset + width > len(coverage[parameter])):
            raise UnsupportedCapture("Physical field exceeds its actual CUDA parameter")
        covered = coverage[parameter]
        if any(covered[offset:offset + width]):
            raise UnsupportedCapture("Physical parameter fields overlap")
        covered[offset:offset + width] = b"\1" * width
        return launch.argument_bytes[parameter][offset:offset + width]

    for field in call.fields:
        if type(field) is not _PhysicalField or field.kind not in ("pointer", "i32", "i64"):
            raise UnsupportedCapture("Unsupported physical parameter field")
        width = 4 if field.kind == "i32" else 8
        actual = span(field.parameter, field.byte_offset, width)
        source = field.source
        if field.kind == "pointer":
            if type(source) is InputSource:
                if type(source.index) is not int or not 0 <= source.index < input_count:
                    raise UnsupportedCapture("Physical pointer input is out of range")
                pointer = source.index
                inputs.add(pointer)
            elif type(source) is BufferSource:
                value = buffer_owners.get(source)
                if type(value) is not torch.Tensor or struct.pack("P", value.data_ptr()) != actual:
                    raise UnsupportedCapture("Physical buffer field differs from its captured owner")
                pointer = buffer_indices.get(source)
                if pointer is None:
                    raise UnsupportedCapture("Physical buffer has no eager allocation slot")
                buffers.add(source)
            else:
                raise UnsupportedCapture("Physical pointer has no recorded Tensor source")
            pointers.append((captured.snapshot[0], field.parameter, field.byte_offset, pointer))
        else:
            if type(source) is IntegerSource and type(source.value) is int:
                value, index = source.value, None
            elif type(source) is ExpressionSource:
                index = numeric.add(source.expression)
                value = numeric.values[index]
            else:
                raise UnsupportedCapture("Physical integer has no exact symbolic or literal source")
            if not -(2 ** (width * 8 - 1)) <= value < 2 ** (width * 8 - 1):
                raise UnsupportedCapture("Physical integer exceeds its selected ABI width")
            if struct.pack("i" if width == 4 else "q", value) != actual:
                raise UnsupportedCapture("Physical integer field differs from its recorded source")
            if index is not None:
                scalars.append((captured.snapshot[0], field.parameter, field.byte_offset, width, index))
    for padding in call.padding:
        if type(padding) is not tuple or len(padding) != 3:
            raise UnsupportedCapture("Physical padding requires an exact compiler span")
        if any(span(*padding)):
            raise UnsupportedCapture("Physical padding differs from its declared zero bytes")
    if any(not all(covered) for covered in coverage):
        raise UnsupportedCapture("Physical fields do not cover every captured parameter byte")
    return pointers, scalars, inputs, buffers


def make_boxed_replay(
    graph: torch.cuda.CUDAGraph,
    records: WrapperCallRecords,
    selected_launchers: tuple[FunctionType, ...],
    launches: tuple[RecordedKernelLaunch, ...],
    buffer_owners: dict[BufferSource, torch.Tensor],
    stream: torch.cuda.Stream,
    *,
    copy_if_misaligned: Any = None,
    resources: tuple[object, ...] = (),
    example_inputs: list[torch.Tensor | int] | tuple[torch.Tensor | int, ...] | None = None,
    release_schedule: Any = None,
) -> Any:
    allocation_plan = bind_wrapper_allocations(records)
    if allocation_plan is None or not records.calls or len(selected_launchers) != len(records.calls):
        raise UnsupportedCapture("Boxed replay requires complete compiler buffer layouts")
    allocations, output_indices = allocation_plan
    release_steps = None
    if release_schedule is not None:
        from compiler_metadata_handoff.metadata import _check_release_schedule, MetadataDeclined
        from compiler_saved_inputs.schedule import DropInput

        try:
            _check_release_schedule(release_schedule, records)
        except MetadataDeclined as error:
            raise UnsupportedCapture(str(error)) from error
        allocation_indices = {layout.source: index for index, layout in enumerate(allocations)}
        steps = []
        for step in release_schedule.steps:
            if type(step) is OwnedBuffer:
                steps.append(("allocate", allocation_indices[step.source]))
            elif type(step) is KernelCallRecord:
                steps.append(("kernel", step.occurrence))
            elif type(step) is DropInput:
                steps.append(("drop", step.input_index))
        release_steps = tuple(steps)
    if len(set(records.input_names)) != len(records.input_names):
        raise UnsupportedCapture("Compiler input names must be unique")
    copies = bind_alignment_copies(records)
    if copies is None:
        raise UnsupportedCapture("Boxed replay requires supported recorded alignment copies")
    numeric = _NumericProgram(records, example_inputs) if records.version == 4 else None
    calls = []
    for index, (record, selected) in enumerate(zip(records.calls, selected_launchers)):
        if record.occurrence != index or type(selected) is not FunctionType:
            raise UnsupportedCapture("Expected the selected generated static launcher occurrence")
        runner = selected.__globals__.get("runner")
        module = runner.__self__ if type(runner) is MethodType else None
        if type(module) is not StaticallyLaunchedCudaKernel:
            raise UnsupportedCapture("Expected the selected static module owner")
        bound = bind_wrapper_arguments(record, getattr(selected, "_cudagraph_arg_info", None))
        if bound is None:
            raise UnsupportedCapture("Selected launcher does not preserve compiler argument correspondence")
        grid = None
        if record.grid_type == "FixedGrid":
            grid = bind_fixed_grid(record)
            if (grid is None or records.version not in (3, 4)
                    or records.version == 3 and any(type(value) is not int for value in record.launcher_grid)):
                raise UnsupportedCapture("User FixedGrid capture requires exact compiler grid expressions")
        elif numeric is not None:
            grid = bind_grid_recipe(record, selected._cudagraph_arg_info,
                                    getattr(selected, "_cudagraph_grid_recipe", None))
            if grid is None:
                raise UnsupportedCapture("Selected launcher has no exact compiler grid recipe")
        calls.append(_BoundCall(bound, module, grid))
    return _make_replay(
        graph, len(records.input_names), allocations, output_indices, copies, tuple(calls),
        launches, buffer_owners, stream, numeric=numeric,
        copy_if_misaligned=copy_if_misaligned, resources=resources, release_steps=release_steps,
    )


def _make_replay(
    graph: torch.cuda.CUDAGraph,
    input_count: int,
    allocations: tuple[OwnedBuffer, ...],
    output_indices: tuple[int, ...] | None,
    copies: tuple[int, ...],
    calls: tuple[_BoundCall | _PhysicalCall, ...],
    launches: tuple[RecordedKernelLaunch, ...],
    buffer_owners: dict[BufferSource, torch.Tensor],
    stream: torch.cuda.Stream,
    *,
    numeric: _NumericProgram | None,
    copy_if_misaligned: Any = None,
    resources: tuple[object, ...] = (),
    release_steps: tuple[tuple[str, int], ...] | None = None,
) -> Any:
    if (not calls or len(launches) != len(calls) or type(resources) is not tuple
            or type(buffer_owners) is not dict):
        raise UnsupportedCapture("Replay requires complete bound calls and captured buffer owners")
    if copies and copy_if_misaligned is None:
        raise UnsupportedCapture("Recorded alignment copies require their native operation")
    if release_steps is not None and (numeric is not None or output_indices is None):
        raise UnsupportedCapture("Saved-input release requires static eager-pool allocations")
    buffer_indices = {layout.source: input_count + index for index, layout in enumerate(allocations)}
    layouts = []
    for layout in allocations:
        dimensions = (layout.size, layout.stride)
        if numeric is not None:
            dimensions = tuple(tuple(("value", numeric.add(value)) if type(value) is IntExpr else value
                                     for value in values) for values in dimensions)
        layouts.append((layout.dtype, *dimensions))
    layouts = tuple(layouts)
    nodes = tuple(launch.after[3][0][0] for launch in launches if len(launch.after[3]) == 1)
    associated = associate_kernel_launches(launches, graph._inspect_captured_kernel_nodes(nodes))
    bindings, scalar_bindings, grid_bindings = [], [], []
    used_inputs, used_buffers = set(), set()
    modules = {}
    for index, (call, launch, captured) in enumerate(zip(calls, launches, associated)):
        if type(call) not in (_BoundCall, _PhysicalCall) or captured.occurrence != index:
            raise UnsupportedCapture("Bound and captured launch occurrences must agree")
        module = call.module
        if type(call) is _PhysicalCall:
            pointers, scalars, inputs, buffers = _bind_physical_call(
                call, launch, captured, input_count, buffer_owners, buffer_indices, numeric,
            )
            bindings.extend(pointers)
            scalar_bindings.extend(scalars)
            used_inputs.update(inputs)
            used_buffers.update(buffers)
        else:
            if type(module) is not StaticallyLaunchedCudaKernel or module.function != launch.function:
                raise UnsupportedCapture("Captured function does not match its selected module owner")
            bound = call.arguments
            scratch = []
            for present, size in ((module.has_global_scratch, module.global_scratch_size),
                                  (module.has_profile_scratch, module.profile_scratch_size)):
                if present:
                    if size != 0:
                        raise UnsupportedCapture("Nonempty launcher scratch requires a separate ownership contract")
                    scratch.append(bytes(struct.calcsize("P")))
            if len(launch.argument_bytes) != len(bound) + len(scratch):
                raise UnsupportedCapture("Bound arguments must cover the complete captured ABI")
            if launch.argument_bytes[len(bound):] != tuple(scratch):
                raise UnsupportedCapture("Launcher scratch fields differ from the selected constants")
            for slot, argument in enumerate(bound):
                source = argument.source
                actual = launch.argument_bytes[slot]
                if type(source) is InputSource:
                    if type(source.index) is not int or not 0 <= source.index < input_count:
                        raise UnsupportedCapture("Input index is out of range")
                    used_inputs.add(source.index)
                    pointer_index = source.index
                elif type(source) is BufferSource:
                    tensor = buffer_owners.get(source)
                    if type(tensor) is not torch.Tensor:
                        raise UnsupportedCapture("Missing a captured buffer owner")
                    if struct.pack("P", tensor.data_ptr()) != actual:
                        raise UnsupportedCapture("Captured buffer bytes differ from their recorded source")
                    used_buffers.add(source)
                    pointer_index = buffer_indices.get(source)
                elif type(source) is IntegerSource:
                    if struct.pack({"i32": "i", "i64": "q"}[argument.triton_type], source.value) != actual:
                        raise UnsupportedCapture("Captured integer differs from its literal")
                    continue
                elif type(source) is ExpressionSource and numeric is not None:
                    value_index = numeric.add(source.expression)
                    value = numeric.values[value_index]
                    width = {"i32": 4, "i64": 8}[argument.triton_type]
                    if not -(2 ** (width * 8 - 1)) <= value < 2 ** (width * 8 - 1):
                        raise UnsupportedCapture("Integer exceeds its selected scalar type")
                    if struct.pack("i" if width == 4 else "q", value) != actual:
                        raise UnsupportedCapture("Captured integer differs from its symbolic expression")
                    scalar_bindings.append((captured.snapshot[0], slot, width, value_index))
                    continue
                else:
                    raise UnsupportedCapture("Unknown bound argument source")
                if len(actual) != struct.calcsize("P"):
                    raise UnsupportedCapture("A bound pointer does not have the native pointer width")
                if pointer_index is not None:
                    bindings.append((captured.snapshot[0], slot, pointer_index))
        if numeric is not None:
            if call.grid is None or len(call.grid) != 3:
                raise UnsupportedCapture("Bound call has no explicit three-axis grid")
            grid_indices = tuple(numeric.add(expression) for expression in call.grid)
            expected = tuple(numeric.values[index] for index in grid_indices)
            if expected != captured.snapshot[4] or any(not 0 < value < 2 ** 31 for value in expected):
                raise UnsupportedCapture("Captured grid differs from its symbolic recipe or supported domain")
            grid_bindings.append((captured.snapshot[0], *grid_indices))
        elif call.grid is not None:
            if (len(call.grid) != 3 or any(type(value) is not IntExpr or value.op != "constant"
                    or type(value.value) is not int or value.args or not 0 < value.value < 2 ** 31
                    for value in call.grid) or tuple(value.value for value in call.grid) != captured.snapshot[4]):
                raise UnsupportedCapture("Captured grid differs from the recorded literal grid")
        modules[id(module)] = module
    if (set(buffer_owners) != used_buffers or not set(buffer_indices).issubset(used_buffers)
            or (output_indices is not None and set(buffer_indices) != used_buffers)):
        raise UnsupportedCapture("Captured owners must cover all bound buffers and returned outputs")
    if numeric is None:
        batch = graph._prepare_kernel_pointer_updates(tuple(bindings), input_count + len(layouts))
    else:
        batch = graph._prepare_kernel_replay_updates(
            tuple(bindings), input_count + len(layouts), tuple(scalar_bindings),
            tuple(grid_bindings), len(numeric.instructions),
        )
    borrows = tuple(module._borrow_for_cudagraph() for module in modules.values())
    retained_buffers = buffer_owners.values() if output_indices is None else ()
    retained = (*borrows, *retained_buffers, *resources)
    prologue = (tuple(copies), copy_if_misaligned) if copies else None
    arguments = (batch, stream, retained, input_count, tuple(sorted(used_inputs)), layouts, prologue)
    if release_steps is not None:
        release_plan = (release_steps, tuple(captured.snapshot[0] for captured in associated))
        return graph._make_boxed_replay(*arguments, output_indices, None, release_plan)
    if output_indices is None:
        return graph._make_boxed_replay(*arguments)
    if numeric is not None:
        return graph._make_boxed_replay(
            *arguments, output_indices, (numeric.integer_indices, tuple(numeric.instructions)),
        )
    return graph._make_boxed_replay(*arguments, output_indices)
