# Native release with dynamic allocation sizes

Qualification3 passed **211 CPU and 23 CUDA tests** on the new native build,
accepted by root and independent audits. The build completed in 101.85 seconds;
the warm source tree and both previous installations were preserved.

The new direct CUDA controls use one native owner across sizes 128, 257, 65,
512 and 33. Kernel scalar/grid updates and output allocation sizes change on
replay. Matching saved-storage byte sizes permit reuse of its address by a later
output; doubled backing sizes correctly prevent that claim. Numerical results
and held outputs remain correct after close. Integer drops, premature Tensor
drops and reversed node order are rejected before replay, followed by a valid
257-element replay on the unchanged graph.

The compiler preserves its actual symbolic layouts, strides and scalar
expressions in the saved-input schedule. CPU controls cover both readers and
the combined numeric/release native-constructor arguments. The previous 18 GPU
cases, including static release through both readers and dynamic Triton/CuTe
integration without release, pass on the new binary.

This does not yet qualify dynamic generated backward release. Its physical
return tuple includes literal None gradients for shape arguments; the current
owned-output contract rejects those slots. `output_slots/` is the separate
implementation for preserving that exact tuple through compiler, readers and
native construction. The nine strict dynamic backward probes remain unqualified.

Evidence: `qualification3/evidence_review.json`,
`qualification3/evidence_independent_review.json`, and
`evidence/build_independent_review.json`. The preceding CPU qualification retains
one obsolete V4-exclusion test failure and its fixture-only version-5 correction.
No new performance or peak-memory claim is made.
