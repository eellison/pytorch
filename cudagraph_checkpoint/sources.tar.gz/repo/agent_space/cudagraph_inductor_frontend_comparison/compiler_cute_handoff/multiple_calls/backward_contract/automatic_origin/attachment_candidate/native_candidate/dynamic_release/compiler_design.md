# Compiler-owned V4 saved-input release

Read-only plan against the frozen `frontend_release` (FR) Python overlays and
the current `compiler_saved_inputs` package. No implementation, framework
execution, native change, or dynamic release qualification accompanies this note.

Keep the existing `ReleaseSchedule` schema and optional
`GeneratedMetadata.release_schedule`. `OwnedBuffer` and `KernelCallRecord`
already carry `IntExpr`; `DropInput` describes a boxed Tensor reference and a
position in the operation sequence, independent of its runtime size. There is
no need for a second schedule, warm-shape specialization, or new origin API.

## Minimal compiler changes

| Source | Current gate | Proposed change |
| --- | --- | --- |
| `compiler_saved_inputs.transport.collect_optional_schedule` | Requires records version 3. | Accept genuine versions 3 and 4. Preserve every existing cache, compilation-mode, configuration and callback-lifetime gate. |
| `compiler_saved_inputs.schedule.collect_release_schedule` | Requires V3; treats every input as `InputBuffer`; reconstructs allocations/calls without a symbol map. | Preserve integer slots in the full box, exclude them from reference drops, and reconstruct from the collector's actual compiler symbols. |
| FR `compiler_metadata_handoff.metadata._check_release_schedule` | Requires V3. | Validate V4 records using existing allocation/alignment binders and reject integer-slot drops explicitly; preserve all operation, use and ordering checks. |
| FR `cudagraph_prepare_from_warmed` shared projection | Already accepts V3/V4 readers; release validation currently rejects V4. | Reuse the existing projection after the validator extension. No new expression substitution, schedule discovery or reader-specific release path. |

`collect_saved_inputs` already joins unchanged AOT placeholder identities,
names and targets to the final wrapper box. It checks candidate positions
against `metadata.inputs.kinds == "tensor"`. Keep that check and its data-only
`FinalSavedInputs` result. Compact origins already cover dynamic AOT callbacks;
neither origin capture nor classification needs a new release-specific mode.

## Exact symbolic reconstruction

Keep the initial `wrapper.collect_cudagraph_call_records() == records` source
check. For each declared `IntegerInput`, use its original boxed index to obtain
the actual value from `wrapper.get_graph_inputs()`. Require the original
`sympy.Symbol`, matching recorded symbol name, and its compiler-simplified
symbol. Reconstruct the same mapping as
`PythonWrapperCodegen.collect_cudagraph_call_records`: original and simplified
symbol map to `IntExpr("boxed", index)`, with distinct positive declared
origins. Do not derive an index from a rendered expression, current Tensor
shape, or example value. Reject undeclared symbolic inputs or a mismatch with
the original ordered `integer_inputs` tuple.

For Tensor inputs retain the exact `InputBuffer` identity checks. Integer
positions remain in `input_names` and `input_uses` at their original ordinals,
but have no Tensor node/source entry. Their pointer-use rows are empty. Reject
any candidate in the integer-index set before walking frees; a scalar is never
converted into a dummy Tensor candidate or removed from the box description.

Pass that map to both `_cudagraph_owned_buffer(node, device, symbols)` and
`_cudagraph_call_record(line, occurrence, sources, symbols)`. These existing
helpers apply compiler simplification/precomputed-symbol substitution and
produce the supported `IntExpr` recipe. Require exact equality with the
corresponding original layout/call, then retain those original records in the
schedule. In particular, preserve symbolic strides, scalar expressions and
expression operand order; neither evaluating a warm hint nor comparing its
numeric result establishes correspondence.

The live walk continues to supply allocation, normalization, call and free
positions. Preserve read-only generated input provenance, first-use copies,
exact FreeLine/FreeIfNotReusedLine ownership, candidate-only drops after last
use, output order and complete allocation/call coverage. Keep reuse and user
kernel calls outside this schedule collector's scope. Other symbolic wrapper
lines are not new lifetime instructions: the original collector must already
accept them before the schedule walk can succeed.

## Metadata and frontend authority

Before interpreting V4 use rows, use the existing `bind_wrapper_allocations`
and `bind_alignment_copies` checks. They validate the supported integer-origin
set, allocation recipes, scalar-expression coverage and Tensor pointer slots;
the metadata input contract separately joins declared integers to boxed kinds.
Then exclude declared integer indices from every `DropInput` in
`_check_release_schedule`. This explicit check matters: an integer normally has
an empty pointer-use row, so `DropInput(integer_index, -1)` would otherwise pass
last-use arithmetic. Normalization must likewise retain its existing
Tensor-only binding. No native storage operation may receive such a slot.

Keep emitted/reconstructed retained records exactly equal to their source
records and leave the release schedule data-only. V4 remains version 4; a
constant-valued example does not justify V3. No schema/version relabel is
needed for either reader or the retained tuple transport.

FR already requires the passed schedule to be the original checked metadata
attachment's schedule object. `_bind_frontend_records` checks the original
selected call, ordered boxed integer indices, operands, injective buffer map,
allocation expressions and ordered outputs. `_project_release_schedule`
compares the full Allocate/Normalize/Invoke sequence, including bound grids,
against the original schedule with only drops omitted. It keeps original
`DropInput` objects, use rows and their exact positions, renaming only owned
buffers. These checks work on `IntExpr` values without evaluating them. Keep
original callable/attachment/selection checks around the reader, reject
release-time Reinterpret, and retain FX's additional-guard/narrowed-domain
rejections. Reader object expiry and recomputed use lists are never AOT release
authority.

## Focused evidence

- Add a genuine live V4 typed-wrapper fixture using an actual positive compiler
  symbol, the real record collector, two generated calls and an early saved
  Tensor free before a later allocation. Put the integer slot between Tensor
  slots in one variant. Check full boxed positions, symbolic size/stride/scalar
  trees, copy order and exact drop position. Do not obtain this positive by
  replacing a V3 record's version. Reuse the static `schedule_fixture` structure
  and current dynamic metadata/reader fixtures where their scope is sufficient.
- Check integer candidate/drop rejection (including the empty-use `-1` case),
  undeclared or swapped symbol origin, constant substitution for a boxed
  expression, changed stride expression, and source records differing from
  the actual wrapper. Preserve ordinary Tensor candidates and external-owner
  exclusions. Confirm expected unsupported facts return no schedule while an
  unexpected collector exception still propagates.
- Round-trip V4 metadata and its retained payload, preserving exact original
  expressions and no compiler/Tensor owners. Use the existing FR shared
  projection negatives for operand/buffer/output and event-order drift; add a
  symbolic positive through each reader and keep original-schedule replacement
  rejection. Reuse existing FX guard/domain controls instead of widening them.
- For actual compiler evidence, adapt the existing public MUST_SAVE workload
  with a dynamic pointwise extent and same-shaped differentiable weight. Observe
  the actual final V4 records, classification and schedule through the existing
  cold hook. Require an emitted early drop and ordinary forward/gradient
  numerics; allow a conservative admission failure to remain visible. The
  current dynamic collector requires literal reduction extents, so a broadcast
  weight-gradient reduction is not an assumed positive.

## Separate native stage

This compiler/reader stage can be qualified without enabling numeric release.
`cudagraph_boxed_replay._make_replay` still rejects `release_steps` with a numeric
program before the native constructor, and native numeric pending-input plumbing
remains a separate change described in `../next_frontend_release.md`. Merely
widening metadata validation does not authorize lifting that gate. Existing
preparation may perform cold capture before reaching it; do not report this
stage as native-ready or infer that no capture occurred.

Keep the fresh, cache-disabled, unpartitioned scope; expected cold declines
return the completed ordinary result once, and unexpected failures propagate.
No validation is added to native hits. Dynamic allocation byte evaluation,
overflow-before-destructive-work checks, claim/enqueue/abort behavior, retained
external owners and actual reuse require the later native qualification. There
is no memory or performance claim from metadata collection alone.
