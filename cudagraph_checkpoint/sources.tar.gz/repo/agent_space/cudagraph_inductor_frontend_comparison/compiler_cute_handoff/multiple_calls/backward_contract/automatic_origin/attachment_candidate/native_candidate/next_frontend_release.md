# Extending the existing release contract

Source assessment against NC/qualification3 (`manifest.json` SHA
`6c3ea0910999133a169fd58cbd0777d64a2f567a36a7a3915addf6693c8de6bc`).
No implementation or execution accompanies this note.

Keep one optional `GeneratedMetadata.release_schedule`. Its authority remains
the paired AOT classification joined to the original backward boxed positions,
then the exact final wrapper IR. Neither reader should discover saved inputs or
invent release positions. The native `(steps, nodes)` release plan can remain
separate from the existing numeric recipe; release eligibility is about call
order, while allocation bytes depend on the current invocation.

## Current boundaries

| Boundary | Selected implementation | Current restriction |
| --- | --- | --- |
| Compiler transport | `compiler_saved_inputs.transport.collect_optional_schedule` | V3 only; existing fresh, cache-disabled, unpartitioned scope gates remain. |
| Live schedule | `compiler_saved_inputs.schedule.collect_release_schedule` | V3; treats every boxed input as an `InputBuffer`; reconstructs layouts without a symbol map. |
| Metadata | `compiler_metadata_handoff.metadata._check_metadata`, `_check_release_schedule`, `collect_metadata` | Release is V3 only. V3 prohibits retained payloads; retention runs only for V4. |
| Reader selection | `cudagraph_prepare_from_warmed._project_frontend_records` | FX/retained require V4. `prepare_from_warmed` rejects a release schedule with either route. |
| Reader construction | `fx_adapter.lowering._lower_fx`; `retained_ir.prototype.retain_wrapper/validate` | FX constructs V4 records; retained requires V4. |
| Native release | `cudagraph_boxed_replay._make_replay`; `PythonGraphReplayOwner`; `GraphReplayLease::prepare_input_release` | Each rejects numeric release. Numeric replay has no pending-input argument. |

These are separate gates. Removing the frontend check alone would neither admit
the qualified static fixture nor make dynamic release safe.

## First stage: genuine V3 through both readers

Thread the checked original record version into reader construction. Construct
and validate literal V3 records for a V3 source; preserve existing V4 behavior.
Do not construct V4 and replace its version afterward. Retained collection and
validation can accept genuine V3 with an empty integer-origin map, and metadata
can retain/reconstruct that payload under the same exact-record equality check.
The existing tuple transport already carries the record version.

Use one cold schedule projection beside `_bind_frontend_records`, shared by FX
and retained. That function already establishes original selected-call identity,
call ordinals, unchanged `InputSource` indices, integer-slot correspondence,
alignment copies, and an injective original-to-reader buffer map. Expose that
checked map instead of independently reconstructing it for release.

There is one additional ordering obligation: `_bind_frontend_records` currently
compares allocation and call lists separately and then discards
`HostProgram.events`. For release, compare the reader's complete
Allocate/Normalize/Invoke sequence with the original schedule after removing
only `DropInput`, using the same buffer map. Preserve output order and layouts.
Initially decline `Reinterpret` for release; existing non-release reader support
need not change. An allocation moved across a call must fail this join even if
both individual lists still match.

Then project the original schedule: rename owned buffers, use the corresponding
checked reader calls, preserve boxed input indices and original drop positions,
and validate against the projected records. Reader input names such as `boxed_3`
are labels, not a second AOT association. `_check_frontend_source` still checks
the exact original callable/attachment/selected globals around cold preparation.
The same native static release constructor can consume the result.
Keep the existing cold policy semantics: expected unsupported correspondence
returns the completed ordinary result once; unexpected errors propagate.

FX events retain fake operands and do not record Python `del`; retained host
events also omit frees. This is acceptable only because drops come from the
original live-IR schedule and all other events are independently matched. Do
not infer drops from fake-object expiry or recompute candidate use lists as new
authority. Also check real backward boxes containing exact `Parameter` objects:
the generated FX entry currently accepts only exact `Tensor`, while the mixed
compiler-bound entry allows `Parameter`. Any needed allowance should be tied to
the checked original compiler binding and keep arbitrary subclasses excluded.

This stage needs Python/reader changes and static FX/retained release-on/off and
retain-graph controls, but no native change. Negative controls should move an
allocation across a call, swap boxed sources, alter a drop/output, and change the
original attachment. No extra checks belong on native hits.

## Second stage: compiler-owned V4 schedule metadata

Compact AOT origins already preserve symbol/scalar boxed positions, and
`collect_saved_inputs` requires candidates to be Tensor positions. Keep that
join. Extend the schedule walk to retain the full box while skipping declared
integer inputs as allocation/free candidates. Build its symbol map from the
same actual compiler inputs and simplifications used by
`collect_cudagraph_call_records`; pass that map to layout and call reconstruction.
Compare resulting `IntExpr` trees to the original V4 records. Never substitute
warm values or infer a formula from multiple examples.

Permit V4 in the optional collector and schedule validator, explicitly reject
drops of integer positions, and retain the same source-use, allocation, output,
read-only input, normalization-first-use, and no-reuse checks. Both readers can
then use the shared cold projection above. FX must continue rejecting narrowed
inherited domains or extra local guards. V4 metadata/reader controls can be
qualified independently while the native numeric-release gate still declines.

## Third stage: native numeric release

The existing numeric call path already evaluates boxed expressions, validates
ABI/grid bounds, and computes checked current layout byte sizes before clearing
inputs or doing normalization. Preserve that ordering. The allocation lambda
already uses invocation-specific layouts in numeric mode; any claim must use
those current byte sizes and the existing alignment/capacity/deleter checks,
never captured buffer sizes.

The cold native proof can share its actual-node/full-completion-chain and
pointer-slot use analysis with numeric batches: scalar/grid updates must not
change node or pointer-source correspondence. Keep complete binding and exact
node checks, and add a cold check that every dropped index is a Tensor slot in
the boxed numeric plan. An unused integer slot must not reach Tensor storage
handling merely because its pointer-use list is empty.

Plumbing is required through the numeric overloads of `GraphReplayLease::replay`
and `CUDAGraph::replay_kernel_updates_impl` to `replay_impl(pending)`. Today the
numeric branch calls `lease_->replay(pointers_, values)` without pending state.
Simply lifting the three static guards would bypass the released-block enqueue
and completion protocol. Preserve the existing ownership lock, checked value
evaluation, pending commit/abort/quarantine, partial-update failure handling,
and retained external-owner behavior; no retry or new allocator policy is needed.

Qualify dynamic records release first, then both readers against identical V4
source correspondence. Exercise changing positive extents, allocation sizes,
release-off/retain-graph, misalignment, numeric overflow before destructive work,
and enqueue failure. Use the actual emitted graph as the admission test: the
current V4 collector limits dynamic reductions to literal reduction extents,
so a broadcast-weight backward is not automatically supported. A pointwise
variant with a same-shaped differentiable weight input is a smaller candidate
than expanding reduction or partition support.

Partitioning, general CUDA registration, buffer reuse/alias planning, cache
transport, and memory-benefit claims remain outside these stages.
