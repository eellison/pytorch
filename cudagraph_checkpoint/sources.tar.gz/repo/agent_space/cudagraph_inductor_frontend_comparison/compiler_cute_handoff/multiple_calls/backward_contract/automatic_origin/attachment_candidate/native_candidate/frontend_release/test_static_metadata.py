from contextlib import contextmanager
from copy import copy
from dataclasses import replace
import os
from tempfile import TemporaryDirectory
from unittest import mock

import torch
from compiler_input_contract.collector import CompilerInputDeclined
from compiler_metadata_handoff.metadata import (
    collect_metadata, emit_metadata, GeneratedMetadata, MetadataDeclined, read_metadata,
)
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from fx_adapter.contract import InputContract, IntegerRange, TensorInput
from retained_ir.prototype import reconstruct_ir, RetentionDeclined
from torch._inductor.codegen.wrapper import PythonWrapperCodegen
from torch._inductor.codecache import PyCodeCache
from torch._inductor.output_code import CompiledFxGraph, CompiledFxGraphConstants
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, CallArgument, ExpressionSource, InputSource, IntegerInput,
    IntegerSource, IntExpr, KernelCallRecord, OwnedBuffer, WrapperCallRecords,
)
from torch._inductor.utils import IndentedBuffer
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def literal_fixture():
    inputs = InputContract(("tensor", "tensor"), (
        TensorInput(0, torch.float32, (2, 3), (3, 1)),
        TensorInput(1, torch.float32, (2, 3), (3, 1)),
    ), ())
    output = OwnedBuffer(BufferSource("out"), torch.float32, (2, 3), (3, 1))
    call = KernelCallRecord(0, "kernel", ("left", "right", "dst", "xnumel"), (
        CallArgument("left", 0, 0, "*fp32", InputSource(0)),
        CallArgument("right", 1, 1, "*fp32", InputSource(1)),
        CallArgument("dst", 2, 2, "*fp32", output.source),
        CallArgument("xnumel", 3, 3, "i32", IntegerSource(6)),
    ), "Grid1D")
    records = WrapperCallRecords(3, 0, ("left", "right"), (call,), (), (output,), (output,))
    return records, GeneratedMetadata(1, inputs, None)


def module_source(records, metadata):
    result = IndentedBuffer()
    # This CPU body checks metadata transport and box ownership, not kernel semantics.
    result.writeline("def call(args):")
    with result.indent():
        result.writeline("calls.append(args)")
        result.writeline("left, right = args")
        result.writeline("args.clear()")
        result.writeline("result = (bias,)")
        result.writeline("outcomes.append(result)")
        result.writeline("return result")
    wrapper = PythonWrapperCodegen.__new__(PythonWrapperCodegen)
    wrapper.launcher_fn_name = "call"
    wrapper.codegen_cudagraph_call_records(result, records)
    emit_metadata(result, "call", metadata)
    return result.getvalue()


def output_fixture(function):
    artifact = CompiledFxGraph.__new__(CompiledFxGraph)
    artifact.current_callable = function
    artifact._cudagraph_original_callable = function
    artifact.compiled_fn_runner = None
    artifact._original_gm = None
    artifact.constants = {}
    artifact.opaque_value_type_classes = {}
    artifact.fx_kwargs = {"static_input_idxs": ()}
    return artifact


def load_source(records, metadata):
    namespace = {"calls": [], "outcomes": [], "bias": object()}
    exec(module_source(records, metadata), namespace)
    return output_fixture(namespace["call"]), namespace


@contextmanager
def isolated_code_cache():
    with TemporaryDirectory() as directory, mock.patch.dict(os.environ, {"TORCHINDUCTOR_CACHE_DIR": directory}), \
            mock.patch.object(PyCodeCache, "modules", []), \
            mock.patch.object(PyCodeCache, "modules_no_attr", {}), \
            mock.patch.object(PyCodeCache, "linemaps", {}):
        yield


class PreparedEntry:
    _boxed_call = True

    def __init__(self):
        self.close_calls = 0

    def __call__(self, box):
        raise AssertionError("The cold policy must return its ordinary result")

    def close(self):
        self.close_calls += 1


class TestStaticMetadata(TestCase):
    def test_collects_complete_v3_without_retention(self):
        records, expected = literal_fixture()
        wrapper = object()
        with mock.patch("compiler_input_contract.collector.compiler_inputs", return_value=expected.inputs) as collect, \
                mock.patch("retained_ir.prototype.retain_wrapper",
                           side_effect=RetentionDeclined("unsupported retained wrapper")) as retain, \
                mock.patch("retained_ir.prototype.export_ir") as export:
            actual = collect_metadata(wrapper, records)
        collect.assert_called_once_with(wrapper)
        self.assertIs(actual.inputs, expected.inputs)
        self.assertEqual(actual, expected)
        self.assertIsNone(actual.retained_ir)
        retain.assert_called_once_with(wrapper, records)
        export.assert_not_called()
        artifact, namespace = load_source(records, actual)
        function, restored = read_metadata(artifact)
        self.assertIs(function, namespace["call"])
        self.assertEqual(restored, expected)
        self.assertEqual(function._cudagraph_call_records, records)
        self.assertEqual(restored.inputs.integer_ranges, ())

    def test_typed_input_decline_omits_optional_metadata(self):
        records, _metadata = literal_fixture()
        with mock.patch("compiler_input_contract.collector.compiler_inputs",
                        side_effect=CompilerInputDeclined("unsupported compiler input")) as collect, \
                mock.patch("retained_ir.prototype.retain_wrapper") as retain:
            metadata = collect_metadata(object(), records)
        self.assertIsNone(metadata)
        collect.assert_called_once()
        retain.assert_not_called()
        artifact, namespace = load_source(records, metadata)
        box = [object(), object()]
        result = artifact.current_callable(box)
        self.assertEqual(box, [])
        self.assertIs(result, namespace["outcomes"][0])
        with self.assertRaises(MetadataDeclined):
            read_metadata(artifact)

    def test_unexpected_input_error_is_not_a_decline(self):
        records, _metadata = literal_fixture()
        error = ValueError("unexpected compiler input failure")
        with mock.patch("compiler_input_contract.collector.compiler_inputs", side_effect=error), \
                self.assertRaises(ValueError) as caught:
            collect_metadata(object(), records)
        self.assertIs(caught.exception, error)

    @parametrize("fault", (
        "symbolic_size", "symbolic_stride", "integer_inputs", "missing_allocations",
        "empty_allocations", "missing_outputs", "empty_outputs", "unknown_output",
        "duplicate_output", "unused_allocation", "missing_calls", "empty_calls",
        "missing_arguments", "symbolic_scalar", "nonliteral_scalar", "unknown_source", "late_copy",
    ))
    def test_malformed_v3_records_decline_before_collection(self, fault):
        records, metadata = literal_fixture()
        output, = records.outputs
        call, = records.calls
        if fault == "symbolic_size":
            output = replace(output, size=(IntExpr("constant", 2), 3))
            records = replace(records, allocations=(output,), outputs=(output,))
        elif fault == "symbolic_stride":
            output = replace(output, stride=(IntExpr("boxed", 0), 1))
            records = replace(records, allocations=(output,), outputs=(output,))
        elif fault == "integer_inputs":
            records = replace(records, integer_inputs=(IntegerInput("rows", 0),))
        elif fault == "missing_allocations":
            records = replace(records, allocations=None)
        elif fault == "empty_allocations":
            records = replace(records, allocations=())
        elif fault == "missing_outputs":
            records = replace(records, outputs=None)
        elif fault == "empty_outputs":
            records = replace(records, outputs=())
        elif fault == "unknown_output":
            records = replace(records, outputs=(replace(output, source=BufferSource("other")),))
        elif fault == "duplicate_output":
            records = replace(records, outputs=(output, output))
        elif fault == "unused_allocation":
            records = replace(records, allocations=(output, replace(output, source=BufferSource("unused"))))
        elif fault == "missing_calls":
            records = replace(records, calls=None)
        elif fault == "empty_calls":
            records = replace(records, calls=())
        elif fault == "missing_arguments":
            records = replace(records, calls=(replace(call, arguments=None),))
        elif fault in ("symbolic_scalar", "nonliteral_scalar", "unknown_source"):
            source = {
                "symbolic_scalar": ExpressionSource(IntExpr("boxed", 0)),
                "nonliteral_scalar": IntegerSource(6.0),
                "unknown_source": IntExpr("constant", 6),
            }[fault]
            argument = replace(call.arguments[-1], source=source)
            records = replace(records, calls=(replace(call, arguments=(*call.arguments[:-1], argument)),))
        else:
            records = replace(records, alignment_copies=(AlignmentCopy(0, 1),))
        with mock.patch("compiler_input_contract.collector.compiler_inputs") as collect, \
                mock.patch("retained_ir.prototype.retain_wrapper") as retain:
            self.assertIsNone(collect_metadata(object(), records))
        collect.assert_not_called()
        retain.assert_not_called()
        artifact, namespace = load_source(records, metadata)
        box = [object(), object()]
        result = artifact.current_callable(box)
        self.assertEqual(box, [])
        self.assertIs(result, namespace["outcomes"][0])
        with self.assertRaises(MetadataDeclined):
            read_metadata(artifact)

    @parametrize("fault", ("boxed_size", "literal_expression", "integer_slot", "negative_size",
                           "negative_stride", "retained_payload"))
    def test_nonliteral_v3_input_or_retained_payload_declines(self, fault):
        records, metadata = literal_fixture()
        first, second = metadata.inputs.tensor_inputs
        if fault == "retained_payload":
            metadata = replace(metadata, retained_ir="{}")
        elif fault == "integer_slot":
            metadata = replace(metadata, inputs=InputContract(("integer", "tensor"),
                (second,), (IntegerRange(0, 1, 32),)))
        else:
            if fault == "boxed_size":
                first = replace(first, size=(IntExpr("boxed", 0), 3))
            elif fault == "literal_expression":
                first = replace(first, size=(IntExpr("constant", 2), 3))
            elif fault == "negative_size":
                first = replace(first, size=(-2, 3))
            else:
                first = replace(first, stride=(-3, 1))
            metadata = replace(metadata, inputs=replace(metadata.inputs, tensor_inputs=(first, second)))
        artifact, namespace = load_source(records, metadata)
        box = [object(), object()]
        result = artifact.current_callable(box)
        self.assertEqual(box, [])
        self.assertIs(result, namespace["outcomes"][0])
        with mock.patch("retained_ir.prototype.reconstruct_ir", wraps=reconstruct_ir) as decode, \
                self.assertRaises(MetadataDeclined):
            read_metadata(artifact)
        self.assertEqual(decode.call_count, int(fault == "retained_payload"))

    def test_existing_policy_publishes_v3_after_one_ordinary_call(self):
        records, metadata = literal_fixture()
        artifact, namespace = load_source(records, metadata)
        original = artifact.current_callable
        policy = NativeCUDAGraphPolicy()
        self.addCleanup(policy.close)
        self.assertIs(policy.wrap_output(artifact), artifact)
        handle, = policy.installations
        entry = PreparedEntry()
        left, right = object(), object()
        box = [left, right]

        def prepare(wrapper, inputs):
            self.assertIs(wrapper, original)
            self.assertIs(type(inputs), tuple)
            self.assertIs(inputs[0], left)
            self.assertIs(inputs[1], right)
            self.assertEqual(box, [])
            return entry

        with mock.patch.object(preparation, "prepare_from_warmed", side_effect=prepare) as prepared:
            result = artifact.current_callable(box)
        prepared.assert_called_once()
        self.assertEqual(len(namespace["calls"]), 1)
        self.assertIs(namespace["calls"][0], box)
        self.assertIs(result, namespace["outcomes"][0])
        self.assertIs(artifact.current_callable, entry)
        self.assertIsNone(handle.metadata.retained_ir)
        self.assertEqual(handle.status, "ready")
        handle.close()
        self.assertEqual(entry.close_calls, 1)
        self.assertIs(artifact.current_callable, original)

    def test_v3_metadata_does_not_admit_static_address_inputs(self):
        records, metadata = literal_fixture()
        artifact, _namespace = load_source(records, metadata)
        original, _metadata = read_metadata(artifact)
        artifact.fx_kwargs["static_input_idxs"] = (0,)
        policy = NativeCUDAGraphPolicy()
        self.addCleanup(policy.close)
        with mock.patch.object(preparation, "prepare_from_warmed") as prepared:
            self.assertIs(policy.wrap_output(artifact), artifact)
        self.assertEqual(policy.installations, ())
        self.assertIs(artifact.current_callable, original)
        prepared.assert_not_called()

    def test_v3_cache_identity_and_serialization_remain_exact(self):
        records, metadata = literal_fixture()
        with isolated_code_cache():
            source = module_source(records, metadata)
            key, path = PyCodeCache.write(source)
            first_attrs = {"calls": [], "outcomes": [], "bias": object()}
            second_attrs = {"calls": [], "outcomes": [], "bias": object()}
            first = PyCodeCache.load_by_key_path(key, path, attrs=first_attrs, set_sys_modules=False)
            second = PyCodeCache.load_by_key_path(key, path, attrs=second_attrs, set_sys_modules=False)
            artifact = output_fixture(first.call)
            other = output_fixture(second.call)
            self.assertEqual(read_metadata(artifact)[1], read_metadata(other)[1])
            self.assertIsNot(first.call, second.call)
            self.assertIsNot(first.call.__globals__, second.call.__globals__)
            self.assertIs(first.call([object(), object()])[0], first_attrs["bias"])
            self.assertIs(second.call([object(), object()])[0], second_attrs["bias"])
            artifact.current_callable = second.call
            with self.assertRaisesRegex(MetadataDeclined, "this artifact's original"):
                read_metadata(artifact)
            artifact.current_callable = first.call
            artifact.cache_key, artifact.source_code, artifact.cache_linemap = key, source, []
            artifact.constants = first_attrs
            restored = copy(artifact)
            restored.prepare_for_serialization()
            self.assertIsNone(restored.current_callable)
            self.assertIsNone(restored._cudagraph_original_callable)
            self.assertIs(artifact.current_callable, first.call)
            restored.after_deserialization(CompiledFxGraphConstants())
            function, actual = read_metadata(restored)
            self.assertIs(function, restored._cudagraph_original_callable)
            self.assertIsNot(function, first.call)
            self.assertEqual(actual, metadata)
            self.assertEqual(function._cudagraph_call_records.version, 3)
            self.assertEqual(actual.inputs.integer_ranges, ())
            self.assertIsNone(actual.retained_ir)


instantiate_parametrized_tests(TestStaticMetadata)


if __name__ == "__main__":
    run_tests()
