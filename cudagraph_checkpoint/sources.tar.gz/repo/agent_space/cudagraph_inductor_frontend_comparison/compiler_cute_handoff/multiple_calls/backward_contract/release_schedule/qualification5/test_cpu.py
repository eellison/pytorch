import conversion_signatures_fixture as conversion
import invocation_runtime_fixture as invocation
import compiler_call_cases_fixture as emission
import scalar_tuple_fixture
import provider_decline_fixture
import descriptor_order_fixture
import cold_decline_fixture
import numeric_domain_fixture
from torch.testing._internal.common_utils import run_tests


class TestCompilerConversion(conversion.TestCompilerConversion):
    pass


class TestConversionSignatures(conversion.TestConversionSignatures):
    pass


class TestCompilerInvocation(invocation.TestCompilerInvocation):
    pass


class TestCompilerCallEmission(emission.TestCompilerCallEmission):
    pass


class TestScalarTupleEffects(scalar_tuple_fixture.TestScalarTupleEffects):
    pass


class TestProviderDecline(provider_decline_fixture.TestProviderDecline):
    pass


class TestDescriptorOrdering(descriptor_order_fixture.TestDescriptorOrdering):
    pass


class TestColdDeclines(cold_decline_fixture.TestColdDeclines):
    pass


class TestGuardedCeilDivision(numeric_domain_fixture.TestGuardedCeilDivision):
    pass


class TestExistingNumeric(numeric_domain_fixture.TestExistingNumeric):
    pass


import multiple_frontend_fixture


class TestMultipleCuTeFrontend(multiple_frontend_fixture.TestMultipleCuTeFrontend):
    pass


import multiple_runtime_fixture


class TestMultipleCuTeRuntime(multiple_runtime_fixture.TestMultipleCuTeRuntime):
    pass


import compiler_proof_fixture


class TestCompilerProofCheck(compiler_proof_fixture.TestCompilerProofCheck):
    pass


import generated_provenance_fixture


class TestGeneratedProvenance(generated_provenance_fixture.TestGeneratedProvenance):
    pass


import shared_registration_fixture


class TestSharedSourceRegistration(shared_registration_fixture.TestSharedSourceRegistration):
    pass


import single_policy_fixture


class TestSingleCuTePolicy(single_policy_fixture.TestSingleCuTePolicy):
    pass


import activation_schedule_fixture
import static_metadata_regression_fixture
import parameter_handoff_regression_fixture


class TestActivationReleaseSchedule(activation_schedule_fixture.TestActivationReleaseSchedule):
    pass


class TestStaticMetadata(static_metadata_regression_fixture.TestStaticMetadata):
    pass


class TestParameterHandoff(parameter_handoff_regression_fixture.TestParameterHandoff):
    pass


if __name__ == "__main__":
    run_tests()
