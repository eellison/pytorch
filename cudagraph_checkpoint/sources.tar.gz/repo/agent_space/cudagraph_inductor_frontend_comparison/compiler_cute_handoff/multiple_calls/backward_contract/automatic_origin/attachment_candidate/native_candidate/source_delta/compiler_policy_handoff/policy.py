"""Cold policy handoff from an ordinary generated call to its native entry."""

from threading import Lock
from weakref import ref

from compiler_metadata_handoff.metadata import _attachment_matches, _check_attachment, MetadataDeclined, read_metadata
from torch._inductor.cudagraph_utils import CUDAGraphPolicy
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import bind_alignment_copies
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture


class HandoffInvalidated(RuntimeError):
    pass


def _check_static_input_coverage(inputs, indices, copies):
    if (type(indices) is not tuple or type(copies) is not tuple
            or any(type(index) is not int or not 0 <= index < len(inputs.kinds)
                   or inputs.kinds[index] != "tensor" or index not in copies for index in indices)
            or len(set(indices)) != len(indices)):
        raise MetadataDeclined("Static compiler inputs require recorded alignment normalization")


def _check_static_inputs(artifact, metadata, records):
    kwargs = getattr(artifact, "fx_kwargs", None)
    indices = kwargs.get("static_input_idxs") if type(kwargs) is dict else None
    if type(indices) not in (list, tuple):
        raise MetadataDeclined("Static compiler input indices are unavailable")
    if not indices:
        return
    snapshot = tuple(indices)
    copies = bind_alignment_copies(records)
    _check_static_input_coverage(metadata.inputs, snapshot, copies)
    if (artifact.fx_kwargs is not kwargs or kwargs.get("static_input_idxs") is not indices
            or len(indices) != len(snapshot)):
        raise MetadataDeclined("Static compiler input indices changed during validation")
    for index in range(len(snapshot)):
        if indices[index] is not snapshot[index]:
            raise MetadataDeclined("Static compiler input indices changed during validation")


class Installation:
    _boxed_call = True

    def __init__(self, artifact, original, metadata, frontend="records"):
        self._artifact = ref(artifact)
        self._original = ref(original)
        self._attachment = original.__dict__["_cudagraph_frontend_attachment"]
        self.metadata = metadata
        self._frontend = frontend
        self._lock = Lock()
        self._entry = None
        self._status = "armed"
        self._decline = None

    @property
    def artifact(self):
        return self._artifact()

    @property
    def original(self):
        return self._original()

    @property
    def entry(self):
        return self._entry

    @property
    def status(self):
        return self._status

    @property
    def decline(self):
        return self._decline

    def _check(self, expected):
        artifact, original = self.artifact, self.original
        result = (artifact, original)
        if (artifact is None or original is None or artifact.current_callable is not expected
                or artifact._cudagraph_original_callable is not original):
            raise HandoffInvalidated("Compiler policy lost its exact callable ownership")
        try:
            _check_static_inputs(artifact, self.metadata, self._attachment.records)
            metadata = _check_attachment(original, self._attachment)
            _check_static_inputs(artifact, self.metadata, self._attachment.records)
        except MetadataDeclined as error:
            raise HandoffInvalidated("Compiler policy source metadata changed") from error
        if metadata is not self.metadata or not _attachment_matches(original, self._attachment):
            raise HandoffInvalidated("Compiler policy metadata identity changed")
        if (self.artifact is not artifact or self.original is not original
                or artifact.current_callable is not expected
                or artifact._cudagraph_original_callable is not original):
            raise HandoffInvalidated("Compiler policy callable changed during validation")
        return result

    def __call__(self, box):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Compiler policy installation is busy")
        snapshot, result = None, None
        try:
            if self._status != "armed":
                raise RuntimeError("Compiler policy installation is not armed")
            self._check(self)
            if type(box) is not list:
                raise TypeError("Compiler policy requires an exact boxed list")
            snapshot = tuple(box)
            artifact, original = self._check(self)
            if len(box) != len(snapshot):
                raise HandoffInvalidated("Compiler policy box changed before ordinary execution")
            for index in range(len(snapshot)):
                if box[index] is not snapshot[index]:
                    raise HandoffInvalidated("Compiler policy box changed before ordinary execution")
            self._status = "warming"
            result = original(box)
            self._status = "preparing"
            self._check(self)
            try:
                options = {}
                if self.metadata.release_schedule is not None:
                    options["release_schedule"] = self.metadata.release_schedule
                if self._frontend != "records":
                    options["frontend"] = self._frontend
                entry = preparation.prepare_from_warmed(original, snapshot, **options)
            except UnsupportedCapture as error:
                self._decline = str(error)
                self._check(self)
                artifact.current_callable = original
                self._status = "declined"
                return result
            self._entry = entry
            try:
                self._check(self)
            except BaseException:
                self._status = "failed"
                entry.close()
                self._entry = None
                raise
            self._status = "publishing"
            if not preparation._publish_prepared(artifact, self, entry):
                self._entry = None
                raise HandoffInvalidated("Compiler policy callable changed during publication")
            self._status = "ready"
            return result
        except BaseException:
            if self._status in ("armed", "warming", "preparing", "publishing"):
                self._status = "failed"
            raise
        finally:
            snapshot, result = None, None
            self._lock.release()

    def close(self):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Compiler policy installation is busy")
        try:
            if self._status == "closed":
                return
            entry = self._entry
            if entry is not None:
                entry.close()
            artifact = self.artifact
            if artifact is not None and (artifact.current_callable is self
                                         or (entry is not None and artifact.current_callable is entry)):
                _, original = self._check(artifact.current_callable)
                artifact.current_callable = original
            self._entry = None
            self._status = "closed"
        except BaseException:
            self._status = "failed"
            raise
        finally:
            self._lock.release()


class NativeCUDAGraphPolicy(CUDAGraphPolicy):
    def __init__(self, *, frontend="records", cute=False):
        if type(frontend) is not str or frontend not in ("records", "fx", "retained"):
            raise ValueError("Unknown compiler frontend")
        if type(cute) is not bool:
            raise TypeError("Expected a boolean CuTe policy option")
        self._frontend = frontend
        self._cute = cute
        self._installations = []
        self._lock = Lock()
        self._closed = False

    @property
    def installations(self):
        return tuple(self._installations)

    def should_wrap(self, compiled_graph):
        return False

    def wrap_output(self, artifact):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Compiler policy is busy")
        try:
            if self._closed:
                raise RuntimeError("Compiler policy is closed")
            for installation in self._installations:
                if installation.artifact is artifact:
                    return artifact
            if self._cute:
                from compiler_cute_handoff.policy import arm_mixed

                if arm_mixed(self, artifact):
                    return artifact
            try:
                original, metadata = read_metadata(artifact)
                _check_static_inputs(artifact, metadata, original._cudagraph_call_records)
            except MetadataDeclined:
                return artifact
            installation = Installation(artifact, original, metadata, self._frontend)
            if not installation._lock.acquire(blocking=False):
                raise RuntimeError("New compiler policy installation is busy")
            try:
                self._installations.append(installation)
                try:
                    installation._check(original)
                except BaseException:
                    self._installations.pop()
                    raise
                artifact.current_callable = installation
            finally:
                installation._lock.release()
            return artifact
        finally:
            self._lock.release()

    def close(self):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Compiler policy is busy")
        try:
            for installation in self._installations:
                installation.close()
            self._closed = True
        finally:
            self._lock.release()
