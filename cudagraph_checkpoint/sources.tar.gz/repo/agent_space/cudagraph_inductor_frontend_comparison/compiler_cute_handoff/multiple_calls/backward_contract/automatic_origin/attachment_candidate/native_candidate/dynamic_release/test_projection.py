"""Real record/binding checks with synthetic reader events and GPU-owner stand-ins."""

from dataclasses import replace
from types import SimpleNamespace
from unittest import mock

from compiler_metadata_handoff.metadata import attach_metadata, GeneratedMetadata, MetadataDeclined
from compiler_saved_inputs.schedule import DropInput, ReleaseSchedule
from fx_adapter.contract import InputContract, TensorInput
from host_program import Allocate, HostProgram, Invoke, Normalize, Reinterpret
from selected_kernel import SelectedKernel
import torch
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, CallArgument, InputSource, IntExpr, KernelCallRecord,
    LauncherArgument, OwnedBuffer, WrapperCallRecords,
)
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


GRID = (IntExpr("constant", 1),) * 3


class TestReleaseProjection(TestCase):
    def setUp(self):
        super().setUp()
        # The GPU selection check is separate; bind_call and metadata checks stay real.
        self.enterContext(mock.patch.object(preparation._SelectedCall, "check", autospec=True))
        a, b = (OwnedBuffer(BufferSource(name), torch.float32, (8, 16), (16, 1)) for name in ("a", "b"))
        records = []
        selected = []
        for index, sources in enumerate(((InputSource(0), a.source), (a.source, InputSource(1), b.source))):
            names = ("src", "out") if index == 0 else ("src", "weight", "out")
            arguments = tuple(CallArgument(name, i, i, "*fp32", source)
                              for i, (name, source) in enumerate(zip(names, sources, strict=True)))
            record = KernelCallRecord(index, f"kernel{index}", names, arguments, "Grid1D")
            mapping = tuple(LauncherArgument(name, i, i, "*fp32", i, None) for i, name in enumerate(names))

            def launcher():
                raise AssertionError("CPU correspondence controls must not launch")

            launcher._cudagraph_arg_info = mapping
            kernel = SimpleNamespace(inductor_meta={
                "cudagraph_parameter_provenance": {name: (i, name == "out", 16) for i, name in enumerate(names)},
            })
            module = SimpleNamespace(arg_tys="O" * len(names))
            selected.append(preparation._SelectedCall(record, kernel, launcher, launcher, module, index + 1,
                                                      arguments, (), GRID))
            records.append(record)
        self.calls = tuple(selected)
        self.source = WrapperCallRecords(3, 0, ("saved", "weight"), tuple(records),
                                         (AlignmentCopy(0, 0), AlignmentCopy(1, 1)), (b, a), (a, b))
        self.schedule = ReleaseSchedule(self.source.input_names, ((0,), (1,)),
            (AlignmentCopy(0, 0), a, records[0], DropInput(0, 0), AlignmentCopy(1, 1), b, records[1]), (b, a))
        renamed = {a.source: BufferSource("buffer_0"), b.source: BufferSource("buffer_1")}
        allocations = tuple(replace(layout, source=renamed[layout.source]) for layout in self.source.allocations)
        calls = tuple(replace(record, arguments=tuple(
            replace(argument, source=renamed.get(argument.source, argument.source)) for argument in record.arguments
        )) for record in self.source.calls)
        projected = replace(self.source, input_names=("boxed_0", "boxed_1"), calls=calls,
                            allocations=allocations, outputs=tuple(reversed(allocations)))
        events = (Normalize(0, 0), Allocate("buffer_0", torch.float32, (8, 16), (16, 1)), Invoke(calls[0], GRID),
                  Normalize(1, 1), Allocate("buffer_1", torch.float32, (8, 16), (16, 1)), Invoke(calls[1], GRID))
        self.program = HostProgram(projected, events, ())
        self.projections = tuple(SelectedKernel.from_compiler_call(call) for call in self.calls)

    def project(self, program=None, schedule=None):
        program = self.program if program is None else program
        schedule = self.schedule if schedule is None else schedule
        adapted, renamed, grids = preparation._bind_frontend_records(
            self.source, self.calls, self.projections, program.records,
        )
        return preparation._project_release_schedule(self.source, program, renamed, grids, schedule), adapted

    def wrapper(self):
        scope = {call.record.kernel_global: call.kernel for call in self.calls}
        exec("def call(args):\n    raise AssertionError('CPU source checks must not execute the wrapper')\n", scope)
        wrapper = scope["call"]
        wrapper._cudagraph_call_records = self.source
        inputs = InputContract(("tensor", "tensor"), tuple(
            TensorInput(index, torch.float32, (8, 16), (16, 1)) for index in range(2)
        ), ())
        attach_metadata(wrapper, GeneratedMetadata(1, inputs, None, self.schedule))
        return wrapper

    def test_exact_projection_preserves_drops_and_boxed_uses(self):
        result, adapted = self.project()
        self.assertEqual(result.input_names, self.program.records.input_names)
        self.assertIs(result.input_uses, self.schedule.input_uses)
        self.assertEqual(result.outputs, self.program.records.outputs)
        self.assertIs(result.steps[3], self.schedule.steps[3])
        self.assertEqual(tuple(call.record for call in adapted), self.program.records.calls)
        self.assertEqual(tuple(step for step in result.steps if type(step) is OwnedBuffer),
                         self.program.records.allocations)
        self.assertEqual(tuple(step for step in result.steps if type(step) is AlignmentCopy),
                         self.source.alignment_copies)

    @parametrize("change", ("allocation_order", "normalization_order", "same_call_order", "missing", "duplicate", "grid", "reinterpret"))
    def test_reader_event_changes_decline(self, change):
        events = list(self.program.events)
        if change == "allocation_order":
            events.insert(2, events.pop(4))
        elif change == "normalization_order":
            events.insert(0, events.pop(3))
        elif change == "same_call_order":
            events[0], events[1] = events[1], events[0]
        elif change == "missing":
            events.pop(4)
        elif change == "duplicate":
            events.insert(2, events[2])
        elif change == "grid":
            events[2] = replace(events[2], bound_grid=(IntExpr("constant", 2), *GRID[1:]))
        else:
            events.insert(2, Reinterpret("buffer_0", "view", (8, 16), (16, 1), 0))
        with self.assertRaisesRegex(UnsupportedCapture, "event order|events only"):
            self.project(replace(self.program, events=tuple(events)))

    @parametrize("change", ("boxed_source", "buffer_collapse", "output_order", "layout"))
    def test_record_correspondence_changes_decline(self, change):
        records = self.program.records
        if change == "boxed_source":
            first = records.calls[0]
            first = replace(first, arguments=(replace(first.arguments[0], source=InputSource(1)), first.arguments[1]))
            records = replace(records, calls=(first, records.calls[1]), alignment_copies=(AlignmentCopy(1, 0),))
        elif change == "buffer_collapse":
            second = records.calls[1]
            second = replace(second, arguments=(*second.arguments[:-1], replace(
                second.arguments[-1], source=records.allocations[0].source)))
            records = replace(records, calls=(records.calls[0], second))
        elif change == "output_order":
            records = replace(records, outputs=tuple(reversed(records.outputs)))
        else:
            first = replace(records.allocations[0], size=(4, 32), stride=(32, 1))
            records = replace(records, allocations=(first, records.allocations[1]), outputs=(records.outputs[0], first))
        with self.assertRaisesRegex(UnsupportedCapture, "normalization contract|selected operands|output order"):
            self.project(replace(self.program, records=records))

    @parametrize("change", ("drop_index", "drop_position", "outputs"))
    def test_invalid_original_schedule_declines(self, change):
        steps = list(self.schedule.steps)
        if change == "drop_index":
            steps[3] = DropInput(1, 0)
            schedule = replace(self.schedule, steps=tuple(steps))
        elif change == "drop_position":
            steps.insert(0, steps.pop(3))
            schedule = replace(self.schedule, steps=tuple(steps))
        else:
            schedule = replace(self.schedule, outputs=tuple(reversed(self.schedule.outputs)))
        with self.assertRaisesRegex(UnsupportedCapture, "last use|generated wrapper"):
            self.project(schedule=schedule)

    @parametrize("change", ("equal", "delayed_drop"))
    def test_replacement_schedule_loses_original_authority(self, change):
        wrapper = self.wrapper()
        schedule = replace(self.schedule)
        if change == "delayed_drop":
            steps = list(schedule.steps)
            steps.insert(5, steps.pop(3))
            schedule = replace(schedule, steps=tuple(steps))
        from compiler_metadata_handoff.metadata import _check_release_schedule

        _check_release_schedule(schedule, self.source)
        with self.assertRaisesRegex(UnsupportedCapture, "original compiler schedule"):
            preparation._project_frontend_records(wrapper, [None, None], self.source, self.calls,
                                                   "fx", schedule)

    def test_reader_cannot_replace_original_attachment(self):
        import fx_adapter.extraction as extraction
        import fx_adapter.lowering as lowering

        wrapper = self.wrapper()

        def read(*args, **kwargs):
            wrapper._cudagraph_call_records = replace(self.source)
            return self.program

        with mock.patch.object(extraction, "trace_generated_fx", return_value=object()), \
                mock.patch.object(lowering, "lower_fx", side_effect=read):
            with self.assertRaisesRegex(MetadataDeclined, "original metadata attachment"):
                preparation._project_frontend_records(wrapper, [None, None], self.source, self.calls,
                                                       "fx", self.schedule)

    def test_nonrelease_projection_keeps_existing_event_scope(self):
        import fx_adapter.extraction as extraction
        import fx_adapter.lowering as lowering

        wrapper = self.wrapper()
        program = replace(self.program, events=(*self.program.events,
                                               Reinterpret("buffer_0", "view", (8, 16), (16, 1), 0)))
        with mock.patch.object(extraction, "trace_generated_fx", return_value=object()), \
                mock.patch.object(lowering, "lower_fx", return_value=program):
            records, calls, attachment, schedule = preparation._project_frontend_records(
                wrapper, [None, None], self.source, self.calls, "fx",
            )
        self.assertIs(records, program.records)
        self.assertEqual(len(calls), 2)
        self.assertIs(attachment, wrapper._cudagraph_frontend_attachment)
        self.assertIsNone(schedule)

    def test_relabelled_v3_records_do_not_admit_v4_release(self):
        _, renamed, grids = preparation._bind_frontend_records(
            self.source, self.calls, self.projections, self.program.records,
        )
        with self.assertRaisesRegex(UnsupportedCapture, "complete V4 compiler records"):
            preparation._project_release_schedule(replace(self.source, version=4), self.program,
                                                  renamed, grids, self.schedule)


instantiate_parametrized_tests(TestReleaseProjection)


if __name__ == "__main__":
    run_tests()
