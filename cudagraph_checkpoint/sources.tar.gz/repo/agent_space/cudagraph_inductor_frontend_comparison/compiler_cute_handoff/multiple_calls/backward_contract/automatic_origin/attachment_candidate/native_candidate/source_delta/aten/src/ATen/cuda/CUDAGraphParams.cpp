#include <ATen/cuda/CUDAGraph.h>
#include <ATen/cuda/CUDAGraphParams.h>
#include <ATen/cuda/CUDAContextLight.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <iterator>
#include <limits>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#if !defined(USE_ROCM) && defined(CUDA_VERSION) && CUDA_VERSION >= 12040
#include <c10/cuda/driver_api.h>
#endif

namespace at::cuda::detail {

class KernelParamCache {
 public:
  uint64_t generation = 0;
  bool pointer_replay_failed = false;
  std::unordered_map<uintptr_t, std::shared_ptr<KernelNodeParams>> nodes;
};

#if !defined(USE_ROCM) && defined(CUDA_VERSION) && CUDA_VERSION >= 12040
CaptureFrontier get_capture_frontier(uintptr_t stream) {
  cudaStreamCaptureStatus status{};
  unsigned long long capture_id = 0;
  cudaGraph_t graph = nullptr;
  const cudaGraphNode_t* dependencies = nullptr;
  const cudaGraphEdgeData* edges = nullptr;
  size_t count = 0;
#if CUDA_VERSION >= 13000
  C10_CUDA_CHECK(cudaStreamGetCaptureInfo(
      reinterpret_cast<cudaStream_t>(stream), &status, &capture_id, &graph,
      &dependencies, &edges, &count));
#else
  C10_CUDA_CHECK(cudaStreamGetCaptureInfo_v3(
      reinterpret_cast<cudaStream_t>(stream), &status, &capture_id, &graph,
      &dependencies, &edges, &count));
#endif
  CaptureFrontier result;
  result.status = static_cast<int>(status);
  if (status != cudaStreamCaptureStatusActive) {
    return result;
  }
  TORCH_CHECK(count == 0 || (dependencies && edges), "Missing CUDA capture dependency data");
  result.capture_id = capture_id;
  result.graph = reinterpret_cast<uintptr_t>(graph);
  result.dependencies.reserve(count);
  static_assert(sizeof(cudaGraphEdgeData) == 8);
  for (size_t index = 0; index < count; ++index) {
    std::array<uint8_t, 8> edge;
    std::memcpy(edge.data(), &edges[index], edge.size());
    result.dependencies.emplace_back(reinterpret_cast<uintptr_t>(dependencies[index]), edge);
  }
  return result;
}

struct KernelNodeParams::Impl {
  struct Image {
    std::vector<uint8_t> buffer;
    std::vector<void*> pointers;
    size_t size = 0;
    std::array<void*, 5> extra{};
  };

  CUgraphNode node;
  CUDA_KERNEL_NODE_PARAMS params{};
  std::vector<std::pair<size_t, size_t>> layout;
  std::array<Image, 2> images;
  size_t committed = 0;
  bool packed;

  std::vector<uint8_t>& stage() {
    const auto& source = images[committed].buffer;
    auto& target = images[committed ^ 1].buffer;
    std::copy(source.begin(), source.end(), target.begin());
    return target;
  }

  void submit(uintptr_t graph_exec, CUDA_KERNEL_NODE_PARAMS request) {
    auto& image = images[committed ^ 1];
    if (packed) {
      request.extra = image.extra.data();
    } else {
      request.kernelParams = image.pointers.data();
    }
    C10_CUDA_DRIVER_CHECK(c10::cuda::DriverAPI::get()->cuGraphExecKernelNodeSetParams_(
        reinterpret_cast<CUgraphExec>(graph_exec), node, &request));
    committed ^= 1;
  }
};

KernelNodeParams::KernelNodeParams(uintptr_t node) : impl_(std::make_unique<Impl>()) {
  auto* api = c10::cuda::DriverAPI::get();
  TORCH_CHECK(
      api->cuGraphKernelNodeGetParams_ && api->cuGraphExecKernelNodeSetParams_,
      "CUDA driver does not support kernel parameter updates");
  auto& state = *impl_;
  state.node = reinterpret_cast<CUgraphNode>(node);
  C10_CUDA_DRIVER_CHECK(api->cuGraphKernelNodeGetParams_(state.node, &state.params));
  TORCH_CHECK(state.params.func || state.params.kern, "Kernel node has no kernel function");
  TORCH_CHECK(
      state.params.func ? api->cuFuncGetParamInfo_ != nullptr : api->cuKernelGetParamInfo_ != nullptr,
      "Kernel parameter queries require CUDA 12.4 or later");
  size_t extent = 0;
  for (size_t index = 0;; ++index) {
    size_t offset = 0;
    size_t size = 0;
    auto status = state.params.func
        ? api->cuFuncGetParamInfo_(state.params.func, index, &offset, &size)
        : api->cuKernelGetParamInfo_(state.params.kern, index, &offset, &size);
    if (status == CUDA_ERROR_INVALID_VALUE) {
      break;
    }
    C10_CUDA_DRIVER_CHECK(status);
    TORCH_CHECK(size <= std::numeric_limits<size_t>::max() - offset, "Kernel parameter extent overflows");
    extent = std::max(extent, offset + size);
    state.layout.emplace_back(offset, size);
  }

  state.packed = state.params.extra != nullptr;
  auto& bytes = state.images[0].buffer;
  if (state.packed) {
    const void* buffer = nullptr;
    const void* size_pointer = nullptr;
    for (size_t index = 0; index < 5; index += 2) {
      auto tag = state.params.extra[index];
      if (tag == CU_LAUNCH_PARAM_END) {
        break;
      }
      TORCH_CHECK(index < 4, "Invalid CUDA kernel extra parameter buffer");
      auto value = state.params.extra[index + 1];
      TORCH_CHECK(value, "Null CUDA kernel extra parameter buffer");
      if (tag == CU_LAUNCH_PARAM_BUFFER_POINTER && !buffer) {
        buffer = value;
      } else if (tag == CU_LAUNCH_PARAM_BUFFER_SIZE && !size_pointer) {
        size_pointer = value;
      } else {
        TORCH_CHECK(false, "Invalid CUDA kernel extra parameter buffer");
      }
    }
    TORCH_CHECK(buffer && size_pointer, "Missing CUDA kernel extra parameter buffer");
    size_t size = 0;
    std::memcpy(&size, size_pointer, sizeof(size));
    bytes.resize(size);
    if (size) {
      std::memcpy(bytes.data(), buffer, size);
    }
  } else {
    bytes.resize(extent);
    TORCH_CHECK(state.layout.empty() || state.params.kernelParams, "CUDA kernel node has no argument pointers");
    for (size_t index = 0; index < state.layout.size(); ++index) {
      auto [offset, size] = state.layout[index];
      TORCH_CHECK(state.params.kernelParams[index], "CUDA kernel argument pointer is null");
      if (size) {
        std::memcpy(bytes.data() + offset, state.params.kernelParams[index], size);
      }
    }
  }
  // GetParams returns node-owned memory. Future updates use only copied bytes.
  state.params.kernelParams = nullptr;
  state.params.extra = nullptr;
  state.images[1].buffer = bytes;
  for (auto& image : state.images) {
    image.size = image.buffer.size();
    image.extra = {
        CU_LAUNCH_PARAM_BUFFER_POINTER, image.buffer.data(),
        CU_LAUNCH_PARAM_BUFFER_SIZE, &image.size, CU_LAUNCH_PARAM_END};
    if (!state.packed) {
      image.pointers.reserve(state.layout.size());
      for (const auto& argument : state.layout) {
        image.pointers.push_back(image.buffer.data() + argument.first);
      }
    }
  }
}

void KernelNodeParams::validate(const std::vector<KernelArgumentUpdate>& updates) const {
  const auto& state = *impl_;
  const auto& buffer = state.images[state.committed].buffer;
  for (const auto& update : updates) {
    TORCH_CHECK_INDEX(
        update.index >= 0 && static_cast<uint64_t>(update.index) < state.layout.size(),
        "Kernel argument index ", update.index, " is out of range");
    auto [offset, size] = state.layout[update.index];
    TORCH_CHECK_VALUE(
        update.value.size() == size,
        "Kernel argument ", update.index, " requires ", size, " bytes, got ", update.value.size());
    TORCH_CHECK_VALUE(
        offset <= buffer.size() && size <= buffer.size() - offset,
        "Kernel argument ", update.index, " exceeds the captured parameter buffer");
  }
}

KernelNodeSnapshot KernelNodeParams::snapshot() const {
  const auto& state = *impl_;
  const auto& buffer = state.images[state.committed].buffer;
  KernelNodeSnapshot result{
      reinterpret_cast<uintptr_t>(state.node),
      reinterpret_cast<uintptr_t>(state.params.func),
      reinterpret_cast<uintptr_t>(state.params.kern),
      reinterpret_cast<uintptr_t>(state.params.ctx),
      {state.params.gridDimX, state.params.gridDimY, state.params.gridDimZ},
      {state.params.blockDimX, state.params.blockDimY, state.params.blockDimZ},
      state.params.sharedMemBytes, state.packed, {}};
  result.arguments.reserve(state.layout.size());
  for (size_t index = 0; index < state.layout.size(); ++index) {
    auto [offset, size] = state.layout[index];
    TORCH_CHECK_VALUE(
        offset <= buffer.size() && size <= buffer.size() - offset,
        "Kernel argument ", index, " exceeds the captured parameter buffer");
    result.arguments.push_back({
        offset, size,
        std::vector<uint8_t>(buffer.begin() + offset, buffer.begin() + offset + size)});
  }
  return result;
}

void KernelNodeParams::update(uintptr_t graph_exec, const std::vector<KernelArgumentUpdate>& updates) {
  validate(updates);
  if (updates.empty()) {
    return;
  }
  auto& state = *impl_;
  auto& staged = state.stage();
  for (const auto& update : updates) {
    auto offset = state.layout[update.index].first;
    std::copy(update.value.begin(), update.value.end(), staged.begin() + offset);
  }
  state.submit(graph_exec, state.params);
}

size_t KernelNodeParams::pointer_offset(int64_t argument, std::optional<size_t> byte_offset) const {
  const auto& state = *impl_;
  TORCH_CHECK_INDEX(
      argument >= 0 && static_cast<uint64_t>(argument) < state.layout.size(),
      "Kernel argument index ", argument, " is out of range");
  const auto [offset, size] = state.layout[argument];
  TORCH_CHECK_VALUE(
      byte_offset || size == sizeof(uintptr_t), "Kernel argument ", argument, " is not pointer-sized");
  const auto field = byte_offset.value_or(0);
  TORCH_CHECK_VALUE(
      field <= size && sizeof(uintptr_t) <= size - field,
      "Pointer field exceeds kernel argument ", argument);
  const auto& buffer = state.images[state.committed].buffer;
  TORCH_CHECK_VALUE(
      offset <= buffer.size() && size <= buffer.size() - offset,
      "Kernel argument ", argument, " exceeds the captured parameter buffer");
  return offset + field;
}

size_t KernelNodeParams::scalar_offset(
    int64_t argument, size_t width, std::optional<size_t> byte_offset) const {
  const auto& state = *impl_;
  TORCH_CHECK_INDEX(
      argument >= 0 && static_cast<uint64_t>(argument) < state.layout.size(),
      "Kernel argument index ", argument, " is out of range");
  const auto [offset, size] = state.layout[argument];
  TORCH_CHECK_VALUE(byte_offset || size == width, "Kernel scalar width differs from the selected ABI");
  const auto field = byte_offset.value_or(0);
  TORCH_CHECK_VALUE(field <= size && width <= size - field, "Scalar field exceeds kernel argument ", argument);
  const auto& buffer = state.images[state.committed].buffer;
  TORCH_CHECK_VALUE(
      offset <= buffer.size() && size <= buffer.size() - offset,
      "Kernel argument ", argument, " exceeds the captured parameter buffer");
  return offset + field;
}

void KernelNodeParams::update_pointers(
    uintptr_t graph_exec,
    c10::ArrayRef<KernelPointerSlot> slots,
    c10::ArrayRef<uintptr_t> pointers) {
  auto& state = *impl_;
  const auto& buffer = state.images[state.committed].buffer;
  const bool dirty = std::any_of(slots.begin(), slots.end(), [&](const auto& slot) {
    return std::memcmp(buffer.data() + slot.offset, &pointers[slot.pointer_index], sizeof(uintptr_t)) != 0;
  });
  if (!dirty) {
    return;
  }
  auto& staged = state.stage();
  for (const auto& slot : slots) {
    std::memcpy(staged.data() + slot.offset, &pointers[slot.pointer_index], sizeof(uintptr_t));
  }
  state.submit(graph_exec, state.params);
}

void KernelNodeParams::update_replay(
    uintptr_t graph_exec,
    c10::ArrayRef<KernelPointerSlot> pointer_slots,
    c10::ArrayRef<KernelScalarSlot> scalar_slots,
    const std::optional<std::array<size_t, 3>>& grid,
    c10::ArrayRef<uintptr_t> pointers,
    c10::ArrayRef<int64_t> values) {
  auto& state = *impl_;
  const auto& buffer = state.images[state.committed].buffer;
  auto request = state.params;
  if (grid) {
    request.gridDimX = static_cast<unsigned int>(values[(*grid)[0]]);
    request.gridDimY = static_cast<unsigned int>(values[(*grid)[1]]);
    request.gridDimZ = static_cast<unsigned int>(values[(*grid)[2]]);
  }
  const bool dirty = request.gridDimX != state.params.gridDimX ||
      request.gridDimY != state.params.gridDimY || request.gridDimZ != state.params.gridDimZ ||
      std::any_of(pointer_slots.begin(), pointer_slots.end(), [&](const auto& slot) {
        return std::memcmp(buffer.data() + slot.offset, &pointers[slot.pointer_index], sizeof(uintptr_t)) != 0;
      }) ||
      std::any_of(scalar_slots.begin(), scalar_slots.end(), [&](const auto& slot) {
        const auto value = values[slot.value_index];
        const int32_t narrow = slot.width == sizeof(int32_t) ? static_cast<int32_t>(value) : 0;
        const void* bytes = slot.width == sizeof(narrow) ? static_cast<const void*>(&narrow) : &value;
        return std::memcmp(buffer.data() + slot.offset, bytes, slot.width) != 0;
      });
  if (!dirty) {
    return;
  }
  auto& staged = state.stage();
  for (const auto& slot : pointer_slots) {
    std::memcpy(staged.data() + slot.offset, &pointers[slot.pointer_index], sizeof(uintptr_t));
  }
  for (const auto& slot : scalar_slots) {
    const auto value = values[slot.value_index];
    const int32_t narrow = slot.width == sizeof(int32_t) ? static_cast<int32_t>(value) : 0;
    const void* bytes = slot.width == sizeof(narrow) ? static_cast<const void*>(&narrow) : &value;
    std::memcpy(staged.data() + slot.offset, bytes, slot.width);
  }
  state.submit(graph_exec, request);
  // The cache describes only successful setters, including their launch grid.
  state.params.gridDimX = request.gridDimX;
  state.params.gridDimY = request.gridDimY;
  state.params.gridDimZ = request.gridDimZ;
}
#else
CaptureFrontier get_capture_frontier(uintptr_t) {
  TORCH_CHECK(false, "CUDA graph inspection requires NVIDIA CUDA 12.4 or later");
}

struct KernelNodeParams::Impl {};

KernelNodeParams::KernelNodeParams(uintptr_t) {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

void KernelNodeParams::validate(const std::vector<KernelArgumentUpdate>&) const {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

void KernelNodeParams::update(uintptr_t, const std::vector<KernelArgumentUpdate>&) {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

size_t KernelNodeParams::pointer_offset(int64_t, std::optional<size_t>) const {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

size_t KernelNodeParams::scalar_offset(int64_t, size_t, std::optional<size_t>) const {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

void KernelNodeParams::update_pointers(
    uintptr_t, c10::ArrayRef<KernelPointerSlot>, c10::ArrayRef<uintptr_t>) {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

void KernelNodeParams::update_replay(
    uintptr_t,
    c10::ArrayRef<KernelPointerSlot>,
    c10::ArrayRef<KernelScalarSlot>,
    const std::optional<std::array<size_t, 3>>&,
    c10::ArrayRef<uintptr_t>,
    c10::ArrayRef<int64_t>) {
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
}

KernelNodeSnapshot KernelNodeParams::snapshot() const {
  TORCH_CHECK(false, "CUDA graph inspection requires NVIDIA CUDA 12.4 or later");
}
#endif

KernelNodeParams::~KernelNodeParams() = default;

void KernelPointerUpdateBatch::validate_values(c10::ArrayRef<int64_t> values) const {
  TORCH_CHECK_VALUE(numeric_, "Prepared updates do not contain a numeric plan");
  TORCH_CHECK_VALUE(values.size() == value_ranges_.size(), "Numeric result count differs from preparation");
  for (size_t index = 0; index < values.size(); ++index) {
    const auto [lower, upper] = value_ranges_[index];
    TORCH_CHECK_VALUE(
        values[index] >= lower && values[index] <= upper,
        "Numeric result ", index, " is outside its scalar ABI or grid range");
  }
}

} // namespace at::cuda::detail

namespace at::cuda {

detail::CapturedGraphSnapshot CUDAGraph::inspect_captured_kernel_nodes(
    const std::vector<uintptr_t>& nodes) {
  TORCH_CHECK(keep_graph_, "Kernel node inspection requires keep_graph=True");
  TORCH_CHECK(capture_ended_ && has_graph_, "Kernel node inspection requires a completed retained graph capture");
#if defined(USE_ROCM) || !defined(CUDA_VERSION) || CUDA_VERSION < 12040
  TORCH_CHECK(false, "CUDA graph inspection requires NVIDIA CUDA 12.4 or later");
#else
  std::unordered_set<uintptr_t> seen;
  for (auto node : nodes) {
    TORCH_CHECK_VALUE(seen.insert(node).second, "Duplicate kernel node handle ", node);
  }
  c10::cuda::CUDAGuard device_guard(capture_dev_);
  size_t count = 0;
  C10_CUDA_CHECK(cudaGraphGetNodes(graph_, nullptr, &count));
  std::vector<cudaGraphNode_t> graph_nodes(count);
  if (count) {
    C10_CUDA_CHECK(cudaGraphGetNodes(graph_, graph_nodes.data(), &count));
    graph_nodes.resize(count);
  }
  detail::CapturedGraphSnapshot result{reinterpret_cast<uintptr_t>(graph_), capture_id_, {}, {}};
  result.nodes.reserve(graph_nodes.size());
  for (auto node : graph_nodes) {
    result.nodes.push_back(reinterpret_cast<uintptr_t>(node));
  }
  std::sort(result.nodes.begin(), result.nodes.end());
  result.kernels.reserve(nodes.size());
  for (auto handle : nodes) {
    auto node = reinterpret_cast<cudaGraphNode_t>(handle);
    TORCH_CHECK_VALUE(
        std::find(graph_nodes.begin(), graph_nodes.end(), node) != graph_nodes.end(),
        "Kernel node ", handle, " does not belong to this graph");
    cudaGraphNodeType type;
    C10_CUDA_CHECK(cudaGraphNodeGetType(node, &type));
    TORCH_CHECK_VALUE(type == cudaGraphNodeTypeKernel, "Node ", handle, " is not a kernel node");
    result.kernels.push_back(detail::KernelNodeParams(handle).snapshot());
  }
  return result;
#endif
}

void CUDAGraph::clear_kernel_params() {
  if (kernel_params_) {
    kernel_params_->nodes.clear();
    ++kernel_params_->generation;
    kernel_params_->pointer_replay_failed = false;
  }
}

std::shared_ptr<detail::KernelParamUpdateBatch> CUDAGraph::prepare_kernel_params(
    std::vector<detail::KernelNodeUpdate> updates) {
  check_not_owned();
  TORCH_CHECK(keep_graph_, "update_kernel_params requires keep_graph=True");
  TORCH_CHECK(capture_ended_ && has_graph_, "Kernel parameter updates require a completed retained graph capture");
#if defined(USE_ROCM) || !defined(CUDA_VERSION) || CUDA_VERSION < 12040
  TORCH_CHECK(false, "Kernel parameter updates require NVIDIA CUDA 12.4 or later");
#endif
  std::unordered_set<uintptr_t> seen;
  for (const auto& update : updates) {
    TORCH_CHECK_VALUE(
        seen.insert(update.node).second,
        "Duplicate kernel node handle ", update.node);
  }
  c10::cuda::CUDAGuard device_guard(capture_dev_);
  if (!kernel_params_) {
    kernel_params_ = std::make_shared<detail::KernelParamCache>();
  }
  auto batch = std::make_shared<detail::KernelParamUpdateBatch>();
  batch->cache_ = kernel_params_;
  batch->generation_ = kernel_params_->generation;
  batch->needs_instantiation_ = !has_graph_exec_;
  batch->updates_ = std::move(updates);
  std::vector<cudaGraphNode_t> graph_nodes;
  const bool has_new_nodes = std::any_of(batch->updates_.begin(), batch->updates_.end(), [&](const auto& update) {
    return kernel_params_->nodes.count(update.node) == 0;
  });
  if (has_new_nodes) {
    size_t count = 0;
    C10_CUDA_CHECK(cudaGraphGetNodes(graph_, nullptr, &count));
    graph_nodes.resize(count);
    if (count) {
      C10_CUDA_CHECK(cudaGraphGetNodes(graph_, graph_nodes.data(), &count));
      graph_nodes.resize(count);
    }
  }
  batch->nodes_.reserve(batch->updates_.size());
  for (const auto& update : batch->updates_) {
    auto found = kernel_params_->nodes.find(update.node);
    std::shared_ptr<detail::KernelNodeParams> state;
    if (found != kernel_params_->nodes.end()) {
      state = found->second;
    } else {
      auto node = reinterpret_cast<cudaGraphNode_t>(update.node);
      TORCH_CHECK_VALUE(
          std::find(graph_nodes.begin(), graph_nodes.end(), node) != graph_nodes.end(),
          "Kernel node ", update.node, " does not belong to this graph");
      cudaGraphNodeType type;
      C10_CUDA_CHECK(cudaGraphNodeGetType(node, &type));
      TORCH_CHECK_VALUE(type == cudaGraphNodeTypeKernel, "Node ", update.node, " is not a kernel node");
      state = std::make_shared<detail::KernelNodeParams>(update.node);
    }
    state->validate(update.arguments);
    batch->nodes_.push_back(std::move(state));
  }
  return batch;
}

void CUDAGraph::update_kernel_params(const detail::KernelParamUpdateBatch& batch) {
  check_not_owned();
  TORCH_CHECK(
      kernel_params_ && batch.cache_ == kernel_params_ && has_graph_exec_ && capture_ended_,
      "Prepared kernel parameter updates belong to a reset or different graph");
  TORCH_CHECK(
      batch.generation_ == kernel_params_->generation ||
          (batch.needs_instantiation_ && batch.generation_ + 1 == kernel_params_->generation),
      "Prepared kernel parameter updates were invalidated by instantiate");
  c10::cuda::CUDAGuard device_guard(capture_dev_);
  std::vector<std::shared_ptr<detail::KernelNodeParams>> nodes;
  nodes.reserve(batch.updates_.size());
  for (size_t index = 0; index < batch.updates_.size(); ++index) {
    const auto& update = batch.updates_[index];
    auto found = kernel_params_->nodes.find(update.node);
    // An instantiate hook may have updated an otherwise untouched argument.
    auto state = found == kernel_params_->nodes.end() ? batch.nodes_[index] : found->second;
    state->validate(update.arguments);
    nodes.push_back(std::move(state));
  }
  for (size_t index = 0; index < batch.updates_.size(); ++index) {
    kernel_params_->nodes.try_emplace(batch.updates_[index].node, nodes[index]);
  }
  try {
    for (size_t index = 0; index < batch.updates_.size(); ++index) {
      nodes[index]->update(reinterpret_cast<uintptr_t>(graph_exec_), batch.updates_[index].arguments);
    }
  } catch (...) {
    kernel_params_->pointer_replay_failed = true;
    throw;
  }
}

std::shared_ptr<detail::KernelPointerUpdateBatch> CUDAGraph::prepare_kernel_pointer_updates(
    std::vector<detail::KernelPointerBinding> bindings, size_t pointer_count) {
  for (const auto& binding : bindings) {
    TORCH_CHECK_VALUE(!binding.byte_offset, "Pointer-only bindings require whole kernel arguments");
  }
  auto batch = prepare_kernel_replay_updates(std::move(bindings), pointer_count, {}, {}, 0);
  batch->numeric_ = false;
  return batch;
}

std::shared_ptr<detail::KernelPointerUpdateBatch> CUDAGraph::prepare_kernel_replay_updates(
    std::vector<detail::KernelPointerBinding> bindings,
    size_t pointer_count,
    std::vector<detail::KernelScalarBinding> scalars,
    std::vector<detail::KernelGridBinding> grids,
    size_t value_count) {
  check_not_owned();
  TORCH_CHECK(has_graph_exec_, "Pointer updates require an instantiated graph");
  TORCH_CHECK(
      !kernel_params_ || !kernel_params_->pointer_replay_failed,
      "Pointer replay failed; re-instantiate the graph before preparing again");
  std::unordered_map<uintptr_t, size_t> positions;
  std::vector<detail::KernelNodeUpdate> requests;
  for (const auto& binding : bindings) {
    TORCH_CHECK_INDEX(binding.pointer_index < pointer_count, "Pointer index is out of range");
    if (positions.emplace(binding.node, requests.size()).second) {
      requests.push_back({binding.node, {}});
    }
  }
  for (const auto& binding : scalars) {
    TORCH_CHECK_VALUE(binding.width == 4 || binding.width == 8, "Scalar width must be 4 or 8 bytes");
    TORCH_CHECK_INDEX(binding.value_index < value_count, "Scalar value index is out of range");
    if (positions.emplace(binding.node, requests.size()).second) {
      requests.push_back({binding.node, {}});
    }
  }
  std::unordered_set<uintptr_t> grid_nodes;
  for (const auto& binding : grids) {
    TORCH_CHECK_VALUE(grid_nodes.insert(binding.node).second, "Duplicate kernel grid binding");
    for (auto value : binding.values) {
      TORCH_CHECK_INDEX(value < value_count, "Grid value index is out of range");
    }
    if (positions.emplace(binding.node, requests.size()).second) {
      requests.push_back({binding.node, {}});
    }
  }
  auto decoded = prepare_kernel_params(std::move(requests));
  auto batch = std::make_shared<detail::KernelPointerUpdateBatch>();
  batch->cache_ = decoded->cache_;
  batch->generation_ = decoded->generation_;
  batch->pointer_count_ = pointer_count;
  batch->numeric_ = true;
  batch->value_ranges_.assign(
      value_count, {std::numeric_limits<int64_t>::min(), std::numeric_limits<int64_t>::max()});
  for (auto& node : decoded->nodes_) {
    batch->nodes_.push_back({node, {}, {}, std::nullopt});
  }
  std::vector<std::vector<std::pair<size_t, size_t>>> spans(batch->nodes_.size());
  for (const auto& binding : bindings) {
    auto position = positions.at(binding.node);
    auto& node = batch->nodes_[position];
    auto offset = node.params->pointer_offset(binding.argument, binding.byte_offset);
    node.slots.push_back({offset, binding.pointer_index});
    spans[position].emplace_back(offset, offset + sizeof(uintptr_t));
  }
  for (const auto& binding : scalars) {
    auto position = positions.at(binding.node);
    auto& node = batch->nodes_[position];
    auto offset = node.params->scalar_offset(binding.argument, binding.width, binding.byte_offset);
    node.scalars.push_back({offset, binding.width, binding.value_index});
    spans[position].emplace_back(offset, offset + binding.width);
    if (binding.width == 4) {
      auto& range = batch->value_ranges_[binding.value_index];
      range.first = std::max(range.first, static_cast<int64_t>(std::numeric_limits<int32_t>::min()));
      range.second = std::min(range.second, static_cast<int64_t>(std::numeric_limits<int32_t>::max()));
    }
  }
  for (auto& fields : spans) {
    std::sort(fields.begin(), fields.end());
    for (size_t index = 1; index < fields.size(); ++index) {
      TORCH_CHECK_VALUE(fields[index - 1].second <= fields[index].first, "Kernel argument bindings overlap");
    }
  }
  if (!grids.empty()) {
    const auto* properties = at::cuda::getDeviceProperties(capture_dev_);
    for (const auto& binding : grids) {
      batch->nodes_[positions.at(binding.node)].grid = binding.values;
      for (size_t axis = 0; axis < 3; ++axis) {
        auto& range = batch->value_ranges_[binding.values[axis]];
        range.first = std::max(range.first, int64_t{1});
        range.second = std::min(range.second, static_cast<int64_t>(properties->maxGridSize[axis]));
      }
    }
  }
  for (const auto& [node, position] : positions) {
    kernel_params_->nodes.try_emplace(node, batch->nodes_[position].params);
  }
  return batch;
}

void CUDAGraph::replay_kernel_pointer_updates(
    const detail::KernelPointerUpdateBatch& batch,
    c10::ArrayRef<uintptr_t> pointers) {
  check_not_owned();
  replay_pointer_updates_impl(batch, pointers);
}

void CUDAGraph::validate_pointer_updates(
    const detail::KernelPointerUpdateBatch& batch, size_t pointer_count) const {
  TORCH_CHECK(
      kernel_params_ && batch.cache_ == kernel_params_ && has_graph_exec_ && capture_ended_,
      "Prepared pointer updates belong to a reset or different graph");
  TORCH_CHECK(batch.generation_ == kernel_params_->generation, "Prepared pointer updates were invalidated by instantiate");
  TORCH_CHECK(!kernel_params_->pointer_replay_failed, "Pointer replay failed; re-instantiate the graph before replaying again");
  TORCH_CHECK_VALUE(pointer_count == batch.pointer_count_, "Pointer count differs from the prepared bindings");
}

void CUDAGraph::replay_pointer_updates_impl(
    const detail::KernelPointerUpdateBatch& batch,
    c10::ArrayRef<uintptr_t> pointers,
    c10::cuda::CUDACachingAllocator::PendingGraphInputs* pending) {
  TORCH_CHECK_VALUE(!batch.numeric_, "Numeric updates require a boxed numeric plan");
  validate_pointer_updates(batch, pointers.size());
  c10::cuda::CUDAGuard device_guard(capture_dev_);
  try {
    for (const auto& node : batch.nodes_) {
      node.params->update_pointers(reinterpret_cast<uintptr_t>(graph_exec_), node.slots, pointers);
    }
    replay_impl(pending);
  } catch (...) {
    kernel_params_->pointer_replay_failed = true;
    throw;
  }
}

void CUDAGraph::replay_kernel_updates_impl(
    const detail::KernelPointerUpdateBatch& batch,
    c10::ArrayRef<uintptr_t> pointers,
    c10::ArrayRef<int64_t> values) {
  validate_pointer_updates(batch, pointers.size());
  c10::cuda::CUDAGuard device_guard(capture_dev_);
  try {
    for (const auto& node : batch.nodes_) {
      node.params->update_replay(
          reinterpret_cast<uintptr_t>(graph_exec_), node.slots, node.scalars, node.grid, pointers, values);
    }
    replay_impl();
  } catch (...) {
    kernel_params_->pointer_replay_failed = true;
    throw;
  }
}

detail::GraphReplayLease::GraphReplayLease(
    std::shared_ptr<CUDAGraph> graph,
    std::shared_ptr<KernelPointerUpdateBatch> batch,
    c10::DeviceIndex device)
    : graph_(std::move(graph)), batch_(std::move(batch)) {
  TORCH_CHECK(graph_ && batch_, "Native replay requires a graph and pointer batch");
  graph_->validate_pointer_updates(*batch_, batch_->pointer_count_);
  TORCH_CHECK(graph_->capture_dev_ == device, "Native replay stream is on a different device");
  const GraphReplayLease* empty = nullptr;
  TORCH_CHECK(
      graph_->replay_owner_.compare_exchange_strong(empty, this),
      "CUDA graph is already leased to a native replay owner");
}

detail::GraphReplayLease::~GraphReplayLease() {
  graph_->replay_owner_.store(nullptr);
}

void detail::GraphReplayLease::replay(
    c10::ArrayRef<uintptr_t> pointers, c10::cuda::CUDACachingAllocator::PendingGraphInputs* pending) {
  graph_->replay_pointer_updates_impl(*batch_, pointers, pending);
}

detail::InputReleasePlan detail::GraphReplayLease::prepare_input_release(
    std::vector<InputReleaseStep> steps, const std::vector<uintptr_t>& nodes,
    size_t input_count, size_t allocation_count) const {
#if defined(USE_ROCM) || !defined(CUDA_VERSION) || CUDA_VERSION < 12040
  TORCH_CHECK(false, "Input release requires NVIDIA CUDA 12.4 or later");
#else
  graph_->validate_pointer_updates(*batch_, input_count + allocation_count);
  TORCH_CHECK_VALUE(!batch_->numeric_ && !nodes.empty() && allocation_count &&
                       batch_->nodes_.size() == nodes.size(),
                   "Input release requires complete static kernel bindings");
  auto snapshot = graph_->inspect_captured_kernel_nodes(nodes);
  TORCH_CHECK_VALUE(snapshot.nodes.size() == nodes.size(), "Release nodes must cover the complete graph");
  std::unordered_map<uintptr_t, size_t> ordinals;
  for (size_t index = 0; index < nodes.size(); ++index) {
    TORCH_CHECK_VALUE(nodes[index] && ordinals.emplace(nodes[index], index).second,
                     "Release nodes must be distinct kernel handles");
  }
  c10::cuda::CUDAGuard device_guard(graph_->capture_dev_);
  size_t edge_count = 0;
#if CUDA_VERSION >= 13000
  C10_CUDA_CHECK(cudaGraphGetEdges(graph_->graph_, nullptr, nullptr, nullptr, &edge_count));
#else
  C10_CUDA_CHECK(cudaGraphGetEdges_v2(graph_->graph_, nullptr, nullptr, nullptr, &edge_count));
#endif
  TORCH_CHECK_VALUE(edge_count == nodes.size() - 1, "Input release requires a complete linear kernel chain");
  std::vector<cudaGraphNode_t> from(edge_count), to(edge_count);
  std::vector<cudaGraphEdgeData> data(edge_count);
  if (edge_count) {
    auto expected = edge_count;
#if CUDA_VERSION >= 13000
    C10_CUDA_CHECK(cudaGraphGetEdges(graph_->graph_, from.data(), to.data(), data.data(), &edge_count));
#else
    C10_CUDA_CHECK(cudaGraphGetEdges_v2(graph_->graph_, from.data(), to.data(), data.data(), &edge_count));
#endif
    TORCH_CHECK_VALUE(edge_count == expected, "Release graph edges changed during preparation");
  }
  std::vector<bool> edges(nodes.size() - 1, false);
  for (size_t index = 0; index < edge_count; ++index) {
    const auto& edge = data[index];
    TORCH_CHECK_VALUE(edge.from_port == 0 && edge.to_port == 0 && edge.type == 0 &&
                         std::all_of(std::begin(edge.reserved), std::end(edge.reserved),
                                     [](auto value) { return value == 0; }),
                     "Input release requires full-completion graph edges");
    auto source = ordinals.find(reinterpret_cast<uintptr_t>(from[index]));
    auto target = ordinals.find(reinterpret_cast<uintptr_t>(to[index]));
    TORCH_CHECK_VALUE(source != ordinals.end() && target != ordinals.end() &&
                         source->second + 1 == target->second && !edges[source->second],
                     "Release call order differs from the captured kernel chain");
    edges[source->second] = true;
  }
  std::vector<std::vector<size_t>> uses(input_count + allocation_count);
  std::vector<bool> bound(nodes.size(), false);
  for (const auto& node : batch_->nodes_) {
    auto found = ordinals.find(node.params->snapshot().node);
    TORCH_CHECK_VALUE(found != ordinals.end() && !bound[found->second],
                     "Release nodes differ from the prepared pointer batch");
    auto ordinal = found->second;
    bound[ordinal] = true;
    for (const auto& slot : node.slots) {
      uses[slot.pointer_index].push_back(ordinal);
    }
  }
  for (auto& row : uses) {
    std::sort(row.begin(), row.end());
    row.erase(std::unique(row.begin(), row.end()), row.end());
  }
  const auto absent = std::numeric_limits<size_t>::max();
  std::vector<size_t> allocations(allocation_count, absent), drops(input_count, absent);
  size_t next_allocation = 0, next_kernel = 0;
  InputReleasePlan result;
  for (size_t position = 0; position < steps.size(); ++position) {
    const auto& step = steps[position];
    if (step.kind == InputReleaseKind::Allocate) {
      TORCH_CHECK_VALUE(step.index == next_allocation && step.index < allocation_count,
                       "Release allocations must appear once in original order");
      allocations[step.index] = position;
      ++next_allocation;
      result.steps.push_back(step);
    } else if (step.kind == InputReleaseKind::Kernel) {
      TORCH_CHECK_VALUE(step.index == next_kernel && next_kernel < nodes.size(),
                       "Release kernels must appear once in captured order");
      for (size_t source = 0; source < uses.size(); ++source) {
        if (std::binary_search(uses[source].begin(), uses[source].end(), next_kernel)) {
          TORCH_CHECK_VALUE(source < input_count ? drops[source] == absent
                                                : allocations[source - input_count] != absent,
                           "Release kernel uses a dropped input or unallocated buffer");
        }
      }
      ++next_kernel;
    } else {
      TORCH_CHECK_VALUE(step.kind == InputReleaseKind::Drop && step.index < input_count &&
                           drops[step.index] == absent &&
                           (uses[step.index].empty() || uses[step.index].back() < next_kernel),
                       "Input drop must be unique and follow its last captured use");
      drops[step.index] = position;
      result.steps.push_back(step);
    }
  }
  TORCH_CHECK_VALUE(next_allocation == allocation_count && next_kernel == nodes.size(),
                   "Release program must cover every allocation and kernel");
  for (size_t input = 0; input < input_count; ++input) {
    if (drops[input] != absent) {
      result.candidates.push_back(input);
    }
  }
  TORCH_CHECK_VALUE(!result.candidates.empty(), "Release program requires saved-input drops");
  result.eligible_inputs.resize(allocation_count);
  for (size_t allocation = 0; allocation < allocation_count; ++allocation) {
    const auto& new_uses = uses[input_count + allocation];
    TORCH_CHECK_VALUE(!new_uses.empty(), "Release allocation has no captured use");
    for (size_t candidate = 0; candidate < result.candidates.size(); ++candidate) {
      auto input = result.candidates[candidate];
      if (drops[input] < allocations[allocation] &&
          (uses[input].empty() || uses[input].back() < new_uses.front())) {
        result.eligible_inputs[allocation].push_back(candidate);
      }
    }
  }
  return result;
#endif
}

void detail::GraphReplayLease::validate_values(c10::ArrayRef<int64_t> values) const {
  batch_->validate_values(values);
}

void detail::GraphReplayLease::replay(
    c10::ArrayRef<uintptr_t> pointers, c10::ArrayRef<int64_t> values) {
  graph_->replay_kernel_updates_impl(*batch_, pointers, values);
}

bool detail::GraphReplayLease::check_capture_pool_retirement() const {
  graph_->validate_pointer_updates(*batch_, batch_->pointer_count_);
  return graph_->check_capture_pool_retirement();
}

void detail::GraphReplayLease::retire_capture_pool() {
  graph_->release_capture_pools();
}

void detail::GraphReplayLease::close() {
  if (graph_->has_graph_exec_) {
    C10_CUDA_CHECK(cudaGraphExecDestroy(graph_->graph_exec_));
    graph_->graph_exec_ = nullptr;
    graph_->has_graph_exec_ = false;
  }
  if (graph_->has_graph_) {
    C10_CUDA_CHECK(cudaGraphDestroy(graph_->graph_));
    graph_->graph_ = nullptr;
    graph_->has_graph_ = false;
  }
  graph_->reset_impl();
}

} // namespace at::cuda
