#!/usr/bin/env bash
set -euo pipefail
source /data/eellison/src/pytorch/agent_space/env.sh
dispatch_root=/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release
unset TORCH_WT WT_PRELUDE
export LANDING_RUNTIME=new
export PYTHONPATH="$dispatch_root/runtime_site"
export TORCH_CUSTOM_PYTHONPATH="$dispatch_root/runtime_site"
export LD_LIBRARY_PATH="$dispatch_root/install_attempt1/torch/lib:$LD_LIBRARY_PATH"
export TORCHINDUCTOR_FORCE_DISABLE_CACHES=0
exec python "$@"
