"""Compile Python and CuTe local reuse conditions against original boxed integers."""

import ctypes
from dataclasses import dataclass

import sympy
import torch
from torch._guards import TracingContext
from torch._inductor.codecache import CppCodeCache
from torch._inductor.runtime.cudagraph_arg_mapping import IntExpr
from torch.fx.experimental.symbolic_shapes import _CppShapeGuardsHelper
from torch.utils._sympy.functions import CeilDiv
from torch.utils._sympy.value_ranges import ValueRanges
from user_triton.guard_export import _BoundedPrinter, GuardExportDeclined, PreparedGuard

from .lowering import BoundCuTeCall, LinkedCuTe
from .numeric import Comparison


@dataclass(frozen=True)
class PreparedCuTeGuard:
    boxed_integer_indices: tuple[int, ...]
    function_address: int
    library_owner: object
    expressions: tuple[str, ...]
    cpp_source: str
    linked: LinkedCuTe | BoundCuTeCall

    @property
    def registration(self):
        return self.boxed_integer_indices, self.function_address, self.library_owner


@dataclass(frozen=True)
class CombinedGuard:
    registration: tuple
    cpp_source: str


def combine_guards(guards):
    if (type(guards) is not tuple or not guards
            or any(type(guard) not in (PreparedGuard, PreparedCuTeGuard) for guard in guards)):
        raise GuardExportDeclined("Expected exact prepared local predicates")
    contracts = tuple((guard.trace if type(guard) is PreparedGuard else guard.linked.trace).input_contract
                      for guard in guards)
    if any(contract is not contracts[0] for contract in contracts):
        raise GuardExportDeclined("Local predicates must share the same original compiler input contract")
    indices = tuple(dict.fromkeys(index for guard in guards for index in guard.boxed_integer_indices))
    lines = []
    for ordinal, guard in enumerate(guards):
        values = ", ".join(f"int_values[{indices.index(index)}]" for index in guard.boxed_integer_indices)
        pointer = "nullptr"
        if values:
            pointer = f"values_{ordinal}"
            lines.append(f"  int64_t {pointer}[] = {{{values}}};")
        lines.append(f"  if (!reinterpret_cast<Predicate>(uintptr_t({guard.function_address}))"
                     f"({pointer}, nullptr)) return 0;")
    body = "\n".join(lines)
    source = f'''#include <cstdint>
using Predicate = int8_t (*)(int64_t*, double*);
extern "C" int8_t guard(int64_t* int_values, double* float_values) {{
{body}
  return 1;
}}
'''
    library = CppCodeCache.load(source)
    address = ctypes.cast(library.guard, ctypes.c_void_p).value
    if address is None:
        raise GuardExportDeclined("Combined local predicate has no function address")
    owners = (library, *(guard.library_owner for guard in guards))
    return CombinedGuard((indices, address, owners), source)


def prepare_guard(linked):
    if type(linked) not in (LinkedCuTe, BoundCuTeCall) or TracingContext.try_get() is not None:
        raise GuardExportDeclined("Expected a linked CuTe invocation outside an ambient compiler context")
    trace = linked.trace
    trace.check()
    linked.owner.check()
    rows = trace.input_contract.integer_ranges
    placeholders, sources = trace.integer_placeholders, trace.integer_sources
    if (len(rows) != len(placeholders) or len(rows) != len(sources)
            or len({row.index for row in rows}) != len(rows)
            or len({id(source) for source in sources}) != len(sources)
            or trace.shape_env.deferred_runtime_asserts):
        raise GuardExportDeclined("CuTe guard inputs or assertion ownership are incomplete")
    declared, domains, symbols = {row.index: row for row in rows}, {}, {}
    for symbol, origin in trace.symbol_sources.items():
        if origin.op != "boxed" or origin.value not in declared or origin.value in symbols:
            raise GuardExportDeclined("CuTe guard symbol lacks one original boxed source")
        row = declared[origin.value]
        symbols[origin.value] = symbol
        domains[symbol] = ValueRanges(max(row.lower, -(2 ** 63)),
                                      min(row.upper if row.upper is not None else 2 ** 63 - 1, 2 ** 63 - 1))
    for row, placeholder, source in zip(rows, placeholders, sources):
        if (type(placeholder) is not torch.SymInt or placeholder.node.shape_env is not trace.shape_env
                or row.index not in symbols
                or not any(source is old for old in trace.shape_env.var_to_sources[symbols[row.index]])):
            raise GuardExportDeclined("CuTe guard lost its exact ShapeEnv source")
    printers = []

    def factory(*args):
        printer = _BoundedPrinter(*args, domains=domains, sources=sources)
        printers.append(printer)
        return printer

    parts, = trace.shape_env.produce_guards_verbose(
        placeholders, sources, langs=("cpp",), _simplified=False, _cpp_printer_factory=factory,
    )
    if type(parts) is not _CppShapeGuardsHelper or len(printers) != 1:
        raise GuardExportDeclined("Expected the complete compiler-produced Python host predicate")
    printer = printers[0]

    def expression(value):
        if type(value) is not IntExpr:
            raise GuardExportDeclined("CuTe numeric condition lost its shared expression")
        if value.op == "constant":
            return sympy.Integer(value.value)
        if value.op == "boxed" and value.value in symbols:
            return symbols[value.value]
        if value.op == "multiply":
            return sympy.Mul(*(expression(arg) for arg in value.args))
        if value.op == "ceildiv" and len(value.args) == 2:
            return CeilDiv(*(expression(arg) for arg in value.args))
        raise GuardExportDeclined("CuTe numeric condition exceeds the proven C++ guard subset")

    conditions = []
    for obligation in linked.obligations:
        value = expression(obligation.expression)
        conditions.extend((sympy.Ge(value, obligation.lower), sympy.Le(value, obligation.upper)))
    predicate = linked.predicate.expression
    if type(predicate) is Comparison:
        operators = {"eq": sympy.Eq, "ne": sympy.Ne, "slt": sympy.Lt,
                     "sle": sympy.Le, "sgt": sympy.Gt, "sge": sympy.Ge}
        if predicate.predicate not in operators:
            raise GuardExportDeclined("Unsigned CuTe comparisons need a typed C++ printer")
        condition = operators[predicate.predicate](expression(predicate.left), expression(predicate.right))
    elif type(predicate) is IntExpr and predicate.op == "constant" and predicate.value in (0, 1):
        condition = sympy.true if predicate.value else sympy.false
    else:
        raise GuardExportDeclined("CuTe dispatch predicate has an unsupported exact representation")
    conditions.append(condition if linked.owner.site.arm else sympy.Not(condition))
    expressions = [value for value in parts.exprs if value != "true"]
    for condition in conditions:
        printed = printer.doprint(condition)
        if printed != "true" and printed not in expressions:
            expressions.append(printed)
    bindings = []
    for source, symbol in printer.source_to_symbol.items():
        matches = [row.index for row, original in zip(rows, sources) if source is original]
        if len(matches) != 1 or not symbol.name.isascii() or not symbol.name.isidentifier():
            raise GuardExportDeclined("CuTe predicate lost its original boxed correspondence")
        bindings.append((matches[0], symbol.name))
    declarations = "\n".join(f"  const int64_t {symbol} = int_values[{index}];"
                             for index, (_, symbol) in enumerate(bindings))
    condition = " && ".join(f"({value})" for value in expressions) or "true"
    source = f'''#include <algorithm>
#include <cstdint>
#include <cmath>
#include <c10/util/generic_math.h>
extern "C" int8_t guard(int64_t* int_values, double* float_values) {{
{declarations}
  return {condition};
}}
'''
    library = CppCodeCache.load(source)
    address = ctypes.cast(library.guard, ctypes.c_void_p).value
    if address is None:
        raise GuardExportDeclined("Compiled CuTe guard has no function address")
    return PreparedCuTeGuard(tuple(index for index, _ in bindings), address, library,
                            tuple(expressions), source, linked)
