The smallest next cleanup is confined to
`python/compiler_cute_handoff/policy.py:MixedInstallation._prepare_variant`.
Use `bind_cute_call` for every compiler call, then call
`link_cute_invocations` once after site selection for both one-call and
multiple-call programs. Today the single-call branch uses
`link_cute_invocation`, which constructs a complete program for each candidate
before the predicate chooses the surviving site; the multiple-call branch
already separates binding from stitching.

Keep the single-call provider key `user_cute` and the indexed multiple-call
keys unchanged. Pass the same original envelope, reader projection, trace,
owner, effects and ordinal to each binding. `prepare_guard` already accepts
`BoundCuTeCall`. For one selected guard, use that guard's original registration;
only multiple guards need `combine_guards`. Keep the current tracing call's
default-ordinal compatibility if existing callers require it. This needs no new
helper API or runtime mode.

Preserve these boundaries:

- Site selection still requires exactly one match per original ordinal. Zero
  matches remain a typed decline; ambiguity and unexpected failures propagate.
  Preserve each call's staged-owner slice, pruning, reverse cleanup, failed
  cleanup retention, and ordered native borrows.
- Preserve the complete reader/compiler program comparison and per-destination
  write authority. Do not remove reconstruction in `link_cute_invocations` or
  `_bind_compiler_program` as part of this cleanup, or add it back to repeated
  `_CompilerInvocation.check` calls. Mutable source/provenance checks remain.
- Keep ordinary execution/result identity, source checks around callbacks and
  capture, native publication, exact single-guard registration, and retained
  library ownership. Native hits continue through `_CUDAGraphBoxedDispatch`
  without Python validation.
- Leave standalone `link_cute`, compatibility
  `link_cute_invocation`/`LinkedCuTe`, factory return shapes and the single-call
  destination accessor unchanged.

Use the existing `TestMultipleCuTeRuntime` controls for independent 4/8
predicates, pruning and staged/borrow cleanup; `TestColdDeclines` for ordinary
fallback versus failed cleanup; `TestCompilerProofCheck` and
`TestGeneratedProvenance` for frozen proof/live source boundaries. Add one
focused CPU assertion that the one-call policy path passes the exact prepared
guard registration without invoking `combine_guards`. If fixture interception
must move from `link_cute_invocation` to `bind_cute_call`, retain all original
ownership and failure assertions.

Requalify the existing consolidated CPU297/GPU12 selection, especially one-call
FX/retained, dynamic width, two-call and residual-normalization cases. Compare
program fields, selected owners, outputs, guards, miss/hit counts and lifetimes.
This proposal claims neither less measured latency nor broader eligibility.

This is a source-only proposal against the consolidated qualification2 tree;
no implementation, framework execution or frozen-source change is included.
