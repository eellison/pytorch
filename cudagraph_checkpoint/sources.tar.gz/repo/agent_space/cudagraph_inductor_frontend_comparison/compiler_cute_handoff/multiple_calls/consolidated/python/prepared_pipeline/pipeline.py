"""Cold orchestration for one admitted Inductor, user Triton and CuTe pipeline."""

import ctypes
from dataclasses import dataclass
from threading import Lock
from types import FunctionType, MappingProxyType
import weakref

import torch
from cute_bridge import preparation
from cute_bridge.guard_export import combine_guards, prepare_guard as prepare_cute_guard
from cute_bridge.lowering import link_cute
from cute_bridge.provider import _constant_consumer, CuTeKernelOwner, extract_pointer_effects
from cute_bridge.tracing import trace_cute_host
from cute_dispatch.cache import Authority, ColdCache, PreparedVariant
from cute_dispatch.entry import OrdinaryRun
from cudagraph_cute_runtime.factory import prepare_dispatch_artifact
from entry_signature import build_entry_signature
from fx_adapter.contract import InputContract
from ordinary_artifact_adapter.invocation import normalize_artifact_invocation
from ordinary_artifact_capture.owner import CaptureIneligible, ObservedOrdinaryEntry
from ordinary_artifact_reuse.binding import bind_ordinary_metadata
from ordinary_artifact_reuse.correspondence import join_ordinary_correspondence
from stream_layout import compile_stream_layout
from target_layout import compile_target_layout
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from user_triton.contract import ReplayProgram
from user_triton.guard_export import prepare_guard as prepare_triton_guard
from user_triton.linking import GeneratedProvider, link_user
from user_triton.provider import observe_user_kernel
from user_triton.tracing import _scoped_host, trace_user_host


@dataclass(frozen=True, eq=False)
class _OrdinaryResult:
    inputs: tuple
    result: tuple
    run: OrdinaryRun
    provider: object


class _PipelineCache(ColdCache):
    def __init__(self, pipeline, declines):
        self._pipeline = reference = weakref.ref(pipeline)
        super().__init__(pipeline.authority, lambda box: reference().ordinary(box),
                         lambda box, result: reference().prepare(box, result), declines)

    def _cold(self, box):
        if self.busy:
            raise RuntimeError("Cold cache is busy")
        pipeline = self._pipeline()
        if pipeline is None:
            raise RuntimeError("Prepared pipeline owner is no longer alive")
        try:
            return super()._cold(box)
        finally:
            pipeline._ordinary_result = None


class PreparedPipeline:
    """Own cold misses and local variants within one caller-owned validity generation.

    The caller admits inputs through the original outer guards and serializes
    dependency changes with invalidate(). Either frontend may supply the prefix
    program. Keep this owner alive while using its native dispatcher directly.
    """

    def __init__(self, authority, prefix_program, generated_providers, boxed_wrapper, *,
                 triton_host, triton_jit, cute_host, cute_entry, cute_kernel,
                 signature_policy, tensor_policies, arch, prefix_output_index=0,
                 triton_key="user_triton", cute_key="user_cute", declines=(UnsupportedCapture,)):
        if type(declines) is not tuple or any(
                not isinstance(kind, type) or not issubclass(kind, Exception) for kind in declines):
            raise TypeError("Expected a tuple of typed preparation declines")
        if (type(authority) is not Authority or type(authority.contract) is not InputContract
                or type(prefix_program) is not ReplayProgram or type(boxed_wrapper) is not FunctionType
                or type(generated_providers) is not dict or not generated_providers
                or any(type(key) is not str or type(value) is not GeneratedProvider
                       for key, value in generated_providers.items())
                or type(triton_host) is not FunctionType or type(cute_host) is not FunctionType
                or type(arch) is not str or not arch
                or type(prefix_output_index) is not int
                or not 0 <= prefix_output_index < len(prefix_program.outputs)
                or type(triton_key) is not str or not triton_key or type(cute_key) is not str or not cute_key
                or triton_key == cute_key or {triton_key, cute_key} & generated_providers.keys()):
            raise TypeError("Expected an original authority, generated prefix and explicit host composition")
        contract = authority.contract
        if (prefix_program.device_index != contract.device_index
                or len(prefix_program.input_names) != len(contract.kinds)
                or {row.boxed_index for row in prefix_program.integer_inputs}
                != {row.index for row in contract.integer_ranges}
                or {call.provider_key for call in prefix_program.calls} != generated_providers.keys()
                or authority.artifact.current_callable is not boxed_wrapper):
            raise ValueError("Prefix program differs from its original boxed compiler boundary")
        self.authority, self.prefix_program, self.boxed_wrapper = authority, prefix_program, boxed_wrapper
        self.generated_providers = MappingProxyType(dict(generated_providers))
        self.triton_host, self.triton_jit, self.cute_host = triton_host, triton_jit, cute_host
        self.arch, self.prefix_output_index = arch, prefix_output_index
        self.triton_key, self.cute_key = triton_key, cute_key
        self._wrapper_code = boxed_wrapper.__code__
        _, self._triton_dependencies = _scoped_host(triton_host, triton_jit)
        self._cute_dependencies = None
        self._ordinary_result = None
        self._user_provider = None
        self._pending_entry = None
        self._pending_owner = None
        self._pending_owners = []
        self._closed = False
        self._lock = Lock()
        self.cache = _PipelineCache(self, (*declines, CaptureIneligible))
        self.ordinary_entry = ObservedOrdinaryEntry(cute_entry, cute_kernel, policy=signature_policy,
                                                   tensor_policies=tensor_policies)
        self._identity = (authority, prefix_program, boxed_wrapper, self.generated_providers,
                          triton_host, triton_jit, cute_host, self.ordinary_entry, arch,
                          prefix_output_index, triton_key, cute_key)
        self._check_cold()

    @property
    def dispatcher(self):
        return self.cache.dispatcher

    @property
    def user_provider(self):
        return self._user_provider

    @property
    def closed(self):
        return self._closed

    def _check_cold(self):
        current = (self.authority, self.prefix_program, self.boxed_wrapper, self.generated_providers,
                   self.triton_host, self.triton_jit, self.cute_host, self.ordinary_entry, self.arch,
                   self.prefix_output_index, self.triton_key, self.cute_key)
        if (self._closed or self.cache.closed or self.cache.failed
                or any(value is not old for value, old in zip(current, self._identity))
                or self.cache.authority is not self.authority
                or self.authority.artifact.current_callable is not self.boxed_wrapper
                or self.boxed_wrapper.__code__ is not self._wrapper_code):
            raise RuntimeError("Prepared pipeline is closed, failed or outside its original authority")
        dependencies = self._triton_dependencies
        if (any(namespace.get(name) is not value for namespace, name, value in dependencies.references)
                or dependencies.host.__code__ is not dependencies.code
                or any(function.__code__ is not code for function, code in dependencies.code_objects)):
            raise RuntimeError("User host dependencies changed within the prepared generation")
        for key, provider in self.generated_providers.items():
            if self.boxed_wrapper.__globals__.get(key) is not provider.selection.identity[0]:
                raise RuntimeError("Generated provider lost its original wrapper global")
            provider.check()
        if self._user_provider is not None:
            self._user_provider.check()
        if self._cute_dependencies is not None:
            self._cute_dependencies.check()
        self.ordinary_entry.check()

    def ordinary(self, box):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Prepared pipeline is busy")
        try:
            self._ordinary_result = None
            self._check_cold()
            if type(box) is not list or len(box) != len(self.prefix_program.input_names):
                raise TypeError("Ordinary execution requires the admitted original boxed list")
            inputs = tuple(box)
            prefix = self.boxed_wrapper(box)
            if type(prefix) is not tuple or len(prefix) != len(self.prefix_program.outputs):
                raise RuntimeError("Ordinary prefix output order differs from its supplied program")
            source = prefix[self.prefix_output_index]
            if self._user_provider is None:
                with observe_user_kernel(self.triton_jit, device_index=self.authority.contract.device_index) as observation:
                    user_output = self.triton_host(source)
                self._user_provider = observation.own()
            else:
                user_output = self.triton_host(source)
            run = self.ordinary_entry.run(self.cute_host, user_output)
            if type(user_output) is not torch.Tensor or type(run.outputs) is not torch.Tensor:
                raise RuntimeError("The declared user hosts must each return one Tensor")
            if self._cute_dependencies is None:
                self._cute_dependencies = run.dependencies
            self._check_cold()
            result = (*prefix, user_output, run.outputs)
            self._ordinary_result = _OrdinaryResult(inputs, result, run, self._user_provider)
            return result
        finally:
            self._lock.release()

    def _discard_staged(self):
        if self._pending_entry is not None:
            self._pending_entry.close()
            self._pending_entry = None
        if self._pending_owner is not None:
            self._pending_owner.close()
            self._pending_owner = None
        while self._pending_owners:
            self._pending_owners[-1].close()
            self._pending_owners.pop()

    def _prepare_artifact(self, signature):
        compilation = self.ordinary_entry.compilation()
        bound = bind_ordinary_metadata(signature, compilation)
        invocation = normalize_artifact_invocation(join_ordinary_correspondence(bound))
        if invocation.program.arch != self.arch:
            raise ValueError("Ordinary compilation target differs from the prepared pipeline authority")
        target = compile_target_layout(invocation.plan)
        stream_target = compile_stream_layout(invocation.formals, invocation.stream_source_index)
        artifact = prepare_dispatch_artifact(invocation, target, stream_target)
        return invocation, artifact

    def prepare(self, box, result):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Prepared pipeline is busy")
        try:
            self._check_cold()
            observed = self._ordinary_result
            if (observed is None or result is not observed.result or observed.provider is not self._user_provider
                    or type(box) is not list
                    or len(box) != len(observed.inputs)
                    or any(value is not old for value, old in zip(box, observed.inputs))
                    or self._pending_entry is not None or self._pending_owner is not None or self._pending_owners):
                raise RuntimeError("Preparation requires its exact ordinary result and original inputs")
            observed.run.check()
            inputs, contract = observed.inputs, self.authority.contract
            user_trace = trace_user_host(self.triton_host, self.triton_jit, self._user_provider,
                contract, inputs, self.prefix_program.outputs[self.prefix_output_index])
            user_program = link_user(self.prefix_program, user_trace, self._user_provider, provider_key=self.triton_key)
            user_guard = prepare_triton_guard(user_trace)
            cute_trace = trace_cute_host(self.cute_host, self.ordinary_entry.entry,
                                        contract, inputs, user_program.outputs[-1])
            signature = build_entry_signature(cute_trace, cute_trace.calls[0], policy=self.ordinary_entry.policy)
            invocation, artifact = self._prepare_artifact(signature)
            candidates = []
            for site in artifact.sites:
                block = tuple(_constant_consumer(artifact, site, "block", axis) for axis in range(3))
                shared = _constant_consumer(artifact, site, "shared", 0)
                self._pending_owner = CuTeKernelOwner(artifact, site, stream=torch.cuda.current_stream().cuda_stream,
                                                      block=block, shared=shared)
                owner = self._pending_owner
                self._pending_owners.append(owner)
                self._pending_owner = None
                effects = extract_pointer_effects(invocation, artifact, site)
                linked = link_cute(user_program, cute_trace, owner, effects, provider_key=self.cute_key)
                guard = combine_guards((user_guard, prepare_cute_guard(linked)))
                indices, address, _ = guard.registration
                values = tuple(inputs[index] for index in indices)
                if any(type(value) is not int or not -(2 ** 63) <= value < 2 ** 63 for value in values):
                    raise ValueError("Compiled predicate inputs must be exact signed int64 values")
                predicate = ctypes.CFUNCTYPE(ctypes.c_int8, ctypes.POINTER(ctypes.c_int64),
                                            ctypes.POINTER(ctypes.c_double))(address)
                matches = predicate((ctypes.c_int64 * len(values))(*values), None)
                if matches not in (0, 1):
                    raise RuntimeError("Compiled local predicate did not return zero or one")
                if matches:
                    candidates.append((owner, linked, guard))
            if len(candidates) != 1:
                raise RuntimeError("Expected exactly one compiler-selected CuTe site")
            owner, linked, guard = candidates[0]
            for staged in tuple(self._pending_owners):
                if staged is not owner:
                    try:
                        staged.close()
                    except BaseException as error:
                        self.cache._fail(error)
                        raise
                    self._pending_owners.remove(staged)
            providers = {**self.generated_providers, self.triton_key: self._user_provider, self.cute_key: owner}
            self._check_cold()
            self._pending_entry = preparation.prepare_variant(linked.program, providers, inputs)
            self._check_cold()
            candidate = PreparedVariant(self.authority, self._pending_entry, guard.registration,
                                        tuple(self._pending_owners))
            self._pending_entry = None
            self._pending_owners.clear()
            return candidate
        except BaseException as error:
            if self.cache.failed:
                raise
            try:
                self._discard_staged()
            except BaseException as cleanup:
                self.cache._fail(cleanup)
                cleanup.add_note(f"Cold preparation also failed: {error!r}")
                raise cleanup from error
            raise
        finally:
            self._ordinary_result = None
            self._lock.release()

    def bootstrap(self, box):
        return self.cache.bootstrap(box)

    def invalidate(self):
        self.cache.invalidate()

    def close(self):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Prepared pipeline is busy")
        if self.cache.busy:
            self._lock.release()
            raise RuntimeError("Cold cache is busy")
        try:
            if self._closed:
                return
            try:
                self.cache.close()
                self._discard_staged()
                if self._user_provider is not None:
                    self._user_provider.close()
                self.ordinary_entry.close()
            except BaseException as error:
                self.cache._fail(error)
                raise
            self._closed = True
        finally:
            self._ordinary_result = None
            self._lock.release()
