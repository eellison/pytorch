"""CuTe logical invocation alongside the existing neutral compiler events."""

from dataclasses import dataclass
from typing import TYPE_CHECKING

from torch._inductor.runtime.cudagraph_boxed_replay import _PhysicalCall
from user_triton.contract import Invocation, ReplayProgram

if TYPE_CHECKING:
    from .provider import CuTeKernelOwner, SitePointerEffects


@dataclass(frozen=True)
class CuTeInvocation:
    provider_key: str
    provider_identity: "CuTeKernelOwner"
    bound: _PhysicalCall
    effects: "SitePointerEffects"


@dataclass(frozen=True)
class MixedProgram(ReplayProgram):
    @property
    def calls(self):
        return tuple(event for event in self.events if type(event) in (Invocation, CuTeInvocation))
