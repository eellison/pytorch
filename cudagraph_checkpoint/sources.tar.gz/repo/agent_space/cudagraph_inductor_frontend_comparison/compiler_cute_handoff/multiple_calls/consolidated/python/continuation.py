from __future__ import annotations

import inspect
import re
from dataclasses import dataclass, field, replace
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from accessors import _function, _tagged_arguments
from cfg_values import CFGProgram, read_cfg_function
from compiler_boundary import _snapshot
from compiler_owner import TaggedProgram, _TaggedCollector
from dispatch_join import JoinedDispatch, join_dispatch
from entry_signature import snapshot_metadata
from frontend import _TRACE_LOCK
from helpers import DispatchHelpers, DispatchScalarHelper, ScalarRequest, emit_dispatch_helpers
from launch_events import CloneBundle
from lowering import bind_host_formals
from mapping import bind_dispatch_sites
from source_dispatch import SourceLaunchSite, check_dispatch_source


CONTINUATION_VERSION = 1


def _uses(source: Any) -> tuple[tuple[Any, str, int, Any], ...]:
    uses = [(None, "predicate", 0, source.predicate)]
    for site in source.sites:
        for role, values in (("grid", site.grid), ("block", site.block_dims), ("shared", (site.shared,)),
                             ("diagnostic", tuple(item.predicate for item in site.diagnostics)),
                             ("kernel_smem", (site.diagnostics[0].kernel_query.results[0],))):
            uses.extend((site, role, index, value) for index, value in enumerate(values))
    return tuple(uses)


def _metadata_signature(metadata: Any) -> tuple[Any, ...]:
    return metadata.symbol_name, metadata.params, metadata.symbols, metadata.ret


class _DispatchCollector(_TaggedCollector):
    def __init__(self, owner: Any, signature: Any, arguments: tuple[Any, ...], keywords: dict[str, Any]) -> None:
        super().__init__(owner)
        self.signature = signature
        self.arguments = arguments
        self.keywords = keywords
        self.helpers: DispatchHelpers | None = None
        self.original_text = ""
        self.original_bytecode = b""

    def __call__(self, owner: Any, module: Any, function_name: str) -> None:
        from cutlass._mlir import ir
        from cutlass.cute.metadata import build_function_metadata

        super().__call__(owner, module, function_name)
        metadata = build_function_metadata(function_name=function_name, signature=self.signature,
                                           args=self.arguments, kwonlyargs=self.keywords)
        with module.context, ir.raw_values():
            self.original_text, self.original_bytecode = _snapshot(module)
            source = check_dispatch_source(module, function_name, snapshot_metadata(metadata))
            prefix = "__cudagraph_dispatch_" + sha256(function_name.encode()).hexdigest()[:16]
            requests = tuple(ScalarRequest(f"{prefix}_{number}", role, index, value, site)
                             for number, (site, role, index, value) in enumerate(_uses(source)))
            self.helpers = emit_dispatch_helpers(source, requests)
            self.text, self.bytecode = _snapshot(module)


@dataclass(frozen=True)
class BoundDispatchHelper:
    joined: JoinedDispatch = field(repr=False)
    helper: DispatchScalarHelper = field(repr=False)
    site: SourceLaunchSite | None = field(repr=False)
    role: str
    index: int
    source_value: Any = field(repr=False)
    cfg: CFGProgram = field(repr=False)
    source_order: tuple[int, ...]
    _seal: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        return (id(self.joined), id(self.helper), id(self.site), self.role, self.index,
                id(self.source_value), id(self.cfg), self.source_order)

    def check(self) -> None:
        if self._state() != self._seal:
            raise RuntimeError("Dispatch helper consumer ownership changed")
        joined = self.joined
        joined.check()
        self._check_body(joined)

    def _check_body(self, joined: JoinedDispatch) -> None:
        from cutlass._mlir import ir

        if self.joined is not joined or self._state() != self._seal:
            raise RuntimeError("Dispatch helper consumer ownership changed")
        self.helper.check()
        self.cfg.check()
        source = joined.admission.source
        program = joined.mapping.program
        helper = self.helper
        if (helper.module is not program.source_module or self.cfg.module is not program.module
                or self.cfg.context is not program.context or helper.symbol != self.cfg.function_name
                or (helper.result_type,) != self.cfg.result_types
                or helper.role != self.role or helper.index != self.index
                or helper.source.host != source.host or helper.input_origin != source.arguments
                or helper.source_types != source.source_types
                or _metadata_signature(helper.source.metadata) != _metadata_signature(source.metadata)):
            raise ValueError("Compiled helper differs from its actual source owner, signature or result")
        if self.site is None:
            if helper.site is not None:
                raise ValueError("Root predicate helper changed its source scope")
        elif (not any(self.site is site for site in source.sites) or helper.site is None
                or helper.site.launch != self.site.launch or helper.site.kernel != self.site.kernel
                or helper.site.callee != self.site.callee):
            raise ValueError("Compiled helper changed its exact dispatch arm")
        with program.source_context, ir.raw_values():
            matches = [value for site, role, index, value in _uses(source)
                       if site is self.site and role == self.role and index == self.index]
            if len(matches) != 1 or matches[0] != self.source_value or helper.output_value != self.source_value:
                raise ValueError("Helper label does not identify its exact original consumer SSA value")
            original = _tagged_arguments(source.host)
            helper_arguments = _tagged_arguments(helper.operation)
            if (tuple(helper_arguments) != helper.source_ids or set(helper_arguments) != set(original)
                    or any(helper_arguments[index].type != original[index].type for index in original)):
                raise ValueError("Source helper changed an original formal ID or type")
        with program.context, ir.raw_values():
            host = _tagged_arguments(_function(program.module, program.function_name, "llvm.func"))
            lowered = _tagged_arguments(_function(program.module, helper.symbol, "llvm.func"))
            if (set(lowered) != set(host) or set(lowered) != set(helper.source_ids)
                    or tuple(lowered) != self.source_order
                    or tuple(str(value.type) for value in lowered.values()) != self.cfg.argument_types
                    or any(lowered[index].type != host[index].type for index in host)):
                raise ValueError("Lowered helper lost its original formal IDs or exact LLVM types")


def check_dispatch_consumers(joined: JoinedDispatch, consumers: tuple[BoundDispatchHelper, ...]) -> None:
    if (type(joined) is not JoinedDispatch or type(consumers) is not tuple
            or any(type(consumer) is not BoundDispatchHelper for consumer in consumers)):
        raise TypeError("Expected an exact joined dispatch and consumer tuple")
    if any(type(consumer.helper) is not DispatchScalarHelper or type(consumer.cfg) is not CFGProgram
           for consumer in consumers):
        raise TypeError("Expected exact scalar helper and CFG owners")
    seals = tuple(consumer._seal for consumer in consumers)
    joined.check()
    for consumer in consumers:
        BoundDispatchHelper._check_body(consumer, joined)
    joined.check()
    for consumer, seal in zip(consumers, seals):
        if consumer.joined is not joined or consumer._seal is not seal or consumer._state() != seal:
            raise RuntimeError("Dispatch helper consumer ownership changed")


def bind_dispatch_consumers(joined: JoinedDispatch, helpers: DispatchHelpers) -> tuple[BoundDispatchHelper, ...]:
    from cutlass._mlir import ir

    if type(joined) is not JoinedDispatch or type(helpers) is not DispatchHelpers:
        raise TypeError("Expected owned source/compiled dispatch and emitted helpers")
    joined.check()
    helpers.check()
    source, program = joined.admission.source, joined.mapping.program
    if helpers.source.module is not program.source_module or helpers.source.host != source.host:
        raise ValueError("Helpers belong to a different original source Module")
    bound, used = [], set()
    with program.context, ir.raw_values():
        for helper in helpers.helpers:
            site = None
            if helper.site is not None:
                matches = [item for item in source.sites if item.launch == helper.site.launch]
                if len(matches) != 1:
                    raise ValueError("Helper scope does not identify an admitted source site")
                site = matches[0]
            key = (None if site is None else site.arm, helper.role, helper.index)
            if key in used:
                raise ValueError("Duplicate helper for an original scalar consumer")
            used.add(key)
            cfg = read_cfg_function(program.module, helper.symbol)
            order = tuple(_tagged_arguments(_function(program.module, helper.symbol, "llvm.func")))
            item = BoundDispatchHelper(joined, helper, site, helper.role, helper.index, helper.output_value, cfg, order, ())
            item = replace(item, _seal=item._state())
            item.check()
            bound.append(item)
    with program.source_context, ir.raw_values():
        expected = {(None if site is None else site.arm, role, index) for site, role, index, _ in _uses(source)}
    if used != expected:
        raise ValueError("Dispatch helpers lack complete original consumer coverage")
    return tuple(bound)


@dataclass(frozen=True)
class DispatchCompilation:
    program: TaggedProgram
    helpers: DispatchHelpers
    joined: JoinedDispatch
    consumers: tuple[BoundDispatchHelper, ...]
    original_text: str = field(repr=False)
    original_bytecode: bytes = field(repr=False)
    _owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        from cutlass._mlir import ir

        owned = self.program, self.helpers, self.joined, self.consumers, self.original_text, self.original_bytecode
        if len(owned) != len(self._owners) or any(actual is not owner for actual, owner in zip(owned, self._owners)):
            raise RuntimeError("Dispatch compilation ownership changed")
        self.program.check()
        self.helpers.check()
        self.joined.check()
        if (type(self.program) is not TaggedProgram or self.joined.mapping.program is not self.program
                or self.helpers.source.module is not self.program.source_module
                or len(self.consumers) != len(self.helpers.helpers)):
            raise ValueError("Dispatch compilation lost its actual compiler or helper owner")
        seen = set()
        with self.program.source_context, ir.raw_values():
            expected = {(None if site is None else site.arm, role, index)
                        for site, role, index, _ in _uses(self.joined.admission.source)}
        for bound, helper in zip(self.consumers, self.helpers.helpers):
            if bound.joined is not self.joined or bound.helper is not helper:
                raise ValueError("Bound dispatch helper changed its collection owner")
            bound.check()
            seen.add((None if bound.site is None else bound.site.arm, bound.role, bound.index))
        if seen != expected or len(seen) != len(self.consumers):
            raise ValueError("Dispatch compilation lost complete scalar consumer coverage")


def compile_dispatch_program(host: Any, kernel: Any, *arguments: Any, arch: str = "sm_80", **keywords: Any) -> DispatchCompilation:
    import cutlass.compiler as compiler
    import cutlass.cute as cute
    from cutlass._mlir import ir
    from cutlass.cutlass_dsl.cutlass import CuTeDSL

    if version("nvidia-cutlass-dsl") != "4.6.2" or type(arch) is not str or re.fullmatch(r"sm_[0-9]+[af]?", arch) is None:
        raise ValueError("Expected CuTe 4.6.2 and an explicit supported architecture spelling")
    if ir.Context.current is not None or not _TRACE_LOCK.acquire(blocking=False):
        raise RuntimeError("Dispatch compilation requires an isolated frontend context")
    try:
        bundle = CloneBundle.create(host, kernel)
        dsl = CuTeDSL._get_dsl()
        if (type(dsl) is not CuTeDSL or dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get()
                or dsl.envar.keep_ir_clean):
            raise RuntimeError("Dispatch compilation requires the standard isolated frontend")
        collector = _DispatchCollector(dsl, inspect.signature(bundle.original_host.__wrapped__), arguments, keywords)
        try:
            source = cute.compile.to_precompiled_mlir(bundle.host, *arguments, **keywords, options=f"--gpu-arch {arch}",
                no_jit_engine=True, trace_finalize_hooks=collector)
        finally:
            bundle.check_originals()
            if dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get():
                raise RuntimeError("Frontend hook scope was not restored")
        if (collector.calls != 1 or collector.helpers is None or type(source) is not compiler.PreCompiledMlirArtifact
                or source.is_consumed or source.get_bitcode() != collector.bytecode):
            raise RuntimeError("Helpers do not belong to the actual frontend artifact")
        names = tuple(metadata.symbol_name for metadata in source.metadata)
        if names != (collector.function_name,):
            raise ValueError("Frontend artifact metadata does not identify the original host")
        actual = snapshot_metadata(source.metadata[0])
        if _metadata_signature(actual) != _metadata_signature(collector.helpers.source.metadata):
            raise ValueError("Actual frontend signature metadata differs from helper source admission")
        collector.helpers.check()
    finally:
        _TRACE_LOCK.release()
    serialized = compiler.serialize_compilation_artifact(source)
    snapshot = compiler.deserialize_compilation_artifact(serialized)
    if (type(snapshot) is not compiler.PreCompiledMlirArtifact or snapshot.is_consumed
            or snapshot.get_bitcode() != collector.bytecode or compiler.serialize_compilation_artifact(snapshot) != serialized):
        raise RuntimeError("Owned metadata snapshot differs from the genuine frontend artifact")
    metadata = tuple(snapshot.metadata)
    native = compiler.CuteCompiler()
    native.set_device_target(arch)
    native.set_host_target(compiler.Compiler.detect_host_triple())
    native.set_abi(compiler.Abi.CutlassCall)
    compiled = native.compile_to(source, compiler.ArtifactType.CompiledMlir)
    if (not source.is_consumed or type(compiled) is not compiler.CompiledMlirArtifact or compiled.is_consumed
            or tuple(item.symbol_name for item in compiled.metadata) != names):
        raise RuntimeError("Expected genuine compiled continuation of the helper-bearing source")
    bytecode = compiled.get_bitcode()
    context = ir.Context()
    with context, ir.Location.unknown(), ir.raw_values():
        module = ir.Module.parse(bytecode)
        if not module.operation.verify():
            raise RuntimeError("Compiled dispatch Module failed verification")
        text, module_bytecode = _snapshot(module)
    program = TaggedProgram(bundle, collector.module, collector.context, source, collector.text, collector.bytecode,
        compiled, module, context, bytecode, text, module_bytecode, collector.function_name, arch,
        sha256(collector.bytecode).hexdigest(), sha256(bytecode).hexdigest(), snapshot, metadata, serialized,
        compiler.serialize_compilation_artifact(compiled), (snapshot, metadata))
    program.check()
    formals = bind_host_formals(program, metadata[0], collector.helpers.source.source_types)
    joined = join_dispatch(bind_dispatch_sites(program, formals))
    consumers = bind_dispatch_consumers(joined, collector.helpers)
    owners = program, collector.helpers, joined, consumers, collector.original_text, collector.original_bytecode
    result = DispatchCompilation(*owners, owners)
    result.check()
    return result
