"""Cold ownership of one exact CuTe site and its aggregate CUDA parameters."""

from __future__ import annotations

import ctypes
import math
from contextlib import contextmanager
from dataclasses import dataclass
from threading import Lock

from cuda.bindings import driver
from cudagraph_cute_runtime.artifact import ArtifactSite, DispatchArtifact, FieldSource
from cudagraph_cute_runtime.loading import ArtifactKernels
from ordinary_artifact_adapter.invocation import ArtifactInvocation, normalize_artifact_invocation
from torch._inductor.runtime.cudagraph_boxed_replay import _KernelModule
from torch.cuda._utils import _check_cuda_bindings


class ProviderDeclined(ValueError):
    pass


def _constant_consumer(artifact, site, role, index):
    from values import ScalarValue

    matches = [artifact.consumers[number] for number in site.consumer_ids
               if (artifact.consumers[number].role, artifact.consumers[number].index) == (role, index)]
    if len(matches) != 1:
        raise ProviderDeclined("The selected site lacks one exact launch consumer")
    consumer, = matches
    numeric = consumer.numeric
    numeric.check()
    cfg = numeric._cfg
    if (consumer.site_id != site.site_id or consumer.source_order != numeric.source_order
            or cfg.result_types != (consumer.result_type,) or len(cfg.blocks) != 1):
        raise ProviderDeclined("Fixed launch fields require a single constant-return consumer")
    block, = cfg.blocks
    if block.terminator.kind != "return" or len(block.terminator.values) != 1 or block.terminator.edges:
        raise ProviderDeclined("Fixed launch fields cannot depend on control flow")
    constants = {}
    for instruction in block.instructions:
        flow = instruction.expression
        if (flow.kind != "constant" or flow.argument is not None or flow.path or flow.operands
                or flow.constant is None or flow.predicate is not None):
            raise ProviderDeclined("Fixed launch fields must be compiler literals, independent of inputs")
        typ, data, size = flow.constant
        if typ not in ("i1", "i32", "i64") or typ != flow.llvm_type:
            raise ProviderDeclined("Unsupported fixed launch constant type")
        value = ScalarValue(typ, int.from_bytes(data, "little"), size)
        if value.data() != data:
            raise ProviderDeclined("Fixed launch constant lost its exact compiler bytes")
        constants[instruction.result] = value
    value = constants.get(block.terminator.values[0])
    if value is None or value.llvm_type != consumer.result_type:
        raise ProviderDeclined("Fixed launch return is not a compiler constant")
    return value.integer(signed=consumer.result_type != "i1")


@dataclass(frozen=True)
class PointerEffect:
    parameter: int
    byte_offset: int
    source: FieldSource
    device_formal: int
    ir_type: str
    required_alignment: int
    read: bool
    written: bool


class SitePointerEffects:
    __slots__ = ("_artifact", "_site", "_fields", "_seal")

    def __new__(cls):
        raise TypeError("SitePointerEffects must be created by extract_pointer_effects")

    def __setattr__(self, name, value):
        raise AttributeError("CuTe pointer-effect provenance is immutable")

    @property
    def artifact(self):
        return self._artifact

    @property
    def site(self):
        return self._site

    @property
    def fields(self):
        return self._fields

    def check(self):
        state = self._artifact, self._site, self._fields
        if (type(self) is not SitePointerEffects or type(self._seal) is not tuple
                or len(state) != len(self._seal)
                or any(actual is not old for actual, old in zip(state, self._seal))):
            raise RuntimeError("CuTe pointer-effect provenance changed")
        self._artifact.check_site(self._site)


def extract_pointer_effects(entry, artifact, site) -> SitePointerEffects:
    from cutlass._mlir import ir
    from entry import DispatchEntry
    from .readonly_analysis import _inspect_kernel, _Unsupported

    if type(entry) not in (DispatchEntry, ArtifactInvocation) or type(artifact) is not DispatchArtifact:
        raise ProviderDeclined("Pointer effects require the original compiler entry and its artifact")
    invocation = normalize_artifact_invocation(entry)
    artifact.check_site(site)
    program = invocation.program
    if (artifact.signature is not invocation.signature
            or artifact.source_sha256 != invocation.source_sha256
            or artifact.compiled_sha256 != invocation.compiled_sha256
            or artifact.function_name != program.function_name or artifact.arch != program.arch
            or not 0 <= site.site_id < len(invocation.joined.sites)):
        raise ProviderDeclined("Pointer effects belong to another compiler artifact")
    bound = invocation.joined.sites[site.site_id]
    source, compiled = bound.source, bound.compiled
    registration = compiled.launch.registration
    if (source.arm is not site.arm or source.callee != site.callee
            or compiled.launch.index != site.launch_index
            or tuple(getattr(registration, name) for name in site.registration._fields) != tuple(site.registration)
            or len(compiled.parameters) != len(site.parameters)):
        raise ProviderDeclined("Pointer effects lost the exact selected launch registration")
    with program.source_context, ir.raw_values():
        shared = _constant_consumer(artifact, site, "shared", 0)
        try:
            formals = _inspect_kernel(source.kernel, module=program.source_module, configured_smem=shared)
        except _Unsupported as error:
            raise ProviderDeclined(str(error)) from error
        by_formal = {row.ir_index: row for row in formals}
        parameters = {row.device_parameter_index: row for row in compiled.parameters}
        if len(by_formal) != len(formals) or len(parameters) != len(compiled.parameters):
            raise ProviderDeclined("Ambiguous device-formal or aggregate parameter correspondence")
        result, used = [], set()
        for field in site.fields.pointers:
            binding = parameters.get(field.parameter)
            if binding is None or not 0 <= field.parameter < len(site.parameters):
                raise ProviderDeclined("Pointer field has no actual compiled parameter")
            parameter = site.parameters[field.parameter]
            row = by_formal.get(binding.source_parameter_index)
            if (row is None or row.ir_index in used or type(row.read) is not bool or type(row.written) is not bool
                    or row.ir_type != source.argument_types[binding.source_parameter_index]
                    or parameter.index != binding.device_parameter_index
                    or parameter.source_arg_index != binding.formal.ir_arg_index
                    or parameter.llvm_arg_index != binding.formal.llvm_arg_index
                    or parameter.llvm_type != binding.parameter.llvm_type
                    or binding.parameter is not compiled.launch.parameters[field.parameter]
                    or source.arguments[binding.source_parameter_index] != binding.source_value
                    or field.source.ir_arg_index != binding.formal.ir_arg_index):
                raise ProviderDeclined("Pointer effects lost their exact source-to-device correspondence")
            formal, = (item for item in artifact.formals if item.source_arg_index == parameter.source_arg_index)
            leaves = [leaf for leaf in formal.leaves if leaf.path == field.source.component_path]
            if (len(leaves) != 1 or field.source.kind != "tensor_property"
                    or field.source.formal_name != formal.name or field.source.metadata_path != formal.metadata_path
                    or field.source.property != "pointer" or field.source.property_path
                    or leaves[0].property != "pointer" or leaves[0].property_path
                    or leaves[0].llvm_type != field.source.llvm_type or leaves[0].size != 8
                    or leaves[0].offset != field.byte_offset):
                raise ProviderDeclined("Pointer field lost its compiler aggregate leaf")
            used.add(row.ir_index)
            result.append(PointerEffect(field.parameter, field.byte_offset, field.source, row.ir_index,
                                        row.ir_type, row.required_alignment, row.read, row.written))
        if used != set(by_formal):
            raise ProviderDeclined("Copied pointer fields do not cover the selected device effects")
    invocation.check()
    artifact.check_site(site)
    fields = tuple(result)
    certificate = object.__new__(SitePointerEffects)
    object.__setattr__(certificate, "_artifact", artifact)
    object.__setattr__(certificate, "_site", site)
    object.__setattr__(certificate, "_fields", fields)
    object.__setattr__(certificate, "_seal", (artifact, site, fields))
    certificate.check()
    return certificate


# Checked close is explicit; failed releases retain both the token and its code.
_OPEN_OWNERS: list[CuTeKernelOwner] = []
_FAILED_BORROWS: list[_CuTeGraphBorrow] = []


class _CuTeGraphBorrow:
    __slots__ = ("_owner", "_token")

    def __init__(self, owner, token):
        self._owner, self._token = owner, token

    def __del__(self):
        owner = getattr(self, "_owner", None)
        if owner is None:
            return
        try:
            owner._release_graph(self._token)
        except BaseException:
            _FAILED_BORROWS.append(self)
        else:
            self._owner = None
            self._token = None

    def __reduce_ex__(self, protocol):
        raise TypeError("CuTe graph borrows cannot be copied or serialized")


class CuTeKernelOwner(_KernelModule):
    def __init__(self, artifact: DispatchArtifact, site: ArtifactSite, *, stream: int,
                 block: tuple[int, int, int], shared: int):
        if type(artifact) is not DispatchArtifact:
            raise ProviderDeclined("CuTe ownership requires a factory-produced dispatch artifact")
        artifact.check_site(site)
        if (type(block) is not tuple or len(block) != 3 or any(type(value) is not int or value <= 0 for value in block)
                or type(shared) is not int or not 0 <= shared < 2**32):
            raise ProviderDeclined("Expected a positive fixed block and nonnegative fixed shared bytes")
        if (tuple(_constant_consumer(artifact, site, "block", axis) for axis in range(3)) != block
                or _constant_consumer(artifact, site, "shared", 0) != shared):
            raise ProviderDeclined("Fixed launch fields differ from the exact compiler consumers")
        if not 0 <= _constant_consumer(artifact, site, "kernel_smem", 0) <= shared:
            raise ProviderDeclined("Fixed shared bytes do not cover the compiler kernel requirement")
        for index, diagnostic in enumerate(site.diagnostics):
            if _constant_consumer(artifact, site, "diagnostic", index) != int(diagnostic.expected):
                raise ProviderDeclined("The compiler shared-memory diagnostic rejects this launch")
        self._artifact, self._site = artifact, site
        self._block, self._shared = block, shared
        self._lock = Lock()
        self._phase = "loading"
        self._kernel = None
        self._loader = ArtifactKernels(artifact, stream=stream)
        self._owners = self._state()
        _OPEN_OWNERS.append(self)
        try:
            self._kernel, = (kernel for original, kernel in self._loader._kernels if original is site)
            limits = self._loader.limits
            if (any(value > limit for value, limit in zip(block, limits.block))
                    or math.prod(block) > min(self._kernel.max_threads, limits.threads)
                    or shared > self._kernel.max_dynamic_shared):
                raise ProviderDeclined("Fixed launch fields exceed the loaded device resources")
            self._phase = "ready"
            self._owners = self._state()
            self.check()
        except BaseException as error:
            self._phase = "failed"
            self._owners = self._state()
            try:
                self.close()
            except BaseException as cleanup:
                error.add_note(f"CuTe owner retained after cleanup failed: {cleanup}")
            raise

    @property
    def artifact(self):
        return self._artifact

    @property
    def site(self):
        return self._site

    @property
    def function(self) -> int:
        if self._phase != "ready":
            raise RuntimeError("CuTe kernel owner is closed or failed")
        return self._kernel.function

    @property
    def parameter_sizes(self):
        return self._site.fields.parameter_sizes

    @property
    def parameter_layout(self):
        return self._kernel.parameter_layout

    @property
    def block(self):
        return self._block

    @property
    def shared(self):
        return self._shared

    @property
    def closed(self):
        return self._phase == "closed"

    def _state(self):
        return self._artifact, self._site, self._block, self._shared, self._lock, self._loader, self._kernel

    def _check_owners(self):
        state = self._state()
        if len(state) != len(self._owners) or any(actual is not old for actual, old in zip(state, self._owners)):
            raise RuntimeError("CuTe kernel owner identity changed")

    @contextmanager
    def _locked(self):
        lock = self._lock
        if not lock.acquire(blocking=False):
            raise RuntimeError("CuTe kernel owner is busy or reentrant")
        try:
            self._check_owners()
            yield
        finally:
            lock.release()

    def _ready(self):
        if self._phase != "ready":
            raise RuntimeError("CuTe kernel owner is closed or failed")

    def check(self):
        with self._locked():
            self._ready()
            self._loader.check()

    def _borrow_for_cudagraph(self):
        with self._locked():
            self._ready()
            token = self._loader.acquire_graph()
            try:
                return _CuTeGraphBorrow(self, token)
            except BaseException as error:
                try:
                    self._loader.release_graph(token)
                except BaseException as cleanup:
                    error.add_note(f"CuTe graph token retained after cleanup failed: {cleanup}")
                raise

    def _release_graph(self, token):
        with self._locked():
            self._loader.release_graph(token)

    def launch(self, parameter_images: tuple[bytes, ...], grid: tuple[int, int, int], stream: int):
        with self._locked():
            self._ready()
            if type(stream) is not int or not 0 <= stream < 2**64 or not self._loader._graphs:
                raise ProviderDeclined("CuTe capture launch requires a raw stream and a held graph borrow")
            kernel = self._loader.validate(self._site, parameter_images, grid, self._block, self._shared)
            if int(_check_cuda_bindings(driver.cuStreamGetCtx(stream))) != self._loader.context:
                raise ProviderDeclined("CuTe capture stream belongs to another CUDA context")
            if (_check_cuda_bindings(driver.cuStreamIsCapturing(stream))
                    != driver.CUstreamCaptureStatus.CU_STREAM_CAPTURE_STATUS_ACTIVE):
                raise ProviderDeclined("CuTe provider launches are supported only during stream capture")
            storage = tuple(ctypes.create_string_buffer(value, len(value)) for value in parameter_images)
            arguments = (ctypes.c_void_p * len(storage))(*(ctypes.addressof(value) for value in storage))
            _check_cuda_bindings(driver.cuLaunchKernel(
                kernel.function, *grid, *self._block, self._shared, stream, ctypes.addressof(arguments), 0))

    def close(self):
        with self._locked():
            if self.closed:
                return
            if self._loader._graphs:
                raise RuntimeError("Cannot close a CuTe kernel borrowed by a prepared CUDA graph")
            try:
                self._loader.close()
            except BaseException:
                self._phase = "failed"
                raise
            self._phase = "closed"
            for index, owner in enumerate(_OPEN_OWNERS):
                if owner is self:
                    _OPEN_OWNERS.pop(index)
                    break

    def __reduce_ex__(self, protocol):
        raise TypeError("CuTe kernel owners cannot be copied or serialized")
