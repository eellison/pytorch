"""Shared ordinary-first metadata adapter, separate from replay preparation."""

from dataclasses import dataclass
from types import FunctionType, MethodType

from torch._inductor.runtime.cudagraph_arg_mapping import (
    bind_fixed_grid, bind_grid_recipe, bind_wrapper_arguments, BufferSource, IntExpr,
    KernelCallRecord, LauncherArgument,
)


@dataclass(frozen=True)
class SelectedKernel:
    arguments: tuple[LauncherArgument, ...]
    grid_recipe: tuple[IntExpr, IntExpr, IntExpr]
    pointer_writes: tuple[tuple[str, bool], ...]
    arg_tys: str
    identity: object
    compiler_call: object | None = None

    @classmethod
    def from_compiler_call(cls, call):
        from torch._inductor.runtime.cudagraph_prepare_from_warmed import _SelectedCall

        if type(call) is not _SelectedCall:
            raise ValueError("Expected the checked compiler call from ordinary selection")
        call.check()
        recipe = call.grid_recipe
        if call.user_facts is None:
            provenance = call.kernel.inductor_meta.get("cudagraph_parameter_provenance", {})
            writes = tuple((name, row[1]) for name, row in provenance.items())
        else:
            recipe = bind_fixed_grid(call.record)
            writes = tuple((row.name, row.written) for row in call.user_facts.analysis.pointer_formals)
        if recipe is None:
            raise ValueError("Selected call has no supported compiler grid")
        result = cls(call.selected._cudagraph_arg_info, recipe, writes, call.module.arg_tys,
                     (call.kernel, call.selected, call.cached, call.module), call)
        result.check()
        return result

    def check(self):
        from torch._inductor.runtime.cudagraph_prepare_from_warmed import _SelectedCall

        call = self.compiler_call
        if call is None:
            return
        if type(call) is not _SelectedCall:
            raise ValueError("Selected projection lost its compiler call")
        call.check()
        if call.user_facts is None:
            provenance = call.kernel.inductor_meta.get("cudagraph_parameter_provenance", {})
            writes = tuple((name, row[1]) for name, row in provenance.items())
            grid = call.grid_recipe
        else:
            writes = tuple((row.name, row.written) for row in call.user_facts.analysis.pointer_formals)
            grid = bind_fixed_grid(call.record)
        identities = (call.kernel, call.selected, call.cached, call.module)
        if (type(self.identity) is not tuple or len(self.identity) != len(identities)
                or any(left is not right for left, right in zip(self.identity, identities))
                or self.arguments is not call.selected._cudagraph_arg_info
                or self.arg_tys != call.module.arg_tys or self.pointer_writes != writes
                or self.grid_recipe != grid):
            raise ValueError("Selected projection changed after ordinary selection")

    def user_pointer_effects(self):
        self.check()
        call = self.compiler_call
        if call is None or call.user_facts is None:
            raise ValueError("User effects require the original selected receipt")
        indices = {row.formal: row.source_arg_index for row in self.arguments if row.abi_index is not None}
        return tuple((row.name, indices[row.name], row.read, row.written)
                     for row in call.user_facts.analysis.pointer_formals)

    def bind_call(self, record, buffer_sources=None):
        self.check()
        if type(record) is not KernelCallRecord:
            raise ValueError("Expected a frontend compiler call record")
        bound = bind_wrapper_arguments(record, self.arguments)
        if record.grid_type == "FixedGrid":
            if self.compiler_call is None or self.compiler_call.user_facts is None:
                raise ValueError("FixedGrid requires a checked user-call projection")
            grid = bind_fixed_grid(record)
            if grid != self.grid_recipe:
                raise ValueError("Frontend grid differs from its original boxed sources")
        else:
            grid = bind_grid_recipe(record, self.arguments, self.grid_recipe)
        abi = "".join("O" if row.triton_type.startswith("*") else {"i32": "i", "i64": "l"}.get(
            row.triton_type, "?") for row in self.arguments if row.abi_index is not None)
        if bound is None or grid is None or abi != self.arg_tys:
            raise ValueError("Trace and selected ABI/grid correspondence differ")
        if self.compiler_call is None:
            return grid
        original = self.compiler_call.record
        if (record.occurrence != original.occurrence or record.kernel_global != original.kernel_global
                or record.formals != original.formals or record.grid_type != original.grid_type
                or record.constexprs != original.constexprs or len(record.arguments) != len(original.arguments)
                or type(buffer_sources) is not dict
                or any(type(left) is not BufferSource or type(right) is not BufferSource
                       for left, right in buffer_sources.items())
                or len(set(buffer_sources.values())) != len(buffer_sources)):
            raise ValueError("Frontend call lost its compiler occurrence or buffer map")
        renamed = buffer_sources.copy()
        for expected, actual in zip(original.arguments, record.arguments):
            if (expected.formal != actual.formal or expected.source_arg_index != actual.source_arg_index
                    or expected.call_arg_index != actual.call_arg_index or expected.triton_type != actual.triton_type):
                raise ValueError("Frontend formal differs from its compiler operand")
            source = expected.source
            if type(source) is BufferSource:
                if type(actual.source) is not BufferSource:
                    raise ValueError("Frontend owned pointer changed source kind")
                if source in renamed:
                    if renamed[source] != actual.source:
                        raise ValueError("Frontend changed a previously bound buffer source")
                elif actual.source in renamed.values():
                    raise ValueError("Frontend collapsed distinct compiler buffers")
                else:
                    renamed[source] = actual.source
            elif type(actual.source) is not type(source) or actual.source != source:
                raise ValueError("Frontend operand differs from its original boxed source")
        self.check()
        buffer_sources.clear()
        buffer_sources.update(renamed)
        return grid

    @classmethod
    def from_warmed(cls, kernel):
        import torch
        from torch._inductor.runtime.static_triton_launcher import StaticallyLaunchedCudaKernel
        from torch._inductor.runtime.triton_heuristics import CachingAutotuner

        if (type(kernel) is not CachingAutotuner or len(kernel.launchers) != 1
                or not kernel._cache_eligible or kernel._plugins
                or type(kernel.run) is not MethodType or kernel.run.__func__ is not CachingAutotuner.run):
            raise ValueError("Ordinary execution must select one unchanged generated launcher first")
        selected, cached = kernel.launchers[0], kernel._cached_launcher
        if type(selected) is not FunctionType or type(cached) is not FunctionType:
            raise ValueError("Expected an already cached launcher")
        arguments = getattr(selected, "_cudagraph_arg_info", None)
        recipe = getattr(selected, "_cudagraph_grid_recipe", None)
        runner = selected.__globals__.get("runner")
        module = runner.__self__ if type(runner) is MethodType else None
        if (type(module) is not StaticallyLaunchedCudaKernel or module.device_agnostic
                or module.module is None or type(module.function) is not int or module.function <= 0
                or arguments is None or recipe is None
                or getattr(selected, "_is_static", None) is not True
                or getattr(cached, "_cudagraph_arg_info", None) is not arguments
                or getattr(cached, "_cudagraph_grid_recipe", None) is not recipe
                or getattr(cached, "config", None) is not selected.config
                or getattr(selected.config, "pre_hook", None) is not None
                or getattr(selected.config, "ir_override", None) is not None
                or kernel.inductor_meta.get("grid_type") != "Grid1D"
                or (cached is not selected and (
                    cached.__code__ is not selected.__code__
                    or type(cached.__globals__.get("runner")) is not torch._C._FastCudaLauncher
                    or getattr(cached, "_static_kernel_owner", None) is not module))):
            raise ValueError("Missing exact selected launcher correspondence")
        provenance = kernel.inductor_meta.get("cudagraph_parameter_provenance", {})
        writes = tuple((name, row[1]) for name, row in provenance.items())
        return cls(arguments, recipe, writes, module.arg_tys, (kernel, selected, cached, module))
