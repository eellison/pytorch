"""Alpha normalization for comparison, never a replay-admission check."""

from dataclasses import fields, replace

from host_program import Allocate, HostProgram, InputAssertion, Invoke, Normalize, Reinterpret
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, CallArgument, ExpressionSource, InputSource, IntegerInput,
    IntegerSource, IntExpr, KernelCallRecord, OwnedBuffer, WrapperCallRecords,
)


def alpha_normalize(program: HostProgram) -> HostProgram:
    if type(program) is not HostProgram:
        raise ValueError("Expected a shared host program")
    names = {}
    for event in program.events:
        name = event.value_id if type(event) is Allocate else event.result_id if type(event) is Reinterpret else None
        if name is not None:
            if name in names:
                raise ValueError("Host value identities are not distinct")
            names[name] = f"value_{len(names)}"
    immutable = (HostProgram, Invoke, Normalize, AlignmentCopy, CallArgument, ExpressionSource,
                 InputSource, IntegerSource, IntExpr, KernelCallRecord, OwnedBuffer)

    def rename(value):
        if type(value) is tuple:
            return tuple(rename(item) for item in value)
        if type(value) is BufferSource:
            return BufferSource(names[value.name])
        if type(value) is IntegerInput:
            return replace(value, symbol=f"boxed_{value.boxed_index}")
        if type(value) is Allocate:
            return replace(value, value_id=names[value.value_id])
        if type(value) is Reinterpret:
            return replace(value, source_id=names[value.source_id], result_id=names[value.result_id])
        if type(value) is InputAssertion:
            return replace(value, label=None)
        if type(value) is WrapperCallRecords:
            values = {row.name: rename(getattr(value, row.name)) for row in fields(value)}
            values["input_names"] = tuple(f"boxed_{index}" for index in range(len(value.input_names)))
            return WrapperCallRecords(**values)
        if type(value) in immutable:
            return replace(value, **{row.name: rename(getattr(value, row.name)) for row in fields(value)})
        return value

    return rename(program)
