"""Validate shared types against the explicitly installed canonical source map."""

from hashlib import sha256
from pathlib import Path
import sys

from production_bootstrap import installed


def check_shared_source(name, module, relative):
    owner = installed()
    registration = sys.modules.get(__name__)
    if (registration is None or __name__ not in owner.modules
            or owner.loaded.get(__name__) is not registration):
        raise RuntimeError("Shared source registration is outside the canonical installation")
    row = owner.modules.get(name)
    if row is None or owner.loaded.get(name) is not module:
        raise RuntimeError(f"The runtime requires the original shared module: {name}")
    if sha256(Path(row["path"]).read_bytes()).hexdigest() != row["sha256"]:
        raise RuntimeError(f"The registered shared source changed: {name}")
