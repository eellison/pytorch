from __future__ import annotations

from hashlib import sha256
from typing import Any

from ordinary_artifact_adapter.invocation import ArtifactInvocation, normalize_artifact_invocation

from ._legacy import EntrySignature, OwnedNumeric, ScalarValue
from .artifact import (
    ARTIFACT_VERSION,
    ArtifactSite,
    BinaryImage,
    ConstantProperty,
    Consumer,
    Diagnostic,
    DispatchArtifact,
    FieldSource,
    Formal,
    IntegerField,
    Leaf,
    NodeFields,
    Padding,
    Parameter,
    PointerField,
    Registration,
    Stream,
    _FunctionGuard,
    _LiveGuards,
    _OrdinaryGuards,
    _Payload,
    _check_guards,
)
from .signature import prepare_entry_source_guard


_RECORDS = (Leaf, ConstantProperty, Formal, Stream, BinaryImage, Registration, Parameter, FieldSource,
            PointerField, IntegerField, Padding, NodeFields, Diagnostic, Consumer, ArtifactSite, _Payload)


def _immutable(value: Any) -> None:
    if value is None or type(value) in (str, int, bool, bytes):
        return
    if type(value) is OwnedNumeric:
        value.check()
        return
    if type(value) is tuple or type(value) in _RECORDS:
        for item in value:
            _immutable(item)
        return
    raise TypeError("Dispatch artifact contains a mutable or unsupported compiler record")


def _property_path(prop: str, path: tuple[int, ...], parameter: Any) -> None:
    if prop == "pointer" and path == ():
        return
    dimensions = parameter.shape if prop == "shape" else parameter.strides
    if (prop not in {"shape", "stride"} or type(path) is not tuple or len(path) != 1
            or type(path[0]) is not int or not 0 <= path[0] < len(dimensions)):
        raise ValueError("Unsupported or out-of-range tensor property path")


def _copy_formals(invocation: ArtifactInvocation, layout: Any, stream_layout: Any) -> tuple[Formal, ...]:
    from values import evaluate

    invocation = normalize_artifact_invocation(invocation)
    signature = invocation.signature
    actual = invocation.bound
    if (len(actual.params) != len(signature.operands)
            or actual.metadata != invocation.joined.admission.source.metadata):
        raise ValueError("Artifact metadata lacks exact original Python operand coverage")
    stream_kind = "Stream" if invocation.kind == "ordinary" else "EnvStream"
    by_source = {}
    for index, (parameter, operand) in enumerate(zip(actual.params, signature.operands)):
        metadata = parameter.metadata
        if (parameter.source is not operand
                or type(metadata.ir_arg_index) is not int or metadata.ir_arg_index < 0
                or metadata.ir_arg_index in by_source or metadata.kind not in {"Tensor", stream_kind}
                or metadata.name != operand.name):
            raise ValueError("Artifact requires exact Tensor and original stream source bindings")
        by_source[metadata.ir_arg_index] = (index, operand, metadata)
    tensors = {formal.source_arg_index: formal for formal in invocation.plan.formals}
    targets = {formal.source_arg_index: formal for formal in layout.formals}
    joined_properties = {id(item.component): item for item in invocation.properties}
    lowered = sorted(invocation.formals.formals, key=lambda formal: formal.llvm_arg_index)
    flow = invocation.joined.mapping.flow
    if (tuple(formal.llvm_arg_index for formal in lowered) != tuple(range(len(flow.host_types)))
            or {formal.ir_arg_index for formal in lowered} != set(by_source)
            or len(lowered) != len(by_source) or set(tensors) != set(targets)):
        raise ValueError("Artifact source and lowered argument coverage differs")
    result = []
    streams = 0
    for formal in lowered:
        index, operand, metadata = by_source[formal.ir_arg_index]
        if (formal.metadata.name != metadata.name or formal.metadata.kind != metadata.kind
                or formal.metadata.ir_arg_index != metadata.ir_arg_index
                or formal.metadata.abi_arg_index != metadata.abi_arg_index
                or formal.llvm_type != flow.host_types[formal.llvm_arg_index]):
            raise ValueError("Artifact formal lost its metadata or lowered ordinal")
        leaves, constants = [], []
        if metadata.kind == stream_kind:
            streams += 1
            if (operand.origin != "environment_stream" or operand.tensor is not None or operand.scalar is not None
                    or formal.ir_arg_index != stream_layout.source_index or formal.llvm_type != stream_layout.llvm_type):
                raise ValueError("Artifact stream is not the injected original environment formal")
            size, alignment = stream_layout.size, stream_layout.alignment
        else:
            if operand.tensor is None or operand.scalar is not None or operand.tensor.device.type != "cuda":
                raise ValueError("Artifact tensor signature must retain its actual CUDA source")
            tensor, target = tensors[formal.ir_arg_index], targets[formal.ir_arg_index]
            if (tensor.llvm_arg_index != formal.llvm_arg_index or target.llvm_arg_index != formal.llvm_arg_index
                    or tensor.llvm_type != formal.llvm_type or target.llvm_type != formal.llvm_type):
                raise ValueError("Artifact aggregate or layout lost the original formal")
            fields = {item.path: item for item in target.fields}
            if len(fields) != len(target.fields) or set(fields) != {leaf.path for leaf in tensor.leaves}:
                raise ValueError("Artifact tensor leaves do not cover the actual compiler layout")
            for component in (*tuple(leaf.component for leaf in tensor.leaves), *tensor.constants):
                prop = joined_properties.get(id(component))
                spec = component.spec
                _property_path(spec.property, spec.property_path, metadata)
                if (prop is None or prop.component is not component or prop.source is not operand
                        or spec.source_arg_index != formal.ir_arg_index):
                    raise ValueError("Artifact component lost its exact original Python operand")
                if spec.property == "pointer":
                    expected_use = None
                else:
                    uses = operand.tensor.shape if spec.property == "shape" else operand.tensor.strides
                    expected_use = uses[spec.property_path[0]]
                if prop.use is not expected_use:
                    raise ValueError("Artifact tensor property lost its exact FX or symbolic use")
            for leaf in tensor.leaves:
                field, spec, value = fields[leaf.path], leaf.component.spec, leaf.component.source
                if (field.llvm_type != leaf.llvm_type or value.kind != "argument"
                        or value.argument != formal.ir_arg_index or value.path != leaf.path
                        or value.value is not None or value.operands or value.attributes):
                    raise ValueError("Artifact leaves require direct compiler-identified component paths")
                if spec.property == "pointer":
                    if not leaf.llvm_type.startswith("!llvm.ptr") or field.size != 8:
                        raise ValueError("Artifact pointer leaf requires its actual 8-byte pointer layout")
                elif leaf.llvm_type not in {"i32", "i64"} or field.size != int(leaf.llvm_type[1:]) // 8:
                    raise ValueError("Artifact tensor integer field has an unsupported width")
                leaves.append(Leaf(leaf.path, leaf.llvm_type, spec.property, spec.property_path,
                                   field.offset, field.size, field.alignment))
            for component in tensor.constants:
                spec = component.spec
                if spec.property not in {"shape", "stride"} or component.source.kind not in {"constant", "zero"}:
                    raise ValueError("Artifact static properties require actual constant accessors")
                value = evaluate(component.source, (), invocation.program.context)
                if type(value) is not ScalarValue or value.llvm_type not in {"i32", "i64"}:
                    raise ValueError("Artifact static property has an unsupported scalar type")
                value.data()
                constants.append(ConstantProperty(spec.property, spec.property_path, value.llvm_type, value.integer(), value.size))
            size, alignment = target.size, target.alignment
        result.append(Formal(formal.ir_arg_index, formal.llvm_arg_index, index, metadata.name,
            formal.metadata.path, metadata.kind, formal.source_type, formal.llvm_type, metadata.shape, metadata.strides,
            metadata.dtype, metadata.element_dtype, metadata.data_address_space, metadata.device_kind,
            metadata.data_alignment, size, alignment, tuple(leaves), tuple(constants)))
    if streams != 1 or not tensors or set(tensors) != {item.source_arg_index for item in result if item.kind == "Tensor"}:
        raise ValueError("Artifact requires Tensor formals and exactly one original environment stream")
    return tuple(result)


def _copy_sites(invocation: ArtifactInvocation, fields: Any, formals: tuple[Formal, ...], consumers: tuple[Consumer, ...],
                binaries: tuple[BinaryImage, ...]) -> tuple[ArtifactSite, ...]:
    invocation = normalize_artifact_invocation(invocation)
    dispatch = invocation
    by_source = {formal.source_arg_index: formal for formal in formals}
    tensors = {formal.source_arg_index: formal for formal in invocation.plan.formals}
    sites = []
    for site_id, (site, field_site) in enumerate(zip(dispatch.joined.sites, fields.sites)):
        if field_site.site is not site or len(field_site.nodes) != 1:
            raise ValueError("Artifact fields must identify one exact original dispatch site")
        node, = field_site.nodes
        launch = site.compiled.launch
        parameters = []
        for binding, parameter in zip(site.compiled.parameters, launch.parameters):
            formal = by_source[binding.formal.ir_arg_index]
            if (formal.kind != "Tensor" or binding.parameter is not parameter
                    or binding.device_parameter_index != parameter.index or parameter.index != len(parameters)
                    or parameter.source.argument != formal.llvm_arg_index
                    or parameter.llvm_type != formal.llvm_type or node.parameter_sizes[parameter.index] != formal.size):
                raise ValueError("Artifact parameters require exact whole Tensor formal forwarding")
            parameters.append(Parameter(parameter.index, parameter.llvm_type, formal.source_arg_index,
                                        formal.llvm_arg_index, formal.size, formal.alignment))

        def source_copy(source):
            formal = by_source[source.ir_arg_index]
            leaves = [leaf for leaf in tensors[source.ir_arg_index].leaves if leaf.path == source.value.path]
            if (source.kind != "tensor_property" or source.formal_name != formal.name
                    or source.metadata_path != formal.metadata_path or len(leaves) != 1
                    or leaves[0].component.source is not source.value
                    or leaves[0].component.spec.property != source.property
                    or leaves[0].component.spec.property_path != source.property_path):
                raise ValueError("Artifact native field lost its exact component source")
            return FieldSource(source.kind, source.ir_arg_index, source.formal_name, source.metadata_path,
                               source.property, source.property_path, source.value.llvm_type, source.value.path)

        if node.fixed or len(parameters) != len(launch.parameters):
            raise ValueError("Artifact native fields require complete non-fixed parameter coverage")
        pointers = tuple(PointerField(item.parameter, item.byte_offset, source_copy(item.source)) for item in node.pointers)
        integers = tuple(IntegerField(item.parameter, item.byte_offset, item.dtype, source_copy(item.source)) for item in node.integers)
        padding = tuple(Padding(item.parameter, item.byte_offset, item.byte_size) for item in node.padding)
        copied_fields = NodeFields(node.launch, node.kernel_symbol, node.parameter_sizes, pointers, integers, (), padding)
        registration = Registration(*tuple(getattr(launch.registration, name) for name in Registration._fields))
        images = [image for image in binaries if image.library_slot == registration.library_slot]
        if (len(images) != 1 or images[0].global_name != registration.binary_global
                or images[0].sha256 != registration.binary_sha256 or registration.kernel_symbol != site.source.callee[1]
                or node.launch != launch.index or node.kernel_symbol != registration.kernel_symbol):
            raise ValueError("Artifact site lost its actual embedded binary or function registration")
        diagnostics = tuple(Diagnostic(item.kind, item.expected, item.limit, item.arch) for item in site.source.diagnostics)
        consumer_ids = tuple(item.consumer_id for item in consumers if item.site_id == site_id)
        expected = {("grid", axis): "i32" for axis in range(3)} | {("block", axis): "i32" for axis in range(3)}
        expected.update({("shared", 0): "i64", ("kernel_smem", 0): "i64"})
        expected.update({("diagnostic", index): "i1" for index in range(len(diagnostics))})
        actual = {(consumers[index].role, consumers[index].index): consumers[index].result_type for index in consumer_ids}
        if actual != expected or len(consumer_ids) != len(expected):
            raise ValueError("Artifact site lacks complete exact launch-field and diagnostic consumers")
        sites.append(ArtifactSite(site_id, site.source.arm, launch.index, site.source.callee, registration,
            tuple(parameters), copied_fields, consumer_ids, diagnostics, site.source.stream_source_arg_index,
            tuple(operation.name for operation in site.source.attributes)))
    if (len(sites) != 2 or {site.arm for site in sites} != {True, False}
            or len({site.callee for site in sites}) != len(sites)
            or {site.launch_index for site in sites} != set(range(len(dispatch.joined.mapping.flow.launches)))):
        raise ValueError("Artifact requires complete two-arm source and compiled launch coverage")
    return tuple(sites)


def prepare_dispatch_artifact(entry: Any, layout: Any, stream_layout: Any) -> DispatchArtifact:
    from entry import DispatchEntry
    from fields_dispatch import derive_dispatch_fields
    from prepared_dispatch import prepare_dispatch

    if type(entry) not in (DispatchEntry, ArtifactInvocation):
        raise TypeError("Artifact preparation requires the genuine joined DispatchEntry")
    invocation = normalize_artifact_invocation(entry)
    invocation.check_layout(layout, stream_layout)
    prepared = prepare_dispatch(invocation, layout, stream_layout)
    fields = derive_dispatch_fields(invocation, layout)
    fields.check()
    dispatch = invocation
    program, signature = invocation.program, invocation.signature
    if type(signature) is not EntrySignature or layout.query.host_target != stream_layout.host_target:
        raise ValueError("Artifact preparation requires one Python, compiler, and layout owner")
    formals = _copy_formals(invocation, layout, stream_layout)
    metadata = invocation.metadata
    symbols = tuple((name, bits, divisibility) for name, bits, divisibility in metadata.symbols)
    for name, bits, divisibility in symbols:
        if (type(name) is not str or type(bits) is not int or bits not in {32, 64}
                or divisibility is not None and (type(divisibility) is not int or divisibility <= 0)):
            raise ValueError("Unsupported compiler dimension symbol")
    for formal in formals:
        for dimensions in (formal.shape, formal.strides):
            for kind, value in dimensions:
                if (type(value) is not int or kind not in {"constant", "symbol"}
                        or kind == "symbol" and not 0 <= value < len(symbols)):
                    raise ValueError("Artifact tensor property lost its compiler dimension identity")
    source_sites = dispatch.joined.sites
    consumers = []
    for index, item in enumerate(prepared.consumers):
        bound = item.bound
        site_ids = [site_id for site_id, site in enumerate(source_sites) if bound.site is site.source]
        if bound.site is not None and len(site_ids) != 1:
            raise ValueError("Artifact helper lost its exact original launch consumer")
        site_id = None if bound.site is None else site_ids[0]
        if (item.numeric.source_order != bound.source_order or item.numeric.result_types != (bound.helper.result_type,)
                or item.numeric.argument_types != tuple(next(formal.llvm_type for formal in formals
                    if formal.source_arg_index == source_index) for source_index in bound.source_order)):
            raise ValueError("Artifact helper lost its actual source tags or scalar result type")
        consumers.append(Consumer(index, bound.helper.symbol, site_id, bound.role, bound.index,
                                  bound.helper.result_type, item.numeric.source_order, item.numeric))
    consumers = tuple(consumers)
    predicates = [item for item in consumers if item.site_id is None]
    if len(predicates) != 1 or (predicates[0].role, predicates[0].index, predicates[0].result_type) != ("predicate", 0, "i1"):
        raise ValueError("Artifact requires its exact original root predicate")
    flow = dispatch.joined.mapping.flow
    binaries = tuple(BinaryImage(image.library_slot, image.global_name, image.sha256, image.data) for image in flow.binaries)
    if (not binaries or len({image.library_slot for image in binaries}) != len(binaries)
            or any(type(image.data) is not bytes or sha256(image.data).hexdigest() != image.sha256 for image in binaries)):
        raise ValueError("Artifact embedded library bytes or identities changed")
    sites = _copy_sites(invocation, fields, formals, consumers, binaries)
    stream_kind = "Stream" if invocation.kind == "ordinary" else "EnvStream"
    stream_formal, = (formal for formal in formals if formal.kind == stream_kind)
    stream = Stream(stream_formal.source_arg_index, stream_formal.llvm_arg_index, stream_formal.operand_index,
                    stream_formal.llvm_type, stream_formal.size, stream_formal.alignment)
    if any(site.stream_source_index != stream.source_index for site in sites):
        raise ValueError("Artifact sites use different original environment streams")
    payload = _Payload(ARTIFACT_VERSION, program.function_name, program.arch, layout.query.host_target,
        invocation.source_sha256, invocation.compiled_sha256, layout.object_sha256, stream_layout.object_sha256,
        tuple(flow.host_types), symbols, tuple((formal.source_arg_index, formal.operand_index) for formal in formals),
        formals, stream, binaries, consumers, sites)
    _immutable(payload)
    if invocation.kind == "ordinary":
        guards = _OrdinaryGuards(invocation.bound, prepare_entry_source_guard(signature))
    else:
        bundle = program.bundle
        originals = (bundle.original_host, bundle.original_host.__wrapped__, bundle.original_kernel, bundle.original_kernel.__wrapped__)
        if (tuple(item.function for item in bundle._functions) != originals
                or originals[1].__code__ is not bundle.host_code or originals[3].__code__ is not bundle.kernel_code):
            raise ValueError("Artifact code pins do not cover the original compilation functions")
        functions = tuple(_FunctionGuard(fn, fn.__code__, getattr(fn, "__wrapped__", None), tuple(fn.__annotations__.items()),
                                        tuple(cell.cell_contents for cell in fn.__closure__ or ())) for fn in originals)
        namespaces = tuple((fn.__globals__, tuple(fn.__globals__.items())) for fn in (originals[1], originals[3]))
        guards = _LiveGuards(functions, namespaces, (originals[1], originals[3]), tuple(signature.operands),
                             prepare_entry_source_guard(signature))
    invocation.check()
    prepared.check()
    fields.check()
    _check_guards(signature, guards)
    result = object.__new__(DispatchArtifact)
    object.__setattr__(result, "_payload", payload)
    object.__setattr__(result, "_signature", signature)
    object.__setattr__(result, "_guards", guards)
    object.__setattr__(result, "_seal", (result, payload, signature, guards))
    result.check()
    return result
