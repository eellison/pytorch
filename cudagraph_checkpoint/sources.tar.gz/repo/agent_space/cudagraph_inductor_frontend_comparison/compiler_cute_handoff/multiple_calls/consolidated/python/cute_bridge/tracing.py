"""Trace a pure Python host into live allocations and exact pre-CuTe entry calls."""

from dataclasses import dataclass, field
from inspect import CO_VARARGS, CO_VARKEYWORDS
import math
from types import FunctionType, MappingProxyType
from typing import Mapping

import python_entry
from python_entry import EntryCall, PythonEntry, PythonHostUnsupported
from python_entry_v2 import _ambient_state
import sympy
import torch
from fx_adapter.contract import AllocateEvent, InputContract, IntegerRange, TensorInput
from fx_adapter.extraction import _materialize
from torch._dynamo.source import LocalSource
from torch._functorch import config as functorch_config
from torch._guards import Source, TracingContext, detect_fake_mode
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, IntExpr, OwnedBuffer
from torch._ops import OpOverload
from torch._subclasses.fake_tensor import FakeTensor, FakeTensorMode
from torch.fx.experimental import _config as fx_config
from torch.fx.experimental.proxy_tensor import get_proxy_mode, make_fx
from torch.fx.experimental.symbolic_shapes import DimDynamic, ShapeEnv
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_leaves
from torch.utils._sympy.numbers import int_oo
from torch.utils._sympy.value_ranges import bound_sympy


@dataclass(frozen=True, eq=False)
class DetachEvent:
    source: torch.Tensor
    result: torch.Tensor


@dataclass(frozen=True)
class CuteHostTrace:
    input_tensor: FakeTensor
    input_layout: OwnedBuffer
    input_contract: InputContract
    integer_placeholders: tuple[torch.SymInt, ...]
    integer_sources: tuple[Source, ...]
    symbol_sources: Mapping[sympy.Symbol, IntExpr]
    shape_env: ShapeEnv
    fake_mode: FakeTensorMode
    graph_module: torch.fx.GraphModule
    events: tuple[AllocateEvent | DetachEvent | EntryCall, ...]
    calls: tuple[EntryCall, ...]
    entries: tuple[PythonEntry, ...]
    outputs: tuple[FakeTensor, ...]
    dependencies: python_entry._Dependencies
    ambient_state: tuple[torch.dtype, bool, bool]
    graph_state: tuple

    def check(self):
        self.dependencies.check()
        if _ambient_state() != self.ambient_state:
            raise PythonHostUnsupported("CuTe host ambient state changed")
        if (self.graph_module.shape_env is not self.shape_env
                or python_entry._graph_state(self.graph_module) != self.graph_state
                or any(not call.node.is_impure() for call in self.calls)):
            raise PythonHostUnsupported("CuTe entry provenance or local ShapeEnv changed")
        python_entry._reject_unavailable(self.shape_env)


class _HostRecorder(TorchDispatchMode):
    def __init__(self, mode, device, entry, symbol_sources):
        super().__init__()
        self.mode, self.device = mode, device
        self.symbol_sources = symbol_sources
        self.recording = python_entry._Recording((entry,), mode, mode.shape_env)
        self.events = []
        self.known_tensors = {}
        self.origins = {}
        self.allocations = {}
        self.input_tensor = None
        self.outputs = None

    def expression(self, value):
        if type(value) is int:
            return sympy.Integer(value)
        if (type(value) is not torch.SymInt or value.node.shape_env is not self.mode.shape_env
                or not value.node.expr.free_symbols.issubset(self.symbol_sources)):
            raise PythonHostUnsupported("CuTe host integer has no original boxed source")
        return self.mode.shape_env.simplify(value.node.expr)

    def check_tensor(self, value):
        if (type(value) is not FakeTensor or value.fake_mode is not self.mode
                or value.device != self.device or value.requires_grad or value.layout != torch.strided):
            raise PythonHostUnsupported("CuTe host Tensor escaped its local fake/device contract")

    def layout(self, value):
        self.check_tensor(value)
        size, stride = tuple(value.size()), tuple(value.stride())
        if len(size) != 2 or len(stride) != 2 or self.expression(value.storage_offset()) != 0:
            raise PythonHostUnsupported("CuTe host requires zero-offset contiguous rank-two layouts")
        dimensions = tuple(self.expression(item) for item in size)
        strides = tuple(self.expression(item) for item in stride)
        if strides != (dimensions[1], sympy.Integer(1)) or any(
            bound_sympy(item, self.mode.shape_env.var_to_range).lower <= 0 for item in dimensions
        ):
            raise PythonHostUnsupported("CuTe host layout is not proven positive and contiguous")
        return size, stride

    def record(self, entry, args, kwargs):
        if self.recording.calls:
            raise PythonHostUnsupported("Expected one registered CuTe entry invocation")
        for _, value in python_entry._leaves((args, kwargs)):
            if isinstance(value, torch.Tensor):
                self.check_tensor(value)
                if self.known_tensors.get(id(value)) is not value:
                    raise PythonHostUnsupported("CuTe entry references an unrecorded Tensor")
            elif type(value) is torch.SymInt:
                self.expression(value)
            elif value is None or type(value) in (int, bool):
                continue
            elif type(value) is not float or not math.isfinite(value):
                raise PythonHostUnsupported("Unsupported CuTe entry scalar operand")
        self.recording.record(entry, args, kwargs)
        self.events.append(self.recording.calls[-1])

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs = {} if kwargs is None else kwargs
        if (type(func) is not OpOverload or func.namespace != "aten" or func._schema.is_mutable
                or torch.Tag.data_dependent_output in func.tags):
            raise PythonHostUnsupported("Unsupported CuTe host Tensor effect or opaque operation")
        for value in tree_leaves((args, kwargs)):
            if isinstance(value, torch.Tensor):
                self.check_tensor(value)
                if self.known_tensors.get(id(value)) is not value:
                    raise PythonHostUnsupported("CuTe host read an unrecorded Tensor")
        allocation = func in (torch.ops.aten.empty_like.default, torch.ops.aten.empty_strided.default)
        if allocation and (self.recording.calls or kwargs.get("pin_memory")):
            raise PythonHostUnsupported("CuTe host allocations must precede the entry and cannot be pinned")
        result = func(*args, **kwargs)
        if allocation:
            size, stride = self.layout(result)
            if id(result) in self.known_tensors:
                raise PythonHostUnsupported("CuTe allocation did not produce a fresh Tensor")
            self.events.append(AllocateEvent(result, size, stride, result.dtype, result.device))
            self.known_tensors[id(result)] = result
            self.origins[id(result)] = result
            self.allocations[id(result)] = result
            return result
        if func is torch.ops.aten.detach.default:
            self.check_tensor(result)
            self.events.append(DetachEvent(args[0], result))
            self.known_tensors[id(result)] = result
            self.origins[id(result)] = self.origins[id(args[0])]
            return result
        for value in tree_leaves(result):
            if type(value) in (int, bool, torch.dtype):
                continue
            if type(value) is torch.SymInt:
                self.expression(value)
            elif type(value) is torch.SymBool:
                if (value.node.shape_env is not self.mode.shape_env
                        or not value.node.expr.free_symbols.issubset(self.symbol_sources)):
                    raise PythonHostUnsupported("CuTe predicate has an unresolved symbolic source")
            elif type(value) is torch.device and value == self.device:
                continue
            else:
                raise PythonHostUnsupported("Only CuTe host allocations and pure Tensor metadata are supported")
        return result


def trace_cute_host(host, entry, contract, example_inputs, input_layout):
    if (python_entry._ACTIVE.get() is not None or TracingContext.try_get() is not None
            or get_proxy_mode() is not None or detect_fake_mode(example_inputs) is not None):
        raise PythonHostUnsupported("CuTe host tracing requires isolated fake/proxy/tracing contexts")
    ambient = _ambient_state()
    if (type(host) is not FunctionType or host.__code__.co_argcount != 1
            or host.__code__.co_kwonlyargcount or host.__code__.co_flags & (CO_VARARGS | CO_VARKEYWORDS)
            or type(entry) is not PythonEntry):
        raise PythonHostUnsupported("Expected a pure one-Tensor host and one registered PythonEntry")
    if (type(contract) is not InputContract or type(contract.kinds) is not tuple or not contract.kinds
            or any(kind not in ("integer", "tensor") for kind in contract.kinds)
            or type(contract.device_index) is not int or contract.device_index < 0
            or type(contract.integer_ranges) is not tuple or type(contract.tensor_inputs) is not tuple
            or type(example_inputs) not in (list, tuple) or len(example_inputs) != len(contract.kinds)):
        raise PythonHostUnsupported("Expected the original boxed compiler input contract")
    integers = {index for index, kind in enumerate(contract.kinds) if kind == "integer"}
    tensors = {index for index, kind in enumerate(contract.kinds) if kind == "tensor"}
    if (not integers or not tensors
            or any(type(row) is not IntegerRange or type(row.index) is not int or type(row.lower) is not int
                   or row.upper is not None and (type(row.upper) is not int or row.upper < row.lower)
                   for row in contract.integer_ranges)
            or {row.index for row in contract.integer_ranges} != integers
            or len(contract.integer_ranges) != len(integers)
            or any(type(row) is not TensorInput or type(row.index) is not int for row in contract.tensor_inputs)
            or {row.index for row in contract.tensor_inputs} != tensors
            or len(contract.tensor_inputs) != len(tensors)
            or any(type(example_inputs[index]) is not torch.Tensor for index in tensors)
            or type(input_layout) is not OwnedBuffer or type(input_layout.source) is not BufferSource
            or type(input_layout.dtype) is not torch.dtype or type(input_layout.size) is not tuple
            or type(input_layout.stride) is not tuple or len(input_layout.size) != 2
            or len(input_layout.stride) != 2):
        raise PythonHostUnsupported("CuTe prefix layout or boxed source correspondence is incomplete")
    dependencies = python_entry._Dependencies(host, (entry,))
    dependencies.check()
    if torch.cuda.is_available() and not torch.cuda.is_initialized():
        raise PythonHostUnsupported("Ordinary CUDA execution must warm the device before CuTe extraction")
    environment = ShapeEnv(duck_shape=False, specialize_zero_one=False)
    values, symbols, sources = {}, {}, []
    for row in contract.integer_ranges:
        hint = example_inputs[row.index]
        if type(hint) is not int or hint < row.lower or row.upper is not None and hint > row.upper:
            raise PythonHostUnsupported("CuTe integer hint violates its inherited compiler domain")
        source = LocalSource(f"boxed_{row.index}")
        symbol = environment.create_symbol(hint, source, dynamic_dim=DimDynamic.DYNAMIC,
                                           positive=None, do_not_specialize_zero_one=True)
        if type(symbol) is not sympy.Symbol:
            raise PythonHostUnsupported("CuTe boxed integers lost their distinct symbolic sources")
        environment.constrain_symbol_range(symbol, row.lower, int_oo if row.upper is None else row.upper)
        values[row.index] = environment.create_symintnode(symbol, hint=hint, source=source)
        symbols[symbol] = IntExpr("boxed", row.index)
        sources.append(source)
    with functorch_config.patch(fake_tensor_allow_unsafe_data_ptr_access=False):
        mode = FakeTensorMode(shape_env=environment, allow_fallback_kernels=False,
                             allow_non_fake_inputs=False, static_shapes=False)
    if mode.propagate_real_tensors:
        raise PythonHostUnsupported("CuTe extraction cannot propagate real Tensor values")
    device = torch.device("cuda", contract.device_index)
    with mode:
        fake = torch.ops.aten.empty_strided.default(
            tuple(_materialize(value, values) for value in input_layout.size),
            tuple(_materialize(value, values) for value in input_layout.stride),
            dtype=input_layout.dtype, device=device,
        )
    state = _HostRecorder(mode, device, entry, symbols)

    def run_host(*arguments):
        if state.input_tensor is not None:
            raise PythonHostUnsupported("A CuTe extraction must execute its original host exactly once")
        state.input_tensor = arguments[-1]
        state.layout(state.input_tensor)
        state.known_tensors[id(state.input_tensor)] = state.input_tensor
        state.origins[id(state.input_tensor)] = state.input_tensor
        with state:
            output = host(state.input_tensor)
        state.check_tensor(output)
        origin = state.origins.get(id(output))
        if state.known_tensors.get(id(output)) is not output or state.allocations.get(id(origin)) is not origin:
            raise PythonHostUnsupported("CuTe host must return a recorded owning allocation")
        state.outputs = (output,)
        return state.outputs

    token = python_entry._ACTIVE.set(state)
    try:
        with mode, fx_config.patch(backed_size_oblivious=True):
            graph_module = make_fx(run_host, tracing_mode="symbolic", _allow_non_fake_inputs=False)(
                *values.values(), fake,
            )
    finally:
        python_entry._ACTIVE.reset(token)
    if state.outputs is None or len(state.recording.calls) != 1 or graph_module.shape_env is not environment:
        raise PythonHostUnsupported("CuTe trace lacks its exact entry, output or local ShapeEnv")
    result = CuteHostTrace(
        state.input_tensor, input_layout, contract, tuple(values.values()), tuple(sources),
        MappingProxyType(symbols), environment, mode, graph_module, tuple(state.events),
        tuple(state.recording.calls), (entry,), state.outputs, dependencies, ambient,
        python_entry._graph_state(graph_module),
    )
    result.check()
    return result


@dataclass(frozen=True, eq=False)
class CuteInvocationTrace:
    binding: object
    descriptor: object
    input_contract: InputContract
    operand_tensors: tuple[FakeTensor, FakeTensor]
    tensor_sources: Mapping
    integer_placeholders: tuple[torch.SymInt, ...]
    integer_sources: tuple[Source, ...]
    symbol_sources: Mapping[sympy.Symbol, IntExpr]
    shape_env: ShapeEnv
    fake_mode: FakeTensorMode
    graph_module: torch.fx.GraphModule
    events: tuple[EntryCall, ...]
    calls: tuple[EntryCall, ...]
    entries: tuple[PythonEntry, ...]
    outputs: tuple
    dependencies: python_entry._Dependencies
    ambient_state: tuple[torch.dtype, bool, bool]
    graph_state: tuple
    call_index: int = 0
    _seal: tuple = field(default=(), repr=False)

    def _state(self):
        from entry_signature import _number_state, _tensor_state

        env = self.shape_env
        return (
            id(self.binding), id(self.descriptor), self.call_index, id(self.input_contract), repr(self.input_contract),
            tuple(_tensor_state(value) for value in self.operand_tensors),
            tuple((source, id(value)) for source, value in self.tensor_sources.items()),
            tuple(_number_state(value) for value in self.integer_placeholders),
            tuple(id(source) for source in self.integer_sources), tuple(self.symbol_sources.items()),
            id(env), id(self.fake_mode), id(self.graph_module), id(self.dependencies),
            tuple(id(call) for call in self.calls), tuple(id(event) for event in self.events),
            tuple(id(entry) for entry in self.entries), self.outputs, self.ambient_state, self.graph_state,
            tuple(guard.expr for guard in env.guards), tuple(env.replacements.items()),
            tuple(env.var_to_range.items()), tuple(env.backed_var_to_val.items()),
        )

    def check(self):
        if (type(self.operand_tensors) is not tuple or len(self.operand_tensors) != 2
                or type(self.call_index) is not int or not 0 <= self.call_index < len(self.binding.records.calls)
                or self.binding.records.calls[self.call_index] is not self.descriptor
                or type(self.tensor_sources) is not MappingProxyType
                or any(type(value) is not tuple for value in (self.calls, self.events, self.entries, self.outputs))
                or len(self.entries) != 1 or self._state() != self._seal):
            raise PythonHostUnsupported("CuTe invocation trace or compiler source mapping changed")
        self.dependencies.check()
        if (_ambient_state() != self.ambient_state or self.fake_mode.shape_env is not self.shape_env
                or self.graph_module.shape_env is not self.shape_env
                or python_entry._graph_state(self.graph_module) != self.graph_state
                or len(self.calls) != 1 or self.events != self.calls or self.outputs
                or not self.calls[0].node.is_impure()):
            raise PythonHostUnsupported("CuTe invocation provenance or local tracing state changed")
        python_entry._reject_unavailable(self.shape_env)
        for value, source in zip(self.integer_placeholders, self.integer_sources):
            if not any(item is source for item in self.shape_env.var_to_sources.get(value.node.expr, ())):
                raise PythonHostUnsupported("CuTe integer lost its original boxed source")
        call = self.calls[0]
        if (type(call) is not EntryCall or call.entry is not self.entries[0]
                or call.target is not self.entries[0].target
                or call.keyword_arguments or len(call.operands) != 2 or len(call.arguments) != 2
                or any(operand.path != ("args", index) or operand.value is not tensor
                       or operand.fx_argument is not call.arguments[index]
                       for index, (operand, tensor) in enumerate(zip(call.operands, self.operand_tensors)))):
            raise PythonHostUnsupported("CuTe invocation lost its exact formal Tensor correspondence")
        self.binding.check()


class _InvocationRecorder(_HostRecorder):
    def __init__(self, mode, device, entry, symbol_sources):
        super().__init__(mode, device, entry, symbol_sources)
        self.operands = None

    def materialize(self, fact, values):
        size = tuple(_materialize(value, values) for value in fact.size)
        stride = tuple(_materialize(value, values) for value in fact.stride)
        if len(size) != 2 or len(stride) != 2:
            raise PythonHostUnsupported("CuTe invocation requires declared rank-two layouts")
        dimensions = tuple(self.expression(value) for value in size)
        strides = tuple(self.expression(value) for value in stride)
        if strides != (dimensions[1], sympy.Integer(1)) or any(
            bound_sympy(value, self.mode.shape_env.var_to_range).lower <= 0 for value in dimensions
        ):
            raise PythonHostUnsupported("CuTe invocation layout is not proven positive and contiguous")
        return size, stride

    def record(self, entry, args, kwargs):
        if (self.operands is None or len(args) != 2 or kwargs
                or any(value is not expected for value, expected in zip(args, self.operands))):
            raise PythonHostUnsupported("The saved CuTe host must forward both declared operands in order")
        super().record(entry, args, kwargs)

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        raise PythonHostUnsupported("The saved CuTe forwarding host cannot allocate or transform its operands")


def _invocation_contract(binding, contract, example_inputs, call_index=0):
    from compiler_cute_handoff.descriptor import BoundCuTeCalls
    from torch._inductor.runtime.cudagraph_arg_mapping import InputSource, pointwise_expression_inputs

    if type(binding) is not BoundCuTeCalls:
        raise PythonHostUnsupported("Expected the exact bound compiler CuTe descriptors")
    binding.check()
    records = binding.records
    if (type(call_index) is not int or not 0 <= call_index < len(records.calls)
            or records.calls[call_index].provider_kind != "cute"):
        raise PythonHostUnsupported("Invocation tracing requires an original owned CuTe call index")
    if (type(contract) is not InputContract or type(contract.kinds) is not tuple or not contract.kinds
            or len(contract.kinds) != len(records.input_names)
            or any(kind not in ("integer", "tensor") for kind in contract.kinds)
            or type(contract.device_index) is not int or contract.device_index < 0
            or type(contract.integer_ranges) is not tuple or type(contract.tensor_inputs) is not tuple
            or type(example_inputs) not in (list, tuple) or len(example_inputs) != len(contract.kinds)):
        raise PythonHostUnsupported("Expected the complete original boxed compiler input contract")
    integers = {index for index, kind in enumerate(contract.kinds) if kind == "integer"}
    tensors = {index for index, kind in enumerate(contract.kinds) if kind == "tensor"}
    if (not tensors or {row.boxed_index for row in records.integer_inputs} != integers
            or any(type(row) is not IntegerRange or type(row.index) is not int or type(row.lower) is not int
                   or row.upper is not None and (type(row.upper) is not int or row.upper < row.lower)
                   for row in contract.integer_ranges)
            or {row.index for row in contract.integer_ranges} != integers
            or len(contract.integer_ranges) != len(integers)
            or any(type(row) is not TensorInput or type(row.index) is not int
                   or type(row.dtype) is not torch.dtype or type(row.size) is not tuple
                   or type(row.stride) is not tuple or len(row.size) != len(row.stride)
                   for row in contract.tensor_inputs)
            or {row.index for row in contract.tensor_inputs} != tensors
            or len(contract.tensor_inputs) != len(tensors)):
        raise PythonHostUnsupported("Compiler contract and descriptor boxed slots differ")
    facts = {row.source.index: row for row in records.tensors if type(row.source) is InputSource}
    device = torch.device("cuda", contract.device_index)
    for row in contract.tensor_inputs:
        fact = facts.get(row.index)
        if (fact is None or row.dtype is not fact.dtype or row.size != fact.size or row.stride != fact.stride
                or torch.device(fact.device) != device or any(
                    type(value) is not int and (type(value) is not IntExpr
                    or pointwise_expression_inputs(value) is None) for value in (*row.size, *row.stride))):
            raise PythonHostUnsupported("Compiler contract and descriptor Tensor layouts differ")
    call = records.calls[call_index]
    if any(torch.device(row.device) != device for row in call.operands):
        raise PythonHostUnsupported("CuTe operand device differs from the compiler contract")
    return call, binding.entries[call_index], device


def trace_cute_invocation(binding, contract, example_inputs, *, call_index=0):
    """Trace the saved two-operand host using compiler layouts and integer hints.

    Tensor box entries are not inspected or retained. The mixed-envelope caller
    must prove that this InputContract belongs to the bound generated function.
    This cold intermediate result does not authorize allocation, effects or replay.
    """
    from entry_signature import _number_state

    if (python_entry._ACTIVE.get() is not None or TracingContext.try_get() is not None
            or get_proxy_mode() is not None or detect_fake_mode() is not None):
        raise PythonHostUnsupported("CuTe invocation tracing requires isolated fake/proxy/tracing contexts")
    descriptor, invocation, device = _invocation_contract(binding, contract, example_inputs, call_index)
    provider = invocation._seal[1]
    host, entry = provider._seal[2], provider._seal[1]
    dependencies = python_entry._Dependencies(host, (entry,))
    dependencies.check()
    ambient = _ambient_state()
    if torch.cuda.is_available() and not torch.cuda.is_initialized():
        raise PythonHostUnsupported("Ordinary CUDA execution must warm the device before CuTe extraction")
    environment = ShapeEnv(duck_shape=False, specialize_zero_one=False)
    values, symbols, sources = {}, {}, []
    for row in contract.integer_ranges:
        hint = example_inputs[row.index]
        if type(hint) is not int or hint < row.lower or row.upper is not None and hint > row.upper:
            raise PythonHostUnsupported("CuTe integer hint violates its inherited compiler domain")
        source = LocalSource(f"boxed_{row.index}")
        symbol = environment.create_symbol(hint, source, dynamic_dim=DimDynamic.DYNAMIC,
                                           positive=None, do_not_specialize_zero_one=True)
        if type(symbol) is not sympy.Symbol:
            raise PythonHostUnsupported("CuTe boxed integers lost their distinct symbolic sources")
        environment.constrain_symbol_range(symbol, row.lower, int_oo if row.upper is None else row.upper)
        values[row.index] = environment.create_symintnode(symbol, hint=hint, source=source)
        symbols[symbol] = IntExpr("boxed", row.index)
        sources.append(source)
    with functorch_config.patch(fake_tensor_allow_unsafe_data_ptr_access=False):
        mode = FakeTensorMode(shape_env=environment, allow_fallback_kernels=False,
                             allow_non_fake_inputs=False, static_shapes=False)
    if mode.propagate_real_tensors:
        raise PythonHostUnsupported("CuTe extraction cannot propagate real Tensor values")
    state = _InvocationRecorder(mode, device, entry, symbols)
    layouts = tuple(state.materialize(row, values) for row in descriptor.operands)
    layout_states = tuple(tuple(_number_state(value) for value in (*size, *stride)) for size, stride in layouts)
    with mode:
        fakes = tuple(torch.ops.aten.empty_strided.default(
            size, stride,
            dtype=row.dtype, device=device,
        ) for row, (size, stride) in zip(descriptor.operands, layouts))

    def run_host(*arguments):
        if state.operands is not None:
            raise PythonHostUnsupported("A CuTe extraction must execute its saved host exactly once")
        state.operands = arguments[-2:]
        for value, fact, expected in zip(state.operands, descriptor.operands, layout_states):
            state.layout(value)
            if (value.dtype != fact.dtype
                    or tuple(_number_state(item) for item in (*value.shape, *value.stride())) != expected):
                raise PythonHostUnsupported("CuTe tracing changed a declared operand layout or boxed origin")
            state.known_tensors[id(value)] = value
        if state.operands[0] is state.operands[1]:
            raise PythonHostUnsupported("CuTe source and destination must remain distinct compiler operands")
        with state:
            result = host(*state.operands)
        if result is not None:
            raise PythonHostUnsupported("The saved CuTe forwarding host must return None")
        return None

    token = python_entry._ACTIVE.set(state)
    try:
        with mode, fx_config.patch(backed_size_oblivious=True):
            graph_module = make_fx(run_host, tracing_mode="symbolic", _allow_non_fake_inputs=False)(
                *values.values(), *fakes,
            )
    finally:
        python_entry._ACTIVE.reset(token)
    if state.operands is None or len(state.recording.calls) != 1 or graph_module.shape_env is not environment:
        raise PythonHostUnsupported("CuTe trace lacks its exact entry, operands or local ShapeEnv")
    result = CuteInvocationTrace(
        binding, descriptor, contract, state.operands,
        MappingProxyType({row.source: value for row, value in zip(descriptor.operands, state.operands)}),
        tuple(values.values()), tuple(sources), MappingProxyType(symbols), environment, mode,
        graph_module, tuple(state.events), tuple(state.recording.calls), (entry,), (),
        dependencies, ambient, python_entry._graph_state(graph_module), call_index=call_index,
    )
    object.__setattr__(result, "_seal", result._state())
    result.check()
    return result
