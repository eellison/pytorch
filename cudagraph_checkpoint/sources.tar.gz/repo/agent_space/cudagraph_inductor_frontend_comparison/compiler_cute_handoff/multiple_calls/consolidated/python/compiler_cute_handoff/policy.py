"""Cold ownership for compiler-ordered generated and CuTe invocations."""

from contextlib import contextmanager
import ctypes
from threading import Lock
from types import FunctionType
from weakref import ref

import torch
from compiler_metadata_handoff.metadata import MetadataDeclined
from compiler_policy_handoff.policy import _check_static_input_coverage, HandoffInvalidated
from cute_bridge import preparation
from cute_bridge.guard_export import combine_guards, prepare_guard
from cute_bridge.lowering import bind_cute_call, link_cute_invocation, link_cute_invocations
from cute_bridge.numeric import NumericDeclined
from cute_bridge.provider import _constant_consumer, CuTeKernelOwner, extract_pointer_effects, ProviderDeclined
from cute_bridge.tracing import trace_cute_invocation
from cute_dispatch.cache import Authority, ColdCache, PreparedVariant
from cudagraph_cute_runtime.factory import prepare_dispatch_artifact
from entry_signature import build_entry_signature
from fx_adapter.contract import FXTraceDeclined
from ordinary_artifact_adapter.invocation import normalize_artifact_invocation
from ordinary_artifact_capture.owner import CaptureIneligible
from ordinary_artifact_reuse.binding import bind_ordinary_metadata
from ordinary_artifact_reuse.correspondence import join_ordinary_correspondence
from python_entry import PythonHostUnsupported
from selected_kernel import SelectedKernel
from stream_layout import compile_stream_layout
from target_layout import compile_target_layout
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch._inductor.runtime.cudagraph_arg_mapping import AlignmentCopy
from torch._inductor.runtime.cudagraph_prepare_from_warmed import _publish_prepared
from user_triton.guard_export import GuardExportDeclined
from user_triton.linking import GeneratedProvider, LinkDeclined

from .envelope import bind_envelope, EnvelopeDeclined
from .invocation import _NativeBorrow, InvocationEntry
from .program import bind_mixed_program, BoundMixedProgram, ProgramDeclined
from .retained import reconstruct_mixed_ir, RetentionDeclined


_DECLINES = (CaptureIneligible, PythonHostUnsupported, UnsupportedCapture,
             LinkDeclined, ProviderDeclined, GuardExportDeclined,
             FXTraceDeclined, ProgramDeclined, RetentionDeclined, NumericDeclined)
_FAILED_INSTALLATIONS = []


@contextmanager
def _isolate_cold_dispatch():
    from torch._functorch._aot_autograd.runtime_wrappers import _AnalyzeCustomOpInputOutputMode
    from torch._ops import _len_torch_dispatch_stack_pre_dispatch
    from torch.utils._python_dispatch import _get_current_dispatch_mode_stack, _pop_mode, _push_mode

    modes = _get_current_dispatch_mode_stack()
    if (_len_torch_dispatch_stack_pre_dispatch() or len(modes) > 1
            or modes and (type(modes[0]) is not _AnalyzeCustomOpInputOutputMode
                          or _AnalyzeCustomOpInputOutputMode.ignore_compile_internals() is not True)):
        raise UnsupportedCapture("Mixed preparation requires no dispatch mode or the exact AOT alias analyzer")
    removed = None
    if modes:
        try:
            removed = _pop_mode()
        except BaseException as error:
            raise RuntimeError("Cannot suspend the AOT alias analyzer for cold preparation") from error
    try:
        if (modes and removed is not modes[0] or _get_current_dispatch_mode_stack()
                or _len_torch_dispatch_stack_pre_dispatch()):
            raise RuntimeError("Dispatch modes changed before cold preparation")
        yield
    finally:
        if removed is not None:
            try:
                _push_mode(removed)
            except BaseException as error:
                raise RuntimeError("Cannot restore the AOT alias analyzer after cold preparation") from error
        restored = _get_current_dispatch_mode_stack()
        if (_len_torch_dispatch_stack_pre_dispatch() or len(restored) != len(modes)
                or any(current is not original for current, original in zip(restored, modes))):
            raise RuntimeError("Dispatch modes changed during cold preparation")


class _MixedCache(ColdCache):
    def __init__(self, installation):
        self._installation = reference = ref(installation)
        super().__init__(installation.authority, lambda box: reference().ordinary(box),
                         lambda box, result: reference().prepare(box, result), _DECLINES, consume_box=True)

    def _cold(self, box):
        installation = self._installation()
        if installation is None:
            raise RuntimeError("Mixed compiler installation expired")
        if not installation._lock.acquire(blocking=False):
            raise RuntimeError("Mixed compiler installation is busy")
        try:
            if installation._status not in ("armed", "ready"):
                raise RuntimeError("Mixed compiler installation is not callable")
            expected = installation if installation._status == "armed" else installation.entry
            installation._active = expected
            installation._check(expected)
            result = super()._cold(box)
            if installation._status == "declined":
                installation._check(installation.original)
                return result
            if expected is installation:
                installation._dispatcher = self.dispatcher
            artifact, _ = installation._check(expected)
            if expected is installation:
                if self.dispatcher is None:
                    raise RuntimeError("Mixed preparation did not create a native dispatcher")
                installation._status = "publishing"
                if not _publish_prepared(artifact, installation, self.dispatcher):
                    raise HandoffInvalidated("Mixed compiler publication lost its callable")
            installation._status = "ready"
            return result
        except BaseException as error:
            if installation._dispatcher is None:
                installation._dispatcher = self.dispatcher
            installation._status = "failed"
            self._fail(error)
            raise
        finally:
            installation._ordinary_result = None
            installation._active = None
            installation._lock.release()


class MixedInstallation:
    _boxed_call = True

    def __init__(self, artifact, original, binding, static_state, *, frontend="records", retained=None):
        self._status = "closed"
        self._artifact, self._original = ref(artifact), ref(original)
        self._binding = binding
        self._static_state = static_state
        self.authority = Authority(binding.inputs, self._artifact, object())
        self._lock = Lock()
        self._owned, self._decline = False, None
        self._active = self._ordinary_result = None
        self._borrows = ()
        self._dispatcher = None
        self._generated = None
        self._frontend, self._retained = frontend, retained
        self._projection = None
        self._pending_entry = self._pending_owner = None
        self._pending_owners = []
        self.cache = _MixedCache(self)
        self._seal = (self.authority, binding, self.cache, self.cache.ordinary, self.cache.prepare,
                      static_state, frontend, retained)
        self._status = "armed"

    @property
    def artifact(self):
        return self._artifact()

    @property
    def original(self):
        return self._original()

    @property
    def entry(self):
        return self._dispatcher

    @property
    def status(self):
        return self._status

    @property
    def decline(self):
        return self._decline

    def _check(self, expected):
        artifact, original = self.artifact, self.original
        result = artifact, original
        authority, binding, cache, ordinary, prepare, static_state, frontend, retained, borrows = self._seal
        projection = self._projection
        kwargs, indices, snapshot = static_state
        if (artifact is None or original is None or artifact.current_callable is not expected
                or artifact._cudagraph_original_callable is not original
                or artifact._cudagraph_installation_owner is not (self if self._owned else None)
                or self.authority is not authority or self._binding is not binding or self.cache is not cache
                or cache.authority is not authority or cache.ordinary is not ordinary or cache.prepare is not prepare
                or cache.dispatcher is not self._dispatcher
                or cache.consume_box is not True or authority.artifact is not self._artifact
                or authority.contract is not binding.inputs or binding.function() is not original
                or self._borrows is not borrows or type(borrows) is not tuple
                or len(borrows) != len(binding.binding.entries)
                or any(type(borrow) is not _NativeBorrow or borrow.entry is not entry
                       for borrow, entry in zip(borrows, binding.binding.entries))
                or self._static_state is not static_state or artifact.fx_kwargs is not kwargs
                or self._frontend is not frontend or self._retained is not retained
                or frontend == "retained" and getattr(original, "_cudagraph_mixed_ir", None) is not retained
                or kwargs.get("static_input_idxs") is not indices or len(indices) != len(snapshot)):
            raise HandoffInvalidated("Mixed compiler installation lost its original authority")
        for index in range(len(snapshot)):
            if indices[index] is not snapshot[index]:
                raise HandoffInvalidated("Mixed compiler static input indices changed")
        try:
            binding.check()
            copies = tuple(event.input_index for event in binding.records.events if type(event) is AlignmentCopy)
            _check_static_input_coverage(binding.inputs, snapshot, copies)
            for borrow in borrows:
                _NativeBorrow.check(borrow)
            if self._generated is not None:
                for provider in self._generated:
                    provider.check()
            if projection is not None:
                if (frontend == "records" or type(projection) is not BoundMixedProgram
                        or projection.binding is not binding):
                    raise HandoffInvalidated("Mixed reader projection lost its compiler authority")
                projection.check()
            binding.check()
        except (EnvelopeDeclined, LinkDeclined, PythonHostUnsupported, MetadataDeclined, ProgramDeclined) as error:
            raise HandoffInvalidated("Mixed compiler source changed") from error
        if len(indices) != len(snapshot):
            raise HandoffInvalidated("Mixed compiler static input indices changed during validation")
        for index in range(len(snapshot)):
            if indices[index] is not snapshot[index]:
                raise HandoffInvalidated("Mixed compiler static input indices changed during validation")
        if (self.artifact is not artifact or self.original is not original
                or artifact.current_callable is not expected
                or artifact._cudagraph_original_callable is not original
                or artifact._cudagraph_installation_owner is not (self if self._owned else None)
                or self._static_state is not static_state or artifact.fx_kwargs is not kwargs
                or self._frontend is not frontend or self._retained is not retained or self._projection is not projection
                or frontend == "retained" and getattr(original, "_cudagraph_mixed_ir", None) is not retained
                or kwargs.get("static_input_idxs") is not indices):
            raise HandoffInvalidated("Mixed compiler callable changed during validation")
        return result

    def __call__(self, box):
        return self.cache.bootstrap(box)

    def ordinary(self, box):
        _, original = self._check(self._active)
        if type(box) is not list:
            raise TypeError("Mixed compiler invocation requires an exact boxed list")
        inputs = tuple(box)
        self._check(self._active)
        if len(box) != len(inputs):
            raise HandoffInvalidated("Mixed compiler box changed before ordinary execution")
        for index in range(len(inputs)):
            if box[index] is not inputs[index]:
                raise HandoffInvalidated("Mixed compiler box changed before ordinary execution")
        self._status = "warming"
        result = original(box)
        if type(result) is not tuple or len(result) != len(self._binding.records.outputs):
            raise HandoffInvalidated("Ordinary result differs from its compiler output projection")
        self._ordinary_result = inputs, result
        self._status = "preparing"
        self._check(self._active)
        return result

    def _discard_staged(self):
        if self._pending_entry is not None:
            self._pending_entry.close()
            self._pending_entry = None
        if self._pending_owner is not None:
            self._pending_owner.close()
            self._pending_owner = None
        while self._pending_owners:
            self._pending_owners[-1].close()
            self._pending_owners.pop()

    def prepare(self, box, result):
        self._check(self._active)
        observed = self._ordinary_result
        if (observed is None or result is not observed[1] or type(box) is not list
                or len(box) != len(observed[0]) or any(value is not old for value, old in zip(box, observed[0]))
                or self._pending_entry is not None or self._pending_owner is not None or self._pending_owners):
            raise HandoffInvalidated("Mixed preparation requires its exact ordinary result and inputs")
        try:
            return self._prepare_variant(box)
        except _DECLINES as error:
            if self.cache.failed:
                raise
            self._decline = str(error)
            self.cache.invalidate()
            artifact, original = self._check(self._active)
            artifact.current_callable = original
            self._status = "declined"
            raise

    def _prepare_variant(self, inputs):
        try:
            with _isolate_cold_dispatch():
                checked = self._binding
                if self._generated is None:
                    providers = {}
                    original = self.original
                    for call in checked.records.generated_calls:
                        if call.kernel_global not in providers:
                            providers[call.kernel_global] = GeneratedProvider(
                                SelectedKernel.from_warmed(original.__globals__[call.kernel_global]))
                    self._generated = tuple(providers[call.kernel_global] for call in checked.records.generated_calls)
                if self._projection is None and self._frontend == "fx":
                    from fx_adapter.extraction import trace_mixed_fx
                    from fx_adapter.lowering import lower_mixed_fx

                    selections = {call.kernel_global: provider.selection for call, provider
                                  in zip(checked.records.generated_calls, self._generated)}
                    self._projection = lower_mixed_fx(checked, trace_mixed_fx(checked, inputs, selections))
                elif self._projection is None and self._frontend == "retained":
                    self._projection = bind_mixed_program(checked, reconstruct_mixed_ir(self._retained))
                selected = []
                single = len(self._borrows) == 1
                for call_index, borrow in enumerate(self._borrows):
                    ordinary_owner = borrow.owner
                    trace = (trace_cute_invocation(checked.binding, checked.inputs, inputs) if single else
                             trace_cute_invocation(checked.binding, checked.inputs, inputs, call_index=call_index))
                    signature = build_entry_signature(trace, trace.calls[0], policy=ordinary_owner.policy)
                    bound = bind_ordinary_metadata(signature, ordinary_owner.compilation())
                    invocation = normalize_artifact_invocation(join_ordinary_correspondence(bound))
                    artifact = prepare_dispatch_artifact(invocation, compile_target_layout(invocation.plan),
                        compile_stream_layout(invocation.formals, invocation.stream_source_index))
                    candidates = []
                    start = len(self._pending_owners)
                    for site in artifact.sites:
                        block = tuple(_constant_consumer(artifact, site, "block", axis) for axis in range(3))
                        shared = _constant_consumer(artifact, site, "shared", 0)
                        self._pending_owner = CuTeKernelOwner(artifact, site,
                            stream=torch.cuda.current_stream().cuda_stream, block=block, shared=shared)
                        owner = self._pending_owner
                        self._pending_owners.append(owner)
                        self._pending_owner = None
                        effects = extract_pointer_effects(invocation, artifact, site)
                        if single:
                            linked = link_cute_invocation(checked, trace, self._generated, owner, effects,
                                                         compiler_program=self._projection)
                        else:
                            linked = bind_cute_call(checked, trace, self._generated, owner, effects,
                                call_index=call_index, provider_key=f"user_cute_{call_index}",
                                compiler_program=self._projection)
                        guard = prepare_guard(linked)
                        indices, address, _ = guard.registration
                        values = tuple(inputs[index] for index in indices)
                        if any(type(value) is not int or not -(2 ** 63) <= value < 2 ** 63 for value in values):
                            raise UnsupportedCapture("Local CuTe predicate needs exact signed int64 inputs")
                        predicate = ctypes.CFUNCTYPE(ctypes.c_int8, ctypes.POINTER(ctypes.c_int64),
                                                    ctypes.POINTER(ctypes.c_double))(address)
                        matches = predicate((ctypes.c_int64 * len(values))(*values), None)
                        if matches not in (0, 1):
                            raise RuntimeError("Local CuTe predicate returned neither zero nor one")
                        if matches:
                            candidates.append((owner, linked, guard))
                    if not candidates:
                        raise UnsupportedCapture("No CuTe site satisfies its replay guards")
                    if len(candidates) != 1:
                        raise RuntimeError("Expected exactly one compiler-selected CuTe site")
                    owner, linked, guard = candidates[0]
                    for staged in tuple(self._pending_owners[start:]):
                        if staged is not owner:
                            try:
                                staged.close()
                            except BaseException as error:
                                self.cache._fail(error)
                                raise
                            self._pending_owners.remove(staged)
                    selected.append((owner, linked, guard))
                providers = {call.kernel_global: provider for call, provider
                             in zip(checked.records.generated_calls, self._generated)}
                if single:
                    owner, linked, guard = selected[0]
                    program = linked.program
                    providers[program.calls[-1].provider_key] = owner
                else:
                    program = link_cute_invocations(checked, self._generated,
                        tuple(linked for _, linked, _ in selected), compiler_program=self._projection)
                    providers.update((linked.provider_key, owner) for owner, linked, _ in selected)
                    guard = combine_guards(tuple(guard for _, _, guard in selected))
                self._check(self._active)
                self._pending_entry = preparation.prepare_variant(program, providers, inputs,
                    compiler_binding=checked, compiler_program=self._projection)
                self._check(self._active)
                candidate = PreparedVariant(self.authority, self._pending_entry, guard.registration,
                                            tuple(self._pending_owners))
            self._pending_entry = None
            self._pending_owners.clear()
            return candidate
        except BaseException as error:
            if self.cache.failed:
                raise
            try:
                self._discard_staged()
            except BaseException as cleanup:
                self.cache._fail(cleanup)
                cleanup.add_note(f"Mixed preparation also failed: {error!r}")
                raise cleanup from error
            raise

    def _close_locked(self):
        if self._status == "closed":
            return
        if self.cache.dispatcher is not self._dispatcher:
            raise HandoffInvalidated("Mixed native dispatcher ownership changed before close")
        self.cache.close()
        self._discard_staged()
        artifact = self.artifact
        if artifact is not None and (artifact.current_callable is self or artifact.current_callable is self.entry):
            _, original = self._check(artifact.current_callable)
            artifact.current_callable = original
        while self._borrows:
            _NativeBorrow.close(self._borrows[-1])
            self._borrows = self._borrows[:-1]
        if artifact is not None and artifact._cudagraph_installation_owner is self:
            artifact._cudagraph_installation_owner = None
        self._owned = False
        self._binding = self._generated = self._ordinary_result = None
        self._projection = self._retained = None
        self._seal = self._static_state = None
        self._status = "closed"
        for index, installation in enumerate(_FAILED_INSTALLATIONS):
            if installation is self:
                del _FAILED_INSTALLATIONS[index]
                break

    def close(self):
        if not self._lock.acquire(blocking=False):
            raise RuntimeError("Mixed compiler installation is busy")
        try:
            self._close_locked()
        except BaseException as error:
            self._status = "failed"
            self.cache._fail(error)
            raise
        finally:
            self._lock.release()

    def __reduce_ex__(self, protocol):
        raise TypeError("Live mixed compiler installations cannot be copied or serialized")

    def __del__(self):
        if getattr(self, "_status", "closed") != "closed":
            try:
                self.close()
            except BaseException:
                _FAILED_INSTALLATIONS.append(self)


def arm_mixed(policy, artifact):
    from torch._inductor.output_code import CompiledFxGraph

    if type(artifact) is not CompiledFxGraph or policy._frontend not in ("records", "fx", "retained"):
        return False
    original = artifact.current_callable
    if type(original) is not FunctionType or artifact._cudagraph_original_callable is not original:
        return False
    if artifact._cudagraph_installation_owner is not None:
        return False
    retained = getattr(original, "_cudagraph_mixed_ir", None) if policy._frontend == "retained" else None
    if policy._frontend == "retained" and type(retained) is not str:
        return False
    try:
        checked = bind_envelope(original)
    except EnvelopeDeclined:
        return False
    kwargs = artifact.fx_kwargs
    indices = kwargs.get("static_input_idxs") if type(kwargs) is dict else None
    if type(indices) not in (list, tuple):
        return False
    snapshot = tuple(indices)
    static_state = kwargs, indices, snapshot
    copies = tuple(event.input_index for event in checked.records.events if type(event) is AlignmentCopy)
    try:
        _check_static_input_coverage(checked.inputs, snapshot, copies)
        checked.check()
    except (MetadataDeclined, EnvelopeDeclined):
        return False
    if len(indices) != len(snapshot):
        raise HandoffInvalidated("Static compiler input indices changed before mixed arming")
    for index in range(len(snapshot)):
        if indices[index] is not snapshot[index]:
            raise HandoffInvalidated("Static compiler input indices changed before mixed arming")
    if (artifact.fx_kwargs is not kwargs or kwargs.get("static_input_idxs") is not indices
            or artifact.current_callable is not original or artifact._cudagraph_original_callable is not original
            or artifact._cudagraph_installation_owner is not None):
        raise HandoffInvalidated("Compiler source changed before mixed arming")
    installation = MixedInstallation(artifact, original, checked, static_state,
                                     frontend=policy._frontend, retained=retained)
    if not installation._lock.acquire(blocking=False):
        raise RuntimeError("New mixed compiler installation is busy")
    try:
        policy._installations.append(installation)
        try:
            for entry in checked.binding.entries:
                borrow = InvocationEntry.borrow_native(entry)
                installation._borrows = (*installation._borrows, borrow)
            installation._seal = (*installation._seal, installation._borrows)
            installation._check(original)
            artifact._cudagraph_installation_owner = installation
            installation._owned = True
            artifact.current_callable = installation
        except BaseException:
            installation._status = "failed"
            try:
                installation._close_locked()
            except BaseException:
                raise
            policy._installations.remove(installation)
            raise
    finally:
        installation._lock.release()
    return True
