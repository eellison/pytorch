from dataclasses import dataclass


CaptureFrontier = tuple[int, int, int, tuple[tuple[int, bytes], ...]]
KernelSnapshot = tuple[
    int, int, int, int, tuple[int, int, int], tuple[int, int, int],
    int, bool, tuple[tuple[int, int, bytes], ...],
]
GraphSnapshot = tuple[int, int, tuple[int, ...], tuple[KernelSnapshot, ...]]


class UnsupportedCapture(ValueError):
    pass


@dataclass(frozen=True)
class RecordedKernelLaunch:
    stream: int
    before: CaptureFrontier
    after: CaptureFrontier
    function: int
    argument_bytes: tuple[bytes, ...]


@dataclass(frozen=True)
class CapturedKernelLaunch:
    occurrence: int
    snapshot: KernelSnapshot


def associate_kernel_launches(
    launches: tuple[RecordedKernelLaunch, ...], snapshot: GraphSnapshot,
) -> tuple[CapturedKernelLaunch, ...]:
    if not launches:
        raise UnsupportedCapture("No kernel launches were recorded")
    first = launches[0]
    identity = first.before[:3]
    if identity[0] != 1 or not identity[1] or not identity[2]:
        raise UnsupportedCapture("An active CUDA graph capture is required")
    if snapshot[:2] != (identity[2], identity[1]):
        raise UnsupportedCapture("Completed graph does not match the recorded capture")

    nodes = []
    seen = set()
    previous = first.before
    for launch in launches:
        if (
            launch.stream != first.stream or launch.before[:3] != identity
            or launch.after[:3] != identity or launch.before != previous
        ):
            raise UnsupportedCapture("Launches must belong to one uninterrupted stream capture")
        if any(edge != bytes(8) for _, edge in (*launch.before[3], *launch.after[3])):
            raise UnsupportedCapture("Nondefault capture dependencies are unsupported")
        if len(launch.after[3]) != 1:
            raise UnsupportedCapture("Each launch must produce one capture frontier node")
        node = launch.after[3][0][0]
        if node in seen or any(node == dependency for dependency, _ in launch.before[3]):
            raise UnsupportedCapture("A launch did not produce a new capture node")
        nodes.append(node)
        seen.add(node)
        previous = launch.after

    if len(snapshot[2]) != len(seen) or set(snapshot[2]) != seen:
        raise UnsupportedCapture("The graph contains unrecorded or missing nodes")
    kernels = {kernel[0]: kernel for kernel in snapshot[3]}
    if len(snapshot[3]) != len(seen) or set(kernels) != seen:
        raise UnsupportedCapture("Kernel inspection does not cover every recorded node")

    result = []
    for occurrence, (node, launch) in enumerate(zip(nodes, launches)):
        kernel = kernels[node]
        if not launch.function or kernel[1] != launch.function:
            raise UnsupportedCapture("Captured function does not match the selected launcher")
        slots = kernel[8]
        if len(slots) != len(launch.argument_bytes):
            raise UnsupportedCapture("Selected launcher does not describe the complete kernel ABI")
        for index, ((_, width, actual), expected) in enumerate(zip(slots, launch.argument_bytes)):
            if len(expected) != width or actual != expected:
                raise UnsupportedCapture(f"Captured argument {index} differs from the selected launch")
        result.append(CapturedKernelLaunch(occurrence, kernel))
    return tuple(result)
