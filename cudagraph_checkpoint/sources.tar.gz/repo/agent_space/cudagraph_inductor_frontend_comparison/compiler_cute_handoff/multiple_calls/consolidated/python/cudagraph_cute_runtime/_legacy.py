from importlib import import_module

from ordinary_artifact_adapter.source_registration import check_shared_source


_SOURCES = (
    ("entry_signature", "cudagraph_cute_entry_join/entry_signature.py"),
    ("metadata_regions", "cudagraph_cute_metadata_regions/metadata_regions.py"),
    ("owned_numeric", "cudagraph_cute_owned_numeric/owned_numeric.py"),
    ("values", "cudagraph_cute_owned_numeric/values.py"),
    ("allocation_recipe", "cudagraph_cute_allocation_recipe/allocation_recipe.py"),
    ("python_execution", "cudagraph_cute_joined_runtime/python_execution.py"),
)
_MODULES = tuple(import_module(name) for name, _ in _SOURCES)


def check_legacy() -> None:
    for (name, relative), module in zip(_SOURCES, _MODULES):
        if import_module(name) is not module:
            raise RuntimeError(f"The runtime requires the original shared module: {name}")
        check_shared_source(name, module, relative)


check_legacy()

EntrySignature = _MODULES[0].EntrySignature
MetadataAggregate = _MODULES[1].MetadataAggregate
UnavailablePointer = _MODULES[1].UnavailablePointer
OwnedNumeric = _MODULES[2].OwnedNumeric
evaluate_owned = _MODULES[2].evaluate_owned
ScalarValue = _MODULES[3].ScalarValue
AggregateValue = _MODULES[3].AggregateValue
scalar = _MODULES[3].scalar
AllocationRecipe = _MODULES[4].AllocationRecipe
MetadataPacket = _MODULES[4].MetadataPacket
TensorMetadata = _MODULES[4].TensorMetadata
ExecutedHost = _MODULES[5].ExecutedHost
PythonExecution = _MODULES[5].PythonExecution
_record_value = _MODULES[5]._record_value
