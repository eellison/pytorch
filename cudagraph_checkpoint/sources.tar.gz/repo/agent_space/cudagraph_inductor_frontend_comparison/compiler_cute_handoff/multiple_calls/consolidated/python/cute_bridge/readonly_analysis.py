"""CuTe device effects with exact fixed shared-memory configuration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from torch._inductor.runtime.cutedsl_parameter_analysis import (
    ANALYSIS_VERSION,
    PointerFormal,
    _ALLOWLIST,
    _FLOAT_OPS,
    _INDEX_OPS,
    _INT_OPS,
    _Unsupported,
    _numeric_type,
    _walk_block,
)


if TYPE_CHECKING:
    from cutlass._mlir import ir


READONLY_ANALYSIS_VERSION = 1
_DIVISION_OPS = {"arith.floordivsi", "arith.remsi"}
_TUPLE_DIVISION_OPS = {"cute.tuple_div", "cute.tuple_mod"}
if ANALYSIS_VERSION != 3:
    raise RuntimeError("This isolated migration requires the reviewed version-3 analyzer")


def _inspect_kernel(kernel: ir.Operation, *, module: ir.Module,
                    configured_smem: int | None = None) -> tuple[PointerFormal, ...]:
    from cutlass._mlir import ir

    if not isinstance(module, ir.Module) or not isinstance(kernel, ir.Operation):
        raise _Unsupported("expected an explicit module owner and kernel operation")
    if not callable(getattr(ir, "raw_values", None)):
        raise _Unsupported("device inspection requires CuTe ir.raw_values()")
    with module.context, ir.raw_values():
        if kernel.name != "cuda.kernel" or not any(op == kernel for op in _walk_block(module.body)):
            raise _Unsupported("kernel does not belong to the supplied module")
        return _inspect_raw_kernel(kernel, configured_smem=configured_smem)


def _inspect_raw_kernel(kernel: ir.Operation, *, configured_smem: int | None = None) -> tuple[PointerFormal, ...]:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import cute

    if len(kernel.regions) != 1 or len(kernel.regions[0].blocks) != 1:
        raise _Unsupported("expected one device entry block")
    block = kernel.regions[0].blocks[0]
    root_ops = [view.operation for view in block.operations]
    if not root_ops or root_ops[-1].name != "cuda.return":
        raise _Unsupported("expected a CUDA kernel return")
    attrs = kernel.attributes
    allowed_attrs = {
        "sym_name", "function_type", "cute.kernel", "gpu.kernel", "cu_attrs",
        "nvvm.reqntid", "smem.partition_num", "arg_attrs",
    }
    if "smem.config_smem_size" in attrs:
        config = attrs["smem.config_smem_size"]
        if (type(configured_smem) is not int or not 0 <= configured_smem < 2**32
                or not isinstance(config, ir.IntegerAttr) or config.type != ir.IntegerType.get_signless(64)
                or config.value != configured_smem):
            raise _Unsupported("kernel shared-memory configuration differs from its exact launch consumer")
        allowed_attrs.add("smem.config_smem_size")
    if set(attrs) - allowed_attrs:
        raise _Unsupported(f"unsupported kernel or argument attributes: {sorted(set(attrs) - allowed_attrs)}")
    signature = attrs["function_type"].value
    if not isinstance(signature, ir.FunctionType) or signature.results:
        raise _Unsupported("expected a void device kernel")
    arg_types = list(block.arguments.types)
    if list(signature.inputs) != arg_types:
        raise _Unsupported("device signature and block argument types differ")
    if "arg_attrs" in attrs and (
        not isinstance(attrs["arg_attrs"], ir.ArrayAttr)
        or len(attrs["arg_attrs"]) != len(arg_types)
        or any(not isinstance(attr, ir.DictAttr) or len(attr) for attr in attrs["arg_attrs"])
    ):
        raise _Unsupported("unsupported device argument attributes")
    for typ in arg_types:
        if isinstance(typ, cute.MemRefType):
            if typ.address_space != 1 or typ.is_swizzled or not _numeric_type(typ.value_type):
                raise _Unsupported("unsupported device tensor type")
        elif not _numeric_type(typ):
            raise _Unsupported("unsupported device formal type")

    shape_ops = {
        "cute.get_shape", "cute.get_leaves", "cute.to_int_tuple",
        "cute.get_scalars", "cute.make_int_tuple", "cute.size",
    }
    metadata_types = (cute.CoordType, cute.LayoutType, cute.ShapeType, cute.IntTupleType)
    # Reject unsupported operations and types in every branch before provenance analysis.
    for op in _walk_block(block):
        if op.name not in _ALLOWLIST | _DIVISION_OPS | _TUPLE_DIVISION_OPS | shape_ops | {"scf.if", "scf.yield"}:
            raise _Unsupported(f"unsupported operation {op.name}")
        if op.successors:
            raise _Unsupported("unstructured control flow is unsupported")
        if op.name == "scf.if":
            if len(op.regions) != 2 or any(len(region.blocks) != 1 for region in op.regions):
                raise _Unsupported("expected two single-block conditional branches")
            for region in op.regions:
                child = region.blocks[0]
                children = list(child.operations)
                if child.arguments or not children or children[-1].operation.name != "scf.yield":
                    raise _Unsupported("unsupported conditional block arguments or terminator")
        elif op.regions:
            raise _Unsupported(f"unsupported control flow {op.name}")
        allowed = (
            {"value"} if op.name == "arith.constant"
            else {"fastmath"} if op.name in _FLOAT_OPS
            else {"overflowFlags"} if op.name in _INT_OPS
            else {"predicate"} if op.name == "arith.cmpi"
            else {"mode"} if op.name == "cute.size"
            else set()
        )
        if set(op.attributes) - allowed:
            raise _Unsupported(f"unsupported attributes on {op.name}")
        for typ in op.results.types:
            if _numeric_type(typ) or isinstance(typ, metadata_types):
                continue
            if (
                isinstance(typ, cute.PtrType)
                and typ.address_space == 1
                and not typ.is_swizzled
                and _numeric_type(typ.value_type)
            ):
                continue
            if op.name == "scf.if" and isinstance(typ, cute.MemRefType) and typ in arg_types:
                continue
            raise _Unsupported(f"unsupported result type on {op.name}")

    formals = list(block.arguments)
    origins = {
        value: index for index, value in enumerate(formals)
        if isinstance(arg_types[index], cute.MemRefType)
    }
    pointer_types: dict[int, ir.Type] = {}
    layout_types: dict[int, ir.Type] = {}
    for op in _walk_block(block):
        if op.name not in ("cute.get_iter", "cute.get_layout"):
            continue
        args = list(op.operands)
        result_types = list(op.results.types)
        if len(args) != 1 or len(result_types) != 1:
            raise _Unsupported("unsupported tensor projection")
        if args[0] not in origins:
            continue
        index = origins[args[0]]
        evidence = pointer_types if op.name == "cute.get_iter" else layout_types
        if evidence.setdefault(index, result_types[0]) != result_types[0]:
            raise _Unsupported("conflicting direct-formal projection types")

    alignments: dict[int, int] = {}
    reads: set[int] = set()
    writes: set[int] = set()
    for index in origins.values():
        if index not in pointer_types or index not in layout_types:
            raise _Unsupported("missing direct-formal iterator/layout type evidence")
        pointer_type = pointer_types[index]
        layout_type = layout_types[index]
        if (
            not isinstance(pointer_type, cute.PtrType)
            or pointer_type.address_space != 1
            or pointer_type.is_swizzled
            or pointer_type.value_type != arg_types[index].value_type
            or not isinstance(layout_type, cute.LayoutType)
            or cute.MemRefType.get(pointer_type, layout_type) != arg_types[index]
        ):
            raise _Unsupported("projection types do not reconstruct the ordinary global tensor")
        alignment = pointer_type.alignment
        if alignment <= 0 or alignment & (alignment - 1):
            raise _Unsupported("unsupported pointer alignment")
        alignments[index] = alignment

    def inspect_block(current: ir.Block) -> list[ir.Value]:
        ops = [view.operation for view in current.operations]
        for op in ops:
            args = list(op.operands)
            result_types = list(op.results.types)
            if op.name == "arith.constant":
                attr = op.attributes.get("value")
                if (
                    args or len(result_types) != 1
                    or not isinstance(attr, (ir.IntegerAttr, ir.FloatAttr))
                    or attr.type != result_types[0]
                ):
                    raise _Unsupported("unsupported numeric constant")
            elif op.name in _DIVISION_OPS:
                if (len(args) != 2 or len(result_types) != 1
                        or not isinstance(result_types[0], ir.IntegerType) or result_types[0].width not in (32, 64)
                        or result_types[0] != ir.IntegerType.get_signless(result_types[0].width)
                        or any(value.type != result_types[0] for value in args)):
                    raise _Unsupported(f"expected matching scalar integer operands and result for {op.name}")
            elif op.name in _TUPLE_DIVISION_OPS:
                if (len(args) != 2 or len(result_types) != 1
                        or any(not isinstance(typ, cute.IntTupleType) or typ.depth != 0 or typ.rank != 1
                               for typ in [*(value.type for value in args), *result_types])):
                    raise _Unsupported(f"expected scalar integer tuple operands and result for {op.name}")
            elif op.name in _FLOAT_OPS | _INT_OPS | {"arith.cmpi"}:
                if (
                    len(args) != 2 or len(result_types) != 1
                    or any(not _numeric_type(value.type) for value in args)
                    or not _numeric_type(result_types[0])
                ):
                    raise _Unsupported(f"unsupported numeric operation {op.name}")
            elif op.name == "arith.sitofp":
                if (
                    len(args) != 1 or len(result_types) != 1
                    or not isinstance(args[0].type, ir.IntegerType) or args[0].type.width != 32
                    or not isinstance(result_types[0], ir.F32Type)
                ):
                    raise _Unsupported("expected signed int32 to float32 conversion")
            elif op.name in _INDEX_OPS:
                if args or len(result_types) != 1 or not isinstance(result_types[0], ir.IntegerType):
                    raise _Unsupported("unsupported thread-index operation")
            elif op.name in ("cute.get_iter", "cute.get_layout"):
                if len(args) != 1 or args[0] not in origins or len(result_types) != 1:
                    raise _Unsupported("unsupported tensor provenance")
                expected = cute.PtrType if op.name == "cute.get_iter" else cute.LayoutType
                if not isinstance(result_types[0], expected):
                    raise _Unsupported("unsupported tensor projection")
                if op.name == "cute.get_iter" and result_types[0].alignment != alignments[origins[args[0]]]:
                    raise _Unsupported("unaccounted pointer alignment assumption")
                evidence = pointer_types if op.name == "cute.get_iter" else layout_types
                if result_types[0] != evidence[origins[args[0]]]:
                    raise _Unsupported("tensor projection type differs from formal evidence")
            elif op.name in shape_ops:
                if op.name == "cute.size":
                    mode = op.attributes.get("mode")
                    if not isinstance(mode, ir.DenseI32ArrayAttr) or len(mode):
                        raise _Unsupported("only full-shape size queries are supported")
                if not args or not result_types:
                    raise _Unsupported("expected shape-only operands and results")
                if any(not isinstance(value.type, metadata_types + (ir.IntegerType,)) for value in args):
                    raise _Unsupported("shape operation uses a pointer or tensor")
                if any(not isinstance(typ, metadata_types + (ir.IntegerType,)) for typ in result_types):
                    raise _Unsupported("shape operation produces a pointer or tensor")
            elif op.name == "cute.make_coord":
                if (
                    len(result_types) != 1 or not isinstance(result_types[0], cute.CoordType)
                    or any(not isinstance(value.type, ir.IntegerType)
                           and not (isinstance(value.type, cute.IntTupleType)
                                    and value.type.depth == 0 and value.type.rank == 1) for value in args)
                ):
                    raise _Unsupported("unsupported coordinate construction")
            elif op.name in ("cute.memref.load", "cute.memref.store"):
                is_load = op.name == "cute.memref.load"
                if (
                    len(args) != (2 if is_load else 3)
                    or args[0] not in origins
                    or not isinstance(args[1].type, cute.CoordType)
                    or (is_load and result_types != [args[0].type.value_type])
                    or (not is_load and (result_types or args[2].type != args[0].type.value_type))
                ):
                    raise _Unsupported("unsupported tensor load/store provenance")
                (reads if is_load else writes).add(origins[args[0]])
            elif op.name == "scf.if":
                if len(args) != 1 or not isinstance(args[0].type, ir.IntegerType) or args[0].type.width != 1:
                    raise _Unsupported("expected a scalar boolean condition")
                branches = [inspect_block(region.blocks[0]) for region in op.regions]
                if any([value.type for value in values] != result_types for values in branches):
                    raise _Unsupported("conditional yield types differ")
                for index, typ in enumerate(result_types):
                    if isinstance(typ, cute.MemRefType):
                        origin = origins.get(branches[0][index])
                        if origin is None or origins.get(branches[1][index]) != origin:
                            raise _Unsupported("conditional tensor has ambiguous pointer provenance")
                        origins[op.results[index]] = origin
                    elif not _numeric_type(typ):
                        raise _Unsupported("unsupported conditional result")
            elif op.name == "scf.yield":
                if result_types:
                    raise _Unsupported("conditional yield cannot produce results")
                return args
            elif op.name == "cuda.return":
                if args or result_types:
                    raise _Unsupported("kernel must return no values")
        return []

    try:
        inspect_block(block)
        if not reads or not writes:
            raise _Unsupported("expected an ordinary load/compute/store kernel")
        return tuple(
            PointerFormal(index, str(arg_types[index]), alignment, index in reads, index in writes)
            for index, alignment in alignments.items()
        )
    finally:
        # The recursive closure must not retain borrowed SSA values past this call.
        origins.clear()
        pointer_types.clear()
        layout_types.clear()
