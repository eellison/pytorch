import conversion_signatures_fixture as conversion
import invocation_runtime_fixture as invocation
import compiler_call_cases_fixture as emission
import scalar_tuple_fixture
import provider_decline_fixture
import descriptor_order_fixture
import cold_decline_fixture
import numeric_domain_fixture
from torch.testing._internal.common_utils import run_tests


class TestCompilerConversion(conversion.TestCompilerConversion):
    pass


class TestConversionSignatures(conversion.TestConversionSignatures):
    pass


class TestCompilerInvocation(invocation.TestCompilerInvocation):
    pass


class TestCompilerCallEmission(emission.TestCompilerCallEmission):
    pass


class TestScalarTupleEffects(scalar_tuple_fixture.TestScalarTupleEffects):
    pass


class TestProviderDecline(provider_decline_fixture.TestProviderDecline):
    pass


class TestDescriptorOrdering(descriptor_order_fixture.TestDescriptorOrdering):
    pass


class TestColdDeclines(cold_decline_fixture.TestColdDeclines):
    pass


class TestGuardedCeilDivision(numeric_domain_fixture.TestGuardedCeilDivision):
    pass


class TestExistingNumeric(numeric_domain_fixture.TestExistingNumeric):
    pass


if __name__ == "__main__":
    run_tests()
