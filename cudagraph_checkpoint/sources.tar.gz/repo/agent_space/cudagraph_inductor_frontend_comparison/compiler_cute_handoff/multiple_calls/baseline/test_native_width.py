import gc
import json
import sys
import traceback
import weakref

import cutlass.cute as cute
from compiler_cute_handoff import descriptor, policy as mixed
from compiler_cute_handoff.envelope import bind_envelope, EnvelopeDeclined
from compiler_cute_handoff.invocation import InvocationEntry, invoke_cute, register_cute_entry
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import SignaturePolicy
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from selected_kernel import SelectedKernel
import conversion_workload_fixture as workload
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._inductor import config
from torch._inductor.codegen.wrapper import CuTeCallLine, KernelCallLine
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, IntExpr
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class TwoCuTeCalls(torch.nn.Module):
    def __init__(self, first, second):
        super().__init__()
        self.first = first
        self.second = second

    def forward(self, value):
        source = value.sin()
        intermediate = source.clone()
        destination = source.clone()
        invoke_cute(self.first, source, intermediate)
        invoke_cute(self.second, intermediate, destination)
        return (destination,)


class TestMultipleCuTeCalls(TestCase):
    @parametrize("frontend", ("fx", "retained"))
    def test_two_calls_clean_decline(self, device, frontend):
        fixture = fixture_module.TestReductionGraphReplayCUDA("test_generated_reduction_replay_fast_True_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        self.enterContext(config.patch(use_fast_triton_launcher=True, fx_graph_cache=True,
            freezing=False, allow_buffer_reuse=False, inplace_buffers=False,
            normalize_static_input_alignment=True))
        owners, registrations, targets = [], [], []
        layout = TensorPolicy((None, 128), (0, 1))
        for _ in range(2):
            python_entry, kernel, _host = make_fixture()
            owner = ObservedOrdinaryEntry(python_entry, kernel, policy=SignaturePolicy(32, 64, 16, "stream"),
                tensor_policies={"source": layout, "destination": layout})
            self.addCleanup(owner.close)
            registration = register_cute_entry(owner, owned_executor=True)
            self.addCleanup(registration.close)
            owners.append(owner)
            registrations.append(registration)
            targets.append(python_entry.target)
        self.assertIsNot(targets[0], targets[1])
        self.assertNotEqual(registrations[0].key, registrations[1].key)
        policy = workload.RecordingPolicy(frontend)
        self.addCleanup(policy.close)
        self.enterContext(config.patch(cudagraph_policy=policy))
        compiled = torch.compile(TwoCuTeCalls(*(entry.key for entry in registrations)),
                                 fullgraph=True, dynamic=True)
        previous = sys.getprofile()
        self.assertIsNone(previous)
        self.addCleanup(sys.setprofile, previous)
        compile_code = type(cute.compile).__call__.__code__
        programs, reports, input_storages, temporary_storages, output_storages = [], [], [], [], []

        def call(rows, first=False):
            value = torch.randn(rows, 128, device=device, dtype=torch.float32)
            torch._dynamo.mark_static(value, 1)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            state = {"compile": [0, 0], "owned": [0, 0], "calls": [], "original": 0,
                     "prepare": 0, "compiler": 0, "box": None, "result": None,
                     "active": False, "intermediate": None}
            failures = []

            def observe(frame, event, result):
                try:
                    code = frame.f_code
                    if event == "return" and code is descriptor.collect_descriptors.__code__ and result is not None:
                        wrapper = frame.f_locals["wrapper"]
                        order = []
                        for line in wrapper.lines:
                            if type(line) is CuTeCallLine:
                                order.append(("cute", line.node.entry_key))
                            elif type(line) is KernelCallLine:
                                order.append(("generated", line.kernel_name))
                        if order not in programs:
                            programs.append(order)
                    for _, original in policy.artifacts:
                        if code is original.__code__ and frame.f_globals is original.__globals__:
                            if event == "call":
                                state["original"] += 1
                                state["active"] = True
                                state["box"] = frame.f_locals[code.co_varnames[0]]
                            elif event == "return":
                                state["active"] = False
                                state["result"] = result
                    if event != "call":
                        return
                    if code is compile_code and frame.f_locals.get("self") is cute.compile:
                        target = frame.f_locals["args"][0]
                        self.assertTrue(any(target is expected for expected in targets))
                        state["compile"][next(i for i, expected in enumerate(targets) if target is expected)] += 1
                    if code is OrdinaryEntry._invoke_owned.__code__:
                        current = frame.f_locals["self"]
                        if any(current is owner for owner in owners):
                            state["owned"][next(i for i, owner in enumerate(owners) if current is owner)] += 1
                    if code is OrdinaryEntry._invoke_compiler.__code__:
                        state["compiler"] += 1
                    if code is mixed.MixedInstallation._prepare_variant.__code__:
                        state["prepare"] += 1
                    if state["active"] and code is InvocationEntry.invoke.__code__:
                        current = frame.f_locals["self"]
                        self.assertTrue(any(current is entry for entry in registrations))
                        index = next(i for i, entry in enumerate(registrations) if current is entry)
                        source, destination = frame.f_locals["source"], frame.f_locals["destination"]
                        state["calls"].append(index)
                        self.assertIs(type(source), torch.Tensor)
                        self.assertIs(type(destination), torch.Tensor)
                        self.assertEqual(tuple(source.shape), (rows, 128))
                        self.assertEqual(tuple(destination.shape), (rows, 128))
                        self.assertEqual(source.stride(), (128, 1))
                        self.assertEqual(destination.stride(), (128, 1))
                        self.assertNotEqual(source.untyped_storage()._cdata, destination.untyped_storage()._cdata)
                        if index == 0:
                            state["intermediate"] = weakref.ref(destination)
                            temporary_storages.extend(StorageWeakRef(tensor.untyped_storage())
                                                      for tensor in (source, destination))
                        else:
                            self.assertIs(source, state["intermediate"]())
                except BaseException as error:
                    if not failures:
                        failures.append("".join(traceback.format_exception(error)))

            try:
                sys.setprofile(observe)
                try:
                    result = compiled(value)
                finally:
                    sys.setprofile(previous)
            except BaseException as error:
                for failure in failures:
                    error.add_note("Deferred multiple-call observer failure:\n" + failure)
                raise
            if failures:
                self.fail(failures[0])
            offset = 64 if rows < 4 else 128
            expected = ((value.sin() * 2 + offset) * 2 + offset,)
            self.assertIs(type(result), tuple)
            self.assertEqual(result, expected)
            self.assertIs(type(state["result"]), tuple)
            self.assertEqual(len(state["result"]), len(result))
            self.assertIs(state["result"][0], result[0])
            self.assertIs(type(state["box"]), list)
            self.assertEqual(state["box"], [])
            self.assertEqual(state["compile"], [1, 1] if first else [0, 0])
            self.assertEqual(state["owned"], [1, 1])
            self.assertEqual(state["calls"], [0, 1])
            self.assertEqual((state["original"], state["prepare"], state["compiler"]), (1, 0, 0))
            self.assertEqual(len(policy.artifacts), 1)
            self.assertEqual(policy.installations, ())
            artifact, original = policy.artifacts[0]
            self.assertIs(artifact.current_callable, original)
            self.assertIsNone(artifact._cudagraph_installation_owner)
            self.assertNotIn("_cute_mixed_attachment", original.__dict__)
            with self.assertRaisesRegex(EnvelopeDeclined, "^Mixed compiler envelope is unavailable$"):
                bind_envelope(original)
            output_storages.append(StorageWeakRef(result[0].untyped_storage()))
            reports.append({"rows": rows, "arm": rows < 4, "compiles": state["compile"],
                            "owned_calls": state["owned"], "call_order": state["calls"],
                            "original_calls": state["original"], "native_preparations": state["prepare"]})
            return result, expected

        held = [call(13, first=True)]
        artifact, original = policy.artifacts[0]
        binding = descriptor.bind_descriptors(original)
        self.assertEqual(len(binding.records.calls), 2)
        self.assertEqual(len(binding.entries), 2)
        for entry, registration, fact in zip(binding.entries, registrations, binding.records.calls, strict=True):
            self.assertIs(entry, registration)
            self.assertIs(original.__globals__[fact.entry_global], registration)
            self.assertEqual(fact.formals, ("source", "destination"))
            for operand in fact.operands:
                self.assertIs(type(operand.source), BufferSource)
                self.assertEqual(operand.stride, (128, 1))
                self.assertEqual(operand.size[1], 128)
                self.assertIs(type(operand.size[0]), IntExpr)
        first, second = binding.records.calls
        self.assertEqual(first.operands[1], second.operands[0])
        self.assertEqual(len({first.operands[0].source, first.operands[1].source, second.operands[1].source}), 3)
        self.assertEqual(binding.records.outputs, (second.operands[1].source,))
        self.assertEqual(len(programs), 1)
        order, = programs
        positions = [i for i, (kind, _) in enumerate(order) if kind == "cute"]
        self.assertEqual([order[i][1] for i in positions], [entry.key for entry in registrations])
        self.assertGreater(positions[0], 0)
        self.assertEqual(positions, [len(order) - 2, len(order) - 1])
        self.assertTrue(all(kind == "generated" for kind, _ in order[:positions[0]]))
        for name in dict.fromkeys(name for kind, name in order if kind == "generated"):
            selection = SelectedKernel.from_warmed(original.__globals__[name])
            _, selected, cached, module = selection.identity
            self.assertIsNot(cached, selected)
            self.assertIs(type(cached.__globals__["runner"]), torch._C._FastCudaLauncher)
            self.assertIs(cached._static_kernel_owner, module)
            fixture.modules[id(module)] = module
        prepared = tuple(owner._owned_executor for owner in owners)
        self.assertTrue(all(item is not None for item in prepared))
        self.assertIsNot(prepared[0], prepared[1])
        self.assertIsNot(prepared[0].selected, prepared[1].selected)
        self.assertIsNot(prepared[0].executor, prepared[1].executor)
        executor_refs = tuple(weakref.ref(item.executor) for item in prepared)
        for rows in (2, 7, 3, 35, 36):
            held.append(call(rows))
            binding.check()
            for owner, saved in zip(owners, prepared, strict=True):
                self.assertIs(owner._owned_executor, saved)
                self.assertEqual(owner._native_borrows, set())
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        self.assertTrue(all(storage.expired() for storage in temporary_storages))
        policy.close()
        for registration in registrations:
            registration.close()
        self.assertTrue(all(owner.closed for owner in owners))
        del prepared, saved
        gc.collect()
        self.assertTrue(all(reference() is None for reference in executor_refs))
        for result, expected in held:
            self.assertEqual(result, expected)
        del result, expected
        held.clear()
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in output_storages))
        print("MULTIPLE_CUTE_CALLS_RESULT=" + json.dumps({"frontend": frontend, "mode": "ordinary_fallback",
            "native_supported": False, "observations": reports, "program_order": order,
            "descriptor_calls": 2, "outer_artifacts": 1, "ordinary_compilations": 2,
            "distinct_selected_executors": True, "exact_output_projection": True,
            "ordinary_output_identity": True, "typed_envelope_decline": True,
            "input_and_intermediate_storages_released": True, "outputs_survive_close": True,
            "output_storages_released": True, "executors_released": True}, sort_keys=True))


instantiate_device_type_tests(TestMultipleCuTeCalls, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
