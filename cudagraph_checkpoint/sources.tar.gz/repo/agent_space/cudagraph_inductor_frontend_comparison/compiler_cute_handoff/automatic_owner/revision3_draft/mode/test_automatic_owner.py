import copy
from contextlib import contextmanager, ExitStack
import ctypes
import gc
import pickle
from types import SimpleNamespace
from unittest import mock
import weakref

from automatic_owner_envelope_fixture import CompilerFixture
from compiler_cute_handoff import policy as mixed
from compiler_cute_handoff.envelope import bind_envelope
from compiler_cute_handoff.invocation import register_cute_entry
from compiler_policy_handoff.policy import HandoffInvalidated, NativeCUDAGraphPolicy
from cute_dispatch.cache import Authority, ColdCache, PreparedVariant
from cute_dispatch.entry import OrdinaryEntry
from ordinary_artifact_capture.owner import CaptureIneligible
import torch
from torch._inductor import config
from torch._inductor.output_code import CompiledFxGraph
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch._functorch._aot_autograd.runtime_wrappers import _AnalyzeCustomOpInputOutputMode
from torch._ops import _len_torch_dispatch_stack_pre_dispatch
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
from torch.utils import _python_dispatch as dispatch


class Resource:
    def __init__(self, events, name):
        self.events, self.name = events, name
        self.closed = False
        self.error = None
        self.close_calls = 0

    def close(self):
        if self.closed:
            return
        self.close_calls += 1
        self.events.append(self.name)
        if self.error is not None:
            raise self.error
        self.closed = True


class Dispatcher:
    """CPU stand-in for the native miss/append/close contract; no native replay."""

    def __init__(self, variants, miss):
        self.variants, self.miss = list(variants), miss
        self.closed = self.failed = self.invalidated = self.active = False
        self.close_calls = 0

    def append(self, entry, registration):
        if self.closed or self.failed or self.invalidated:
            raise RuntimeError("Dispatcher cannot append")
        self.variants.append((entry, registration))

    def __call__(self, box):
        if self.active or self.closed:
            raise RuntimeError("Dispatcher is busy or closed")
        self.active = True
        try:
            return self.miss(box)
        finally:
            self.active = False

    def invalidate(self):
        self.invalidated = True

    def close(self):
        if self.active:
            raise RuntimeError("Cannot close inside a native miss")
        if self.closed:
            return
        self.close_calls += 1
        for entry, _ in self.variants:
            entry.close()
        self.variants.clear()
        self.closed = True


@instantiate_parametrized_tests
class TestAutomaticCuTeOwner(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.enterContext(torch.no_grad())
        self.enterContext(mock.patch.object(torch._C, "_cuda_make_boxed_dispatch", side_effect=Dispatcher))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, *, cute=True, frontend="records", arm=True, cleanup_policy=True):
        compiler = CompilerFixture(self)
        records = compiler.collect()
        _, source = compiler.emit(records)
        tensor_index = records.inputs.tensor_inputs[0].index
        body = ("calls.append(box)\n    hook(box)\n"
                f"    value = box[{tensor_index}]\n    box.clear()\n"
                "    result = (value.clone(),)\n    outcomes.append(result)\n    return result")
        source = source.replace("raise AssertionError('CPU source fixture must not execute the generated CUDA wrapper')", body)
        namespace = {row.kernel_global: object() for row in records.generated_calls}
        namespace.update(calls=[], outcomes=[], hook=lambda box: None)
        exec(compile(source, "<automatic-owner-cpu-ordinary>", "exec"), namespace)
        original = namespace["call"]
        artifact = CompiledFxGraph.__new__(CompiledFxGraph)
        artifact.current_callable = artifact._cudagraph_original_callable = original
        artifact._cudagraph_installation_owner = None
        artifact.compiled_fn_runner = artifact._original_gm = None
        artifact.constants, artifact.opaque_value_type_classes = {}, {}
        artifact.fx_kwargs = {"static_input_idxs": []}
        policy = NativeCUDAGraphPolicy(cute=cute, frontend=frontend)
        if cleanup_policy:
            self.addCleanup(policy.close)
        if arm:
            self.assertIs(policy.wrap_output(artifact), artifact)
        return SimpleNamespace(compiler=compiler, artifact=artifact, original=original,
                               namespace=namespace, policy=policy)

    def box(self, fixture, rows=13):
        return [rows if kind == "integer" else torch.empty(1)
                for kind in bind_envelope(fixture.original).inputs.kinds]

    def prepare(self, installation, events):
        entry, owner = Resource(events, "entry"), Resource(events, "owner")
        candidate = PreparedVariant(installation.authority, entry, ((), 1, object()), (owner,))
        return candidate

    @contextmanager
    def cold_build(self, fixture, installation, error=None):
        """Actual cold orchestration with explicit compiler, driver and owner stand-ins."""
        stages, events = [], []
        entry, owner = Resource(events, "entry"), Resource(events, "owner")
        trace = SimpleNamespace(calls=(object(),))
        invocation = SimpleNamespace(plan=object(), formals=(), stream_source_index=0)
        artifact = SimpleNamespace(sites=(object(),))
        linked = SimpleNamespace(program=SimpleNamespace(calls=(SimpleNamespace(provider_key="user_cute"),)))
        predicate = ctypes.CFUNCTYPE(ctypes.c_int8, ctypes.POINTER(ctypes.c_int64),
                                    ctypes.POINTER(ctypes.c_double))(lambda integers, floats: 1)
        guard = SimpleNamespace(registration=((), ctypes.cast(predicate, ctypes.c_void_p).value, predicate))
        installation._generated = tuple(SimpleNamespace(check=lambda: None)
                                        for _ in installation._binding.records.generated_calls)
        ambient = torch.get_default_dtype(), torch.is_grad_enabled(), torch.is_inference_mode_enabled()
        check = installation._check

        def final_check(expected):
            if installation._pending_entry is not None:
                self.assertEqual(dispatch._get_current_dispatch_mode_stack(), [])
                stages.append("final_source")
            return check(expected)

        with ExitStack() as stack:
            stack.enter_context(mock.patch.object(installation, "_check", side_effect=final_check))
            stack.enter_context(mock.patch.object(torch.cuda, "current_stream", return_value=SimpleNamespace(cuda_stream=1)))
            patches = (
                (mixed, "trace_cute_invocation", trace),
                (mixed, "build_entry_signature", object()),
                (fixture.compiler.owner, "compilation", object()),
                (mixed, "bind_ordinary_metadata", object()),
                (mixed, "join_ordinary_correspondence", object()),
                (mixed, "normalize_artifact_invocation", invocation),
                (mixed, "compile_target_layout", object()),
                (mixed, "compile_stream_layout", object()),
                (mixed, "prepare_dispatch_artifact", artifact),
                (mixed, "_constant_consumer", 1),
                (mixed, "CuTeKernelOwner", owner),
                (mixed, "extract_pointer_effects", object()),
                (mixed, "link_cute_invocation", linked),
                (mixed, "prepare_guard", guard),
                (mixed.preparation, "prepare_variant", entry),
            )
            for target, name, value in patches:
                def call(*args, _name=name, _value=value, **kwargs):
                    self.assertEqual(dispatch._get_current_dispatch_mode_stack(), [])
                    self.assertEqual(_len_torch_dispatch_stack_pre_dispatch(), 0)
                    self.assertEqual((torch.get_default_dtype(), torch.is_grad_enabled(),
                                      torch.is_inference_mode_enabled()), ambient)
                    stages.append(_name)
                    if _name == "trace_cute_invocation":
                        self.assertIs(args[0], installation._binding.binding)
                        self.assertIs(args[1], installation._binding.inputs)
                    if _name == "prepare_variant" and error is not None:
                        raise error
                    return _value
                stack.enter_context(mock.patch.object(target, name, side_effect=call))
            yield SimpleNamespace(entry=entry, owner=owner, stages=stages, events=events)

    @parametrize("analyzer", (False, True))
    @parametrize("outcome", ("success", "decline", "unexpected"))
    def test_cold_build_isolates_only_aot_and_restores_mode(self, analyzer, outcome):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        mode = _AnalyzeCustomOpInputOutputMode()
        expected = [mode] if analyzer else []
        ordinary_modes = []
        fixture.namespace["hook"] = lambda box: ordinary_modes.append(dispatch._get_current_dispatch_mode_stack())
        box = self.box(fixture)
        error = (UnsupportedCapture("fixture late capture decline") if outcome == "decline" else
                 ValueError("fixture unexpected capture error") if outcome == "unexpected" else None)
        with self.cold_build(fixture, installation, error) as build, ExitStack() as stack:
            if analyzer:
                stack.enter_context(mode)
            if outcome == "unexpected":
                with self.assertRaises(ValueError) as raised:
                    fixture.artifact.current_callable(box)
                self.assertIs(raised.exception, error)
                self.assertEqual(installation.status, "failed")
            else:
                result = fixture.artifact.current_callable(box)
                self.assertIs(result, fixture.namespace["outcomes"][0])
                self.assertEqual(installation.status, "ready" if outcome == "success" else "declined")
            self.assertEqual(ordinary_modes, [expected])
            self.assertEqual(dispatch._get_current_dispatch_mode_stack(), expected)
            self.assertEqual(_len_torch_dispatch_stack_pre_dispatch(), 0)
            self.assertEqual(box, [])
            self.assertIs(fixture.namespace["calls"][0], box)
            self.assertEqual(len(fixture.namespace["calls"]), 1)
            self.assertIn("build_entry_signature", build.stages)
            self.assertIn("prepare_variant", build.stages)
            if outcome == "success":
                self.assertIn("final_source", build.stages)
                self.assertEqual(build.events, [])
            else:
                self.assertEqual(build.events, ["owner"])
            self.assertIsNone(installation._pending_entry)
            self.assertEqual(installation._pending_owners, [])
        self.assertEqual(dispatch._get_current_dispatch_mode_stack(), [])

    @parametrize("kind", ("user", "subclass", "nested"))
    def test_unknown_mode_stack_declines_after_exact_ordinary_result(self, kind):
        class UserMode(dispatch.TorchDispatchMode):
            def __torch_dispatch__(self, func, types, args=(), kwargs=None):
                return func(*args, **(kwargs or {}))

        class AnalyzerSubclass(_AnalyzeCustomOpInputOutputMode):
            pass

        fixture = self.fixture()
        installation, = fixture.policy.installations
        modes = ([UserMode()] if kind == "user" else [AnalyzerSubclass()] if kind == "subclass" else
                 [_AnalyzeCustomOpInputOutputMode(), _AnalyzeCustomOpInputOutputMode()])
        box = self.box(fixture)
        with ExitStack() as stack, mock.patch.object(mixed, "trace_cute_invocation") as trace:
            for mode in modes:
                stack.enter_context(mode)
            result = fixture.artifact.current_callable(box)
            trace.assert_not_called()
            self.assertIs(result, fixture.namespace["outcomes"][0])
            self.assertEqual(dispatch._get_current_dispatch_mode_stack(), modes)
            self.assertEqual(box, [])
            self.assertEqual(len(fixture.namespace["calls"]), 1)
            self.assertIs(fixture.artifact.current_callable, fixture.original)
            self.assertEqual(installation.status, "declined")
            self.assertIsNone(installation.entry)

    def test_predispatch_mode_declines_without_removing_any_mode(self):
        from torch._ops import _get_dispatch_mode_pre_dispatch
        from torch._subclasses.functional_tensor import FunctionalTensorMode

        mode = FunctionalTensorMode(pre_dispatch=True)
        with mode, _AnalyzeCustomOpInputOutputMode():
            before = dispatch._get_current_dispatch_mode_stack()
            with self.assertRaisesRegex(UnsupportedCapture, "dispatch mode"), mixed._isolate_cold_dispatch():
                self.fail("Pre-dispatch mode must decline before construction")
            self.assertEqual(dispatch._get_current_dispatch_mode_stack(), before)
            self.assertEqual(_len_torch_dispatch_stack_pre_dispatch(), 1)
            self.assertIs(_get_dispatch_mode_pre_dispatch(torch._C._TorchDispatchModeKey.FUNCTIONAL), mode)
        self.assertEqual(_len_torch_dispatch_stack_pre_dispatch(), 0)

    @parametrize("cleanup_failure", (False, True))
    def test_mode_restore_failure_keeps_stages_until_checked_cleanup(self, cleanup_failure):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        mode = _AnalyzeCustomOpInputOutputMode()
        restore_error = UnsupportedCapture("fixture mode restore failure")
        cleanup_error = UnsupportedCapture("fixture staged close failure")
        push = dispatch._push_mode
        box = self.box(fixture)
        with self.cold_build(fixture, installation) as build:
            build.entry.error = cleanup_error if cleanup_failure else None

            def fail_restore(value):
                self.assertIs(value, mode)
                self.assertIs(installation._pending_entry, build.entry)
                self.assertEqual(installation._pending_owners, [build.owner])
                self.assertEqual(build.events, [])
                push(value)
                raise restore_error

            with mode, mock.patch.object(dispatch, "_push_mode", side_effect=fail_restore):
                with self.assertRaises(UnsupportedCapture if cleanup_failure else RuntimeError) as raised:
                    fixture.artifact.current_callable(box)
                self.assertEqual(dispatch._get_current_dispatch_mode_stack(), [mode])
            if cleanup_failure:
                self.assertIs(raised.exception, cleanup_error)
                self.assertIsInstance(raised.exception.__cause__, RuntimeError)
                self.assertIs(raised.exception.__cause__.__cause__, restore_error)
                self.assertIs(installation._pending_entry, build.entry)
                self.assertEqual(installation._pending_owners, [build.owner])
                self.assertEqual(build.events, ["entry"])
                build.entry.error = None
            else:
                self.assertIs(raised.exception.__cause__, restore_error)
                self.assertIsNone(installation._pending_entry)
                self.assertEqual(installation._pending_owners, [])
                self.assertEqual(build.events, ["entry", "owner"])
            self.assertTrue(installation.cache.failed)
            self.assertEqual(installation.status, "failed")
            self.assertIsNone(installation.decline)
            self.assertEqual(box, [])
            self.assertEqual(len(fixture.namespace["calls"]), 1)
            installation.close()
            self.assertEqual(build.entry.close_calls, 2 if cleanup_failure else 1)
            self.assertEqual(build.owner.close_calls, 1)
            self.assertEqual(fixture.compiler.owner._native_borrows, set())

    @parametrize("consume", (False, True))
    def test_cache_mode_preserves_legacy_or_consumes_actual_box(self, consume):
        box, seen, result = [object()], [], object()
        original = box[0]
        authority = Authority(object(), object(), object())

        def ordinary(values):
            seen.append(values is box)
            self.assertIs(values[0], original)
            values.clear()
            return result

        def prepare(values, returned):
            self.assertIs(values[0], original)
            self.assertIs(returned, result)
            return PreparedVariant(authority, Resource([], "entry"), ((), 1, object()))

        cache = ColdCache(authority, ordinary, prepare, consume_box=consume)
        self.addCleanup(cache.close)
        self.assertIs(cache.bootstrap(box), result)
        self.assertEqual(seen, [consume])
        self.assertEqual(len(box), 0 if consume else 1)

    @parametrize("option", (1, "yes"))
    def test_cache_mode_requires_exact_bool(self, option):
        with self.assertRaises(TypeError):
            ColdCache(Authority(None, None, None), None, None, consume_box=option)

    def test_consuming_cache_rejects_unconsumed_box_before_preparation(self):
        box, prepare = [object()], mock.Mock()
        cache = ColdCache(Authority(None, None, None), lambda values: (), prepare, consume_box=True)
        self.addCleanup(cache.close)
        with self.assertRaisesRegex(RuntimeError, "consume"):
            cache.bootstrap(box)
        prepare.assert_not_called()
        self.assertEqual(len(box), 1)

    def test_borrow_blocks_registration_direct_owner_and_other_registration_close(self):
        fixture = CompilerFixture(self)
        other = register_cute_entry(fixture.owner)
        self.addCleanup(other.close)
        borrow = fixture.entry.borrow_native()
        self.addCleanup(borrow.close)
        borrow.check()
        self.assertIs(borrow.entry, fixture.entry)
        self.assertIs(borrow.owner, fixture.owner)
        with self.assertRaises(AttributeError):
            borrow.owner = object()
        for close in (fixture.entry.close, fixture.owner.close, other.close):
            with self.assertRaisesRegex(RuntimeError, "borrowed"):
                close()
        self.assertFalse(fixture.entry.closed)
        with self.assertRaises(TypeError):
            pickle.dumps(borrow)
        borrow.close()
        borrow.close()
        self.assertEqual(fixture.owner._native_borrows, set())
        other.close()

    def test_arming_source_callback_preserves_competing_callable_and_releases_borrow(self):
        fixture = self.fixture(arm=False)
        acquire = OrdinaryEntry._acquire_native_borrow
        competitor = lambda box: None

        def change(owner):
            token = acquire(owner)
            fixture.artifact.current_callable = competitor
            return token

        with mock.patch.object(OrdinaryEntry, "_acquire_native_borrow", change), self.assertRaises(HandoffInvalidated):
            fixture.policy.wrap_output(fixture.artifact)
        self.assertIs(fixture.artifact.current_callable, competitor)
        self.assertIsNone(fixture.artifact._cudagraph_installation_owner)
        self.assertEqual(fixture.policy.installations, ())
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    @parametrize("frontend", ("records", "fx", "retained"))
    def test_default_policy_leaves_mixed_call_ordinary(self, frontend):
        fixture = self.fixture(cute=False, frontend=frontend)
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertEqual(fixture.policy.installations, ())
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    @parametrize("fault", ("static_inputs", "metadata", "original"))
    def test_ineligible_admission_does_not_acquire_borrow(self, fault):
        fixture = self.fixture(arm=False)
        if fault == "static_inputs":
            fixture.artifact.fx_kwargs["static_input_idxs"].append(1)
        elif fault == "metadata":
            fixture.original._cute_mixed_attachment = None
        else:
            fixture.artifact._cudagraph_original_callable = lambda box: None
        fixture.policy.wrap_output(fixture.artifact)
        self.assertEqual(fixture.policy.installations, ())
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    def test_bootstrap_and_local_miss_return_each_exact_ordinary_result_once(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        events, candidates = [], []

        def prepare(values):
            self.assertIs(installation._ordinary_result[1], fixture.namespace["outcomes"][-1])
            self.assertTrue(all(x is y for x, y in zip(values, installation._ordinary_result[0])))
            candidate = self.prepare(installation, events)
            candidates.append(candidate)
            return candidate

        with mock.patch.object(installation, "_prepare_variant", side_effect=prepare) as prepare_call:
            first = self.box(fixture)
            result = fixture.artifact.current_callable(first)
            self.assertIs(result, fixture.namespace["outcomes"][0])
            self.assertIs(fixture.namespace["calls"][0], first)
            self.assertEqual(first, [])
            self.assertIs(fixture.artifact.current_callable, installation.entry)
            second = self.box(fixture, 2)
            returned = fixture.artifact.current_callable(second)
            self.assertIs(returned, fixture.namespace["outcomes"][1])
            self.assertIs(fixture.namespace["calls"][1], second)
            self.assertEqual(second, [])
            self.assertEqual(prepare_call.call_count, 2)
        self.assertEqual(len(installation.cache.variants), 2)
        self.assertIsNone(installation._ordinary_result)
        self.assertIsNone(installation._active)
        fixture.policy.close()
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertEqual(events.count("entry"), 2)
        self.assertEqual(events.count("owner"), 2)
        self.assertEqual(fixture.compiler.owner._native_borrows, set())
        self.assertIsNotNone(result[0])
        self.assertFalse(fixture.compiler.entry.closed)

    @parametrize("decline", ("capture", "unsupported"))
    def test_first_decline_restores_original_without_retry(self, decline):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        error = CaptureIneligible("fixture capsule") if decline == "capture" else UnsupportedCapture("fixture ABI")
        with mock.patch.object(installation, "_prepare_variant", side_effect=error) as prepare:
            result = fixture.artifact.current_callable(self.box(fixture))
            self.assertIs(result, fixture.namespace["outcomes"][0])
            self.assertIs(fixture.artifact.current_callable, fixture.original)
            fixture.artifact.current_callable(self.box(fixture))
            self.assertEqual(prepare.call_count, 1)
        self.assertEqual(installation.status, "declined")
        self.assertEqual(len(fixture.namespace["calls"]), 2)
        self.assertIsNone(installation.entry)

    def test_later_decline_defers_dispatcher_close_until_miss_unwinds(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        candidate = self.prepare(installation, [])
        with mock.patch.object(installation, "_prepare_variant", return_value=candidate):
            fixture.artifact.current_callable(self.box(fixture))
        dispatcher = installation.entry
        with mock.patch.object(installation, "_prepare_variant", side_effect=CaptureIneligible("fixture miss")):
            result = dispatcher(self.box(fixture, 2))
        self.assertIs(result, fixture.namespace["outcomes"][1])
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertTrue(dispatcher.invalidated)
        self.assertEqual(dispatcher.close_calls, 0)
        self.assertFalse(candidate.entry.closed)
        with self.assertRaisesRegex(RuntimeError, "borrowed"):
            fixture.compiler.entry.close()
        fixture.policy.close()
        self.assertTrue(dispatcher.closed)
        self.assertTrue(candidate.entry.closed)

    def test_typed_cleanup_failure_on_later_miss_is_not_an_eligibility_decline(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        with mock.patch.object(installation, "_prepare_variant", return_value=self.prepare(installation, [])):
            fixture.artifact.current_callable(self.box(fixture))
        error = UnsupportedCapture("fixture cleanup failed")

        def fail(values):
            installation.cache._fail(error)
            raise error

        with mock.patch.object(installation, "_prepare_variant", side_effect=fail), self.assertRaises(UnsupportedCapture) as raised:
            fixture.artifact.current_callable(self.box(fixture, 2))
        self.assertIs(raised.exception, error)
        self.assertEqual(installation.status, "failed")
        self.assertIsNone(installation.decline)
        self.assertEqual(installation.entry.close_calls, 0)
        self.assertTrue(installation.entry.invalidated)
        self.assertEqual(len(fixture.namespace["calls"]), 2)

    @parametrize("kind", ("value", "runtime"))
    def test_unexpected_preparation_error_is_not_a_decline(self, kind):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        error = ValueError("unexpected") if kind == "value" else RuntimeError("unexpected")
        with mock.patch.object(installation, "_prepare_variant", side_effect=error):
            with self.assertRaises(type(error)) as raised:
                fixture.artifact.current_callable(self.box(fixture))
        self.assertIs(raised.exception, error)
        self.assertEqual(installation.status, "failed")
        self.assertIsNone(installation.decline)
        self.assertEqual(len(fixture.namespace["calls"]), 1)

    def test_ordinary_exception_preserves_box_and_skips_preparation(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        error = ValueError("ordinary failure")
        fixture.namespace["hook"] = mock.Mock(side_effect=error)
        box = self.box(fixture)
        with mock.patch.object(installation, "_prepare_variant") as prepare:
            with self.assertRaises(ValueError) as raised:
                fixture.artifact.current_callable(box)
            prepare.assert_not_called()
        self.assertIs(raised.exception, error)
        self.assertNotEqual(box, [])
        self.assertEqual(len(fixture.namespace["calls"]), 1)

    @parametrize("fault", ("original", "attachment", "kernel", "static_inputs"))
    def test_source_changes_reject_before_box_consumption(self, fault):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        box = self.box(fixture)
        if fault == "original":
            target, name, replacement = fixture.artifact, "_cudagraph_original_callable", lambda box: None
        elif fault == "attachment":
            target, name, replacement = fixture.original, "_cute_mixed_attachment", None
        elif fault == "kernel":
            target, name, replacement = fixture.namespace, "prefix_kernel", object()
        else:
            target, name, replacement = fixture.artifact.fx_kwargs, "static_input_idxs", [1]
        context = mock.patch.dict(target, {name: replacement}) if type(target) is dict else mock.patch.object(target, name, replacement)
        with context, self.assertRaises((HandoffInvalidated, RuntimeError)):
            fixture.artifact.current_callable(box)
        self.assertNotEqual(box, [])
        self.assertEqual(fixture.namespace["calls"], [])

    def test_validation_callback_cannot_overwrite_competing_callable(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        checked = installation._binding
        original_check = checked.check
        competitor = lambda box: None

        def change():
            original_check()
            fixture.artifact.current_callable = competitor

        box = self.box(fixture)
        with mock.patch.object(checked, "check", side_effect=change), self.assertRaises(HandoffInvalidated):
            installation(box)
        self.assertIs(fixture.artifact.current_callable, competitor)
        self.assertNotEqual(box, [])
        self.assertEqual(fixture.namespace["calls"], [])

    def test_reentrant_call_and_close_cannot_duplicate_ordinary_execution(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations

        def hook(box):
            with self.assertRaisesRegex(RuntimeError, "busy"):
                installation(box)
            with self.assertRaisesRegex(RuntimeError, "busy"):
                installation.close()
            with self.assertRaisesRegex(RuntimeError, "borrowed"):
                fixture.compiler.owner.close()

        fixture.namespace["hook"] = hook
        with mock.patch.object(installation, "_prepare_variant", return_value=self.prepare(installation, [])):
            fixture.artifact.current_callable(self.box(fixture))
        self.assertEqual(len(fixture.namespace["calls"]), 1)

    @parametrize("close_failure", (False, True))
    def test_publication_conflict_retains_cleanup_and_never_overwrites(self, close_failure):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        events = []
        candidate = self.prepare(installation, events)
        error = RuntimeError("fixture close failed")
        candidate.entry.error = error if close_failure else None
        publish = mixed._publish_prepared
        competitor = lambda box: None

        def conflict(artifact, expected, entry):
            artifact.current_callable = competitor
            return publish(artifact, expected, entry)

        with mock.patch.object(installation, "_prepare_variant", return_value=candidate), mock.patch.object(
            mixed, "_publish_prepared", side_effect=conflict
        ), self.assertRaises(RuntimeError):
            fixture.artifact.current_callable(self.box(fixture))
        self.assertIs(fixture.artifact.current_callable, competitor)
        self.assertEqual(candidate.entry.close_calls, 1)
        self.assertFalse(candidate.owners[0].closed)
        self.assertTrue(fixture.compiler.owner._native_borrows)
        candidate.entry.error = None
        installation.close()
        self.assertTrue(candidate.owners[0].closed)
        self.assertEqual(candidate.entry.close_calls, 2 if close_failure else 1)
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    def test_source_failure_after_staging_invalidates_and_retains_variant(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        candidate = self.prepare(installation, [])
        previous = fixture.namespace["prefix_kernel"]

        def prepare(box):
            fixture.namespace["prefix_kernel"] = object()
            return candidate

        try:
            with mock.patch.object(installation, "_prepare_variant", side_effect=prepare), self.assertRaises(HandoffInvalidated):
                fixture.artifact.current_callable(self.box(fixture))
            self.assertTrue(installation.entry.invalidated)
            self.assertIs(installation.cache.variants[0], candidate)
            self.assertFalse(candidate.entry.closed)
        finally:
            fixture.namespace["prefix_kernel"] = previous
        installation.close()
        self.assertTrue(candidate.entry.closed)

    def test_no_example_or_artifact_function_cycle_after_cold_call(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        box = self.box(fixture)
        tensor = weakref.ref(box[bind_envelope(fixture.original).inputs.tensor_inputs[0].index])
        with mock.patch.object(installation, "_prepare_variant", return_value=self.prepare(installation, [])):
            fixture.artifact.current_callable(box)
        gc.collect()
        self.assertIsNone(tensor())
        artifact, function = weakref.ref(fixture.artifact), weakref.ref(fixture.original)
        del fixture.artifact, fixture.original, fixture.namespace
        gc.collect()
        self.assertIsNone(artifact())
        self.assertIsNone(function())
        installation.close()
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    def test_live_artifact_keeps_local_miss_owner_after_policy_is_dropped(self):
        fixture = self.fixture(cleanup_policy=False)
        installation, = fixture.policy.installations
        reference, policy = weakref.ref(installation), weakref.ref(fixture.policy)
        authority = installation.authority
        installation._prepare_variant = lambda values: PreparedVariant(
            authority, Resource([], "entry"), ((), 1, object()), (Resource([], "owner"),))
        self.addCleanup(lambda: reference() is not None and reference().close())
        fixture.artifact.current_callable(self.box(fixture))
        del fixture.policy, installation
        gc.collect()
        self.assertIsNone(policy())
        self.assertIs(reference(), fixture.artifact._cudagraph_installation_owner)
        self.assertIsNotNone(reference())
        result = fixture.artifact.current_callable(self.box(fixture, 2))
        self.assertIs(result, fixture.namespace["outcomes"][-1])
        self.assertEqual(len(reference().cache.variants), 2)
        reference().close()
        self.assertIs(fixture.artifact.current_callable, fixture.original)
        self.assertIsNone(fixture.artifact._cudagraph_installation_owner)
        self.assertEqual(fixture.compiler.owner._native_borrows, set())

    @parametrize("close_failure", (False, True))
    def test_dead_artifact_releases_resources_or_retains_failed_cleanup(self, close_failure):
        fixture = self.fixture(cleanup_policy=False)
        installation, = fixture.policy.installations
        candidate = self.prepare(installation, [])
        with mock.patch.object(installation, "_prepare_variant", return_value=candidate):
            result = fixture.artifact.current_callable(self.box(fixture))
        marker = Resource([], "global")
        fixture.namespace["lifetime_marker"] = marker
        reference, function, global_marker = weakref.ref(installation), weakref.ref(fixture.original), weakref.ref(marker)
        candidate.entry.error = RuntimeError("destructor cleanup failed") if close_failure else None
        old_failures = tuple(mixed._FAILED_INSTALLATIONS)
        del installation, fixture.policy, fixture.artifact, fixture.original, fixture.namespace, marker
        gc.collect()
        self.assertIsNone(function())
        self.assertIsNone(global_marker())
        if close_failure:
            self.assertEqual(len(mixed._FAILED_INSTALLATIONS), len(old_failures) + 1)
            retained = mixed._FAILED_INSTALLATIONS[-1]
            self.assertEqual(retained.status, "failed")
            self.assertEqual(candidate.entry.close_calls, 1)
            self.assertTrue(fixture.compiler.owner._native_borrows)
            candidate.entry.error = None
            retained.close()
            self.assertEqual(candidate.entry.close_calls, 2)
            del retained
        else:
            self.assertIsNone(reference())
        self.assertEqual(tuple(mixed._FAILED_INSTALLATIONS), old_failures)
        self.assertTrue(candidate.entry.closed)
        self.assertTrue(candidate.owners[0].closed)
        self.assertEqual(fixture.compiler.owner._native_borrows, set())
        self.assertIsNotNone(result[0])

    def test_serialization_copy_clears_only_copy_owner_and_reload_starts_unarmed(self):
        fixture = self.fixture()
        installation, = fixture.policy.installations
        with mock.patch.object(installation, "_prepare_variant", return_value=self.prepare(installation, [])):
            fixture.artifact.current_callable(self.box(fixture))
        duplicate = copy.copy(fixture.artifact)
        duplicate.prepare_for_serialization()
        self.assertIsNone(duplicate._cudagraph_installation_owner)
        self.assertIsNone(duplicate.current_callable)
        self.assertIs(fixture.artifact._cudagraph_installation_owner, installation)
        self.assertFalse(installation.entry.closed)
        with mock.patch.object(installation, "_prepare_variant", return_value=self.prepare(installation, [])):
            fixture.artifact.current_callable(self.box(fixture, 2))
        self.assertEqual(len(installation.cache.variants), 2)
        fresh = self.fixture(arm=False)
        duplicate.cache_key, duplicate.cache_linemap = "fixture", []
        with mock.patch.object(duplicate, "write_to_disk", return_value="<cpu-lifecycle-fixture>"), mock.patch(
            "torch._inductor.codecache.PyCodeCache.load_by_key_path", return_value=SimpleNamespace(call=fresh.original)
        ):
            duplicate.after_deserialization(SimpleNamespace(unwrap=lambda artifact: {}))
        self.assertIs(duplicate.current_callable, fresh.original)
        self.assertIs(duplicate._cudagraph_original_callable, fresh.original)
        self.assertIsNone(duplicate._cudagraph_installation_owner)
        fresh.policy.wrap_output(duplicate)
        new_installation, = fresh.policy.installations
        self.assertIs(duplicate._cudagraph_installation_owner, new_installation)
        self.assertIsNot(new_installation, installation)
        self.assertIsNone(new_installation.entry)


if __name__ == "__main__":
    run_tests()
