# Partial owner finalization

The preserved public attempt reports four `MixedInstallation.__del__` errors because `_status` is absent. Both public cases still fail at the separate TorchDispatch ambient-state gate; this lifecycle correction does not resolve that failure.

The selected source provides this copying path:

1. `torch._dynamo.utils.record_compilation_metrics` calls `_scrubbed_inductor_config_for_logging`.
2. That helper calls `config.get_config_copy()`. This uses `_get_dict()` without the exclusions used by `get_serializable_config_copy()`, so the active `cudagraph_policy` is deep-copied despite its serialization/hash exclusions.
3. The policy's `_installations` list precedes its lock in instance state. `copy._reconstruct` allocates an installation without calling `__init__`, then recursively copies its state before updating the new object's dictionary.
4. A noncopyable live dependency aborts the state copy. The abandoned object has no `_status`; the current finalizer reads that attribute outside its exception handler.

Root's preserved `diagnostic_attempt1.log` now confirms the caller in both destructor events. Both stacks start at `_scrubbed_inductor_config_for_logging` (`utils.py:1963`) and `record_compilation_metrics` (`utils.py:2052`). The first arrives through `MetricsContext.__exit__` at compile completion; the second arrives through runtime metrics `finish` from `CompiledFxGraph.__call__`. The passive observer records only filename/function/line tuples and runs before its artifact guard. The copy allocation/state ordering above is established by the selected stdlib source.

`lifecycle.diff` proposes two local changes: reject the standard copy/pickle protocol before reconstruction, and treat an absent `_status` as a never-initialized owner during finalization. Real initialized owners retain the existing cleanup and failed-owner retention path. Config logging remains unchanged and uses its existing typed serialization fallback. Copying the containing `CompiledFxGraph` for serialization remains allowed; that shallow artifact copy clears its owner reference through the existing lifecycle method.

The patch adds five CPU cases to the existing test class: shallow copy, deep copy, pickle, actual Inductor config logging with a live installation, and finalization of an allocated but never-initialized installation. The transfer/logging cases check unchanged borrows, artifact ownership, resource close counts, no unraisable errors or retained failed clones, and a usable subsequent miss. They reuse the existing explicitly documented CPU native stand-ins. The constructor control checks that no cleanup is attempted without resources.

Only proposal files were written. The frozen runtime, tests, source reviews and execution snapshots remain unchanged. No framework, GPU or build execution was performed.
