# Cold preparation under AOT's first-call mode

Source-only correction; the parent diagnostic identified the exact mode.
The preserved public failure is `public_attempt1.log`: both ordinary calls reach
CuTe tracing, then `python_entry_v2._ambient_state` rejects a nonempty dispatch
stack. `diagnostic_attempt1.log` records exactly one
`_AnalyzeCustomOpInputOutputMode`, zero pre-dispatch modes and no TracingContext.
The separate destructor correction is in `lifecycle.diff`.

Selected WARM `torch/_functorch/_aot_autograd/runtime_wrappers.py:515-541` installs
`_AnalyzeCustomOpInputOutputMode` through `_FirstInvocationContext` on the first
ordinary call. Its handler at 448-512 checks custom-op aliasing, skips HOP alias
checks, and declares `ignore_compile_internals() == True`. Selected
`torch/utils/_python_dispatch.py:238-264` defines that opt-out as excluding
compiler internals while retaining ordinary compiled execution semantics.
The generated `prepare_from_warmed` has no dispatch-stack isolation gate;
CuTe's `python_entry_v2.py:13-21` deliberately requires both mode stacks empty.

The draft accepts exactly this one AOT mode with no pre-dispatch mode, or an
empty stack. It temporarily pops that exact object during cold construction,
using the same pop/push primitives as `_pop_mode_temporarily`. Leave the original boxed call and
its result outside the context, so the first ordinary execution still sees the
alias checker. Preserve dtype, grad, inference and TorchFunction/default-device
state; do not clear tracing, fake, proxy, functionalization or arbitrary modes.
An unknown mode/stack combination should be a typed preparation decline after
ordinary execution. Unexpected source or stack mutation remains an error.

The context must encompass trace creation, signature/capsule joining, effects,
guard compilation, capture and final source checks: later `trace.check()` calls
also require the empty-stack ambient state. Keep it inside `_prepare_variant`'s
existing cleanup `try`. Restore the mode before clearing staged entry/owner
fields or returning the candidate. If context restoration fails, those fields
must still own the native entry and code owners for cleanup or retained retry.
Pop/push failures become RuntimeError with the original cause, including when
the primitive raises a typed eligibility exception. Existing staged cleanup runs
after restoration; its close/release methods do not call the trace ambient gate.
Do not change the strict standalone trace API or its stored ambient contract.

Twelve new CPU controls use the real AOT mode and actual preparation orchestration
with explicit ordinary/compiler/driver stand-ins: ordinary sees that exact mode; preparation sees no
dispatch modes; success, typed decline and unexpected error restore the same
mode object and leave the original result/box contract intact. Add unknown
user-mode and pre-dispatch negatives that preserve the stack and skip preparation,
plus staged-resource cleanup on a restoration failure. The real public GPU2
retry should retain its first-call alias checker and demonstrate the later miss
without that first-call mode. No test globally disables alias checking.

`mode.diff` changes one runtime helper and scopes the existing `_prepare_variant`
body; removing that context gives the exact previous AST. All 35 existing CPU
cases remain unchanged, giving 47 mode-draft cases before the separate five
lifecycle controls. AST, inventory and hash checks used only the Python standard
library; the author ran no framework, GPU or build commands.
