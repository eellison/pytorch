"""Methods to merge into TestAutomaticCuTeOwner; not a standalone test module."""

class LifecycleControls:
    @parametrize("operation", ("copy", "deepcopy", "pickle", "config_logging"))
    def test_live_installation_cannot_be_copied_by_logging_or_serialization(self, operation):
        from torch._dynamo.utils import _scrubbed_inductor_config_for_logging

        fixture = self.fixture()
        installation, = fixture.policy.installations
        candidate = self.prepare(installation, [])
        with mock.patch.object(installation, "_prepare_variant", return_value=candidate):
            fixture.artifact.current_callable(self.box(fixture))
        borrowed = set(fixture.compiler.owner._native_borrows)
        failures = tuple(mixed._FAILED_INSTALLATIONS)
        unraisable = []
        with mock.patch("sys.unraisablehook", side_effect=lambda error: unraisable.append(str(error.exc_value))):
            if operation == "config_logging":
                with config.patch(cudagraph_policy=fixture.policy):
                    self.assertEqual(_scrubbed_inductor_config_for_logging(), "Inductor Config cannot be pickled")
            else:
                transfer = pickle.dumps if operation == "pickle" else getattr(copy, operation)
                with self.assertRaisesRegex(TypeError, "cannot be copied or serialized"):
                    transfer(installation)
            gc.collect()
        self.assertEqual(unraisable, [])
        self.assertEqual(tuple(mixed._FAILED_INSTALLATIONS), failures)
        self.assertIs(fixture.artifact._cudagraph_installation_owner, installation)
        self.assertIs(fixture.artifact.current_callable, installation.entry)
        self.assertEqual(installation.status, "ready")
        self.assertEqual(fixture.compiler.owner._native_borrows, borrowed)
        self.assertEqual((candidate.entry.close_calls, candidate.owners[0].close_calls), (0, 0))
        with mock.patch.object(installation, "_prepare_variant", return_value=self.prepare(installation, [])):
            result = fixture.artifact.current_callable(self.box(fixture, 2))
        self.assertIs(result, fixture.namespace["outcomes"][-1])
        self.assertEqual(len(installation.cache.variants), 2)

    def test_never_initialized_installation_finalizer_is_inert(self):
        failures = tuple(mixed._FAILED_INSTALLATIONS)
        unraisable = []
        installation = object.__new__(mixed.MixedInstallation)
        reference = weakref.ref(installation)
        with mock.patch.object(mixed.MixedInstallation, "close") as close, mock.patch(
            "sys.unraisablehook", side_effect=lambda error: unraisable.append(str(error.exc_value))
        ):
            del installation
            gc.collect()
            close.assert_not_called()
        self.assertIsNone(reference())
        self.assertEqual(unraisable, [])
        self.assertEqual(tuple(mixed._FAILED_INSTALLATIONS), failures)

