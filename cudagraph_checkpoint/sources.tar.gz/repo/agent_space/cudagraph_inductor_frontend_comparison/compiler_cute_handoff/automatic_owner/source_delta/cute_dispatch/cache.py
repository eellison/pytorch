"""Cold preparation around the existing native callable; hits bypass this object."""

from dataclasses import dataclass
import weakref

import torch


@dataclass(frozen=True, eq=False)
class Authority:
    contract: object
    artifact: object
    generation: object


@dataclass
class PreparedVariant:
    authority: Authority
    entry: object
    registration: tuple
    owners: tuple = ()

    def close(self):
        self.entry.close()
        for owner in reversed(self.owners):
            owner.close()


class ColdCache:
    def __init__(self, authority, ordinary, prepare, declines=(), *, consume_box=False):
        if type(consume_box) is not bool or type(authority) is not Authority or type(declines) is not tuple or any(
            not isinstance(kind, type) or not issubclass(kind, Exception) for kind in declines
        ):
            raise TypeError("Expected an exact cold authority and typed preparation declines")
        self.authority = authority
        self.ordinary = ordinary
        self.prepare = prepare
        self.declines = declines
        self.consume_box = consume_box
        self.dispatcher = None
        self.variants = []
        self.pending = None
        self.busy = False
        self.invalidated = False
        self.failed = False
        self.closed = False
        reference = weakref.ref(self)

        def miss(box):
            cache = reference()
            if cache is None:
                raise RuntimeError("Cold cache owner is no longer alive")
            return cache._cold(box)

        self.miss = miss

    def bootstrap(self, box):
        if self.dispatcher is not None:
            raise RuntimeError("Call the published native dispatcher after bootstrap")
        return self._cold(box)

    def _fail(self, error):
        self.failed = True
        self.invalidated = True
        if self.dispatcher is not None and not self.dispatcher.closed:
            try:
                self.dispatcher.invalidate()
            except BaseException as invalidation_error:
                error.add_note(f"Native dispatcher invalidation also failed: {invalidation_error!r}")

    def _discard(self):
        try:
            self.pending.close()
        except BaseException as error:
            self._fail(error)
            raise
        self.pending = None

    def _cold(self, box):
        if self.busy:
            raise RuntimeError("Cold cache is busy")
        if self.closed or self.failed:
            raise RuntimeError("Cold cache is closed or failed")
        if type(box) is not list:
            raise TypeError("Expected an exact boxed list")
        self.busy = True
        try:
            snapshot = tuple(box)
            consumed = False

            def check_box():
                if self.consume_box and consumed:
                    if box:
                        raise RuntimeError("Ordinary compiler call did not consume its boxed inputs")
                    return
                if len(box) != len(snapshot) or any(current is not saved for current, saved in zip(box, snapshot)):
                    raise RuntimeError("Caller box changed during cold preparation")

            if self.consume_box:
                check_box()
                result = self.ordinary(box)
                consumed = True
            else:
                result = self.ordinary(list(snapshot))
            check_box()
            if self.invalidated or self.dispatcher is not None and self.dispatcher.invalidated:
                return result
            try:
                candidate = self.prepare(list(snapshot), result)
            except self.declines:
                if self.failed:
                    raise
                check_box()
                return result
            if type(candidate) is not PreparedVariant:
                raise TypeError("Preparation did not return an owned PreparedVariant")
            self.pending = candidate
            try:
                check_box()
                if candidate.authority is not self.authority:
                    raise RuntimeError("Candidate lost its original compiler authority")
                discard = self.invalidated or self.dispatcher is not None and self.dispatcher.invalidated
                if not discard:
                    self.variants.append(candidate)
                    try:
                        if self.dispatcher is None:
                            self.dispatcher = torch._C._cuda_make_boxed_dispatch(
                                ((candidate.entry, candidate.registration),), self.miss
                            )
                        else:
                            self.dispatcher.append(candidate.entry, candidate.registration)
                    except BaseException:
                        self.variants.pop()
                        raise
            except BaseException:
                if self.pending is not None:
                    self._discard()
                raise
            if discard:
                self._discard()
                check_box()
            else:
                self.pending = None
                try:
                    check_box()
                    if self.invalidated:
                        self.dispatcher.invalidate()
                except BaseException as error:
                    self._fail(error)
                    raise
            return result
        finally:
            self.busy = False

    def invalidate(self):
        if self.closed:
            raise RuntimeError("Cold cache is closed")
        self.invalidated = True
        if self.dispatcher is not None:
            self.dispatcher.invalidate()

    def close(self):
        if self.busy:
            raise RuntimeError("Cold cache is busy")
        if self.closed:
            return
        try:
            if self.dispatcher is not None:
                self.dispatcher.close()
            if self.pending is not None:
                self._discard()
            for variant in reversed(self.variants):
                variant.close()
        except BaseException as error:
            self._fail(error)
            raise
        self.variants.clear()
        self.closed = True
