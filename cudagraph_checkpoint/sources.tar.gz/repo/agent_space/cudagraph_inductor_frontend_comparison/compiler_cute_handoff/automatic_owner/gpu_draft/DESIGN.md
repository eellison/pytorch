# Public mixed CuTe policy controls

Two device-generic cases exercise normal and fast generated launchers through
`torch.compile` and `NativeCUDAGraphPolicy(cute=True)`. The model is the same
pointwise prefix and initialized cloned destination used by the separate
invocation-link controls. This test does not manually prepare or install any
native entry.

The first public call at M13 must execute the original generated function and
ordinary CuTe entry once, prepare one real variant and publish the native
dispatcher. Passive profiling checks the original code and globals, the actual
boxed list, and the exact original tuple returned by the cold cache.
The list at the first-call/native-miss cache boundary must be the same object
passed to the ordinary callback and original function, and empty at return.
Public outer tuple construction is checked separately by identity of its Tensor
elements. The actual preparation frame supplies its checked envelope, trace,
signature, ordinary compilation, correspondence, dispatch artifact, selected
CuTe owner and compiled guard for identity checks. No artifact is reconstructed
by the test, and the complete capture-byte oracle remains in invocation-link.

The policy config patch ends after this first call. The test drops its policy
and installation references and requires the policy weak reference to expire.
Its cleanup keeps only the actual compiled artifact, whose declared owner field
must retain the installation. A public M7 hit then runs without ordinary or
cold execution. A public M2 miss must execute ordinary once, return that exact
ordinary result, reuse the same compilation capsule, create a fresh signature,
and append the other compiled local guard to the same dispatcher. Public M3,
M35 and M36 calls must hit these variants. The original argument box and example
Tensor are not retained by observers beyond each call.

Public hit profiling filters the generated function and the cold owner, cache,
invocation, tracing, linking, guard export, provider and preparation paths, plus
the ordinary CuTe and generated autotuner entry methods. Cold calls calibrate
these observations; hot calls also trap ordinary execution and preparation.
Outer Dynamo/AOT Python frames are allowed. This is not the direct native
dispatcher's stronger zero-all-Python-frame assertion from invocation-link.

The test checks ordinary/registration close is blocked while borrowed, warm and
replay inputs expire, temporary source storage expires, and ordinary outputs
stay alive only while held. Explicit installation close restores the same
original generated function and clears its artifact owner; an M5 public call
then runs ordinary without rearming. Both ordinary and native outputs remain
correct after close and their storage expires after release, while closed
installation/dispatcher objects remain referenced.

The fixture deliberately uses one dynamic row extent, literal width 128,
float32 row-major buffers, no alias/reuse, and an initialized destination. No
persistent CuTe cache, static parameter, performance, or broader operator claim
is made. Failure and cleanup classification remain covered by the focused CPU
controls. The existing symbolic-program fixture dependencies and automatic-owner
canonical modules suffice; no new helper module is required. Only the parent
executes framework/GPU work under the reviewed controller.
