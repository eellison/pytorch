# Automatic mixed CuTe owner

`NativeCUDAGraphPolicy(cute=True)` opts into the existing checked mixed envelope:
generated calls followed by one terminal owned CuTe invocation, with the compiler's
actual output projection. The default is `False`. Mixed admission currently uses
`frontend="records"` and requires an empty compiler `static_input_idxs` list or tuple.
The generated records/FX/retained policy paths are otherwise unchanged.

`arm_mixed` binds the original function's envelope and actual `CompiledFxGraph`,
then acquires a native borrow from the exact registered ordinary CuTe owner.
`MixedInstallation` is the first callable. Its nonblocking lock covers source
validation, the original boxed call, preparation and publication. The real box is
consumed by that original call exactly once. The returned tuple is returned by
identity after preparation; capture output never replaces the ordinary result.

Cold preparation composes existing APIs: generated selections, two-operand CuTe
trace, the actual ordinary compilation capsule, signature/correspondence/layout
binding, selected CuTe pointer effects, `link_cute_invocation`, the compiled local
predicate and `prepare_variant(..., compiler_binding=...)`. Exactly one site must
match the actual boxed integers. No predicate is inferred from examples. Generated
selections are retained without closing their modules, since ordinary fallback
still needs those modules. Each prepared variant retains its exact trace/signature
as proof metadata until cleanup; real example inputs and ordinary results are released.

The existing native dispatcher is published directly as `current_callable`.
Its compiled guards select hits; a local miss invokes the same cold transaction
and appends a prepared variant. Existing native stream/context, boxed ABI and
output-arity requirements remain authoritative. There is no hot Python wrapper,
new native code, extra input/alias validation, or replacement of outer guards.

`ColdCache(consume_box=True)` supplies the real box to ordinary execution and
requires it to be empty afterward. Its default remains nonconsuming. A typed
preparation decline restores only the installation's own callable and returns the
already completed ordinary result. It invalidates an existing dispatcher but does
not close it inside an active miss. Unexpected errors, source/ownership changes,
and cleanup failures propagate. A failed cache cannot reinterpret a cleanup error
as an eligibility decline merely because its type appears in the decline tuple.

The artifact's declared `_cudagraph_installation_owner` field owns the installation
after the policy is dropped. The reverse artifact/function references and native
miss callback remain weak, avoiding a native dispatcher ownership cycle. Cache
serialization clears only the copied artifact's owner field; reload starts with
no installation. This does not enable caching for the noncacheable CuTe HOP.

Explicit close drains the dispatcher and native entries before CuTe code owners,
restores the original callable only while still owned, then releases the ordinary
entry borrow and artifact anchor. Direct ordinary-owner close and closing another
registration of the same owner are blocked while borrowed. Destructor cleanup
handles loss of both artifact and policy roots. Failed destructor cleanup retains
the installation in `_FAILED_INSTALLATIONS`; successful explicit retry removes
that reference. Native quarantine errors may remain unrecoverable. Cleanup never
implicitly retries a failed close in the same transaction. Held output tensors
retain their normal storage ownership after entry close.

## Files and controls

`overlays.json` lists the six canonical module replacements; `base_sources.json`
pins each copied source from the qualified symbolic-program manifest. The new
module is `compiler_cute_handoff.policy`. No package or loader layer is added.
The only CPU helper alias is `automatic_owner_envelope_fixture`, mapped to the
unchanged `mixed_envelope/test_envelope.py` pinned by `test_inventory.json`.
Execution also selects the existing invocation-link lowering/preparation overlays
and invocation-trace module through the parent's canonical manifest.

The 35 CPU controls use real compiler IR, emitted envelope attachments,
`CompiledFxGraph` lifecycle methods and an actual uncompiled ordinary owner.
The ordinary boxed function, native dispatcher, prepared entry and device-code
owners are explicitly CPU stand-ins. Controls cover actual-box/result identity,
legacy cache mode, typed and unexpected failures, reentrancy, publication conflicts,
source changes, close ordering/retry, native borrows, policy/artifact lifetimes,
and serialization-copy ownership. The reload control mocks module loading; it is
not a disk-cache round trip. These controls do not establish native ABI or GPU
correctness. Parent-run public GPU tests must exercise the actual linker and
native dispatcher, including local misses, hits and storage lifetimes.

This candidate does not add scalar CuTe host operands, static parameter authority,
mixed FX/retained projection, partitioning, allocator planning, TMA or generic
custom-op support. Existing typed envelope/trace/linker eligibility remains in force.
