import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


review = json.loads((ROOT / "execution_review.json").read_text())
expected = review["files"] | {str(ROOT / "execution_review.json"): digest(ROOT / "execution_review.json")}
for path, sha in expected.items():
    if digest(path) != sha:
        raise RuntimeError("Changed execution input: " + path)
prior_path = ROOT / "revision1_sources/execution_review.json"
prior = json.loads(prior_path.read_text())
prior_expected = prior["files"] | {str(ROOT / "execution_review.json"): digest(prior_path)}
if {path for path, sha in prior["files"].items() if digest(path) != sha} != {str(ROOT / "run_tests.py")}:
    raise RuntimeError("Unexpected runtime change between execution revisions")
manifest = json.loads((ROOT / "manifest.json").read_text())
files = {str(ROOT / name): digest(ROOT / name) for name in (
    "execution_review.json", "manifest.json", "root_source_review.json", "audit_results.py",
    "source_review.json", "independent_review.json", "controller_independent_review.json",
    "execution_independent_review.json", "public_root_review.json", "gpu_draft/independent_review.json",
    "revision1_sources/execution_review.json", "revision1_sources/run_tests.py",
)}
attempts = []
for suite, cases in review["cases"].items():
    current = suite in ("cpu", "public")
    number = 2 if suite == "cpu" else 1
    directory = ROOT / "attempts" / f"{suite}_attempt{number}"
    result = json.loads((directory / "result.json").read_text())
    saved = json.loads((directory / "sources.json").read_text())
    if saved != (expected if current else prior_expected):
        raise RuntimeError("Snapshot map mismatch: " + suite)
    for index, (path, sha) in enumerate(saved.items()):
        copy = directory / "sources" / f"{index:03d}_{Path(path).name}"
        if digest(copy) != sha:
            raise RuntimeError("Saved source mismatch: " + str(copy))
    gpu = suite in ("frontend", "pipeline", "public")
    if (result["accepted"] is not True or result["exit_code"] != 0
            or result["sources_unchanged"] is not True or result["identities_checked"] is not True
            or result["manifest_sha256"] != digest(ROOT / "manifest.json")
            or result["loaded_modules"] != {name: row["path"] for name, row in manifest["modules"].items()}
            or result["native_source"] != manifest["native"]["torch_python"]
            or result["native_extension"] != manifest["native"]["extension"]
            or result["cuda_initialized"] != gpu or result["initialization_checked"] != gpu
            or sorted(row["id"] for row in result["cases"]) != sorted(cases)
            or any(row["result"] != "ok" for row in result["cases"])):
        raise RuntimeError("Result mismatch: " + suite)
    for name in ("result.json", "sources.json", "output.log"):
        files[str(directory / name)] = digest(directory / name)
    if gpu:
        for name in ("gpu_before.json", "gpu_initialization.json"):
            guard = json.loads((directory / name).read_text())
            if (guard["physical_index"] != 1 or guard["uuid"] != "GPU-93d3590a-5f90-d77c-fe32-095983771555"
                    or guard["memory_mib"] > 128 or guard["utilization"] != 0 or guard["processes"]):
                raise RuntimeError("Idle guard mismatch: " + suite)
            files[str(directory / name)] = digest(directory / name)
        cpu = ROOT / ("attempts/cpu_attempt2/result.json" if current else "attempts/cpu_attempt1/result.json")
        if result["cpu_result"] != {"path": str(cpu), "sha256": digest(cpu)}:
            raise RuntimeError("CPU prerequisite mismatch: " + suite)
    attempts.append({"suite": suite, "path": str(directory), "cases": len(cases),
                     "accepted": True, "execution_revision": 2 if current else 1,
                     "saved_inputs_checked": len(saved)})

log = (ROOT / "attempts/public_attempt1/output.log").read_text()
markers = [json.loads(line.split("AUTOMATIC_CUTE_POLICY_RESULT=", 1)[1])
           for line in log.splitlines() if "AUTOMATIC_CUTE_POLICY_RESULT=" in line]
if len(markers) != 2 or sorted(row["fast"] for row in markers) != [False, True]:
    raise RuntimeError("Missing public CuTe GPU cases")
for marker in markers:
    if (marker["ordinary_batches"] != [13, 2, 5] or marker["native_hit_batches"] != [7, 3, 35, 36]
            or marker["ordinary_compilations"] != 1 or marker["public_hit_checked_frames"] != []
            or any(marker[key] is not True for key in (
                "single_original_artifact", "one_ordinary_call_per_miss", "exact_cold_return_tuple",
                "public_ordinary_output_tensor_identity", "same_dispatcher_after_miss",
                "same_compilation_fresh_signatures", "policy_expired_before_hit_and_local_miss",
                "artifact_retains_miss_owner", "ordinary_borrow_protected",
                "input_and_temporary_storage_expired", "held_outputs_after_close",
                "output_storage_expired_after_release", "close_restores_ordinary_call",
                "automatic_public_policy"))):
        raise RuntimeError("Public CuTe semantic marker mismatch")
    cold = marker["cold_preparations"]
    if (len(cold) != 2 or [row["batch"] for row in cold] != [13, 2]
            or [row["arm"] for row in cold] != [False, True]
            or any(row["outputs"] != 1 or row["generated_calls"] < 1 for row in cold)):
        raise RuntimeError("Public local variant mismatch")

directory = ROOT / "attempts/pipeline_attempt1"
for frontend, fast in (("fx", True), ("retained", False)):
    path = directory / f"pipeline_{frontend}_{fast}.json"
    result = json.loads(path.read_text())
    if (result["frontend"] != frontend or result["fast"] != fast
            or result["ordinary_cute_compilations"] != 1 or result["python_frames"] != []
            or len(result["variants"]) != 4 or len(result["native_hit_batches"]) != 10
            or any(result[key] is not True for key in (
                "same_capsule_across_misses", "original_embedded_binaries_verified",
                "cold_input_and_output_storage_released_before_hits",
                "native_output_storage_released_after_caller_drops_outputs",
                "held_outputs_correct_after_close", "captured_buffers_untouched",
                "generated_wrapper_usable_after_pipeline_close"))):
        raise RuntimeError("Existing pipeline regression mismatch")
    files[str(path)] = digest(path)

evidence = {
    "scope": "Automatic public compiler/CuTe installation and local-variant replay with affected regressions.",
    "reviewed_utc": datetime.now(timezone.utc).isoformat(), "accepted": True,
    "counts": {"cpu": 204, "gpu": 37, "total": 241}, "attempts": attempts,
    "current_execution_inputs_checked": len(expected),
    "saved_execution_inputs_checked": sum(row["saved_inputs_checked"] for row in attempts),
    "files": files, "native_changed": False, "automatic_public_native_cute": True,
    "regression_epochs": "Revision1 regressions and revision2 public tests use identical runtime modules, packages and native installation. Only GPU test/controller routes were added; CPU35 prerequisite repeated.",
    "limits": [
        "Opt-in records frontend, inference, generated prefix and one terminal CuTe call with two owned operands; no aliases, static inputs or buffer reuse.",
        "Public hit profiling checks the generated/CuTe/cold paths; outer Dynamo Python frames are not claimed absent.",
        "Both FX and retained IR pass the existing explicitly composed three-provider pipeline; automatic mixed CuTe uses compiler records.",
        "No new timing benchmark, native build, full CI or production-readiness claim.",
    ],
}
path = ROOT / "evidence_review.json"
if path.exists():
    raise RuntimeError("Evidence already exists")
path.write_text(json.dumps(evidence, indent=2) + "\n")
print(json.dumps({"audit": digest(path), "files": len(files), "cases": 241,
                  "saved_inputs": evidence["saved_execution_inputs_checked"]}))
