from contextlib import ExitStack
import gc
import json
import sys
import weakref
from unittest import mock

import cutlass.cute as cute
from compiler_cute_handoff import invocation as invocation_module
from compiler_cute_handoff import policy as mixed
from compiler_cute_handoff.invocation import invoke_cute, register_cute_entry
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from cute_bridge import guard_export, lowering, preparation, provider, tracing
from cute_dispatch import cache as cache_module
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import SignaturePolicy
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from selected_kernel import SelectedKernel
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._dynamo.utils import counters
from torch._inductor import config
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class RecordingPolicy(NativeCUDAGraphPolicy):
    def __init__(self, artifacts):
        super().__init__(cute=True)
        self.artifacts = artifacts

    def wrap_output(self, artifact):
        original = artifact.current_callable
        result = super().wrap_output(artifact)
        self.artifacts.append((artifact, original))
        return result


class TestAutomaticCuTePolicy(TestCase):
    @parametrize("fast", (False, True))
    def test_public_local_variants_and_policy_lifetime(self, device, fast):
        fixture = fixture_module.TestReductionGraphReplayCUDA(f"test_generated_reduction_replay_fast_{fast}_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        self.enterContext(config.patch(
            use_fast_triton_launcher=fast, fx_graph_cache=True,
            allow_buffer_reuse=False, inplace_buffers=False,
        ))
        python_entry, kernel, _ = make_fixture()
        layout = TensorPolicy((None, 128), (0, 1))
        ordinary = ObservedOrdinaryEntry(
            python_entry, kernel, policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout},
        )
        self.addCleanup(ordinary.close)
        registration = register_cute_entry(ordinary)
        self.addCleanup(registration.close)
        key = registration.key

        def model(value):
            source = value.sin()
            destination = source.clone()
            invoke_cute(key, source, destination)
            return (destination,)

        artifacts = []
        policy = RecordingPolicy(artifacts)

        def close_owned():
            for artifact, _ in artifacts:
                installation = artifact._cudagraph_installation_owner
                if installation is not None:
                    installation.close()

        # The cleanup owns artifacts, not the policy whose release is tested.
        self.addCleanup(close_owned)
        compiled = torch.compile(model, fullgraph=True, dynamic=True)
        compile_target, compilations = cute.compile, []

        def compile_once(target, *args, **kwargs):
            self.assertIs(target, python_entry.target)
            compilations.append(target)
            self.assertEqual(len(compilations), 1)
            return compile_target(target, *args, **kwargs)

        self.enterContext(mock.patch.object(cute, "compile", compile_once))
        previous_profile = sys.getprofile()
        self.assertIsNone(previous_profile)
        self.addCleanup(sys.setprofile, previous_profile)
        ordinary_code = OrdinaryEntry.run.__code__
        prepare_code = mixed.MixedInstallation._prepare_variant.__code__
        cache_code = mixed._MixedCache._cold.__code__
        callback_code = mixed.MixedInstallation.ordinary.__code__
        autotuner_code = CachingAutotuner.run.__code__
        forbidden_files = {
            module.__file__ for module in
            (mixed, invocation_module, cache_module, guard_export, lowering, preparation, provider, tracing)
        }
        active = None
        input_storages, source_storages, destination_storages, native_storages = [], [], [], []
        cold_records, ordinary_batches, native_batches = [], [], []
        capsule_ids, signature_ids = [], []

        def observe(frame, event, result):
            if active is None:
                return
            if event == "call" and frame.f_code is tracing.trace_cute_invocation.__code__:
                from torch.utils._python_dispatch import _get_current_dispatch_mode_stack
                from torch._ops import _len_torch_dispatch_stack_pre_dispatch
                modes = _get_current_dispatch_mode_stack()
                print("AMBIENT_MODE_DIAGNOSTIC=" + json.dumps({
                    "types": [type(mode).__module__ + "." + type(mode).__qualname__ for mode in modes],
                    "pre_dispatch": _len_torch_dispatch_stack_pre_dispatch(),
                    "tracing_context": torch._guards.TracingContext.try_get() is not None,
                }), flush=True)
            if event == "call" and frame.f_code is mixed.MixedInstallation.__del__.__code__:
                stack, cursor = [], frame.f_back
                while cursor is not None and len(stack) < 12:
                    stack.append((cursor.f_code.co_filename, cursor.f_code.co_name, cursor.f_lineno))
                    cursor = cursor.f_back
                print("INSTALLATION_DESTRUCTOR_DIAGNOSTIC=" + json.dumps(stack), flush=True)
            if event == "call" and (frame.f_code.co_filename in forbidden_files
                                     or frame.f_code in (ordinary_code, autotuner_code)):
                active["frames"].append((frame.f_code.co_filename, frame.f_code.co_name))
            if not artifacts:
                return
            artifact, original = artifacts[0]
            if event == "call" and frame.f_code is cache_code:
                active["cache_box"] = frame.f_locals["box"]
            if frame.f_code is original.__code__ and frame.f_globals is original.__globals__:
                if event == "call":
                    active["frames"].append((frame.f_code.co_filename, frame.f_code.co_name))
                    active["original_calls"] += 1
                    box = frame.f_locals[original.__code__.co_varnames[0]]
                    self.assertIs(type(box), list)
                    if active["mode"] == "cold":
                        self.assertIs(box, active["cold_box"])
                    active["original_box"] = box
                elif event == "return":
                    self.assertIs(type(result), tuple)
                    self.assertEqual(active["original_box"], [])
                    active["ordinary_result"] = result
            if event == "call" and frame.f_code is callback_code:
                self.assertIs(frame.f_locals["self"], artifact._cudagraph_installation_owner)
                active["cold_box"] = frame.f_locals["box"]
                self.assertIs(active["cold_box"], active["cache_box"])
            if event == "return" and frame.f_code is ordinary_code and frame.f_locals.get("self") is ordinary:
                if result is not None:
                    source, destination = frame.f_locals["inputs"]
                    call, = result.calls
                    self.assertIs(call.entry, python_entry)
                    self.assertIs(call.arguments[0], source)
                    self.assertIs(call.arguments[1], destination)
                    self.assertIs(frame.f_locals["host"], registration.provider.host)
                    active["ordinary_runs"] += 1
                    source_storages.append(StorageWeakRef(source.untyped_storage()))
                    destination_storages.append(StorageWeakRef(destination.untyped_storage()))
            if event == "return" and frame.f_code is prepare_code and result is not None:
                installation = frame.f_locals["self"]
                self.assertIs(type(result), cache_module.PreparedVariant)
                self.assertIs(installation, artifact._cudagraph_installation_owner)
                checked, trace = frame.f_locals["checked"], frame.f_locals["trace"]
                signature, bound = frame.f_locals["signature"], frame.f_locals["bound"]
                invocation, dispatch_artifact = frame.f_locals["invocation"], frame.f_locals["artifact"]
                linked, owner, guard = (frame.f_locals[name] for name in ("linked", "owner", "guard"))
                self.assertIs(checked, installation._binding)
                self.assertIs(checked.function(), original)
                self.assertIs(trace.binding, checked.binding)
                self.assertIs(trace.input_contract, checked.inputs)
                self.assertIs(signature.trace, trace)
                self.assertIs(invocation.bound, bound)
                self.assertIs(bound.compilation, ordinary._compilation)
                self.assertIs(dispatch_artifact.signature, signature)
                self.assertIs(linked.owner, owner)
                self.assertIs(linked.program.outputs, checked.records.outputs)
                self.assertEqual(result.owners, (owner,))
                self.assertEqual(result.registration, guard.registration)
                self.assertEqual(bool(owner.site.arm), active["batch"] < 4)
                indices = tuple(row.index for row in checked.inputs.integer_ranges)
                self.assertEqual(guard.boxed_integer_indices, indices)
                self.assertEqual(tuple(frame.f_locals["inputs"][index] for index in indices), (active["batch"],))
                capsule_ids.append(id(bound.compilation))
                signature_ids.append(id(signature))
                active["preparations"] += 1
                cold_records.append({
                    "batch": active["batch"], "arm": bool(owner.site.arm),
                    "site_id": owner.site.site_id, "boxed_indices": indices,
                    "guard_expressions": guard.expressions,
                    "generated_calls": len(checked.records.generated_calls),
                    "outputs": len(checked.records.outputs),
                })
            if event == "return" and frame.f_code is cache_code and result is not None:
                self.assertIs(result, active["ordinary_result"])
                self.assertEqual(active["cache_box"], [])
                active["cold_returns"] += 1

        def call(batch, mode):
            nonlocal active
            value = torch.randn((batch, 128), device=device)
            torch._dynamo.mark_static(value, 1)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            state = {"batch": batch, "mode": mode, "frames": [], "original_calls": 0,
                     "ordinary_runs": 0, "preparations": 0, "cold_returns": 0}
            active = state
            try:
                with ExitStack() as stack:
                    if mode == "hit":
                        error = AssertionError("A public native hit entered ordinary execution or preparation")
                        stack.enter_context(mock.patch.object(OrdinaryEntry, "run", side_effect=error))
                        stack.enter_context(mock.patch.object(CachingAutotuner, "run", side_effect=error))
                        stack.enter_context(mock.patch.object(mixed.MixedInstallation, "_prepare_variant", side_effect=error))
                    sys.setprofile(observe)
                    try:
                        result = compiled(value)
                    finally:
                        sys.setprofile(previous_profile)
            finally:
                active = None
            expected = (value.sin() * 2 + (64 if batch < 4 else 128),)
            self.assertEqual(result, expected)
            self.assertEqual((len(artifacts), len(compilations)), (1, 1))
            self.assertEqual(len(result), 1)
            self.assertEqual((tuple(result[0].shape), result[0].stride(), result[0].storage_offset()),
                             ((batch, 128), (128, 1), 0))
            self.assertIsNone(result[0]._base)
            if mode == "hit":
                self.assertEqual(state["frames"], [])
                self.assertEqual((state["original_calls"], state["ordinary_runs"],
                                  state["preparations"], state["cold_returns"]), (0, 0, 0, 0))
                native_batches.append(batch)
                native_storages.append(StorageWeakRef(result[0].untyped_storage()))
            else:
                self.assertEqual((state["original_calls"], state["ordinary_runs"]), (1, 1))
                self.assertTrue(state["frames"])
                self.assertIs(result[0], state["ordinary_result"][0])
                self.assertEqual((state["preparations"], state["cold_returns"]),
                                 (1, 1) if mode == "cold" else (0, 0))
                ordinary_batches.append(batch)
            return result, expected

        bypasses = counters["inductor"]["fxgraph_cache_bypass"]
        with config.patch(cudagraph_policy=policy):
            held = [call(13, "cold")]
        artifact, original = artifacts[0]
        installation, = policy.installations
        self.assertIs(artifact._cudagraph_installation_owner, installation)
        self.assertIs(artifact.current_callable, installation.entry)
        self.assertIs(type(installation.entry), torch._C._CUDAGraphBoxedDispatch)
        self.assertEqual((installation.status, len(installation.cache.variants)), ("ready", 1))
        dispatcher = installation.entry
        installation_ref, policy_ref = weakref.ref(installation), weakref.ref(policy)
        selected = ordinary.selected
        selections = {}
        for generated in installation._generated:
            selection = generated.selection
            selections[id(selection.identity[0])] = selection
            fixture.modules[id(selection.identity[3])] = selection.identity[3]
        del generated, selection, installation, policy
        gc.collect()
        self.assertIsNone(policy_ref())
        self.assertIsNotNone(installation_ref())
        self.assertIs(artifact._cudagraph_installation_owner, installation_ref())
        held.append(call(7, "hit"))
        self.assertEqual(len(installation_ref().cache.variants), 1)
        held.append(call(2, "cold"))
        self.assertIs(artifact.current_callable, dispatcher)
        self.assertEqual((installation_ref().status, len(installation_ref().cache.variants)), ("ready", 2))
        self.assertEqual(ordinary_batches, [13, 2])
        self.assertEqual(len(set(capsule_ids)), 1)
        self.assertEqual(len(set(signature_ids)), 2)
        self.assertEqual({row["arm"] for row in cold_records}, {False, True})
        for close in (registration.close, ordinary.close):
            with self.assertRaisesRegex(RuntimeError, "borrowed"):
                close()
        for batch in (3, 35, 36):
            held.append(call(batch, "hit"))
        self.assertEqual(native_batches, [7, 3, 35, 36])
        self.assertEqual(len(installation_ref().cache.variants), 2)
        self.assertIs(ordinary.selected, selected)
        for selection in selections.values():
            current = SelectedKernel.from_warmed(selection.identity[0])
            self.assertTrue(all(left is right for left, right in zip(current.identity, selection.identity)))
        self.assertEqual(len(compilations), 1)
        self.assertGreater(counters["inductor"]["fxgraph_cache_bypass"], bypasses)
        self.assertFalse(invoke_cute.cacheable())
        self.assertIsNone(ordinary._calls)
        self.assertEqual((ordinary._capture.arguments, ordinary._capture.keywords), ((), {}))
        self.assertIsNone(installation_ref()._ordinary_result)
        self.assertIsNone(installation_ref()._active)
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        self.assertEqual(len(source_storages), 2)
        self.assertTrue(all(storage.expired() for storage in source_storages))
        self.assertTrue(all(not storage.expired() for storage in destination_storages))
        installation = installation_ref()
        installation.close()
        self.assertTrue(dispatcher.closed)
        self.assertIs(artifact.current_callable, original)
        self.assertIsNone(artifact._cudagraph_installation_owner)
        self.assertEqual(ordinary._native_borrows, set())
        self.assertFalse(registration.closed)
        held.append(call(5, "ordinary"))
        self.assertEqual(ordinary_batches, [13, 2, 5])
        self.assertEqual(len(cold_records), 2)
        registration.close()
        for result, expected in held:
            self.assertEqual(result, expected)
        self.assertEqual(len({result[0].data_ptr() for result, _ in held}), len(held))
        del result, expected
        held.clear()
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertEqual((len(source_storages), len(destination_storages), len(native_storages)), (3, 3, 4))
        self.assertTrue(all(storage.expired() for storage in
                            (*input_storages, *source_storages, *destination_storages, *native_storages)))
        print("AUTOMATIC_CUTE_POLICY_RESULT=" + json.dumps({
            "fast": fast, "ordinary_batches": ordinary_batches, "native_hit_batches": native_batches,
            "ordinary_compilations": len(compilations), "cold_preparations": cold_records,
            "single_original_artifact": len(artifacts) == 1, "one_ordinary_call_per_miss": True,
            "exact_cold_return_tuple": True, "public_ordinary_output_tensor_identity": True,
            "same_dispatcher_after_miss": True, "same_compilation_fresh_signatures": True,
            "policy_expired_before_hit_and_local_miss": True, "artifact_retains_miss_owner": True,
            "public_hit_checked_frames": [], "ordinary_borrow_protected": True,
            "input_and_temporary_storage_expired": True, "held_outputs_after_close": True,
            "output_storage_expired_after_release": True, "close_restores_ordinary_call": True,
            "automatic_public_policy": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestAutomaticCuTePolicy, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
