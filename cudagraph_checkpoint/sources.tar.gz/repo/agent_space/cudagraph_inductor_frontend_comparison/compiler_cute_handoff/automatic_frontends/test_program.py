from dataclasses import replace
import gc
import pickle
from unittest import mock
import weakref

from automatic_frontends_envelope_fixture import CompilerFixture
from compiler_cute_handoff import program as program_module
from compiler_cute_handoff.descriptor import CuTeCall
from compiler_cute_handoff.envelope import bind_envelope, GeneratedCall, Release
from compiler_cute_handoff.program import bind_mixed_program, MixedHostProgram, ProgramDeclined
import torch
from torch._inductor import config
from torch._inductor.codegen.wrapper import FreeLine
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, ExpressionSource, InputSource, IntExpr,
    KernelCallRecord, OwnedBuffer, pointwise_product,
)
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def reader_program(checked):
    """Synthetic reader output for binder tests; no FX or retained extraction."""
    records = checked.records
    renamed = {row.source: BufferSource(f"reader_{index}") for index, row in enumerate(records.allocations)}

    def source(value):
        return renamed[value] if type(value) is BufferSource else value

    events = []
    for event in records.events:
        if type(event) is OwnedBuffer:
            events.append(replace(event, source=source(event.source)))
        elif type(event) is GeneratedCall:
            events.append(replace(event.record, arguments=tuple(replace(arg, source=source(arg.source))
                for arg in event.record.arguments)))
        elif type(event) is CuTeCall:
            events.append(replace(event, operands=tuple(replace(row, source=source(row.source)) for row in event.operands)))
        elif type(event) is not Release:
            events.append(event)
    outputs = tuple(replace(row, source=source(row.source)) for row in records.outputs)
    returned = {row.source for row in outputs}
    sources = [InputSource(row.index) for row in records.inputs.tensor_inputs] + list(renamed.values())
    events.extend(Release(value) for value in sources if value not in returned)
    return MixedHostProgram(1, records.inputs, tuple(events), outputs)


@instantiate_parametrized_tests
class TestMixedFrontendProgram(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, **kwargs):
        compiler = CompilerFixture(self, **kwargs)
        function, _ = compiler.emit()
        checked = bind_envelope(function)
        return compiler, function, checked, reader_program(checked)

    @parametrize("dynamic", (False, True))
    def test_complete_reader_events_outputs_and_compiler_effects(self, dynamic):
        compiler, function, checked, program = self.fixture(dynamic=dynamic, return_prefix=True)
        bound = bind_mixed_program(checked, program)
        self.assertIs(bound.binding, checked)
        self.assertIs(bound.binding.function(), function)
        self.assertIs(bound.program, program)
        self.assertIs(bound.inputs, checked.inputs)
        self.assertIs(bound.records.inputs, program.inputs)
        self.assertIs(bound.records.outputs, program.outputs)
        self.assertIsNot(bound.records, checked.records)
        self.assertEqual(tuple(row.source for row in program.outputs), (BufferSource("reader_1"), BufferSource("reader_0")))
        self.assertEqual(bound.buffer_sources, ((BufferSource("prefix"), BufferSource("reader_0")),
                                               (BufferSource("destination"), BufferSource("reader_1"))))
        supplied = tuple(row for row in program.events if type(row) is KernelCallRecord)
        projected = tuple(row for row in bound.records.events if type(row) is GeneratedCall)
        self.assertEqual((len(projected), len(supplied)), (2, 2))
        self.assertTrue(all(row.record is actual for row, actual in zip(projected, supplied)))
        self.assertEqual(projected[0].reads, (InputSource(compiler.source_index),))
        self.assertEqual(projected[0].writes, projected[1].reads)
        self.assertEqual(projected[0].operations, ("prefix",))
        self.assertEqual(projected[1].operations, ("destination",))
        self.assertIsNone(compiler.owner.selected)
        bound.check()

    def test_original_early_release_may_move_to_end_of_program(self):
        compiler = CompilerFixture(self)
        release = next(line for line in compiler.wrapper.lines if type(line) is FreeLine and line.node is compiler.source)
        compiler.wrapper.lines.remove(release)
        compiler.wrapper.lines.insert(compiler.wrapper.lines.index(compiler.prefix_call) + 1, release)
        function, _ = compiler.emit()
        checked = bind_envelope(function)
        program = reader_program(checked)
        original_release = next(index for index, event in enumerate(checked.records.events)
                                if type(event) is Release and event.source == InputSource(compiler.source_index))
        reader_release = next(index for index, event in enumerate(program.events)
                              if type(event) is Release and event.source == InputSource(compiler.source_index))
        self.assertLess(original_release, reader_release)
        bound = bind_mixed_program(checked, program)
        self.assertIs(bound.records.outputs, program.outputs)
        self.assertIs(bound.binding.function(), function)

    def test_data_only_round_trip_and_live_binding_are_distinct(self):
        _, function, checked, program = self.fixture()
        restored = pickle.loads(pickle.dumps(program))
        self.assertEqual(restored, program)
        self.assertIsNot(restored.inputs, checked.inputs)
        bound = bind_mixed_program(checked, restored)
        self.assertIs(bound.program, restored)
        self.assertIs(bound.inputs, checked.inputs)
        self.assertIs(bound.binding.function(), function)
        with self.assertRaisesRegex(TypeError, "not cache transport"):
            pickle.dumps(bound)

    @parametrize("version", (None, True, 2))
    def test_unknown_or_inexact_schema_declines(self, version):
        _, function, checked, program = self.fixture()
        with self.assertRaisesRegex(ProgramDeclined, "schema"):
            bind_mixed_program(checked, replace(program, version=version))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("contract_index", "allocation_source", "call_source", "cute_source",
                          "copy_index", "release_source", "output_source", "events"))
    def test_unhashable_reader_fields_decline_before_source_sets(self, fault):
        _, function, checked, program = self.fixture()
        events = list(program.events)
        if fault == "contract_index":
            inputs = replace(program.inputs, tensor_inputs=(replace(program.inputs.tensor_inputs[0], index=[]),))
            program = replace(program, inputs=inputs)
        elif fault == "output_source":
            program = replace(program, outputs=(replace(program.outputs[0], source=BufferSource([])),))
        elif fault == "events":
            program = replace(program, events=events)
        else:
            kinds = {"allocation_source": OwnedBuffer, "call_source": KernelCallRecord, "cute_source": CuTeCall,
                     "copy_index": AlignmentCopy, "release_source": Release}
            index = next(index for index, event in enumerate(events) if type(event) is kinds[fault])
            event = events[index]
            if fault == "allocation_source":
                event = replace(event, source=BufferSource([]))
            elif fault == "call_source":
                event = replace(event, arguments=(replace(event.arguments[0], source=InputSource([])), *event.arguments[1:]))
            elif fault == "cute_source":
                event = replace(event, operands=(replace(event.operands[0], source=BufferSource([])), event.operands[1]))
            elif fault == "copy_index":
                event = replace(event, input_index=[])
            else:
                event = Release(InputSource([]))
            events[index] = event
            program = replace(program, events=tuple(events))
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, program)
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("source", "boxed", "width", "boolean_index", "grid", "compiler_effect_row"))
    def test_generated_formals_and_original_sources_remain_exact(self, fault):
        _, function, checked, program = self.fixture(extra_integer=True)
        events = list(program.events)
        index = next(index for index, event in enumerate(events) if type(event) is KernelCallRecord)
        call = events[index]
        arguments = list(call.arguments)
        if fault == "source":
            arguments[0] = replace(arguments[0], source=BufferSource("reader_0"))
        elif fault == "boxed":
            arguments[-1] = replace(arguments[-1], source=ExpressionSource(pointwise_product((IntExpr("boxed", 0), 128))))
        elif fault == "width":
            arguments[-1] = replace(arguments[-1], triton_type="i64")
        elif fault == "boolean_index":
            arguments[0] = replace(arguments[0], source_arg_index=False)
        if fault == "compiler_effect_row":
            events[index] = next(event for event in checked.records.events if type(event) is GeneratedCall)
        else:
            events[index] = replace(call, arguments=tuple(arguments), grid_type="Grid2D" if fault == "grid" else call.grid_type)
        with self.assertRaisesRegex(ProgramDeclined, "generated call"):
            bind_mixed_program(checked, replace(program, events=tuple(events)))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("missing_call", "missing_allocation", "missing_copy", "late_copy"))
    def test_complete_event_order_is_required(self, fault):
        _, function, checked, program = self.fixture()
        events = list(program.events)
        kind = KernelCallRecord if fault == "missing_call" else OwnedBuffer if fault == "missing_allocation" else AlignmentCopy
        index = next(index for index, event in enumerate(events) if type(event) is kind)
        event = events.pop(index)
        if fault == "late_copy":
            events.insert(next(index for index, item in enumerate(events) if type(item) is KernelCallRecord) + 1, event)
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, replace(program, events=tuple(events)))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("paired_layout_output", "missing_output", "reordered_outputs", "collapsed_buffers"))
    def test_allocations_and_complete_outputs_are_independent_obligations(self, fault):
        _, function, checked, program = self.fixture(return_prefix=True)
        events, outputs = list(program.events), program.outputs
        allocations = [index for index, event in enumerate(events) if type(event) is OwnedBuffer]
        if fault == "paired_layout_output":
            output = replace(outputs[0], size=(1, 128))
            events[allocations[1]], outputs = output, (output, outputs[1])
        elif fault == "missing_output":
            outputs = outputs[:1]
        elif fault == "reordered_outputs":
            outputs = tuple(reversed(outputs))
        else:
            events[allocations[1]] = replace(events[allocations[1]], source=events[allocations[0]].source)
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, replace(program, events=tuple(events), outputs=outputs))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("paired_flow", "entry", "boxed_operand"))
    def test_terminal_invocation_cannot_change_prior_dataflow(self, fault):
        compiler, function, checked, program = self.fixture()
        events = list(program.events)
        index = next(index for index, event in enumerate(events) if type(event) is CuTeCall)
        call = events[index]
        if fault == "paired_flow":
            generated_index = max(index for index, event in enumerate(events) if type(event) is KernelCallRecord)
            generated = events[generated_index]
            events[generated_index] = replace(generated, arguments=(
                replace(generated.arguments[0], source=call.operands[1].source), *generated.arguments[1:]))
            call = replace(call, operands=(call.operands[1], call.operands[1]))
        elif fault == "entry":
            call = replace(call, entry_key="unregistered")
        else:
            call = replace(call, operands=(replace(call.operands[0], source=InputSource(compiler.source_index)), call.operands[1]))
        events[index] = call
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, replace(program, events=tuple(events)))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("early", "duplicate", "missing", "output"))
    def test_release_policy_is_explicit(self, fault):
        _, function, checked, program = self.fixture()
        events = list(program.events)
        index = next(index for index, event in enumerate(events) if type(event) is Release)
        if fault == "early":
            events.insert(0, events.pop(index))
        elif fault == "duplicate":
            events.append(events[index])
        elif fault == "missing":
            events.pop(index)
        else:
            events.append(Release(program.outputs[0].source))
        with self.assertRaisesRegex(ProgramDeclined, "release"):
            bind_mixed_program(checked, replace(program, events=tuple(events)))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("code", "kernel", "closed_entry"))
    def test_original_authority_is_checked_again(self, fault):
        compiler, function, checked, program = self.fixture()
        bound = bind_mixed_program(checked, program)
        if fault == "code":
            function.__code__ = (lambda box: None).__code__
        elif fault == "kernel":
            function.__globals__[checked.records.generated_calls[0].kernel_global] = object()
        else:
            compiler.entry.close()
        with self.assertRaisesRegex(ProgramDeclined, "authority"):
            bound.check()

    @parametrize("fault", ("program", "effects", "coherent_rename"))
    def test_bound_program_content_cannot_change(self, fault):
        _, function, checked, program = self.fixture()
        bound = bind_mixed_program(checked, program)
        if fault == "program":
            bound.program = replace(program)
        elif fault == "effects":
            call = next(event for event in bound.records.events if type(event) is GeneratedCall)
            object.__setattr__(call, "reads", ())
        else:
            source = next(event.source for event in program.events if type(event) is OwnedBuffer)
            object.__setattr__(source, "name", "consistent_but_changed")
        with self.assertRaises(ProgramDeclined):
            bound.check()
        self.assertIs(checked.function(), function)

    def test_late_failure_publishes_no_partial_source_map(self):
        _, function, checked, program = self.fixture(return_prefix=True)
        bound = bind_mixed_program(checked, program)
        original_map = bound.buffer_sources
        with mock.patch.object(program_module, "BoundMixedProgram") as constructor, self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, replace(program, outputs=tuple(reversed(program.outputs))))
        constructor.assert_not_called()
        self.assertIs(bound.buffer_sources, original_map)
        bound.check()
        self.assertIs(checked.function(), function)

    def test_program_mutation_during_final_origin_validation_declines(self):
        _, function, checked, program = self.fixture()
        bound = bind_mixed_program(checked, program)
        original_check = checked.check
        calls = 0

        def check():
            nonlocal calls
            original_check()
            calls += 1
            if calls == 3:
                source = next(event.source for event in program.events if type(event) is OwnedBuffer)
                object.__setattr__(source, "name", "changed_during_validation")

        with mock.patch.object(checked, "check", side_effect=check), self.assertRaisesRegex(ProgramDeclined, "during source"):
            bound.check()
        self.assertEqual(calls, 3)
        self.assertIs(checked.function(), function)

    @parametrize("boundary", ("origin", "projection"))
    def test_unexpected_validation_errors_propagate(self, boundary):
        _, function, checked, program = self.fixture()
        error = ValueError("unexpected validator failure")
        target, name = (checked, "check") if boundary == "origin" else (program_module, "_check_envelope")
        with mock.patch.object(target, name, side_effect=error), self.assertRaises(ValueError) as caught:
            bind_mixed_program(checked, program)
        self.assertIs(caught.exception, error)
        self.assertIs(checked.function(), function)

    def test_binding_does_not_keep_original_function_alive(self):
        _, function, checked, program = self.fixture()
        bound = bind_mixed_program(checked, program)
        reference = weakref.ref(function)
        del function
        gc.collect()
        self.assertIsNone(reference())
        with self.assertRaisesRegex(ProgramDeclined, "authority"):
            bound.check()

    def test_program_is_not_a_compiler_authority(self):
        _, function, checked, program = self.fixture()
        with self.assertRaisesRegex(ProgramDeclined, "original bound"):
            bind_mixed_program(program, program)
        self.assertIs(checked.function(), function)


if __name__ == "__main__":
    run_tests()
