The wrapper overlay emits `call._cudagraph_mixed_ir` for a final wrapper containing
an actual `CuTeCallLine`. After the existing final wrapper IR passes,
`retain_mixed_wrapper(self)` reads the live typed IR and `export_mixed_ir` produces
a data-only string. A typed `RetentionDeclined` leaves an explicit `None`;
unexpected exceptions propagate. The existing descriptor, envelope and generated
record emission remain unchanged. Wrappers without CuTe do not consult the new
reader or receive the attribute.

Collection is independent of the frontend policy and does not consume the
emitted mixed envelope. A separate envelope decline can coexist with a retained
payload; that data alone does not authorize replay. Original compiler binding,
complete reader correspondence and selected ABI proof remain required by the
later policy/preparation integration. No live IR, owner or examples enter the
payload, and this change adds no cache or native behavior.

The focused CPU tests call the actual `_generate` method with the qualified
typed compiler fixture. The final-pass hook and unrelated ordinary-body formatting
are stand-ins; the collectors, serializers and attachment emission are real.
Tests cover literal/symbolic data, separate envelope decline, typed retention and
export declines, unexpected failures, post-pass output order and the non-CuTe
branch. The generated stand-in body is compiled to inspect attachments but is
not executed. These controls do not qualify an ordinary generated kernel or GPU
replay. The author ran only standard-library AST/hash checks.
