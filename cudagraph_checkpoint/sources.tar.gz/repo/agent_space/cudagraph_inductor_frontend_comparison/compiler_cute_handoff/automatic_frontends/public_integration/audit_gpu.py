import hashlib
import json
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    execution = ROOT / "execution_review.json"
    review = json.loads(execution.read_text())
    manifest = json.loads((ROOT / "manifest.json").read_text())
    directory = ROOT / "attempts/public_attempt1"
    result_path = directory / "result.json"
    result = json.loads(result_path.read_text())
    expected = review["files"] | {str(execution): digest(execution)}
    require(result["accepted"] and result["exit_code"] == 0, "Public GPU process did not pass")
    require(result["sources_unchanged"] and result["identities_checked"], "Source or module checks failed")
    require(result["cuda_initialized"] and result["initialization_checked"], "Missing guarded CUDA initialization")
    require(sorted(row["id"] for row in result["cases"]) == sorted(review["cases"]["public"])
            and all(row["result"] == "ok" for row in result["cases"]), "Incomplete public case inventory")
    require(result["loaded_modules"] == {name: row["path"] for name, row in manifest["modules"].items()},
            "Unexpected canonical modules")
    require(result["manifest_sha256"] == digest(ROOT / "manifest.json"), "Unexpected manifest")
    require(result["native_source"] == manifest["native"]["torch_python"]
            and result["native_extension"] == manifest["native"]["extension"], "Unexpected native build")
    require(result["loaded_test_helpers"] == {}, "Unexpected public helper injection")
    dependencies = json.loads((ROOT / "gpu_dependencies.json").read_text())
    modules = {}
    for key in ("frontend_modules", "fixture_modules", "fixture_support_modules"):
        modules.update({name: row["path"] for name, row in dependencies[key].items()})
    require(result["loaded_dependencies"] == modules, "Unexpected dependency modules")
    require(result["final_sys_path"] == result["expected_sys_path"], "Import path changed")
    source_path = directory / "sources.json"
    sources = json.loads(source_path.read_text())
    require(sources == expected, "Unexpected source snapshot map")
    for index, (path, sha) in enumerate(sources.items()):
        saved = directory / "sources" / f"{index:03d}_{Path(path).name}"
        require(digest(Path(path)) == sha and digest(saved) == sha, "Source changed: " + path)
    for name in ("gpu_before.json", "gpu_initialization.json"):
        state = json.loads((directory / name).read_text())
        require(state["physical_index"] == 1 and state["uuid"] == dependencies["gpu"]["uuid"],
                "Unexpected physical GPU")
        require(state["memory_mib"] <= 128 and state["utilization"] == 0 and state["processes"] == [],
                "GPU was not idle before initialization")
    cpu_path = ROOT / "attempts/cpu_attempt1/result.json"
    require(result["cpu_result"] == {"path": str(cpu_path), "sha256": digest(cpu_path)},
            "Public run did not use its reviewed CPU prerequisite")
    log_path = ROOT / "public_attempt1.log"
    reports = []
    for line in log_path.read_text().splitlines():
        if "MIXED_FRONTEND_POLICY_RESULT=" in line:
            reports.append(json.loads(line.split("MIXED_FRONTEND_POLICY_RESULT=", 1)[1]))
    require(len(reports) == 4 and {(row["frontend"], row["fast"]) for row in reports}
            == {(frontend, fast) for frontend in ("fx", "retained") for fast in (False, True)},
            "Missing public frontend/launcher condition")
    required = (
        "reader_outputs_reach_native_preparation", "same_projection_across_local_misses",
        "compiler_recorded_parameter_normalization", "single_original_artifact", "one_ordinary_call_per_miss",
        "exact_cold_return_tuple", "public_ordinary_output_tensor_identity", "same_dispatcher_after_miss",
        "same_compilation_fresh_signatures", "policy_expired_before_hit_and_local_miss",
        "artifact_retains_miss_owner", "ordinary_borrow_protected", "input_and_temporary_storage_expired",
        "held_outputs_after_close", "output_storage_expired_after_release", "close_restores_ordinary_call",
        "owned_executor_reused_across_local_miss", "first_audited_launch_once", "executor_released_after_close",
        "replaced_and_final_parameter_storage_expired", "automatic_public_policy",
    )
    for row in reports:
        require(all(row[name] is True for name in required), "Public invariant not established")
        readers = ({"fx_trace": 1, "fx_lower": 1, "retained_decode": 0} if row["frontend"] == "fx"
                   else {"fx_trace": 0, "fx_lower": 0, "retained_decode": 1})
        require(row["reader_calls"] == readers, "Reader was substituted or repeated")
        require(row["ordinary_batches"] == [13, 2, 5] and row["native_hit_batches"] == [7, 35, 3, 36],
                "Unexpected cold/hit/ordinary schedule")
        require(row["ordinary_compilations"] == 1 and row["public_hit_checked_frames"] == [],
                "Repeated compilation or Python work on native hits")
        require([(item["batch"], item["arm"]) for item in row["cold_preparations"]] == [(13, False), (2, True)],
                "Both local CuTe branches were not exercised")
        require([item["parameter_copied"] for item in row["native_copies"]] == [False, True],
                "Parameter normalization conditions were not exercised")
        require(row["warm_owned_state_and_dependency_checks"] == 0, "Owned executor repeated cold auditing")
    saved_log = directory / "output.log"
    shutil.copy2(log_path, saved_log)
    paths = [Path(__file__).resolve(), execution, result_path, source_path, saved_log,
             directory / "gpu_before.json", directory / "gpu_initialization.json",
             ROOT / "cpu_evidence_review.json", ROOT / "cpu_evidence_independent_review.json",
             ROOT / "controller_independent_review.json", ROOT / "gpu_independent_review.json",
             ROOT / "composed_adversarial_review.json"]
    cpu = json.loads((ROOT / "cpu_evidence_review.json").read_text())
    require(cpu["accepted"] and cpu["cases"] == 112, "Missing complete CPU112 evidence")
    report = {
        "scope": "Public mixed frontend composition: CPU112 plus GPU4, root evidence audit.",
        "accepted": True,
        "cases": 116,
        "gpu_cases": 4,
        "gpu_saved_sources_checked": len(sources),
        "cpu_evidence": "Previously root/independently audited CPU112; unchanged execution map.",
        "files": {str(path): digest(path) for path in paths},
        "reports": reports,
        "limitations": ["Supported generated prefix plus terminal owned CuTe invocation on the current GPU/build.",
                        "Functional composition proof; no new performance measurement or arbitrary-op coverage."],
    }
    output = ROOT / "evidence_review.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"accepted": True, "cases": 116, "saved_gpu_sources": len(sources),
                      "evidence_sha256": digest(output)}))


if __name__ == "__main__":
    main()
