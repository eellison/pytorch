from contextlib import ExitStack
from types import SimpleNamespace
from unittest import mock

import public_owner_fixture as owner_fixture
from public_program_fixture import reader_program
from compiler_cute_handoff import policy as mixed
from compiler_cute_handoff.program import bind_mixed_program, ProgramDeclined
from compiler_cute_handoff.retained import export_mixed_ir, retain_mixed_wrapper, RetentionDeclined
from compiler_policy_handoff.policy import HandoffInvalidated
from fx_adapter import extraction, lowering
from fx_adapter.contract import FXTraceDeclined
import torch
from torch._inductor import config
from torch._inductor.virtualized import V
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


@instantiate_parametrized_tests
class TestMixedFrontendPolicy(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.enterContext(torch.no_grad())
        self.enterContext(mock.patch.object(torch._C, "_cuda_make_boxed_dispatch", side_effect=owner_fixture.Dispatcher))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, frontend, *, payload=True):
        fixture = owner_fixture.TestAutomaticCuTeOwner.fixture(self, frontend=frontend, arm=False)
        if frontend == "retained" and payload:
            with V.set_graph_handler(fixture.compiler.graph):
                program = retain_mixed_wrapper(fixture.compiler.wrapper)
            fixture.original._cudagraph_mixed_ir = export_mixed_ir(program)
        fixture.policy.wrap_output(fixture.artifact)
        return fixture

    def box(self, fixture, rows=13):
        return owner_fixture.TestAutomaticCuTeOwner.box(self, fixture, rows)

    @parametrize("frontend", ("fx", "retained"))
    def test_chosen_reader_reaches_link_and_preparation_once(self, frontend):
        fixture = self.fixture(frontend)
        installation, = fixture.policy.installations
        projection = bind_mixed_program(installation._binding, reader_program(installation._binding))
        outer = object()
        decode = mixed.reconstruct_mixed_ir
        with owner_fixture.TestAutomaticCuTeOwner.cold_build(self, fixture, installation), ExitStack() as stack:
            installation._generated = tuple(SimpleNamespace(check=lambda: None, selection=object())
                                            for _ in installation._binding.records.generated_calls)
            trace = stack.enter_context(mock.patch.object(extraction, "trace_mixed_fx", return_value=outer))
            lower = stack.enter_context(mock.patch.object(lowering, "lower_mixed_fx", return_value=projection))
            retained = stack.enter_context(mock.patch.object(mixed, "reconstruct_mixed_ir", wraps=decode))
            for rows in (13, 2):
                result = fixture.artifact.current_callable(self.box(fixture, rows))
                self.assertIs(result, fixture.namespace["outcomes"][-1])
                self.assertEqual(installation.status, "ready")
                self.assertIs(mixed.link_cute_invocation.call_args.kwargs["compiler_program"], installation._projection)
                self.assertIs(mixed.preparation.prepare_variant.call_args.kwargs["compiler_program"], installation._projection)
                self.assertIs(mixed.preparation.prepare_variant.call_args.kwargs["compiler_binding"], installation._binding)
            if frontend == "fx":
                trace.assert_called_once()
                lower.assert_called_once_with(installation._binding, outer)
                retained.assert_not_called()
                self.assertIs(installation._projection, projection)
            else:
                trace.assert_not_called()
                lower.assert_not_called()
                retained.assert_called_once_with(fixture.original._cudagraph_mixed_ir)
                self.assertIs(installation._projection.binding, installation._binding)
        self.assertEqual(len(fixture.namespace["calls"]), 2)

    @parametrize("frontend", ("fx", "retained"))
    @parametrize("unexpected", (False, True))
    def test_reader_failure_never_substitutes_records(self, frontend, unexpected):
        fixture = self.fixture(frontend)
        installation, = fixture.policy.installations
        declined = FXTraceDeclined if frontend == "fx" else RetentionDeclined
        error = ValueError("unexpected reader failure") if unexpected else declined("unsupported reader program")
        target, name = (extraction, "trace_mixed_fx") if frontend == "fx" else (mixed, "reconstruct_mixed_ir")
        with owner_fixture.TestAutomaticCuTeOwner.cold_build(self, fixture, installation) as build:
            installation._generated = tuple(SimpleNamespace(check=lambda: None, selection=object())
                                            for _ in installation._binding.records.generated_calls)
            with mock.patch.object(target, name, side_effect=error):
                if unexpected:
                    with self.assertRaises(ValueError) as raised:
                        fixture.artifact.current_callable(self.box(fixture))
                    self.assertIs(raised.exception, error)
                    self.assertEqual(installation.status, "failed")
                else:
                    result = fixture.artifact.current_callable(self.box(fixture))
                    self.assertIs(result, fixture.namespace["outcomes"][0])
                    self.assertEqual(installation.status, "declined")
            self.assertNotIn("trace_cute_invocation", build.stages)
            self.assertNotIn("prepare_variant", build.stages)
            self.assertIsNone(installation._projection)
        self.assertEqual(len(fixture.namespace["calls"]), 1)

    def test_correspondence_failure_is_a_cold_decline(self):
        fixture = self.fixture("retained")
        installation, = fixture.policy.installations
        with owner_fixture.TestAutomaticCuTeOwner.cold_build(self, fixture, installation) as build:
            with mock.patch.object(mixed, "bind_mixed_program", side_effect=ProgramDeclined("changed outputs")):
                result = fixture.artifact.current_callable(self.box(fixture))
            self.assertIs(result, fixture.namespace["outcomes"][0])
            self.assertEqual(installation.status, "declined")
            self.assertNotIn("prepare_variant", build.stages)

    def test_retained_requires_a_payload_when_arming(self):
        fixture = self.fixture("retained", payload=False)
        self.assertEqual(fixture.policy.installations, ())
        self.assertIs(fixture.artifact.current_callable, fixture.original)

    @parametrize("field", ("frontend", "payload"))
    def test_frontend_authority_cannot_change_after_arming(self, field):
        fixture = self.fixture("retained")
        installation, = fixture.policy.installations
        target, name, value = ((installation, "_frontend", "fx") if field == "frontend" else
                               (fixture.original, "_cudagraph_mixed_ir", fixture.original._cudagraph_mixed_ir + " "))
        with mock.patch.object(target, name, value):
            with self.assertRaises(HandoffInvalidated):
                installation._check(installation)
        self.assertEqual(fixture.namespace["calls"], [])

    def test_records_does_not_enter_either_reader(self):
        fixture = self.fixture("records")
        installation, = fixture.policy.installations
        with owner_fixture.TestAutomaticCuTeOwner.cold_build(self, fixture, installation), ExitStack() as stack:
            for target, name in ((extraction, "trace_mixed_fx"), (lowering, "lower_mixed_fx"),
                                 (mixed, "reconstruct_mixed_ir"), (mixed, "bind_mixed_program")):
                stack.enter_context(mock.patch.object(target, name, side_effect=AssertionError("unselected reader")))
            result = fixture.artifact.current_callable(self.box(fixture))
            self.assertIs(result, fixture.namespace["outcomes"][0])
            self.assertIsNone(mixed.link_cute_invocation.call_args.kwargs["compiler_program"])
            self.assertIsNone(mixed.preparation.prepare_variant.call_args.kwargs["compiler_program"])

    @parametrize("field", ("_frontend", "_projection"))
    def test_reader_state_cannot_change_during_source_check(self, field):
        fixture = self.fixture("retained")
        installation, = fixture.policy.installations
        check = installation._binding.check

        def changed():
            check()
            setattr(installation, field, object())

        with mock.patch.object(installation, field, getattr(installation, field)):
            with mock.patch.object(installation._binding, "check", side_effect=changed):
                with self.assertRaises(HandoffInvalidated):
                    installation._check(installation)


if __name__ == "__main__":
    run_tests()
