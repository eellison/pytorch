import gc
import json
import sys
import traceback

import cutlass.cute as cute
from cutlass.base_dsl.jit_executor import ExecutionArgs, JitExecutor
from compiler_cute_handoff import invocation, policy as mixed, program, retained
from compiler_cute_handoff.invocation import register_cute_entry, invoke_cute
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from cute_bridge import guard_export, lowering, preparation, provider, tracing
from cute_dispatch import cache, entry as ordinary_module
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import SignaturePolicy
from fx_adapter import extraction as fx_extraction, lowering as fx_lowering
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from selected_kernel import SelectedKernel
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._inductor import config
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class PrefixCuTe(torch.nn.Module):
    def __init__(self, key, workload):
        super().__init__()
        self.key = key
        self.workload = workload

    def forward(self, value):
        if self.workload == "row_normalize":
            source = value * torch.rsqrt(value.square().mean(dim=-1, keepdim=True) + 1e-4)
            extra = ()
        else:
            left, right = value.sin(), value.cos()
            source = left + right
            extra = (left, right)
        destination = source.clone()
        invoke_cute(self.key, source, destination)
        return (*extra, destination)


class RecordingPolicy(NativeCUDAGraphPolicy):
    def __init__(self, frontend):
        super().__init__(cute=True, frontend=frontend)
        self.artifacts = []

    def wrap_output(self, artifact):
        self.artifacts.append((artifact, artifact._cudagraph_original_callable))
        return super().wrap_output(artifact)


class TestMixedWorkloads(TestCase):
    @parametrize("workload", ("row_normalize", "fanout"))
    @parametrize("frontend", ("fx", "retained"))
    def test_public_prefix(self, device, workload, frontend):
        fixture = fixture_module.TestReductionGraphReplayCUDA("test_generated_reduction_replay_fast_True_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        self.enterContext(config.patch(
            use_fast_triton_launcher=True, fx_graph_cache=True, freezing=False,
            allow_buffer_reuse=False, inplace_buffers=False,
            normalize_static_input_alignment=True,
        ))
        self.assertFalse(torch.is_grad_enabled())
        python_entry, kernel, _ = make_fixture()
        layout = TensorPolicy((None, 128), (0, 1))
        owner = ObservedOrdinaryEntry(python_entry, kernel, policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout})
        self.addCleanup(owner.close)
        registration = register_cute_entry(owner, owned_executor=True)
        self.addCleanup(registration.close)
        policy = RecordingPolicy(frontend)
        self.addCleanup(policy.close)
        self.enterContext(config.patch(cudagraph_policy=policy))
        model = PrefixCuTe(registration.key, workload)
        compiled = torch.compile(model, fullgraph=True, dynamic=True)

        previous = sys.getprofile()
        self.assertIsNone(previous)
        self.addCleanup(sys.setprofile, previous)
        compile_code = type(cute.compile).__call__.__code__
        owned_code = OrdinaryEntry._invoke_owned.__code__
        prepare_code = mixed.MixedInstallation._prepare_variant.__code__
        sdk_codes = (JitExecutor.__call__.__code__, JitExecutor.run_compiled_program.__code__,
                     ExecutionArgs.generate_execution_args.__code__, compile_code)
        forbidden = {module.__file__ for module in (
            mixed, invocation, program, retained, ordinary_module, cache, guard_export,
            lowering, preparation, provider, tracing, fx_extraction, fx_lowering,
        )}
        input_storages, output_storages, observations = [], [], []
        total_compiles = 0
        output_count = 1 if workload == "row_normalize" else 3

        def call(batch, cold):
            nonlocal total_compiles
            value = torch.randn(batch, 128, device=device, dtype=torch.float32)
            torch._dynamo.mark_static(value, 1)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            state = {"batch": batch, "cold": cold, "original": 0, "ordinary": 0,
                     "preparations": 0, "compiles": 0, "frames": [], "wrong_compile_target": False,
                     "observer_errors": []}

            def collect(frame, event, result):
                if event != "call":
                    return
                code = frame.f_code
                if not cold and (code.co_filename in forbidden or code in sdk_codes
                                 or code is CachingAutotuner.run.__code__):
                    state["frames"].append((code.co_filename, code.co_name))
                if code is compile_code and frame.f_locals.get("self") is cute.compile:
                    state["compiles"] += 1
                    args = frame.f_locals.get("args", ())
                    state["wrong_compile_target"] |= not args or args[0] is not python_entry.target
                if code is owned_code and frame.f_locals.get("self") is owner:
                    state["ordinary"] += 1
                if code is prepare_code:
                    state["preparations"] += 1
                for _, original in policy.artifacts:
                    if code is original.__code__ and frame.f_globals is original.__globals__:
                        state["original"] += 1
                        if not cold:
                            state["frames"].append((code.co_filename, code.co_name))

            def observe(frame, event, result):
                try:
                    collect(frame, event, result)
                except BaseException as error:
                    if not state["observer_errors"]:
                        state["observer_errors"].append("".join(traceback.format_exception(error)))

            try:
                sys.setprofile(observe)
                try:
                    result = compiled(value)
                finally:
                    sys.setprofile(previous)
            except BaseException as error:
                for failure in state["observer_errors"]:
                    error.add_note("Deferred workload profiler failure:\n" + failure)
                raise
            if state["observer_errors"]:
                self.fail("Deferred workload profiler failure:\n" + state["observer_errors"][0])
            total_compiles += state["compiles"]
            self.assertFalse(state["wrong_compile_target"])
            if workload == "row_normalize":
                source = value * torch.rsqrt(value.square().mean(dim=-1, keepdim=True) + 1e-4)
                extra = ()
            else:
                left, right = value.sin(), value.cos()
                source, extra = left + right, (left, right)
            expected = (*extra, source * 2 + (64 if batch < 4 else 128))
            self.assertEqual(result, expected)
            self.assertIs(type(result), tuple)
            self.assertEqual(len(result), output_count)
            for tensor in result:
                self.assertEqual(tuple(tensor.shape), (batch, 128))
                self.assertIsNone(tensor._base)
                output_storages.append(StorageWeakRef(tensor.untyped_storage()))
            if cold:
                self.assertEqual(len(policy.installations), 1, "Expected automatic native admission")
                current, = policy.installations
                self.assertEqual(current.status, "ready", current.decline)
            self.assertEqual((state["original"], state["ordinary"], state["preparations"]),
                             (1, 1, 1) if cold else (0, 0, 0))
            if not cold:
                self.assertEqual(state["frames"], [])
                self.assertEqual(state["compiles"], 0)
            self.assertEqual(len(policy.artifacts), 1)
            observations.append(state)
            return result, expected

        held = [call(13, True)]
        self.assertEqual(total_compiles, 1)
        installation, = policy.installations
        artifact, original = policy.artifacts[0]
        self.assertEqual(installation.status, "ready")
        self.assertIs(artifact.current_callable, installation.entry)
        self.assertIs(type(installation.entry), torch._C._CUDAGraphBoxedDispatch)
        self.assertIs(installation._binding.function(), original)
        self.assertEqual(installation._frontend, frontend)
        self.assertIs(type(installation._projection), program.BoundMixedProgram)
        self.assertIs(installation._projection.binding, installation._binding)
        self.assertEqual(len(installation._projection.program.outputs), output_count)
        self.assertEqual(len(installation._binding.records.outputs), output_count)
        self.assertEqual(len(installation.cache.variants), 1)
        self.assertTrue(installation._binding.records.generated_calls)
        for generated in installation._generated:
            selection = generated.selection
            current = SelectedKernel.from_warmed(selection.identity[0])
            self.assertEqual(len(current.identity), len(selection.identity))
            self.assertTrue(all(left is right for left, right in zip(current.identity, selection.identity)))
            _, selected_launcher, cached, module = selection.identity
            self.assertIsNot(cached, selected_launcher)
            self.assertIs(type(cached.__globals__["runner"]), torch._C._FastCudaLauncher)
            self.assertIs(cached._static_kernel_owner, module)
            fixture.modules[id(module)] = module
        dispatcher, projection, selected = installation.entry, installation._projection, owner.selected
        held.append(call(2, True))
        self.assertEqual(len(installation.cache.variants), 2)
        variants = tuple(installation.cache.variants)
        self.assertEqual({variant.owners[0].site.arm for variant in variants}, {False, True})
        for batch in (7, 3, 35, 36):
            held.append(call(batch, False))
            self.assertIs(artifact.current_callable, dispatcher)
            self.assertIs(installation._projection, projection)
            self.assertIs(owner.selected, selected)
            self.assertEqual(len(installation.cache.variants), len(variants))
            self.assertTrue(all(now is before for now, before in zip(installation.cache.variants, variants)))
        self.assertEqual(total_compiles, 1)
        self.assertEqual(installation.status, "ready")
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        installation.close()
        self.assertTrue(dispatcher.closed)
        self.assertIs(artifact.current_callable, original)
        self.assertEqual(owner._native_borrows, set())
        registration.close()
        for result, expected in held:
            self.assertEqual(result, expected)
        self.assertEqual(len({tensor.data_ptr() for result, _ in held for tensor in result}), len(held) * output_count)
        del result, expected
        held.clear()
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in output_storages))
        print("MIXED_WORKLOAD_RESULT=" + json.dumps({
            "workload": workload, "frontend": frontend, "fast": True,
            "ordinary_compilations": total_compiles, "output_count": output_count,
            "generated_calls": len(projection.records.generated_calls),
            "observations": observations, "same_native_variants": True,
            "input_storage_released": True, "held_outputs_correct_after_close": True,
            "output_storage_released": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestMixedWorkloads, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
