from contextlib import ExitStack
from unittest import mock

from retained_emission_envelope_fixture import CompilerFixture
from compiler_cute_handoff import envelope, retained
from compiler_cute_handoff.envelope import bind_envelope, EnvelopeDeclined
from compiler_cute_handoff.program import bind_mixed_program
from compiler_cute_handoff.retained import reconstruct_mixed_ir, RetentionDeclined
import torch
from torch._inductor import config
from torch._inductor.codegen.wrapper import CuTeCallLine, WrapperLine
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource
from torch._inductor.utils import IndentedBuffer
from torch._inductor.virtualized import V
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


@instantiate_parametrized_tests
class TestRetainedMixedEmission(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch({"graph_partition": False, "use_static_triton_launcher": True,
                                       "triton.autotune_at_compile_time": False}))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def generate(self, fixture, *, passes=None):
        """Actual _generate/collectors/attachments; ordinary body formatting is a stand-in."""
        wrapper = fixture.wrapper
        wrapper.launcher_fn_name = "call"
        wrapper.wrapper_call = IndentedBuffer()
        wrapper.imports = IndentedBuffer()
        wrapper.imports.writeline("import torch")
        wrapper.subgraph_definitions = IndentedBuffer()
        wrapper.prefix = IndentedBuffer()
        wrapper.prefix.writeline("def call(box):")
        wrapper.suffix = IndentedBuffer()
        wrapper.kernel_declarations = IndentedBuffer()

        def format_line(line, code):
            code.writeline("pass")

        with ExitStack() as stack:
            stack.enter_context(V.set_graph_handler(fixture.graph))
            final_pass = stack.enter_context(mock.patch.object(wrapper, "run_wrapper_ir_passes", side_effect=passes))
            for name in ("_write_multi_kernel_defs", "mark_output_type", "finalize_prefix", "add_benchmark_harness"):
                stack.enter_context(mock.patch.object(wrapper, name, return_value=None))
            stack.enter_context(mock.patch.object(wrapper, "get_output_refs", return_value=[]))
            for kind in {type(line) for line in wrapper.lines if isinstance(line, WrapperLine)}:
                stack.enter_context(mock.patch.object(kind, "codegen", format_line))
            rendered, _ = wrapper._generate(is_inference=True)
            final_pass.assert_called_once_with(True)
        namespace = {fixture.prefix_call.kernel_name: object(), fixture.output_call.kernel_name: object()}
        exec(compile(rendered.value, "<retained-emission-fixture>", "exec"), namespace)
        return namespace["call"], rendered.value

    @parametrize("dynamic", (False, True))
    @parametrize("envelope_declines", (False, True))
    def test_actual_generate_emits_independent_data_payload(self, dynamic, envelope_declines):
        fixture = CompilerFixture(self, dynamic=dynamic, return_prefix=True)
        with ExitStack() as stack:
            if envelope_declines:
                stack.enter_context(mock.patch.object(envelope, "collect_envelope",
                                                     side_effect=EnvelopeDeclined("separate envelope decline")))
            function, source = self.generate(fixture)
        self.assertIs(type(function._cudagraph_mixed_ir), str)
        program = reconstruct_mixed_ir(function._cudagraph_mixed_ir)
        self.assertEqual(tuple(row.source for row in program.outputs),
                         (BufferSource("destination"), BufferSource("prefix")))
        self.assertEqual(program.outputs[0].size[1], 128)
        self.assertIn("._cudagraph_mixed_ir = ", source)
        self.assertTrue(hasattr(function, "_cute_invocation_descriptors"))
        self.assertEqual(hasattr(function, "_cute_mixed_envelope"), not envelope_declines)
        self.assertFalse(hasattr(function, "_cudagraph_call_records"))
        self.assertIsNone(fixture.owner.selected)
        if not envelope_declines:
            bound = bind_mixed_program(bind_envelope(function), program)
            self.assertEqual(bound.records.outputs, program.outputs)
            bound.check()

    @parametrize("stage", ("retain_mixed_wrapper", "export_mixed_ir"))
    def test_typed_decline_emits_none_without_losing_other_metadata(self, stage):
        fixture = CompilerFixture(self)
        with mock.patch.object(retained, stage, side_effect=RetentionDeclined("unsupported reader")):
            function, _ = self.generate(fixture)
        self.assertIsNone(function._cudagraph_mixed_ir)
        self.assertTrue(hasattr(function, "_cute_invocation_descriptors"))
        bind_envelope(function).check()

    @parametrize("stage", ("retain_mixed_wrapper", "export_mixed_ir"))
    def test_unexpected_reader_failure_propagates(self, stage):
        fixture = CompilerFixture(self)
        error = ValueError("unexpected retained reader failure")
        with mock.patch.object(retained, stage, side_effect=error):
            with self.assertRaises(ValueError) as caught:
                self.generate(fixture)
        self.assertIs(caught.exception, error)

    def test_collection_observes_final_pass_outputs(self):
        fixture = CompilerFixture(self, return_prefix=True)

        def final_pass(is_inference):
            self.assertTrue(is_inference)
            fixture.graph.graph_outputs.reverse()

        function, _ = self.generate(fixture, passes=final_pass)
        program = reconstruct_mixed_ir(function._cudagraph_mixed_ir)
        self.assertEqual(tuple(row.source for row in program.outputs),
                         (BufferSource("prefix"), BufferSource("destination")))
        self.assertEqual(function._cute_invocation_descriptors.outputs, tuple(row.source for row in program.outputs))

    def test_non_cute_wrapper_does_not_consult_reader(self):
        fixture = CompilerFixture(self)
        fixture.wrapper.lines = [line for line in fixture.wrapper.lines if type(line) is not CuTeCallLine]
        fixture.graph.operations.remove(fixture.op)
        with mock.patch.object(retained, "retain_mixed_wrapper", side_effect=AssertionError("must not retain")), \
                mock.patch.object(fixture.wrapper, "collect_cudagraph_call_records", return_value=None):
            function, source = self.generate(fixture)
        self.assertFalse(hasattr(function, "_cudagraph_mixed_ir"))
        self.assertNotIn("._cudagraph_mixed_ir = ", source)


if __name__ == "__main__":
    run_tests()
