from contextlib import ExitStack
import gc
import json
import sys
import traceback
import weakref
from unittest import mock

import cutlass.cute as cute
from cutlass.base_dsl.jit_executor import ExecutionArgs, JitExecutor
from compiler_cute_handoff import invocation as invocation_module
from compiler_cute_handoff import policy as mixed
from compiler_cute_handoff import program as program_module, retained as retained_module
from compiler_cute_handoff.envelope import GeneratedCall
from compiler_cute_handoff.invocation import invoke_cute, register_cute_entry
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from cute_bridge import guard_export, lowering, preparation, provider, tracing
from cute_dispatch import cache as cache_module
from cute_dispatch import entry as ordinary_module
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import SignaturePolicy
from fx_adapter import extraction as fx_extraction, lowering as fx_lowering
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from selected_kernel import SelectedKernel
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._dynamo.utils import counters
from torch._inductor import config
from torch._inductor.runtime.cudagraph_arg_mapping import AlignmentCopy, BufferSource, InputSource, IntExpr
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class RecordingPolicy(NativeCUDAGraphPolicy):
    def __init__(self, artifacts, frontend):
        super().__init__(cute=True, frontend=frontend)
        self.artifacts = artifacts

    def wrap_output(self, artifact):
        original = artifact.current_callable
        result = super().wrap_output(artifact)
        self.artifacts.append((artifact, original))
        return result


class ParameterCuTe(torch.nn.Module):
    def __init__(self, device, key):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.randn(128, device=device))
        self.key = key

    def forward(self, value):
        source = (value * self.weight).sin()
        destination = source.clone()
        invoke_cute(self.key, source, destination)
        return (destination,)


class TestMixedFrontendIntegration(TestCase):
    @parametrize("frontend", ("fx", "retained"))
    @parametrize("fast", (False, True))
    def test_public_mixed_frontend(self, device, frontend, fast):
        fixture = fixture_module.TestReductionGraphReplayCUDA(f"test_generated_reduction_replay_fast_{fast}_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        self.enterContext(config.patch(
            use_fast_triton_launcher=fast, fx_graph_cache=True,
            allow_buffer_reuse=False, inplace_buffers=False,
            normalize_static_input_alignment=True, freezing=False,
        ))
        python_entry, kernel, _ = make_fixture()
        layout = TensorPolicy((None, 128), (0, 1))
        ordinary = ObservedOrdinaryEntry(
            python_entry, kernel, policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout},
        )
        self.addCleanup(ordinary.close)
        registration = register_cute_entry(ordinary, owned_executor=True)
        self.addCleanup(registration.close)
        self.assertIs(registration.provider.run.__func__, OrdinaryEntry._invoke_owned)
        model = ParameterCuTe(device, registration.key)
        self.assertFalse(torch.is_grad_enabled())
        self.assertEqual(model.weight.data_ptr() % 16, 0)
        weight_storages = [StorageWeakRef(model.weight.untyped_storage())]
        weight_layout = model.weight.dtype, tuple(model.weight.shape), model.weight.stride()

        artifacts = []
        policy = RecordingPolicy(artifacts, frontend)

        def close_owned():
            for artifact, _ in artifacts:
                installation = artifact._cudagraph_installation_owner
                if installation is not None:
                    installation.close()

        # The cleanup owns artifacts, not the policy whose release is tested.
        self.addCleanup(close_owned)
        compiled = torch.compile(model, fullgraph=True, dynamic=True)
        compile_target, compilations = cute.compile, []

        def compile_once(target, *args, **kwargs):
            self.assertIs(target, python_entry.target)
            compilations.append(target)
            self.assertEqual(len(compilations), 1)
            return compile_target(target, *args, **kwargs)

        self.enterContext(mock.patch.object(cute, "compile", compile_once))
        previous_profile = sys.getprofile()
        self.assertIsNone(previous_profile)
        self.addCleanup(sys.setprofile, previous_profile)
        ordinary_code = OrdinaryEntry._run_locked.__code__
        owned_code = OrdinaryEntry._invoke_owned.__code__
        sdk_call_code = JitExecutor.__call__.__code__
        sdk_launch_code = JitExecutor.run_compiled_program.__code__
        marshal_code = ExecutionArgs.generate_execution_args.__code__
        state_code = OrdinaryEntry._state.__code__
        dependency_codes = (ordinary_module.python_entry._Dependencies.__init__.__code__,
                            ordinary_module.python_entry._Dependencies.check.__code__)
        prepare_code = mixed.MixedInstallation._prepare_variant.__code__
        cache_code = mixed._MixedCache._cold.__code__
        callback_code = mixed.MixedInstallation.ordinary.__code__
        autotuner_code = CachingAutotuner.run.__code__
        replay_code = preparation._make_replay.__code__
        preparation_code = preparation.prepare_variant.__code__
        normalize = torch._C._dynamo.guards.copy_if_misaligned
        forbidden_files = {
            module.__file__ for module in
            (mixed, invocation_module, ordinary_module, cache_module, guard_export, lowering, preparation,
             provider, tracing, fx_extraction, fx_lowering, program_module, retained_module)
        }
        reader_codes = {fx_extraction.trace_mixed_fx.__code__: "fx_trace",
                        fx_lowering.lower_mixed_fx.__code__: "fx_lower",
                        retained_module.reconstruct_mixed_ir.__code__: "retained_decode"}
        reader_calls = dict.fromkeys(reader_codes.values(), 0)
        projection_ids = []
        active = None
        input_storages, source_storages, destination_storages, native_storages = [], [], [], []
        cold_records, ordinary_batches, native_batches = [], [], []
        capsule_ids, signature_ids = [], []
        boxed_facts, replay_copies, normalized_storages = [], [], []
        owned_records = []

        def collect_observation(frame, event, result):
            if active is None:
                return
            if event == "call" and frame.f_code in reader_codes:
                reader_calls[reader_codes[frame.f_code]] += 1
            if event == "call" and (frame.f_code.co_filename in forbidden_files
                                     or frame.f_code in (ordinary_code, autotuner_code, sdk_call_code, sdk_launch_code, marshal_code)):
                active["frames"].append((frame.f_code.co_filename, frame.f_code.co_name))
            if not artifacts:
                return
            artifact, original = artifacts[0]
            if frame.f_code is owned_code and frame.f_locals.get("self") is ordinary:
                if event == "call":
                    self.assertFalse(active["in_owned"])
                    caller = frame.f_back
                    self.assertIs(caller.f_code, invocation_module._CuTeProvider.invoke.__code__)
                    self.assertIs(caller.f_back.f_code, invocation_module.InvocationEntry.invoke.__code__)
                    self.assertIs(caller.f_back.f_back.f_code, original.__code__)
                    self.assertIs(caller.f_back.f_back.f_globals, original.__globals__)
                    source, destination = frame.f_locals["source"], frame.f_locals["destination"]
                    self.assertIs(type(source), torch.Tensor)
                    self.assertIs(type(destination), torch.Tensor)
                    self.assertIs(frame.f_locals["host"], registration.provider.host)
                    source_storages.append(StorageWeakRef(source.untyped_storage()))
                    destination_storages.append(StorageWeakRef(destination.untyped_storage()))
                    active["prepared_on_entry"] = ordinary._owned_executor is not None
                    active["in_owned"] = True
                    active["ordinary_runs"] += 1
                elif event == "return":
                    prepared = ordinary._owned_executor
                    active["owned_returns"].append({
                        "result": result,
                        "binding": None if prepared is None else (
                            type(prepared.executor), prepared.selected is ordinary.selected,
                            prepared.executor.jit_module is ordinary.selected.jit_module,
                            prepared.host is registration.provider.host, prepared.metadata is ordinary.metadata),
                        "executor_id": None if prepared is None else id(prepared.executor),
                    })
                    active["in_owned"] = False
            if event == "call" and active["in_owned"]:
                if frame.f_code is state_code and frame.f_locals.get("self") is ordinary:
                    active["state_checks"] += 1
                if frame.f_code in dependency_codes:
                    active["dependency_checks"] += 1
                if (frame.f_code is marshal_code and ordinary.selected is not None
                        and frame.f_locals.get("self") is ordinary.selected.execution_args):
                    active["marshals"] += 1
                if (frame.f_code is sdk_launch_code and ordinary.selected is not None
                        and frame.f_locals["self"].jit_module is ordinary.selected.jit_module):
                    expected_executor = (ordinary._owned_executor.executor if active["prepared_on_entry"]
                                         else ordinary.selected._default_executor)
                    self.assertIs(frame.f_locals["self"], expected_executor)
                    active["sdk_launches"] += 1
                if (frame.f_code is sdk_call_code and ordinary._owned_executor is not None
                        and frame.f_locals["self"] is ordinary._owned_executor.executor):
                    self.assertTrue(active["prepared_on_entry"])
                    self.assertIs(frame.f_locals["self"], ordinary._owned_executor.executor)
                    self.assertIs(frame.f_back.f_code, owned_code)
                    runtime = frame.f_back.f_locals["runtime"]
                    arguments, keywords = frame.f_locals["args"], frame.f_locals["kwargs"]
                    self.assertEqual(len(arguments), len(runtime.args))
                    self.assertTrue(all(left is right for left, right in zip(arguments, runtime.args)))
                    self.assertEqual(tuple(keywords), tuple(runtime.kwargs))
                    self.assertTrue(all(keywords[name] is runtime.kwargs[name] for name in keywords))
                    bound = ordinary.signature.bind_partial(*arguments, **keywords)
                    for formal, local in zip(registration.formals, ("source", "destination")):
                        self.assertEqual(bound.arguments[formal].data_ptr, frame.f_back.f_locals[local].data_ptr())
                    active["sdk_calls"] += 1
            if event == "call" and frame.f_code is cache_code:
                active["cache_box"] = frame.f_locals["box"]
            if frame.f_code is original.__code__ and frame.f_globals is original.__globals__:
                if event == "call":
                    active["frames"].append((frame.f_code.co_filename, frame.f_code.co_name))
                    active["original_calls"] += 1
                    box = frame.f_locals[original.__code__.co_varnames[0]]
                    self.assertIs(type(box), list)
                    if active["mode"] == "cold":
                        self.assertIs(box, active["cold_box"])
                    active["original_box"] = box
                    parameter_index, = [index for index, item in enumerate(box) if item is model.weight]
                    input_index, = [index for index, item in enumerate(box) if item is active["input"]()]
                    self.assertEqual(tuple(artifact.fx_kwargs["static_input_idxs"]), (parameter_index,))
                    facts = {"parameter": parameter_index, "input": input_index,
                             "integers": {index: item for index, item in enumerate(box) if type(item) is int}}
                    active["boxed_facts"] = facts
                    boxed_facts.append(facts)
                elif event == "return":
                    active["original_box_empty"] = active["original_box"] == []
                    active["ordinary_result"] = result
            if event == "call" and frame.f_code is callback_code:
                self.assertIs(frame.f_locals["self"], artifact._cudagraph_installation_owner)
                active["cold_box"] = frame.f_locals["box"]
                self.assertIs(active["cold_box"], active["cache_box"])
            if event == "return" and frame.f_code is ordinary_code and frame.f_locals.get("self") is ordinary:
                if result is not None:
                    source, destination = frame.f_locals["inputs"]
                    self.assertIs(type(source), torch.Tensor)
                    self.assertIs(type(destination), torch.Tensor)
                    call, = result.calls
                    self.assertIs(call.entry, python_entry)
                    self.assertIs(call.arguments[0], source)
                    self.assertIs(call.arguments[1], destination)
                    self.assertIs(frame.f_locals["host"], registration.provider.host)
                    active["audited_runs"] += 1
            if event == "call" and frame.f_code is replay_code:
                self.assertIs(frame.f_back.f_code, preparation_code)
                installation = artifact._cudagraph_installation_owner
                checked = installation._binding
                copies = tuple(event.input_index for event in checked.records.events if type(event) is AlignmentCopy)
                self.assertEqual(frame.f_locals["copies"], copies)
                self.assertIs(frame.f_locals["copy_if_misaligned"], normalize)
                parameter_index = active["boxed_facts"]["parameter"]
                self.assertIn(parameter_index, copies)
                state = frame.f_back.f_locals["state"]
                compiler = frame.f_back.f_locals["compiler"]
                self.assertIs(compiler.binding, checked)
                self.assertIs(compiler.compiler_program, installation._projection)
                self.assertIs(state.originals[parameter_index], model.weight)
                normalized = state.normalized[parameter_index]
                copied = model.weight.data_ptr() % 16 != 0
                self.assertEqual(normalized is not model.weight, copied)
                self.assertEqual(normalized.data_ptr() % 16, 0)
                if copied:
                    normalized_storages.append(StorageWeakRef(normalized.untyped_storage()))
                replay_copies.append({"batch": active["batch"], "indices": copies,
                                      "parameter_copied": copied})
            if event == "return" and frame.f_code is prepare_code and result is not None:
                installation = frame.f_locals["self"]
                self.assertIs(type(result), cache_module.PreparedVariant)
                self.assertIs(installation, artifact._cudagraph_installation_owner)
                checked, trace = frame.f_locals["checked"], frame.f_locals["trace"]
                signature, bound = frame.f_locals["signature"], frame.f_locals["bound"]
                invocation, dispatch_artifact = frame.f_locals["invocation"], frame.f_locals["artifact"]
                linked, owner, guard = (frame.f_locals[name] for name in ("linked", "owner", "guard"))
                self.assertIs(checked, installation._binding)
                self.assertIs(checked.function(), original)
                self.assertIs(trace.binding, checked.binding)
                self.assertIs(trace.input_contract, checked.inputs)
                self.assertIs(signature.trace, trace)
                self.assertIs(invocation.bound, bound)
                self.assertIs(bound.compilation, ordinary._compilation)
                self.assertIs(dispatch_artifact.signature, signature)
                self.assertIs(linked.owner, owner)
                projection = installation._projection
                self.assertIs(type(projection), program_module.BoundMixedProgram)
                self.assertIs(projection.binding, checked)
                self.assertIs(linked.program.outputs, projection.program.outputs)
                self.assertEqual(linked.program.allocations, projection.records.allocations)
                projection_ids.append(id(projection))
                self.assertEqual(result.owners, (owner,))
                self.assertEqual(result.registration, guard.registration)
                self.assertEqual(bool(owner.site.arm), active["batch"] < 4)
                indices = tuple(row.index for row in checked.inputs.integer_ranges)
                self.assertEqual(guard.boxed_integer_indices, indices)
                self.assertEqual(tuple(frame.f_locals["inputs"][index] for index in indices), (active["batch"],))
                parameter_index = active["boxed_facts"]["parameter"]
                input_index = active["boxed_facts"]["input"]
                batch_index, = indices
                self.assertEqual(active["boxed_facts"]["integers"], {batch_index: active["batch"]})
                layouts = {row.index: row for row in checked.inputs.tensor_inputs}
                self.assertEqual(set(layouts), {parameter_index, input_index})
                self.assertEqual((layouts[parameter_index].size, layouts[parameter_index].stride), ((128,), (1,)))
                self.assertEqual((layouts[input_index].size, layouts[input_index].stride),
                                 ((IntExpr("boxed", batch_index), 128), (128, 1)))
                self.assertEqual(tuple(artifact.fx_kwargs["static_input_idxs"]), (parameter_index,))
                copies = tuple(event for event in checked.records.events if type(event) is AlignmentCopy)
                self.assertEqual(linked.program.copies, copies)
                self.assertIn(parameter_index, tuple(copy.input_index for copy in copies))
                call, = checked.cute.calls
                self.assertTrue(all(type(operand.source) is BufferSource for operand in call.operands))
                self.assertEqual(len({operand.source for operand in call.operands}), 2)
                self.assertEqual(checked.records.outputs[0].source, call.operands[1].source)
                self.assertTrue(any(InputSource(parameter_index) in event.reads for event in checked.records.events
                                    if type(event) is GeneratedCall))
                capsule_ids.append(id(bound.compilation))
                signature_ids.append(id(signature))
                active["preparations"] += 1
                cold_records.append({
                    "batch": active["batch"], "arm": bool(owner.site.arm),
                    "site_id": owner.site.site_id, "boxed_indices": indices,
                    "guard_expressions": guard.expressions,
                    "generated_calls": len(checked.records.generated_calls),
                    "outputs": len(checked.records.outputs),
                    "parameter_index": parameter_index, "input_index": input_index,
                    "recorded_copies": tuple(copy.input_index for copy in copies),
                })
            if event == "return" and frame.f_code is cache_code and result is not None:
                self.assertIs(result, active["ordinary_result"])
                self.assertEqual(active["cache_box"], [])
                active["cold_returns"] += 1

        def observe(frame, event, result):
            try:
                collect_observation(frame, event, result)
            except BaseException as error:
                if active is not None and not active["observer_errors"]:
                    active["observer_errors"].append("".join(traceback.format_exception(error)))

        def call(batch, mode, update="unchanged"):
            nonlocal active
            self.assertIs(type(model.weight), torch.nn.Parameter)
            self.assertEqual((model.weight.dtype, tuple(model.weight.shape), model.weight.stride()), weight_layout)
            value = torch.randn((batch, 128), device=device)
            torch._dynamo.mark_static(value, 1)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            state = {"batch": batch, "mode": mode, "input": weakref.ref(value),
                     "frames": [], "original_calls": 0,
                     "ordinary_runs": 0, "preparations": 0, "cold_returns": 0,
                     "in_owned": False, "prepared_on_entry": False, "audited_runs": 0,
                     "sdk_calls": 0, "sdk_launches": 0, "marshals": 0,
                     "state_checks": 0, "dependency_checks": 0,
                     "owned_returns": [], "observer_errors": []}
            active = state
            try:
                with ExitStack() as stack:
                    if mode == "hit":
                        error = AssertionError("A public native hit entered ordinary execution or preparation")
                        stack.enter_context(mock.patch.object(OrdinaryEntry, "run", side_effect=error))
                        stack.enter_context(mock.patch.object(OrdinaryEntry, "_invoke_owned", side_effect=error))
                        stack.enter_context(mock.patch.object(JitExecutor, "__call__", side_effect=error))
                        stack.enter_context(mock.patch.object(CachingAutotuner, "run", side_effect=error))
                        stack.enter_context(mock.patch.object(mixed.MixedInstallation, "_prepare_variant", side_effect=error))
                    sys.setprofile(observe)
                    try:
                        result = compiled(value)
                    except BaseException as error:
                        for failure in state["observer_errors"]:
                            error.add_note("Deferred profiler validation failure:\n" + failure)
                        raise
                    finally:
                        sys.setprofile(previous_profile)
            finally:
                active = None
            if state["observer_errors"]:
                self.fail("Deferred profiler validation failure:\n" + state["observer_errors"][0])
            expected = ((value * model.weight).sin() * 2 + (64 if batch < 4 else 128),)
            self.assertEqual(result, expected)
            self.assertEqual((len(artifacts), len(compilations)), (1, 1))
            self.assertEqual(len(result), 1)
            self.assertEqual((tuple(result[0].shape), result[0].stride(), result[0].storage_offset()),
                             ((batch, 128), (128, 1), 0))
            self.assertIsNone(result[0]._base)
            if mode == "hit":
                self.assertEqual(state["frames"], [])
                self.assertEqual((state["original_calls"], state["ordinary_runs"],
                                  state["preparations"], state["cold_returns"]), (0, 0, 0, 0))
                self.assertEqual((state["sdk_calls"], state["sdk_launches"], state["marshals"]), (0, 0, 0))
                native_batches.append(batch)
                native_storages.append(StorageWeakRef(result[0].untyped_storage()))
            else:
                self.assertEqual((state["original_calls"], state["ordinary_runs"]), (1, 1))
                self.assertTrue(state["frames"])
                self.assertIs(type(state["ordinary_result"]), tuple)
                self.assertTrue(state["original_box_empty"])
                self.assertIs(result[0], state["ordinary_result"][0])
                owned_return, = state["owned_returns"]
                self.assertIsNone(owned_return["result"])
                self.assertIsNotNone(owned_return["binding"])
                self.assertIs(owned_return["binding"][0], JitExecutor)
                self.assertEqual(owned_return["binding"][1:], (True, True, True, True))
                self.assertEqual((state["sdk_launches"], state["marshals"]), (1, 1))
                if state["prepared_on_entry"]:
                    self.assertEqual((state["sdk_calls"], state["audited_runs"],
                                      state["state_checks"], state["dependency_checks"]), (1, 0, 0, 0))
                else:
                    self.assertEqual((state["sdk_calls"], state["audited_runs"]), (0, 1))
                    self.assertGreater(state["state_checks"], 0)
                    self.assertGreater(state["dependency_checks"], 0)
                owned_records.append({"batch": batch, "prepared_on_entry": state["prepared_on_entry"],
                    "executor_id": owned_return["executor_id"], "sdk_launches": state["sdk_launches"],
                    "sdk_calls": state["sdk_calls"], "marshals": state["marshals"],
                    "audited_runs": state["audited_runs"], "state_checks": state["state_checks"],
                    "dependency_checks": state["dependency_checks"]})
                self.assertEqual((state["preparations"], state["cold_returns"]),
                                 (1, 1) if mode == "cold" else (0, 0))
                ordinary_batches.append(batch)
            updates.append({"batch": batch, "mode": mode, "weight": update})
            return result, expected

        updates = []
        bypasses = counters["inductor"]["fxgraph_cache_bypass"]
        with config.patch(cudagraph_policy=policy):
            held = [call(13, "cold")]
        artifact, original = artifacts[0]
        installation, = policy.installations
        self.assertIs(artifact._cudagraph_installation_owner, installation)
        self.assertIs(artifact.current_callable, installation.entry)
        self.assertIs(type(installation.entry), torch._C._CUDAGraphBoxedDispatch)
        self.assertEqual((installation.status, len(installation.cache.variants)), ("ready", 1))
        dispatcher = installation.entry
        installation_ref, policy_ref = weakref.ref(installation), weakref.ref(policy)
        selected = ordinary.selected
        executor_ref = weakref.ref(ordinary._owned_executor.executor)
        selections = {}
        for generated in installation._generated:
            selection = generated.selection
            selections[id(selection.identity[0])] = selection
            fixture.modules[id(selection.identity[3])] = selection.identity[3]
        del generated, selection, installation, policy
        gc.collect()
        self.assertIsNone(policy_ref())
        self.assertIsNotNone(installation_ref())
        self.assertIs(artifact._cudagraph_installation_owner, installation_ref())
        model.weight.add_(0.25)
        held.append(call(7, "hit", "in_place"))
        self.assertEqual(len(installation_ref().cache.variants), 1)
        model.weight = torch.nn.Parameter(torch.randn(128, device=device))
        self.assertEqual(model.weight.data_ptr() % 16, 0)
        weight_storages.append(StorageWeakRef(model.weight.untyped_storage()))
        held.append(call(35, "hit", "aligned_replacement"))
        gc.collect()
        self.assertTrue(weight_storages[0].expired(), "Native replay retained the original Parameter storage")
        backing = torch.randn(129, device=device)
        model.weight = torch.nn.Parameter(backing[1:])
        del backing
        self.assertNotEqual(model.weight.data_ptr() % 16, 0)
        weight_storages.append(StorageWeakRef(model.weight.untyped_storage()))
        held.append(call(2, "cold", "misaligned_replacement"))
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in weight_storages[:-1]))
        self.assertIs(artifact.current_callable, dispatcher)
        self.assertEqual((installation_ref().status, len(installation_ref().cache.variants)), ("ready", 2))
        self.assertEqual(ordinary_batches, [13, 2])
        self.assertEqual(len(set(capsule_ids)), 1)
        self.assertEqual(len(set(signature_ids)), 2)
        self.assertEqual(len(set(projection_ids)), 1)
        self.assertEqual(reader_calls, {"fx_trace": 1, "fx_lower": 1, "retained_decode": 0}
                         if frontend == "fx" else {"fx_trace": 0, "fx_lower": 0, "retained_decode": 1})
        self.assertEqual({row["arm"] for row in cold_records}, {False, True})
        for close in (registration.close, ordinary.close):
            with self.assertRaisesRegex(RuntimeError, "borrowed"):
                close()
        held.append(call(3, "hit", "same_misaligned"))
        model.weight.add_(0.5)
        held.append(call(36, "hit", "misaligned_in_place"))
        self.assertEqual(native_batches, [7, 35, 3, 36])
        self.assertEqual([row["parameter_copied"] for row in replay_copies], [False, True])
        self.assertEqual(len({row["parameter"] for row in boxed_facts}), 1)
        self.assertEqual(len({row["input"] for row in boxed_facts}), 1)
        self.assertEqual(len(installation_ref().cache.variants), 2)
        self.assertIs(ordinary.selected, selected)
        self.assertIs(ordinary._owned_executor.executor, executor_ref())
        for selection in selections.values():
            current = SelectedKernel.from_warmed(selection.identity[0])
            self.assertTrue(all(left is right for left, right in zip(current.identity, selection.identity)))
        self.assertEqual(len(compilations), 1)
        self.assertGreater(counters["inductor"]["fxgraph_cache_bypass"], bypasses)
        self.assertFalse(invoke_cute.cacheable())
        self.assertIsNone(ordinary._calls)
        self.assertEqual((ordinary._capture.arguments, ordinary._capture.keywords), ((), {}))
        self.assertIsNone(installation_ref()._ordinary_result)
        self.assertIsNone(installation_ref()._active)
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        self.assertEqual(len(source_storages), 2)
        self.assertTrue(all(storage.expired() for storage in (*source_storages, *normalized_storages)))
        self.assertTrue(all(not storage.expired() for storage in destination_storages))
        installation = installation_ref()
        installation.close()
        self.assertTrue(dispatcher.closed)
        self.assertIs(artifact.current_callable, original)
        self.assertIsNone(artifact._cudagraph_installation_owner)
        self.assertEqual(ordinary._native_borrows, set())
        self.assertFalse(registration.closed)
        held.append(call(5, "ordinary"))
        self.assertEqual(ordinary_batches, [13, 2, 5])
        self.assertEqual(len(cold_records), 2)
        self.assertEqual([row["prepared_on_entry"] for row in owned_records], [False, True, True])
        self.assertEqual(len({row["executor_id"] for row in owned_records}), 1)
        eager_checks = []

        def observe_eager(frame, event, result):
            if event == "call" and frame.f_code is state_code and frame.f_locals.get("self") is ordinary:
                eager_checks.append(1)

        eager_source = torch.randn(3, 128, device=device)
        eager_destination = torch.empty_like(eager_source)
        sys.setprofile(observe_eager)
        try:
            invoke_cute(registration.key, eager_source, eager_destination)
        finally:
            sys.setprofile(previous_profile)
        self.assertTrue(eager_checks)
        self.assertEqual(eager_destination, eager_source * 2 + 64)
        self.assertEqual(len(compilations), 1)
        del eager_source, eager_destination
        registration.close()
        self.assertIsNone(ordinary._owned_executor)
        gc.collect()
        self.assertIsNone(executor_ref())
        del model.weight
        for result, expected in held:
            self.assertEqual(result, expected)
        self.assertEqual(len({result[0].data_ptr() for result, _ in held}), len(held))
        del result, expected
        held.clear()
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertEqual((len(source_storages), len(destination_storages), len(native_storages)), (3, 3, 4))
        self.assertTrue(all(storage.expired() for storage in
                            (*weight_storages, *input_storages, *source_storages, *destination_storages,
                             *native_storages, *normalized_storages)))
        print("MIXED_FRONTEND_POLICY_RESULT=" + json.dumps({
            "frontend": frontend, "reader_calls": reader_calls, "same_projection_across_local_misses": True,
            "reader_outputs_reach_native_preparation": True,
            "fast": fast, "ordinary_batches": ordinary_batches, "native_hit_batches": native_batches,
            "updates": updates, "boxed_facts": boxed_facts, "native_copies": replay_copies,
            "compiler_recorded_parameter_normalization": True,
            "replaced_and_final_parameter_storage_expired": True,
            "ordinary_compilations": len(compilations), "cold_preparations": cold_records,
            "single_original_artifact": len(artifacts) == 1, "one_ordinary_call_per_miss": True,
            "exact_cold_return_tuple": True, "public_ordinary_output_tensor_identity": True,
            "same_dispatcher_after_miss": True, "same_compilation_fresh_signatures": True,
            "policy_expired_before_hit_and_local_miss": True, "artifact_retains_miss_owner": True,
            "public_hit_checked_frames": [], "ordinary_borrow_protected": True,
            "input_and_temporary_storage_expired": True, "held_outputs_after_close": True,
            "output_storage_expired_after_release": True, "close_restores_ordinary_call": True,
            "automatic_public_policy": True,
            "owned_invocations": owned_records, "owned_executor_reused_across_local_miss": True,
            "first_audited_launch_once": True, "warm_owned_state_and_dependency_checks": 0,
            "eager_hop_keeps_resolution_audit": len(eager_checks), "executor_released_after_close": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestMixedFrontendIntegration, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
