from dataclasses import replace
import gc
import pickle
import re
import sys
from types import SimpleNamespace
from unittest import mock
import weakref

from automatic_fx_envelope_fixture import CompilerFixture
from compiler_cute_handoff.descriptor import emit_descriptors
from compiler_cute_handoff.envelope import bind_envelope, emit_envelope, GeneratedCall, Release
from compiler_cute_handoff.invocation import InvocationEntry
from compiler_cute_handoff.program import MixedHostProgram, ProgramDeclined
from cute_dispatch.entry import OrdinaryEntry
from fx_adapter import extraction
from fx_adapter.contract import AllocateEvent, CuTeInvokeEvent, FXTraceDeclined, InvokeEvent, NormalizeEvent
from fx_adapter.extraction import trace_generated_fx, trace_mixed_fx
from fx_adapter.invocation import invoke
from fx_adapter.lowering import lower_fx, lower_mixed_fx
from selected_kernel import SelectedKernel
import sympy
import torch
from torch._guards import tracing, TracingContext
from torch._inductor import config
from torch._inductor.codegen.wrapper import (
    AllocateLine, CuTeCallLine, EnterDeviceContextManagerLine, ExitDeviceContextManagerLine,
    FreeLine, InputAlignmentLine, KernelCallLine,
)
from torch._inductor.runtime.cudagraph_arg_mapping import (
    bind_launcher_arguments, BufferSource, ExpressionSource, InputSource,
    IntExpr, KernelArgument, KernelCallRecord, pointwise_product,
)
from torch._inductor.runtime.static_triton_launcher import StaticallyLaunchedCudaKernel
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch._inductor.utils import IndentedBuffer
from torch._inductor.virtualized import V
from torch._subclasses.fake_tensor import FakeTensor, FakeTensorMode
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def selected_kernels(test, records):
    """Real launcher checks with synthetic loaded handles and a stand-in driver."""
    kernels, selections = {}, {}
    for call in records.generated_calls:
        if call.kernel_global in kernels:
            continue
        formals = tuple(KernelArgument(row.formal, row.source_arg_index, row.triton_type, row.call_arg_index, None)
                        for row in call.arguments)
        names = list(call.formals)
        mapping = bind_launcher_arguments(formals, names, names, names)
        module = StaticallyLaunchedCudaKernel.__new__(StaticallyLaunchedCudaKernel)
        module.function, module.module = 23 + call.occurrence, 17 + call.occurrence
        module.functions, module.modules = {}, {}
        module.device_agnostic, module._graph_borrows = False, 0
        module.arg_tys = "OOi"
        module.C_impl = SimpleNamespace(_unload_kernel=mock.Mock())
        test.addCleanup(module.close)
        namespace = {"runner": module.run}
        exec("def launcher(*args, stream):\n    raise AssertionError('CPU fixture must not launch')\n", namespace)
        launcher = namespace["launcher"]
        launcher._cudagraph_arg_info = mapping
        launcher._cudagraph_grid_recipe = (
            IntExpr("ceildiv", args=(IntExpr("formal", "xnumel"), IntExpr("constant", 128))),
            IntExpr("constant", 1), IntExpr("constant", 1),
        )
        launcher._is_static = True
        launcher.config = SimpleNamespace(pre_hook=None, ir_override=None)
        kernel = CachingAutotuner.__new__(CachingAutotuner)
        kernel.launchers, kernel._cached_launcher = [launcher], launcher
        kernel._cache_eligible, kernel._plugins = True, ()
        kernel.inductor_meta = {"grid_type": "Grid1D", "cudagraph_parameter_provenance": {
            "in_ptr0": (0, False, 16), "out_ptr0": (1, True, 16),
        }}
        kernels[call.kernel_global] = kernel
        selections[call.kernel_global] = SelectedKernel.from_warmed(kernel)
    return kernels, selections


def emitted_fixture(test, *, dynamic=True, extra_integer=False, return_prefix=False, repeated=False, fault=None):
    # The typed IR and CuTe emission are real; the surrounding source is a bounded CPU fixture.
    fixture = CompilerFixture(test, dynamic=dynamic, extra_integer=extra_integer, return_prefix=return_prefix)
    if repeated:
        fixture.output_call.kernel_name = fixture.prefix_call.kernel_name
    records = fixture.collect()
    kernels, selections = selected_kernels(test, records)
    replacements = {str(value): name for name, value in fixture.graph.graph_inputs.items()
                    if isinstance(value, sympy.Symbol)}

    def render(value):
        text = str(value)
        for symbol, name in replacements.items():
            text = re.sub(r"\b" + re.escape(symbol) + r"\b", name, text)
        return text

    code = IndentedBuffer()
    code.writeline("import torch")
    code.splice(fixture.wrapper.header)
    code.writeline("def call(box):")
    with code.indent(), V.set_graph_handler(fixture.graph):
        code.writeline(", ".join(fixture.graph.graph_input_names) + ", = box")
        code.writeline("box.clear()")
        if fault == "guard":
            code.writeline("if rows < 4:")
            with code.indent():
                code.writeline("rows = rows + 0")
        for line in fixture.wrapper.lines:
            if type(line) is EnterDeviceContextManagerLine:
                code.writeline(f"with torch.cuda._DeviceGuard({line.device_idx}):")
                code.do_indent()
                code.writeline(f"torch.cuda.set_device({line.device_idx})")
            elif type(line) is ExitDeviceContextManagerLine:
                code.do_unindent()
            elif type(line) is AllocateLine:
                if fault == "allocation" and line.node is fixture.destination:
                    code.writeline("destination = prefix")
                else:
                    code.writeline(f"{line.node.get_name()} = empty_strided_cuda("
                        f"{render(tuple(line.node.get_size()))}, {render(tuple(line.node.get_stride()))}, torch.float32)")
            elif type(line) is KernelCallLine:
                if fault == "call" and line is fixture.prefix_call:
                    continue
                args = ", ".join(render(arg) for arg in line.call_args)
                if fault == "boxed" and line is fixture.output_call:
                    args = args.replace("rows", "other")
                if fault == "flow" and line is fixture.output_call:
                    args = args.replace("prefix", "source")
                code.writeline(f"{line.kernel_name}.run({args}, stream=get_raw_stream(0))")
                if fault == "late_copy" and line is fixture.prefix_call:
                    code.writeline("source = copy_if_misaligned(source)")
            elif type(line) is InputAlignmentLine:
                if fault not in ("copy", "late_copy"):
                    line.codegen(code)
            elif type(line) is CuTeCallLine:
                if fault == "cute":
                    continue
                if fault == "swap":
                    code.writeline(f"{line.entry_global}.invoke(destination, prefix)")
                elif fault == "scalar":
                    code.writeline(f"{line.entry_global}.invoke(rows, destination)")
                elif fault == "global":
                    code.writeline("unregistered_entry.invoke(prefix, destination)")
                else:
                    line.codegen(code)
            elif type(line) is FreeLine:
                code.writeline(f"del {line.node.get_name()}")
            else:
                raise AssertionError(f"Unexpected fixture line {type(line)}")
        outputs = [node.get_name() for node in fixture.graph.graph_outputs]
        if fault == "missing_output":
            outputs = outputs[:-1]
        elif fault == "output_order":
            outputs.reverse()
        elif fault == "duplicate_output":
            outputs = [outputs[0], outputs[0]]
        code.writeline("return (" + ", ".join(outputs) + ("," if outputs else "") + ")")
    emit_descriptors(code, "call", records.cute)
    emit_envelope(code, "call", records)
    text = code.getvalue()
    exec(compile(text, "<mixed-fx-compiler-fixture>", "exec"), kernels)
    function = kernels["call"]
    examples = [13 if kind == "integer" else torch.empty((3,), device="meta", dtype=torch.int64)
                for kind in records.inputs.kinds]
    return fixture, function, bind_envelope(function), examples, selections, text


@instantiate_parametrized_tests
class TestMixedFXReader(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.enterContext(mock.patch.object(torch.cuda, "is_available", return_value=False))
        self.assertFalse(torch.cuda.is_initialized())
        self.cuda_calls = [self.enterContext(mock.patch.object(owner, name,
            side_effect=AssertionError("CPU FX reader must not initialize CUDA")))
            for owner, name in ((torch.cuda, "init"), (torch.cuda, "_lazy_init"), (torch._C, "_cuda_init"))]
        self.addCleanup(self.check_no_cuda)

    def check_no_cuda(self):
        for function in self.cuda_calls:
            function.assert_not_called()
        self.assertFalse(torch.cuda.is_initialized())

    @parametrize("dynamic", (False, True))
    @parametrize("parameter", (False, True))
    def test_complete_real_fx_events_and_actual_outputs(self, dynamic, parameter):
        fixture, function, checked, examples, selections, text = emitted_fixture(self, dynamic=dynamic, return_prefix=True)
        if parameter:
            examples[fixture.source_index] = torch.nn.Parameter(torch.empty((5,), device="meta"), requires_grad=False)
        original_box = tuple(examples)
        entered = []
        codes = {InvocationEntry.invoke.__code__, OrdinaryEntry.run.__code__, OrdinaryEntry._invoke_owned.__code__}

        def observe(frame, event, arg):
            if event == "call" and frame.f_code in codes:
                entered.append(frame.f_code)

        old_profile = sys.getprofile()
        sys.setprofile(observe)
        try:
            traced = trace_mixed_fx(checked, examples, selections)
        finally:
            sys.setprofile(old_profile)
        self.assertEqual(entered, [])
        self.assertIsNone(fixture.owner.selected)
        self.assertIn(f"{checked.cute.calls[0].entry_global}.invoke(prefix, destination)", text)
        self.assertEqual(len(examples), len(original_box))
        for before, after in zip(original_box, examples):
            self.assertIs(before, after)
        value = traced.placeholders[fixture.source_index]
        self.assertIs(type(value), FakeTensor)
        self.assertEqual(value.dtype, torch.float32)
        self.assertEqual(value.size(1), 128)
        self.assertIs(traced.contract, checked.inputs)
        self.assertIs(traced.compiler_binding, checked)
        self.assertEqual([type(event) for event in traced.events],
            [NormalizeEvent, AllocateEvent, InvokeEvent, AllocateEvent, InvokeEvent, CuTeInvokeEvent])
        allocated = [event.tensor for event in traced.events if type(event) is AllocateEvent]
        cute = traced.events[-1]
        self.assertIs(cute.operands[0], allocated[0])
        self.assertIs(cute.operands[1], allocated[1])
        self.assertEqual(len(traced.outputs), 2)
        self.assertIs(traced.outputs[0], allocated[1])
        self.assertIs(traced.outputs[1], allocated[0])
        self.assertEqual(sum(node.op == "call_function" and node.target is invoke
                             for node in traced.graph_module.graph.nodes), 3)
        bound = lower_mixed_fx(checked, traced)
        self.assertIs(bound.binding, checked)
        self.assertIs(type(bound.program), MixedHostProgram)
        self.assertEqual(bound.buffer_sources, ((BufferSource("prefix"), BufferSource("trace_0")),
                                               (BufferSource("destination"), BufferSource("trace_1"))))
        self.assertEqual(tuple(row.source for row in bound.program.outputs), (BufferSource("trace_1"), BufferSource("trace_0")))
        self.assertEqual([type(event).__name__ for event in bound.program.events],
            ["AlignmentCopy", "OwnedBuffer", "KernelCallRecord", "OwnedBuffer", "KernelCallRecord", "CuTeCall", "Release"])
        calls = [event for event in bound.program.events if type(event) is KernelCallRecord]
        projected = [event.record for event in bound.records.events if type(event) is GeneratedCall]
        self.assertEqual((len(calls), len(projected)), (2, 2))
        for actual, stored in zip(calls, projected):
            self.assertIs(actual, stored)
        if dynamic:
            self.assertEqual(calls[0].arguments[-1].source,
                ExpressionSource(pointwise_product((IntExpr("boxed", 0), 128))))
        self.assertEqual(bound.program.events[-1], Release(InputSource(fixture.source_index)))
        bound.check()
        self.assertIs(checked.function(), function)

    def test_repeated_global_keeps_both_ordered_occurrences(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self, repeated=True)
        self.assertEqual(tuple(selections), ("prefix_kernel",))
        traced = trace_mixed_fx(checked, examples, selections)
        bound = lower_mixed_fx(checked, traced)
        calls = bound.records.generated_calls
        self.assertEqual(len(calls), 2)
        self.assertEqual(tuple((call.occurrence, call.kernel_global) for call in calls),
                         ((0, "prefix_kernel"), (1, "prefix_kernel")))
        self.assertEqual(calls[0].arguments[0].source, InputSource(1))
        self.assertEqual(calls[0].arguments[1].source, calls[1].arguments[0].source)
        self.assertNotEqual(calls[0].arguments[1].source, calls[1].arguments[1].source)
        self.assertIs(checked.function(), function)

    def test_end_releases_extend_original_lifetime(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        traced = trace_mixed_fx(checked, examples, selections)
        bound = lower_mixed_fx(checked, traced)
        self.assertEqual(tuple(event for event in bound.program.events if type(event) is Release),
                         (Release(InputSource(1)), Release(BufferSource("trace_0"))))
        self.assertTrue(all(type(event) is Release for event in bound.program.events[-2:]))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("call", "copy", "late_copy", "allocation", "flow", "cute", "swap", "boxed"))
    def test_actual_wrapper_changes_decline_without_record_fallback(self, fault):
        _, function, checked, examples, selections, _ = emitted_fixture(self, extra_integer=True, fault=fault)
        with self.assertRaises((FXTraceDeclined, ProgramDeclined)):
            lower_mixed_fx(checked, trace_mixed_fx(checked, examples, selections))
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("missing_output", "output_order", "duplicate_output"))
    def test_complete_returned_output_projection_is_required(self, fault):
        _, function, checked, examples, selections, _ = emitted_fixture(self, return_prefix=True, fault=fault)
        traced = trace_mixed_fx(checked, examples, selections)
        with self.assertRaises(ProgramDeclined):
            lower_mixed_fx(checked, traced)
        self.assertIs(checked.function(), function)

    def test_empty_actual_return_is_not_filled_from_records(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self, fault="missing_output")
        traced = trace_mixed_fx(checked, examples, selections)
        self.assertEqual(traced.outputs, ())
        with self.assertRaises(ProgramDeclined):
            lower_mixed_fx(checked, traced)
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("scalar", "global"))
    def test_unknown_cute_operand_or_entry_is_not_executed(self, fault):
        fixture, function, checked, examples, selections, _ = emitted_fixture(self, fault=fault)
        with self.assertRaises(FXTraceDeclined):
            trace_mixed_fx(checked, examples, selections)
        self.assertIsNone(fixture.owner.selected)
        self.assertIs(checked.function(), function)

    def test_boxed_equal_hints_remain_distinct(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self, extra_integer=True)
        traced = trace_mixed_fx(checked, examples, selections)
        other, rows = traced.placeholders[:2]
        self.assertNotEqual(other.node.expr, rows.node.expr)
        bound = lower_mixed_fx(checked, traced)
        self.assertEqual(bound.program.outputs[0].size, (IntExpr("boxed", 1), 128))
        self.assertEqual(bound.records.generated_calls[0].arguments[-1].source,
            ExpressionSource(pointwise_product((IntExpr("boxed", 1), 128))))
        self.assertIs(checked.function(), function)

    def test_new_local_guard_cannot_become_outer_authority(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self, fault="guard")
        traced = trace_mixed_fx(checked, examples, selections)
        self.assertTrue(traced.shape_env.guards)
        with self.assertRaisesRegex(FXTraceDeclined, "Additional local guards"):
            lower_mixed_fx(checked, traced)
        self.assertIs(checked.function(), function)

    def test_parameter_allowance_is_only_compiler_bound(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        examples[1] = torch.nn.Parameter(torch.empty((1,), device="meta"), requires_grad=False)
        with self.assertRaisesRegex(FXTraceDeclined, "exact boxed slots"):
            trace_generated_fx(function, checked.inputs, examples, selections)
        traced = trace_mixed_fx(checked, examples, selections)
        self.assertIs(type(traced.placeholders[1]), FakeTensor)
        with self.assertRaisesRegex(FXTraceDeclined, "checked compiler binding"):
            lower_fx(traced)

    def test_arbitrary_tensor_subclass_is_not_admitted(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)

        class ForeignTensor(torch.Tensor):
            pass

        examples[1] = torch.Tensor._make_subclass(ForeignTensor, examples[1], False)
        with self.assertRaisesRegex(FXTraceDeclined, "exact boxed slots"):
            trace_mixed_fx(checked, examples, selections)
        self.assertIs(checked.function(), function)

    @parametrize("fault", ("code", "kernel", "entry"))
    def test_stale_original_authority_declines(self, fault):
        fixture, function, checked, examples, selections, _ = emitted_fixture(self)
        if fault == "code":
            function.__code__ = (lambda box: ()).__code__
        elif fault == "kernel":
            function.__globals__["prefix_kernel"] = object()
        else:
            fixture.entry.close()
        with self.assertRaises(FXTraceDeclined):
            trace_mixed_fx(checked, examples, selections)

    @parametrize("fault", ("kernel", "arguments", "grid", "writes"))
    def test_selected_mapping_and_owner_are_original(self, fault):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        selection = selections["prefix_kernel"]
        if fault == "kernel":
            changed = replace(selection, identity=(object(), *selection.identity[1:]))
        elif fault == "arguments":
            changed = replace(selection, arguments=tuple(list(selection.arguments)))
        elif fault == "grid":
            changed = replace(selection, grid_recipe=tuple(list(selection.grid_recipe)))
        else:
            changed = replace(selection, pointer_writes=(("in_ptr0", True), ("out_ptr0", True)))
        selections["prefix_kernel"] = changed
        with self.assertRaisesRegex(FXTraceDeclined, "original selected"):
            trace_mixed_fx(checked, examples, selections)
        self.assertIs(checked.function(), function)

    def test_mutation_during_make_fx_is_rechecked(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        make_fx = extraction.make_fx

        def changed(*args, **kwargs):
            run = make_fx(*args, **kwargs)

            def call(*values):
                result = run(*values)
                function.__globals__["prefix_kernel"] = object()
                return result

            return call

        with mock.patch.object(extraction, "make_fx", changed), self.assertRaises(FXTraceDeclined):
            trace_mixed_fx(checked, examples, selections)

    def test_reader_error_preserves_exception_without_fallback(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        error = ValueError("actual FX tracing failure")
        with mock.patch.object(extraction, "make_fx", side_effect=error), self.assertRaises(ValueError) as raised:
            trace_mixed_fx(checked, examples, selections)
        self.assertIs(raised.exception, error)
        self.assertIs(checked.function(), function)

    def test_compiler_binding_cannot_be_substituted(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        traced = trace_mixed_fx(checked, examples, selections)
        with self.assertRaises(FXTraceDeclined):
            lower_mixed_fx(None, traced)
        with self.assertRaises(FXTraceDeclined):
            lower_mixed_fx(checked, replace(traced, compiler_binding=None))
        self.assertIs(checked.function(), function)

    @parametrize("ambient", ("fake", "tracing"))
    def test_mixed_reader_preserves_ambient_restrictions(self, ambient):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        mode = FakeTensorMode()
        context = mode if ambient == "fake" else tracing(TracingContext(mode))
        with context, self.assertRaisesRegex(FXTraceDeclined, "ambient"):
            trace_mixed_fx(checked, examples, selections)
        self.assertIs(checked.function(), function)

    def test_bound_program_retains_no_examples_or_outer_fx_trace(self):
        _, function, checked, examples, selections, _ = emitted_fixture(self)
        value = weakref.ref(examples[1])
        traced = trace_mixed_fx(checked, examples, selections)
        trace_ref, graph_ref = weakref.ref(traced), weakref.ref(traced.graph_module)
        bound = lower_mixed_fx(checked, traced)
        self.assertEqual(pickle.loads(pickle.dumps(bound.program)), bound.program)
        del examples, traced
        gc.collect()
        self.assertIsNone(value())
        self.assertIsNone(trace_ref())
        self.assertIsNone(graph_ref())
        bound.check()
        self.assertIs(checked.function(), function)


if __name__ == "__main__":
    run_tests()
