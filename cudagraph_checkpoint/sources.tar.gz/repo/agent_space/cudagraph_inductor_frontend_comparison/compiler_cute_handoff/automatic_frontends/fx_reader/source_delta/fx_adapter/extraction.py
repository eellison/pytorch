"""Extract generated host operations in a fresh local symbolic FX context."""

from dataclasses import dataclass, field
from dis import get_instructions
from inspect import CO_VARARGS, CO_VARKEYWORDS
from types import FunctionType, SimpleNamespace

import sympy
import torch
from selected_kernel import SelectedKernel
from torch._dynamo.source import LocalSource
from torch._guards import TracingContext, detect_fake_mode
from torch._inductor.runtime.cudagraph_arg_mapping import IntExpr
from torch._subclasses.fake_tensor import FakeTensor, FakeTensorMode
from torch.fx.experimental import _config as fx_config
from torch.fx.experimental.proxy_tensor import get_proxy_mode, make_fx
from torch.fx.experimental.symbolic_shapes import DimDynamic, ShapeEnv
from torch.utils._sympy.numbers import int_oo

from fx_adapter import invocation
from fx_adapter.contract import (
    AllocateEvent, CuTeInvokeEvent, FXTrace, FXTraceDeclined, HostEvent, InputContract, IntegerRange,
    InvokeEvent, LayoutEvent, NormalizeEvent, ReinterpretEvent, TensorInput,
)


def _materialize(expression, integers):
    if type(expression) is int:
        return expression
    if type(expression) is not IntExpr or type(expression.args) is not tuple:
        raise FXTraceDeclined("Expected an exact compiler layout expression")
    if expression.op == "constant" and type(expression.value) is int and not expression.args:
        return expression.value
    if expression.op == "boxed" and type(expression.value) is int and not expression.args:
        if expression.value not in integers:
            raise FXTraceDeclined("Layout expression references an undeclared boxed integer")
        return integers[expression.value]
    if expression.value is None and len(expression.args) == 2:
        left, right = (_materialize(arg, integers) for arg in expression.args)
        if expression.op == "multiply":
            return left * right
        if expression.op == "ceildiv" and type(right) is int and right > 0:
            return -((-left) // right)
    raise FXTraceDeclined("Unsupported compiler layout expression")


class _DeviceGuard:
    def __init__(self, state, index):
        self.state, self.index = state, index

    def __enter__(self):
        self.state.check_device(self.index)
        if self.state.in_device:
            raise FXTraceDeclined("Nested device scopes are outside the host contract")
        self.state.in_device = True

    def __exit__(self, *unused):
        self.state.in_device = False


@dataclass
class _Extraction:
    mode: FakeTensorMode
    device: torch.device
    events: list[HostEvent] = field(default_factory=list)
    placeholders: tuple[object, ...] | None = None
    outputs: tuple[torch.Tensor, ...] | None = None
    in_device: bool = False

    def check_device(self, index):
        if type(index) is not int or index != self.device.index:
            raise FXTraceDeclined("Device dispatch differs from the supplied compiler contract")

    def raw_stream(self, index):
        self.check_device(index)
        if not self.in_device:
            raise FXTraceDeclined("Stream lookup outside the recorded device scope")
        return self

    def check_tensor(self, tensor):
        if type(tensor) is not FakeTensor or tensor.fake_mode is not self.mode:
            raise FXTraceDeclined("Host operation escaped the fresh local FakeTensorMode")

    def dimensions(self, values):
        if type(values) not in (tuple, torch.Size):
            raise FXTraceDeclined("Expected a tuple of compiler layout dimensions")
        for value in values:
            if type(value) is int:
                continue
            if type(value) is not torch.SymInt or value.node.shape_env is not self.mode.shape_env:
                raise FXTraceDeclined("Layout dimension has no local integer source")
        return tuple(values)

    def allocate(self, size, stride, dtype):
        if not self.in_device or type(dtype) is not torch.dtype:
            raise FXTraceDeclined("Expected an allocation on the bound CUDA device")
        size, stride = self.dimensions(size), self.dimensions(stride)
        tensor = torch.ops.aten.empty_strided.default(size, stride, dtype=dtype, device=self.device)
        self.events.append(AllocateEvent(tensor, size, stride, dtype, self.device))
        return tensor

    def reinterpret(self, tensor, size, stride, offset):
        self.check_tensor(tensor)
        if type(offset) is not int or offset != 0:
            raise FXTraceDeclined("Only literal zero-offset reinterpretation is supported")
        size, stride = self.dimensions(size), self.dimensions(stride)
        result = torch.ops.aten.as_strided.default(tensor, size, stride, offset)
        self.events.append(ReinterpretEvent(tensor, result, size, stride, offset))
        return result

    def assert_layout(self, tensor, size, stride, label=None):
        self.check_tensor(tensor)
        if label is not None and type(label) is not str:
            raise FXTraceDeclined("Expected a literal diagnostic assertion label")
        size, stride = self.dimensions(size), self.dimensions(stride)
        self.events.append(LayoutEvent(tensor, size, stride, label))
        invocation.assert_layout(tensor, size, stride, label)
        return True

    def assert_layout_grouped(self, items, sizes, strides, label=None):
        if any(type(values) not in (tuple, list) for values in (items, sizes, strides)):
            raise FXTraceDeclined("Expected tuple or list containers for grouped layout assertions")
        if len(items) != len(sizes) or len(items) != len(strides):
            raise FXTraceDeclined("Expected equal numbers of items, sizes, and strides")
        for tensor, size, stride in zip(items, sizes, strides):
            self.assert_layout(tensor, size, stride, label)
        return True

    def normalize(self, tensor):
        self.check_tensor(tensor)
        self.events.append(NormalizeEvent(tensor))
        invocation.normalize(tensor)
        return tensor

    def launch(self, name, arguments, stream, kwargs):
        if not self.in_device or stream is not self or kwargs:
            raise FXTraceDeclined("Unexpected launch stream or keyword arguments")
        for value in arguments:
            if type(value) is FakeTensor:
                self.check_tensor(value)
            elif type(value) in (int, torch.SymInt):
                self.dimensions((value,))
            else:
                raise FXTraceDeclined("Unsupported generated invocation argument")
        self.events.append(InvokeEvent(name, arguments))
        invocation.invoke(name, arguments)


class _Kernel:
    def __init__(self, state, name):
        self.state, self.name = state, name

    def run(self, *args, stream, **kwargs):
        self.state.launch(self.name, args, stream, kwargs)


class _CuTeEntry:
    def __init__(self, state, name):
        self.state, self.name = state, name

    def invoke(self, source, destination):
        if not self.state.in_device:
            raise FXTraceDeclined("CuTe invocation is outside the recorded device scope")
        self.state.check_tensor(source)
        self.state.check_tensor(destination)
        self.state.events.append(CuTeInvokeEvent(self.name, (source, destination)))
        invocation.invoke(self.name, (source, destination))


def _check_mixed(checked, selections):
    from compiler_cute_handoff.envelope import BoundMixedEnvelope, EnvelopeDeclined

    if type(checked) is not BoundMixedEnvelope:
        raise FXTraceDeclined("Expected the original checked mixed compiler envelope")
    try:
        checked.check()
    except EnvelopeDeclined as error:
        raise FXTraceDeclined("Original mixed compiler authority is unavailable") from error
    wrapper = checked.function()
    if wrapper is None:
        raise FXTraceDeclined("Original mixed wrapper expired")
    names = tuple(call.kernel_global for call in checked.records.generated_calls)
    if (type(selections) is not dict or set(selections) != set(names)
            or any(type(value) is not SelectedKernel for value in selections.values())):
        raise FXTraceDeclined("Mixed tracing requires one exact selection per generated global")
    for name, selected in selections.items():
        try:
            current = SelectedKernel.from_warmed(wrapper.__globals__[name])
        except ValueError as error:
            raise FXTraceDeclined("Generated selection is no longer available") from error
        if (type(selected.identity) is not tuple or len(selected.identity) != len(current.identity)
                or any(left is not right for left, right in zip(selected.identity, current.identity))
                or selected.arguments is not current.arguments or selected.grid_recipe is not current.grid_recipe
                or selected.pointer_writes != current.pointer_writes or selected.arg_tys != current.arg_tys):
            raise FXTraceDeclined("Mixed tracing changed its original selected generated owner")
    try:
        checked.check()
    except EnvelopeDeclined as error:
        raise FXTraceDeclined("Original mixed compiler authority changed during selection") from error
    return wrapper


def trace_mixed_fx(checked, example_inputs, selections):
    """Trace the complete checked wrapper without entering its owned CuTe host."""
    wrapper = _check_mixed(checked, selections)
    result = _trace_generated_fx(wrapper, checked.inputs, example_inputs, selections, checked)
    _check_mixed(checked, selections)
    return result


def trace_generated_fx(wrapper, contract, example_inputs, selections):
    """Record a warmed generated host under explicit compiler input authority.

    Integer examples supply hints only. Tensor layouts and their relationships come
    from the contract. Standard FakeTensor CUDA setup occurs before make_fx; the
    host operations record live events with their actual symbolic arguments. FX
    is diagnostic; lowering consumes events, input identities and the complete
    local ShapeEnv. This result does not authorize replay or guard reuse.
    """
    return _trace_generated_fx(wrapper, contract, example_inputs, selections)


def _trace_generated_fx(wrapper, contract, example_inputs, selections, compiler=None):
    if (TracingContext.try_get() is not None or get_proxy_mode() is not None
            or detect_fake_mode(example_inputs) is not None):
        raise FXTraceDeclined("Local extraction cannot borrow an ambient tracing/fake/proxy context")
    if (type(wrapper) is not FunctionType or wrapper.__closure__ or wrapper.__defaults__
            or wrapper.__kwdefaults__ or wrapper.__code__.co_argcount != 1
            or wrapper.__code__.co_kwonlyargcount
            or wrapper.__code__.co_flags & (CO_VARARGS | CO_VARKEYWORDS)):
        raise FXTraceDeclined("Expected an exact one-box generated function")
    if (type(contract) is not InputContract or type(contract.kinds) is not tuple
            or not contract.kinds or any(kind not in ("integer", "tensor") for kind in contract.kinds)
            or type(contract.device_index) is not int or contract.device_index < 0
            or type(example_inputs) not in (list, tuple) or len(example_inputs) != len(contract.kinds)
            or type(contract.tensor_inputs) is not tuple or type(contract.integer_ranges) is not tuple):
        raise FXTraceDeclined("Expected a complete boxed compiler input contract")
    tensor_indices = {index for index, kind in enumerate(contract.kinds) if kind == "tensor"}
    integer_indices = {index for index, kind in enumerate(contract.kinds) if kind == "integer"}
    if (not tensor_indices
            or any(type(row) is not TensorInput or type(row.index) is not int
                   or type(row.dtype) is not torch.dtype or type(row.size) is not tuple
                   or type(row.stride) is not tuple or len(row.size) != len(row.stride)
                   for row in contract.tensor_inputs)
            or {row.index for row in contract.tensor_inputs} != tensor_indices
            or len(contract.tensor_inputs) != len(tensor_indices)
            or any(type(row) is not IntegerRange or type(row.index) is not int
                   or type(row.lower) is not int or (row.upper is not None and (
                       type(row.upper) is not int or row.upper < row.lower))
                   for row in contract.integer_ranges)
            or {row.index for row in contract.integer_ranges} != integer_indices
            or len(contract.integer_ranges) != len(integer_indices)
            or any(type(example_inputs[index]) not in ((torch.Tensor, torch.nn.Parameter) if compiler is not None
                                                      else (torch.Tensor,)) for index in tensor_indices)):
        raise FXTraceDeclined("Tensor layouts and integer ranges must cover their exact boxed slots")
    if (type(selections) is not dict or not selections or any(
        type(name) is not str or not name.isidentifier() or type(selected) is not SelectedKernel
        for name, selected in selections.items()
    )):
        raise FXTraceDeclined("Expected exact selected-kernel metadata by generated global name")
    if torch.cuda.is_available() and not torch.cuda.is_initialized():
        raise FXTraceDeclined("Ordinary CUDA execution must warm the device before extraction")

    environment = ShapeEnv(duck_shape=False, specialize_zero_one=False)
    integers, symbol_sources = {}, {}
    for row in contract.integer_ranges:
        hint = example_inputs[row.index]
        if type(hint) is not int or hint < row.lower or (row.upper is not None and hint > row.upper):
            raise FXTraceDeclined("Integer hint does not satisfy its inherited compiler domain")
        source = LocalSource(f"boxed_{row.index}")
        symbol = environment.create_symbol(
            hint, source, dynamic_dim=DimDynamic.DYNAMIC, positive=None,
            do_not_specialize_zero_one=True,
        )
        if type(symbol) is not sympy.Symbol:
            raise FXTraceDeclined("A declared boxed integer lost its symbolic source")
        environment.constrain_symbol_range(symbol, row.lower, int_oo if row.upper is None else row.upper)
        integers[row.index] = environment.create_symintnode(symbol, hint=hint, source=source)
        symbol_sources[symbol] = IntExpr("boxed", row.index)

    mode = FakeTensorMode(
        shape_env=environment, allow_fallback_kernels=False,
        allow_non_fake_inputs=False, static_shapes=False,
    )
    device = torch.device("cuda", contract.device_index)
    flat_inputs = [integers.get(index) for index in range(len(contract.kinds))]
    with mode:
        for row in contract.tensor_inputs:
            flat_inputs[row.index] = torch.ops.aten.empty_strided.default(
                tuple(_materialize(value, integers) for value in row.size),
                tuple(_materialize(value, integers) for value in row.stride),
                dtype=row.dtype, device=device,
            )

    state = _Extraction(mode, device)
    cuda = SimpleNamespace(_DeviceGuard=lambda index: _DeviceGuard(state, index), set_device=state.check_device)
    dtype_names = ("float16", "bfloat16", "float32", "float64", "int8", "uint8", "int16", "int32", "int64", "bool")
    namespace = {
        "__builtins__": {},
        "torch": SimpleNamespace(cuda=cuda, **{name: getattr(torch, name) for name in dtype_names}),
        "assert_size_stride": state.assert_layout,
        "assert_size_stride_grouped": state.assert_layout_grouped,
        "copy_if_misaligned": state.normalize,
        "empty_strided_cuda": state.allocate,
        "reinterpret_tensor": state.reinterpret,
        "get_raw_stream": state.raw_stream,
    }
    if namespace.keys() & selections.keys():
        raise FXTraceDeclined("Selected kernel name conflicts with a supported host operation")
    namespace.update({name: _Kernel(state, name) for name in selections})
    if compiler is not None:
        for call in compiler.cute.calls:
            if call.entry_global in namespace:
                raise FXTraceDeclined("CuTe entry name conflicts with another host operation")
            namespace[call.entry_global] = _CuTeEntry(state, call.entry_global)
        if any(op.opname == "LOAD_GLOBAL" and op.argval not in namespace for op in get_instructions(wrapper)):
            raise FXTraceDeclined("Mixed wrapper references an unsupported host global")
    cloned = FunctionType(wrapper.__code__, namespace, wrapper.__name__)

    def run_boxed(*args):
        if state.placeholders is not None:
            raise FXTraceDeclined("A host extraction must execute its wrapper exactly once")
        state.placeholders = args
        box = list(args)
        outputs = cloned(box)
        if box or type(outputs) is not tuple:
            raise FXTraceDeclined("Generated wrapper must consume its input box and return a tuple")
        for output in outputs:
            state.check_tensor(output)
        state.outputs = outputs
        return outputs

    # Diagnostic contiguity queries use safe guard_or fallbacks. Explicit host
    # SymBool branches still retain their ordinary ShapeEnv guards.
    with mode, fx_config.patch(backed_size_oblivious=True):
        graph_module = make_fx(run_boxed, tracing_mode="symbolic", _allow_non_fake_inputs=False)(*flat_inputs)
    if (state.placeholders is None or state.outputs is None
            or len(state.placeholders) != len(contract.kinds) or graph_module.shape_env is not environment):
        raise FXTraceDeclined("Host extraction escaped the explicit local input contract")
    for index in tensor_indices:
        state.check_tensor(state.placeholders[index])
    return FXTrace(
        graph_module, contract, symbol_sources, dict(selections), environment,
        state.placeholders, tuple(state.events), state.outputs, compiler,
    )
