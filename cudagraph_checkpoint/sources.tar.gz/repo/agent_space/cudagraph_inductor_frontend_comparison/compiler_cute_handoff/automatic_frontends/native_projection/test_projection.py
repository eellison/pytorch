from dataclasses import replace
from unittest import mock

import native_projection_link_fixture as link_fixture
from native_projection_program_fixture import reader_program
from compiler_cute_handoff.program import bind_mixed_program
from cute_bridge import preparation
from cute_bridge.lowering import _bind_compiler_program, link_cute_invocation
from host_program import Normalize
import torch
from torch._inductor import config
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, ExpressionSource, IntExpr
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
from user_triton.linking import LinkDeclined


@instantiate_parametrized_tests
class TestNativeReaderProjection(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(torch.no_grad())
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, **kwargs):
        fixture = link_fixture.TestCompilerCuTeLink.fixture(self, **kwargs)
        projection = bind_mixed_program(fixture.checked, reader_program(fixture.checked))
        linked = link_cute_invocation(fixture.checked, fixture.trace, fixture.generated,
            fixture.owner, fixture.effects, compiler_program=projection)
        return fixture, projection, linked

    @parametrize("return_prefix", (False, True))
    @parametrize("destination_read", (False, True))
    def test_native_plan_uses_reader_buffers_and_outputs(self, return_prefix, destination_read):
        fixture, projection, linked = self.fixture(return_prefix=return_prefix, destination_read=destination_read)
        program = linked.program
        self.assertIs(program.outputs, projection.program.outputs)
        self.assertEqual(program.allocations, projection.records.allocations)
        self.assertNotEqual(program.allocations, fixture.checked.records.allocations)
        pointers = tuple(field.source for field in program.calls[-1].bound.fields if field.kind == "pointer")
        self.assertEqual(pointers, (BufferSource("reader_0"), BufferSource("reader_1")))
        context = _bind_compiler_program(program, fixture.providers, fixture.checked, compiler_program=projection)
        self.assertIs(context.binding, fixture.checked)
        self.assertIs(context.compiler_program, projection)
        self.assertEqual(context.destination, BufferSource("reader_1"))
        plan = preparation._validate(program, fixture.providers, fixture.box, compiler=context)
        self.assertEqual(tuple(program.allocations[index] for index in plan.outputs), projection.program.outputs)
        self.assertEqual(plan.calls[-1].grid, (13, 1, 1))

    def test_renaming_preserves_distinct_boxed_origins(self):
        fixture, projection, linked = self.fixture(extra_integer=True)
        scalars = [field.source.expression for field in linked.program.calls[-1].bound.fields
                   if type(field.source) is ExpressionSource]
        self.assertEqual(scalars, [IntExpr("boxed", 1), IntExpr("boxed", 1)])
        self.assertEqual(linked.program.calls[-1].bound.grid[0], IntExpr("boxed", 1))
        self.assertIs(fixture.trace.descriptor, fixture.checked.cute.calls[0])
        self.assertIsNot(fixture.trace.descriptor, projection.records.cute.calls[0])

    def test_projection_is_required_to_reconstruct_reader_program(self):
        fixture, projection, linked = self.fixture()
        with self.assertRaisesRegex(LinkDeclined, "complete compiler projection"):
            _bind_compiler_program(linked.program, fixture.providers, fixture.checked)
        original = link_cute_invocation(fixture.checked, fixture.trace, fixture.generated,
                                       fixture.owner, fixture.effects)
        with self.assertRaisesRegex(LinkDeclined, "complete compiler projection"):
            _bind_compiler_program(original.program, fixture.providers, fixture.checked, compiler_program=projection)

    def test_projection_from_another_compiler_is_rejected(self):
        fixture, _, linked = self.fixture()
        _, other, _ = self.fixture()
        with self.assertRaisesRegex(LinkDeclined, "original compiler binding"):
            _bind_compiler_program(linked.program, fixture.providers, fixture.checked, compiler_program=other)

    @parametrize("field", ("records", "buffer_sources", "program"))
    def test_preparation_rechecks_projection_after_link(self, field):
        fixture, projection, linked = self.fixture()
        context = _bind_compiler_program(linked.program, fixture.providers, fixture.checked,
                                         compiler_program=projection)
        setattr(projection, field, None)
        with self.assertRaisesRegex(LinkDeclined, "Reader projection"):
            context.check()

    @parametrize("fault", ("outputs", "pointer", "grid", "copy"))
    def test_complete_native_program_cannot_be_replaced(self, fault):
        fixture, projection, linked = self.fixture()
        program = linked.program
        if fault == "outputs":
            program = replace(program, outputs=tuple(reversed(program.outputs)))
        elif fault == "copy":
            program = replace(program, copies=(), events=tuple(event for event in program.events
                                                              if type(event) is not Normalize))
        else:
            call = program.calls[-1]
            if fault == "pointer":
                fields = tuple(replace(field, source=BufferSource("reader_0"))
                               if field.kind == "pointer" else field for field in call.bound.fields)
                bound = replace(call.bound, fields=fields)
            else:
                bound = replace(call.bound, grid=(IntExpr("constant", 13), *call.bound.grid[1:]))
            program = replace(program, events=tuple(replace(call, bound=bound) if event is call else event
                                                    for event in program.events))
        with self.assertRaisesRegex(LinkDeclined, "complete compiler projection"):
            _bind_compiler_program(program, fixture.providers, fixture.checked, compiler_program=projection)

    def test_reader_does_not_supply_generated_provenance(self):
        fixture, projection, _ = self.fixture()
        kernel = fixture.generated[0].selection.identity[0]
        formal = fixture.checked.records.generated_calls[0].arguments[1].formal
        provenance = kernel.inductor_meta["cudagraph_parameter_provenance"]
        name, written, alignment = provenance[formal]
        self.assertNotEqual(name, "reader_0")
        provenance[formal] = "reader_0", written, alignment
        with self.assertRaises(LinkDeclined):
            link_cute_invocation(fixture.checked, fixture.trace, fixture.generated,
                                 fixture.owner, fixture.effects, compiler_program=projection)

    def test_public_preparation_forwards_checked_projection_before_capture(self):
        fixture, projection, linked = self.fixture()
        with mock.patch.object(preparation, "_validate", side_effect=RuntimeError("stop before capture")) as validate:
            with self.assertRaisesRegex(RuntimeError, "stop before capture"):
                preparation.prepare_variant(linked.program, fixture.providers, fixture.box,
                    compiler_binding=fixture.checked, compiler_program=projection)
        context = validate.call_args.kwargs["compiler"]
        self.assertIs(context.compiler_program, projection)
        self.assertIs(context.binding, fixture.checked)
        context.check()

    def test_projection_without_original_authority_declines_before_validation(self):
        fixture, projection, linked = self.fixture()
        with mock.patch.object(preparation, "_validate", side_effect=AssertionError("must not validate")):
            with self.assertRaisesRegex(UnsupportedCapture, "original compiler binding"):
                preparation.prepare_variant(linked.program, fixture.providers, fixture.box,
                                             compiler_program=projection)


if __name__ == "__main__":
    run_tests()
