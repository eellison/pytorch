"""Join recorded Python operands to compiler-owned CuTe parameter fields."""

from dataclasses import dataclass

import torch
from fx_adapter.contract import AllocateEvent
from host_program import Allocate, InputAssertion, Normalize
from python_entry import EntryCall
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, bind_grid_recipe, bind_wrapper_arguments, BufferSource, ExpressionSource,
    InputSource, IntegerSource, IntExpr, OwnedBuffer, pointwise_product,
)
from torch._inductor.runtime.cudagraph_boxed_replay import _PhysicalCall, _PhysicalField
from user_triton.contract import Invocation, ReplayProgram
from user_triton.linking import _Expressions, GeneratedProvider, LinkDeclined

from .contract import CuTeInvocation, MixedProgram
from .numeric import lower_numeric, NumericSource, RangeObligation
from .tracing import CuteHostTrace, CuteInvocationTrace, DetachEvent


@dataclass(frozen=True)
class LinkedCuTe:
    program: MixedProgram
    trace: CuteHostTrace | CuteInvocationTrace
    owner: object
    predicate: object
    obligations: tuple[RangeObligation, ...]


class _Operands:
    def __init__(self, trace, artifact, tensors, expressions):
        self.trace = trace
        self.artifact = artifact
        self.tensors = tensors
        self.expressions = expressions
        self.formals = {formal.source_arg_index: formal for formal in artifact.formals}
        self.ranges = {row.index: row for row in trace.input_contract.integer_ranges}
        if len(self.formals) != len(artifact.formals):
            raise LinkDeclined("CuTe compiler formals have duplicate original indices")

    def tensor(self, formal):
        operand = self.artifact.signature.operands[formal.operand_index]
        if (formal.kind != "Tensor" or operand.name != formal.name or operand.tensor is None
                or id(operand.tensor.value) not in self.tensors):
            raise LinkDeclined("CuTe formal has no recorded Python Tensor identity")
        return operand.tensor

    def property(self, formal, name, path):
        tensor = self.tensor(formal)
        if name == "pointer" and path == ():
            return self.tensors[id(tensor.value)]
        if name not in ("shape", "stride") or len(path) != 1:
            raise LinkDeclined("Unsupported CuTe Tensor property path")
        uses = tensor.shape if name == "shape" else tensor.strides
        if type(path[0]) is not int or not 0 <= path[0] < len(uses):
            raise LinkDeclined("CuTe Tensor property path exceeds its original operand")
        return self.expressions(uses[path[0]].value)

    def field(self, source):
        formal = self.formals.get(source.ir_arg_index)
        if (formal is None or source.kind != "tensor_property" or source.formal_name != formal.name
                or source.metadata_path != formal.metadata_path):
            raise LinkDeclined("CuTe field lost its exact original formal")
        leaves = [leaf for leaf in formal.leaves if leaf.path == source.component_path]
        if len(leaves) != 1:
            raise LinkDeclined("CuTe field lacks one compiler-identified aggregate leaf")
        leaf, = leaves
        if (source.llvm_type, source.property, source.property_path) != (
                leaf.llvm_type, leaf.property, leaf.property_path):
            raise LinkDeclined("CuTe field property differs from its compiler leaf")
        return self.property(formal, source.property, source.property_path)

    def numeric(self, source_index, path):
        formal = self.formals.get(source_index)
        if formal is None:
            raise LinkDeclined("CuTe computation has no original formal")
        leaves = [leaf for leaf in formal.leaves if leaf.path == path]
        if len(leaves) != 1 or leaves[0].property == "pointer":
            raise LinkDeclined("CuTe computation is not a recorded integer metadata leaf")
        leaf, = leaves
        value = self.property(formal, leaf.property, leaf.property_path)
        return self.numeric_value(value)

    def numeric_value(self, value):
        if type(value) is int:
            return NumericSource(IntExpr("constant", value), value, value)
        if type(value) is IntExpr and value.op == "boxed" and value.value in self.ranges:
            row = self.ranges[value.value]
            return NumericSource(value, row.lower, row.upper)
        raise LinkDeclined("CuTe metadata expression needs broader per-operation range proofs")


def _lower_cute_call(artifact, site, owner, operands):
    obligations = []
    predicate = None
    fields = []
    for field in site.fields.pointers:
        source = operands.field(field.source)
        if type(source) is not BufferSource:
            raise LinkDeclined("CuTe pointers must name recorded owned buffers")
        fields.append(_PhysicalField(field.parameter, field.byte_offset, "pointer", source))
    for field in site.fields.integers:
        value = operands.field(field.source)
        source = ExpressionSource(value) if type(value) is IntExpr else IntegerSource(value)
        fields.append(_PhysicalField(field.parameter, field.byte_offset, field.dtype, source))
        numeric = operands.numeric_value(value)
        bits = {"i32": 32, "i64": 64}.get(field.dtype)
        if bits is None:
            raise LinkDeclined("CuTe integer field has an unsupported physical width")
        minimum, maximum = -(2 ** (bits - 1)), 2 ** (bits - 1) - 1
        if (numeric.lower is None or numeric.lower < minimum
                or numeric.upper is None or numeric.upper > maximum):
            obligations.append(RangeObligation(numeric.expression, minimum, maximum,
                                              "CuTe physical integer field"))
    grids = {}
    for consumer in artifact.consumers:
        if consumer.site_id == site.site_id and consumer.role == "grid":
            value = lower_numeric(consumer.numeric, operands.numeric)
            if len(value.values) != 1 or type(value.values[0].expression) is not IntExpr:
                raise LinkDeclined("CuTe grid did not lower to one native integer recipe")
            grids[consumer.index] = value.values[0].expression
            obligations.extend(value.obligations)
        elif consumer.site_id is None and consumer.role == "predicate":
            value = lower_numeric(consumer.numeric, operands.numeric)
            if predicate is not None or len(value.values) != 1:
                raise LinkDeclined("CuTe artifact lacks one exact dispatch predicate")
            predicate = value.values[0]
            obligations.extend(value.obligations)
    if set(grids) != {0, 1, 2} or predicate is None:
        raise LinkDeclined("CuTe launch lacks complete grid or dispatch computations")
    bound = _PhysicalCall(tuple(fields), owner, tuple(grids[index] for index in range(3)),
                          tuple(tuple(row) for row in site.fields.padding))
    return bound, predicate, tuple(obligations)


def link_cute(prefix, trace, owner, effects, *, provider_key="user_cute"):
    if type(prefix) is not ReplayProgram or type(trace) is not CuteHostTrace:
        raise LinkDeclined("Expected an independently constructed prefix and its live CuTe trace")
    if (trace.input_layout not in prefix.allocations or type(provider_key) is not str
            or provider_key in {call.provider_key for call in prefix.calls}):
        raise LinkDeclined("CuTe input or provider key lacks a unique prefix binding")
    trace.check()
    owner.check()
    effects.check()
    artifact, site = owner.artifact, owner.site
    signature = artifact.signature
    if (signature.trace is not trace or len(trace.calls) != 1 or signature.call is not trace.calls[0]
            or effects.artifact is not artifact or effects.site is not site):
        raise LinkDeclined("CuTe artifact differs from its original trace or selected effects")
    expressions = _Expressions(trace, {row.boxed_index for row in prefix.integer_inputs})
    tensors = {id(trace.input_tensor): trace.input_layout.source}
    operands = _Operands(trace, artifact, tensors, expressions)
    allocations, events = list(prefix.allocations), list(prefix.events)
    names = {layout.source.name for layout in allocations}
    fresh, obligations = set(), []
    invoked = False
    predicate = None
    for event in trace.events:
        if type(event) is AllocateEvent:
            if event.device != torch.device("cuda", prefix.device_index) or id(event.tensor) in tensors:
                raise LinkDeclined("CuTe allocation changed device or reused a Tensor identity")
            name = f"{provider_key}_buffer_{len(fresh)}"
            if name in names:
                raise LinkDeclined("CuTe allocation identifier conflicts with its prefix")
            layout = OwnedBuffer(BufferSource(name), event.dtype, tuple(expressions(v) for v in event.size),
                                 tuple(expressions(v) for v in event.stride))
            if (len(layout.size) != 2 or layout.stride != (layout.size[1], 1)
                    or pointwise_product(layout.size) is None):
                raise LinkDeclined("CuTe allocation requires a contiguous rank-two descriptor")
            names.add(name)
            tensors[id(event.tensor)] = layout.source
            fresh.add(layout.source)
            allocations.append(layout)
            events.append(Allocate(name, layout.dtype, layout.size, layout.stride))
        elif type(event) is DetachEvent:
            if id(event.source) not in tensors or id(event.result) in tensors:
                raise LinkDeclined("CuTe detach lost its recorded Tensor correspondence")
            tensors[id(event.result)] = tensors[id(event.source)]
        elif type(event) is EntryCall:
            if invoked or event is not signature.call:
                raise LinkDeclined("Expected the one original CuTe entry invocation")
            invoked = True
            bound, predicate, local = _lower_cute_call(artifact, site, owner, operands)
            obligations.extend(local)
            events.append(CuTeInvocation(provider_key, owner, bound, effects))
        else:
            raise LinkDeclined("Unsupported pre-JIT CuTe host event")
    if not invoked or len(trace.outputs) != 1 or tensors.get(id(trace.outputs[0])) not in fresh:
        raise LinkDeclined("CuTe host must return its recorded independent allocation")
    source = tensors[id(trace.outputs[0])]
    output = next(layout for layout in allocations if layout.source == source)
    program = MixedProgram(prefix.device_index, prefix.input_names, prefix.integer_inputs,
                           tuple(allocations), (*prefix.outputs, output), prefix.copies,
                           tuple(events), prefix.input_assertions)
    return LinkedCuTe(program, trace, owner, predicate, tuple(dict.fromkeys(obligations)))


def _check_invocation_sources(checked, trace, generated, owner, effects, provider_key):
    from compiler_cute_handoff.envelope import BoundMixedEnvelope
    from .provider import CuTeKernelOwner, SitePointerEffects

    if (type(checked) is not BoundMixedEnvelope or type(trace) is not CuteInvocationTrace
            or type(generated) is not tuple or not generated
            or any(type(provider) is not GeneratedProvider for provider in generated)
            or type(owner) is not CuTeKernelOwner or type(effects) is not SitePointerEffects
            or type(provider_key) is not str or not provider_key):
        raise LinkDeclined("Expected a checked compiler envelope and its exact selected providers")
    checked.check()
    trace.check()
    owner.check()
    effects.check()
    records = checked.records
    function = checked.function()
    artifact, site = owner.artifact, owner.site
    if (trace.binding is not checked.binding or trace.input_contract is not checked.inputs
            or trace.descriptor is not checked.cute.calls[0]
            or artifact.signature.trace is not trace or artifact.signature.call is not trace.calls[0]
            or effects.artifact is not artifact or effects.site is not site
            or len(generated) != len(records.generated_calls) or not checked.cute.integer_inputs
            or provider_key in {call.kernel_global for call in records.generated_calls}
            or records.cute is not checked.cute):
        raise LinkDeclined("CuTe link mixed compiler, trace, signature or selected-site authorities")
    operands = trace.descriptor.operands
    if (len(operands) != 2 or any(type(row.source) is not BufferSource for row in operands)
            or operands[0].source == operands[1].source
            or len(trace.tensor_sources) != 2
            or any(trace.tensor_sources.get(row.source) is not tensor
                   for row, tensor in zip(operands, trace.operand_tensors))):
        raise LinkDeclined("CuTe operands lost their exact compiler-owned Tensor correspondence")
    keys = {}
    for record, provider in zip(records.generated_calls, generated):
        provider.check()
        selection = provider.selection
        if (record.grid_type != "Grid1D" or type(selection.identity) is not tuple
                or len(selection.identity) != 4 or selection.identity[0] is not function.__globals__.get(record.kernel_global)
                or selection.identity[3] is not provider.module or selection.arguments is not provider.arguments
                or getattr(selection.identity[1], "_expected_positional_count", None) != len(record.arguments)
                or selection.identity[0].inductor_meta.get("grid_type") != record.grid_type
                or record.kernel_global in keys and keys[record.kernel_global] is not provider):
            raise LinkDeclined("Generated occurrence differs from its original selected launcher")
        keys[record.kernel_global] = provider
    if any(type(event) is AlignmentCopy for event in records.events):
        if function.__globals__.get("copy_if_misaligned") is not torch._C._dynamo.guards.copy_if_misaligned:
            raise LinkDeclined("Compiler normalization lost its canonical native builtin")
    effects.check()
    trace.check()
    checked.check()


def _reader_records(checked, compiler_program):
    if compiler_program is None:
        return checked.records
    from compiler_cute_handoff.program import BoundMixedProgram, ProgramDeclined

    if type(compiler_program) is not BoundMixedProgram or compiler_program.binding is not checked:
        raise LinkDeclined("Reader projection requires its original compiler binding")
    try:
        compiler_program.check()
    except ProgramDeclined as error:
        raise LinkDeclined("Reader projection changed before native preparation") from error
    return compiler_program.records


def link_cute_invocation(checked, trace, generated, owner, effects, *, provider_key="user_cute",
                         compiler_program=None):
    from compiler_cute_handoff.descriptor import CuTeCall
    from compiler_cute_handoff.envelope import GeneratedCall, Release
    from user_triton.provider import _POINTER_DTYPES

    _check_invocation_sources(checked, trace, generated, owner, effects, provider_key)
    records = _reader_records(checked, compiler_program)
    expressions = _Expressions(trace, {row.boxed_index for row in checked.cute.integer_inputs})
    tensors = {id(tensor): row.source for tensor, row in zip(trace.operand_tensors, records.cute.calls[0].operands)}
    operands = _Operands(trace, owner.artifact, tensors, expressions)
    bound, predicate, obligations = _lower_cute_call(owner.artifact, owner.site, owner, operands)
    destination = records.cute.calls[0].operands[1].source
    if any(effect.written and operands.field(effect.source) != destination for effect in effects.fields):
        raise LinkDeclined("Selected CuTe effects write outside the compiler destination")
    events, copies = [], []
    facts = {row.source: row for row in records.cute.tensors}
    originals = {} if compiler_program is None else {new: old for old, new in compiler_program.buffer_sources}
    count = 0
    for event in records.events:
        if type(event) is OwnedBuffer:
            events.append(Allocate(event.source.name, event.dtype, event.size, event.stride))
        elif type(event) is AlignmentCopy:
            copies.append(event)
            events.append(Normalize(event.input_index, event.before_call))
        elif type(event) is GeneratedCall:
            record, provider = event.record, generated[count]
            arguments = bind_wrapper_arguments(record, provider.arguments)
            grid = bind_grid_recipe(record, provider.arguments, provider.selection.grid_recipe)
            if arguments is None or grid is None:
                raise LinkDeclined("Generated compiler operands or grid differ from the selected ABI")
            abi = "".join("O" if arg.triton_type.startswith("*") else {"i32": "i", "i64": "l"}[arg.triton_type]
                          for arg in arguments)
            if abi != provider.module.arg_tys:
                raise LinkDeclined("Generated selected module differs from the complete argument ABI")
            writes = set()
            provenance = provider.selection.identity[0].inductor_meta.get("cudagraph_parameter_provenance", {})
            for arg in arguments:
                source = arg.source
                if type(source) not in (InputSource, BufferSource):
                    continue
                row = provenance.get(arg.formal)
                original = originals[source] if compiler_program is not None and type(source) is BufferSource else source
                name = checked.cute.input_names[source.index] if type(source) is InputSource else original.name
                if (type(row) is not tuple or len(row) != 3 or row[0] != name
                        or source not in facts or _POINTER_DTYPES.get(arg.triton_type) != facts[source].dtype
                        or type(row[1]) is not bool or type(row[2]) is not int
                        or not 0 < row[2] <= 16 or row[2] & (row[2] - 1)
                        or provider.pointer_writes.get(arg.formal) is not row[1]
                        or provider.pointer_alignments.get(arg.formal) != row[2]):
                    raise LinkDeclined("Generated pointer provenance differs from its compiler source")
                if type(source) is InputSource:
                    if row[1] or row[2] > 1 and source.index not in {copy.input_index for copy in copies}:
                        raise LinkDeclined("Generated inputs require read-only recorded alignment authority")
                elif row[1]:
                    writes.add(source)
            if writes != set(event.writes):
                raise LinkDeclined("Selected generated writers differ from typed compiler initialization")
            events.append(Invocation(record.kernel_global, record.formals, record.arguments, grid, provider))
            count += 1
        elif type(event) is CuTeCall:
            events.append(CuTeInvocation(provider_key, owner, bound, effects))
        elif type(event) is Release:
            # The checked no-reuse program keeps temporaries through graph enqueue.
            continue
        else:
            raise LinkDeclined("Unsupported compiler envelope event")
    program = MixedProgram(checked.inputs.device_index, checked.cute.input_names, checked.cute.integer_inputs,
        records.allocations, records.outputs, tuple(copies), tuple(events), tuple(
            InputAssertion(InputSource(row.index), row.size, row.stride, None) for row in checked.inputs.tensor_inputs))
    _check_invocation_sources(checked, trace, generated, owner, effects, provider_key)
    _reader_records(checked, compiler_program)
    return LinkedCuTe(program, trace, owner, predicate, tuple(dict.fromkeys(obligations)))


@dataclass(frozen=True)
class _CompilerInvocation:
    binding: object
    linked: LinkedCuTe
    generated: tuple[GeneratedProvider, ...]
    providers: dict
    provider_rows: tuple
    compiler_program: object = None

    @property
    def destination(self):
        return _reader_records(self.binding, self.compiler_program).cute.calls[0].operands[1].source

    def check(self):
        event = self.linked.program.calls[-1]
        _check_invocation_sources(self.binding, self.linked.trace, self.generated,
                                  self.linked.owner, event.effects, event.provider_key)
        _reader_records(self.binding, self.compiler_program)
        if (type(self.providers) is not dict or len(self.providers) != len(self.provider_rows)
                or any(self.providers.get(key) is not provider for key, provider in self.provider_rows)):
            raise LinkDeclined("Compiler provider mapping changed during preparation")


def _bind_compiler_program(program, providers, checked, *, compiler_program=None):
    if type(program) is not MixedProgram or type(providers) is not dict:
        raise LinkDeclined("Compiler preparation requires the linked mixed program and exact providers")
    calls = program.calls
    if (len(calls) < 2 or type(calls[-1]) is not CuTeInvocation
            or any(type(call) is not Invocation for call in calls[:-1])
            or set(providers) != {call.provider_key for call in calls}):
        raise LinkDeclined("Compiler program lost its generated prefix or terminal CuTe call")
    event = calls[-1]
    owner = providers[event.provider_key]
    from .provider import CuTeKernelOwner
    if type(owner) is not CuTeKernelOwner:
        raise LinkDeclined("Compiler terminal provider is not its selected CuTe owner")
    trace = owner.artifact.signature.trace
    generated = tuple(providers[call.provider_key] for call in calls[:-1])
    linked = link_cute_invocation(checked, trace, generated, owner, event.effects,
                                  provider_key=event.provider_key, compiler_program=compiler_program)
    if program != linked.program:
        raise LinkDeclined("Mixed program differs from the complete compiler projection")
    result = _CompilerInvocation(checked, linked, generated, providers, tuple(providers.items()), compiler_program)
    result.check()
    return result
