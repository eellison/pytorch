"""Cold preparation of one caller-authorized mixed host variant."""

import math
import struct
from dataclasses import dataclass
from typing import Any

import torch
from host_program import Allocate, InputAssertion, Normalize, Reinterpret
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, bind_wrapper_arguments, BufferSource, ExpressionSource,
    InputSource, IntegerInput, IntegerSource, IntExpr, OwnedBuffer,
)
from torch._inductor.runtime.cudagraph_boxed_replay import (
    _BoundCall, _make_replay, _NumericProgram, _PhysicalCall, _PhysicalField,
)
from torch._inductor.runtime.cudagraph_launch_association import RecordedKernelLaunch, UnsupportedCapture
from torch._inductor.runtime.cudagraph_prepare_from_warmed import _Preparation
from torch._inductor.runtime.static_triton_launcher import StaticallyLaunchedCudaKernel
from torch._inductor.runtime.triton_compat import autograd_profiler
from torch.cuda._utils import _check_cuda_bindings
from torch.utils._debug_mode import get_active_debug_mode

from user_triton.contract import Invocation, ReplayProgram
from user_triton.provider import _POINTER_DTYPES

from .contract import CuTeInvocation, MixedProgram


@dataclass(frozen=True)
class _CaptureCall:
    event: Invocation | CuTeInvocation
    provider: Any
    bound: _BoundCall | _PhysicalCall
    function: int
    grid: tuple[int, int, int]
    scratch: tuple[bytes, ...]


@dataclass(frozen=True)
class _Plan:
    numeric: _NumericProgram
    calls: tuple[_CaptureCall, ...]
    outputs: tuple[int, ...]
    copies: tuple[int, ...]
    dimensions: dict[str, tuple[tuple[int, ...], tuple[int, ...]]]


def _dimensions(values, numeric, *, positive):
    if type(values) is not tuple:
        raise UnsupportedCapture("Expected exact recorded dimension tuples")
    result = []
    for value in values:
        if type(value) is IntExpr:
            value = numeric.values[numeric.add(value)]
        if type(value) is not int or not (0 < value if positive else 0 <= value) or value >= 2 ** 63:
            raise UnsupportedCapture("Recorded dimension exceeds the supported integer domain")
        result.append(value)
    return tuple(result)


def _layout(layout, numeric, *, canonical):
    if (type(layout) is not OwnedBuffer or type(layout.source) is not BufferSource
            or type(layout.source.name) is not str or not layout.source.name
            or type(layout.dtype) is not torch.dtype or layout.dtype not in _POINTER_DTYPES.values()
            or type(layout.size) is not tuple or type(layout.stride) is not tuple
            or len(layout.size) not in (1, 2) or len(layout.stride) != len(layout.size)):
        raise UnsupportedCapture("Expected a supported owning rank-one or rank-two buffer")
    if canonical and layout.stride != ((1,) if len(layout.size) == 1 else (layout.size[1], 1)):
        raise UnsupportedCapture("Replay buffers require their exact contiguous descriptor")
    size = _dimensions(layout.size, numeric, positive=True)
    stride = _dimensions(layout.stride, numeric, positive=False)
    span = 1 + sum((extent - 1) * step for extent, step in zip(size, stride))
    if math.prod(size) >= 2 ** 63 or span * layout.dtype.itemsize >= 2 ** 63:
        raise UnsupportedCapture("Recorded buffer storage size exceeds int64")
    return size, stride


def _validate_cute_call(event, provider, program, numeric, tensor_indices, active, layouts,
                        written, prefix_buffers, example_inputs, compiler_destination=None):
    from .provider import CuTeKernelOwner, PointerEffect, SitePointerEffects

    bound, effects = event.bound, event.effects
    if (type(provider) is not CuTeKernelOwner or event.provider_identity is not provider
            or type(bound) is not _PhysicalCall or bound.module is not provider
            or type(effects) is not SitePointerEffects
            or effects.artifact is not provider.artifact or effects.site is not provider.site):
        raise UnsupportedCapture("CuTe invocation lost its selected owner, artifact or site")
    provider.check()
    effects.check()
    artifact, site = provider.artifact, provider.site
    if (type(bound.fields) is not tuple or type(bound.padding) is not tuple
            or bound.padding != tuple(tuple(row) for row in site.fields.padding)
            or provider.parameter_sizes != site.fields.parameter_sizes
            or tuple(size for _, size in provider.parameter_layout) != provider.parameter_sizes
            or struct.calcsize("P") != 8):
        raise UnsupportedCapture("CuTe physical parameters differ from the selected compiler ABI")
    schema = {(row.parameter, row.byte_offset): ("pointer", row.source) for row in site.fields.pointers}
    schema.update({(row.parameter, row.byte_offset): (row.dtype, row.source) for row in site.fields.integers})
    fields = {(row.parameter, row.byte_offset): row for row in bound.fields if type(row) is _PhysicalField}
    pointers = {(row.parameter, row.byte_offset): row for row in effects.fields if type(row) is PointerEffect}
    if (len(schema) != len(site.fields.pointers) + len(site.fields.integers)
            or len(fields) != len(bound.fields) or set(fields) != set(schema)
            or len(pointers) != len(effects.fields)
            or set(pointers) != {(row.parameter, row.byte_offset) for row in site.fields.pointers}):
        raise UnsupportedCapture("CuTe physical fields and pointer effects must have complete unique coverage")
    spans = [[] for _ in provider.parameter_sizes]
    for key, field in fields.items():
        kind, _ = schema[key]
        if (field.kind != kind or kind not in ("pointer", "i32", "i64")
                or type(field.parameter) is not int or not 0 <= field.parameter < len(spans)
                or type(field.byte_offset) is not int or field.byte_offset < 0):
            raise UnsupportedCapture("CuTe field changed its actual physical type or destination")
        width = 4 if kind == "i32" else 8
        spans[field.parameter].append((field.byte_offset, field.byte_offset + width))
        if kind != "pointer":
            source = field.source
            if type(source) is IntegerSource and type(source.value) is int:
                value = source.value
            elif type(source) is ExpressionSource and type(source.expression) is IntExpr:
                value = numeric.values[numeric.add(source.expression)]
            else:
                raise UnsupportedCapture("CuTe scalar field has no exact literal or symbolic origin")
            if not -(2 ** (8 * width - 1)) <= value < 2 ** (8 * width - 1):
                raise UnsupportedCapture("CuTe expression exceeds its selected scalar ABI")
    for parameter, offset, width in bound.padding:
        if (type(parameter) is not int or not 0 <= parameter < len(spans)
                or type(offset) is not int or offset < 0 or type(width) is not int or width <= 0):
            raise UnsupportedCapture("CuTe padding has no exact compiler span")
        spans[parameter].append((offset, offset + width))
    for size, intervals in zip(provider.parameter_sizes, spans):
        cursor = 0
        for start, end in sorted(intervals):
            if start != cursor or not start < end <= size:
                raise UnsupportedCapture("CuTe fields and padding must cover each parameter exactly")
            cursor = end
        if cursor != size:
            raise UnsupportedCapture("CuTe parameter contains bytes without a recorded source")

    call_buffers, call_writes, call_inputs = set(), set(), set()
    parameter_layouts, symbols = {}, {}
    copied_inputs = {row.input_index for row in program.copies}
    for key, effect in pointers.items():
        source = fields[key].source
        if (effect.source != schema[key][1] or type(effect.read) is not bool or type(effect.written) is not bool
                or type(effect.required_alignment) is not int or not 0 < effect.required_alignment <= 16
                or effect.required_alignment & (effect.required_alignment - 1)):
            raise UnsupportedCapture("CuTe pointer effects or alignment facts changed")
        parameter = site.parameters[effect.parameter]
        formal, = (row for row in artifact.formals if row.source_arg_index == parameter.source_arg_index)
        operand = artifact.signature.operands[formal.operand_index]
        if (formal.kind != "Tensor" or operand.tensor is None or operand.name != formal.name
                or type(formal.data_alignment) is not int or not 0 < formal.data_alignment <= 16
                or formal.data_alignment & (formal.data_alignment - 1)
                or operand.tensor.device != torch.device("cuda", program.device_index)):
            raise UnsupportedCapture("CuTe pointer has no supported original Tensor formal")
        alignment = max(effect.required_alignment, formal.data_alignment)
        if type(source) is InputSource:
            if (type(source.index) is not int or source.index not in tensor_indices or effect.written
                    or alignment > 1 and source.index not in copied_inputs):
                raise UnsupportedCapture("CuTe input pointers require read-only recorded alignment authority")
            assertions = [row for row in program.input_assertions if row.source == source]
            if not assertions or any((row.size, row.stride) != (assertions[0].size, assertions[0].stride)
                                     for row in assertions):
                raise UnsupportedCapture("CuTe input pointer lacks a unique compiler layout")
            size, stride = assertions[0].size, assertions[0].stride
            value = example_inputs[source.index]
            if value.dtype != operand.tensor.dtype or value.device != operand.tensor.device:
                raise UnsupportedCapture("CuTe input dtype or device differs from its original formal")
            call_inputs.add(source.index)
        elif type(source) is BufferSource:
            if (source not in active or layouts.get(source) != active[source]
                    or active[source].dtype != operand.tensor.dtype
                    or effect.written and source in prefix_buffers and not (
                        source == compiler_destination and source in written
                        and any(output.source == source for output in program.outputs))):
                raise UnsupportedCapture("CuTe pointer lacks a matching live allocation or writes into its prefix")
            if effect.read and source not in written:
                raise UnsupportedCapture("CuTe pointer reads an uninitialized owned buffer")
            size, stride = active[source].size, active[source].stride
            call_buffers.add(source)
            if effect.written:
                call_writes.add(source)
        else:
            raise UnsupportedCapture("CuTe pointer field has no original Tensor source")
        if effect.parameter in parameter_layouts:
            raise UnsupportedCapture("CuTe Tensor parameters require one exact pointer field")
        parameter_layouts[effect.parameter] = (size, stride)
        _dimensions(size, numeric, positive=True)
        _dimensions(stride, numeric, positive=False)
        for actual, expected in ((size, formal.shape), (stride, formal.strides)):
            if len(actual) != len(expected):
                raise UnsupportedCapture("CuTe pointer layout rank differs from its compiler formal")
            for value, (kind, index) in zip(actual, expected):
                if kind == "constant":
                    if value != index:
                        raise UnsupportedCapture("CuTe layout changed a compiler-static property")
                elif kind == "symbol":
                    if index in symbols and symbols[index] != value:
                        raise UnsupportedCapture("CuTe layouts disagree on an original compiler symbol")
                    symbols[index] = value
                else:
                    raise UnsupportedCapture("CuTe layout has an unknown compiler dimension origin")
        for constant in formal.constants:
            actual = size if constant.property == "shape" else stride
            if (constant.property not in ("shape", "stride") or len(constant.property_path) != 1
                    or actual[constant.property_path[0]] != constant.value):
                raise UnsupportedCapture("CuTe layout changed an elided compiler constant")
    if set(parameter_layouts) != set(range(len(provider.parameter_sizes))):
        raise UnsupportedCapture("CuTe parameters lack complete original Tensor sources")
    for key, (kind, origin) in schema.items():
        if kind == "pointer":
            continue
        size, stride = parameter_layouts[key[0]]
        values = size if origin.property == "shape" else stride
        if origin.property not in ("shape", "stride") or len(origin.property_path) != 1:
            raise UnsupportedCapture("CuTe scalar field has an unsupported Tensor property origin")
        value = values[origin.property_path[0]]
        expected = ExpressionSource(value) if type(value) is IntExpr else IntegerSource(value)
        if fields[key].source != expected:
            raise UnsupportedCapture("CuTe scalar field lost its exact pointer-layout correspondence")
    if not call_buffers.issubset(written | call_writes):
        raise UnsupportedCapture("CuTe allocation has no preceding or current writer")
    if type(bound.grid) is not tuple or len(bound.grid) != 3 or any(type(value) is not IntExpr for value in bound.grid):
        raise UnsupportedCapture("CuTe grid requires three explicit numeric recipes")
    grid = tuple(numeric.values[numeric.add(value)] for value in bound.grid)
    if not (0 < grid[0] < 2 ** 31 and 0 < grid[1] <= 65535 and 0 < grid[2] <= 65535):
        raise UnsupportedCapture("CuTe capture grid exceeds CUDA launch bounds")
    return _CaptureCall(event, provider, bound, provider.function, grid, ()), call_buffers, call_writes, call_inputs


def _validate(program, providers, example_inputs, *, compiler=None):
    if compiler is not None:
        from .lowering import _CompilerInvocation
        if (type(compiler) is not _CompilerInvocation or compiler.linked.program != program
                or compiler.providers is not providers):
            raise UnsupportedCapture("Compiler preparation lost its checked program projection")
        compiler.check()
    if (type(program) not in (ReplayProgram, MixedProgram) or type(program.device_index) is not int or program.device_index < 0
            or type(program.input_names) is not tuple or not program.input_names
            or any(type(name) is not str or not name for name in program.input_names)
            or len(set(program.input_names)) != len(program.input_names)
            or type(program.integer_inputs) is not tuple or not program.integer_inputs
            or type(program.allocations) is not tuple or not program.allocations
            or type(program.outputs) is not tuple or not program.outputs
            or type(program.events) is not tuple or not program.events
            or type(program.copies) is not tuple or type(program.input_assertions) is not tuple
            or type(providers) is not dict or any(type(name) is not str for name in providers)
            or type(example_inputs) not in (list, tuple) or len(example_inputs) != len(program.input_names)):
        raise UnsupportedCapture("Expected a complete mixed host program and its actual boxed inputs")
    integer_indices, integer_names = set(), set()
    for row in program.integer_inputs:
        if (type(row) is not IntegerInput or type(row.boxed_index) is not int
                or not 0 <= row.boxed_index < len(program.input_names) or row.boxed_index in integer_indices
                or type(row.symbol) is not str or not row.symbol or row.symbol in integer_names):
            raise UnsupportedCapture("Integer inputs require unique exact boxed origins")
        integer_indices.add(row.boxed_index)
        integer_names.add(row.symbol)
    tensor_indices = set(range(len(program.input_names))) - integer_indices
    if any(type(example_inputs[index]) is not torch.Tensor and not (
            compiler is not None and type(example_inputs[index]) is torch.nn.Parameter) for index in tensor_indices):
        raise UnsupportedCapture("Every noninteger box must contain an ordinary Tensor")
    numeric = _NumericProgram(program, example_inputs)
    layouts, dimensions = {}, {}
    for layout in program.allocations:
        concrete = _layout(layout, numeric, canonical=True)
        if layout.source in layouts:
            raise UnsupportedCapture("Allocation sources must be unique")
        layouts[layout.source] = layout
        dimensions[layout.source.name] = concrete
    outputs = []
    for output in program.outputs:
        _layout(output, numeric, canonical=True)
        if layouts.get(output.source) != output or output.source in outputs:
            raise UnsupportedCapture("Outputs must be distinct exact owning allocations")
        outputs.append(output.source)
    if any(type(copy) is not AlignmentCopy or type(copy.input_index) is not int
           or type(copy.before_call) is not int for copy in program.copies):
        raise UnsupportedCapture("Alignment copies require exact input and occurrence indices")
    for assertion in program.input_assertions:
        if (type(assertion) is not InputAssertion or type(assertion.source) is not InputSource
                or type(assertion.source.index) is not int or assertion.source.index not in tensor_indices
                or type(assertion.size) is not tuple or type(assertion.stride) is not tuple
                or len(assertion.size) != len(assertion.stride)):
            raise UnsupportedCapture("Input layout authority has no exact Tensor source")
        _dimensions(assertion.size, numeric, positive=False)
        _dimensions(assertion.stride, numeric, positive=False)

    active, names, used, written, first_use = {}, set(), set(), set(), {}
    prefix_buffers = set()
    calls, copies = [], []
    for position, event in enumerate(program.events):
        if type(event) is Allocate:
            layout = OwnedBuffer(BufferSource(event.value_id), event.dtype, event.size, event.stride)
            concrete = _layout(layout, numeric, canonical=False)
            if event.value_id in names:
                raise UnsupportedCapture("Host allocation sources cannot be redefined")
            names.add(event.value_id)
            active[layout.source] = layout
            dimensions[event.value_id] = concrete
        elif type(event) is Reinterpret:
            previous = program.events[position - 1] if position else None
            if (calls or type(previous) is not Allocate or previous.value_id != event.source_id
                    or type(event.source_id) is not str or type(event.result_id) is not str
                    or not event.result_id or event.result_id in names
                    or type(event.offset) is not int or event.offset != 0):
                raise UnsupportedCapture("Only an adjacent fresh pre-use reinterpret is supported")
            source = BufferSource(event.source_id)
            original = active[source]
            layout = OwnedBuffer(BufferSource(event.result_id), original.dtype, event.size, event.stride)
            concrete = _layout(layout, numeric, canonical=True)
            if (layout.size != original.size or len(layout.stride) != len(original.stride)
                    or any(before != after and extent != 1
                           for extent, before, after in zip(layout.size, original.stride, layout.stride))):
                raise UnsupportedCapture("A fresh reinterpret may only change literal singleton strides")
            active = {layout.source if key == source else key: layout if key == source else value
                      for key, value in active.items()}
            names.add(event.result_id)
            dimensions[event.result_id] = concrete
        elif type(event) is Normalize:
            if (type(event.input_index) is not int or event.input_index not in tensor_indices
                    or type(event.before_call) is not int or event.before_call != len(calls)
                    or event.input_index in first_use or any(copy.input_index == event.input_index for copy in copies)):
                raise UnsupportedCapture("Normalization must precede its input's first invocation")
            copies.append(AlignmentCopy(event.input_index, event.before_call))
        elif type(event) is Invocation:
            if (type(event.provider_key) is not str or event.provider_key not in providers
                    or type(event.formals) is not tuple or any(type(name) is not str for name in event.formals)
                    or type(event.arguments) is not tuple or type(event.grid) is not tuple or len(event.grid) != 3):
                raise UnsupportedCapture("Invocation has no exact selected provider or grid")
            provider = providers[event.provider_key]
            if (event.provider_identity is not None and event.provider_identity is not provider
                    or hasattr(provider, "pointer_formals") and event.provider_identity is not provider):
                raise UnsupportedCapture("Invocation differs from its exact selected provider")
            provider.check()
            module = provider.module
            bound = bind_wrapper_arguments(event, provider.arguments)
            if (bound is None or type(module) is not StaticallyLaunchedCudaKernel or module.device_agnostic
                    or module.module is None or type(module.function) is not int or module.function <= 0
                    or module._has_tensordesc):
                raise UnsupportedCapture("Invocation does not match an owned selected CUDA ABI")
            if hasattr(provider, "pointer_formals"):
                writes = {row.name: row.written for row in provider.pointer_formals}
                reads = {row.name: row.read for row in provider.pointer_formals}
                alignments = {row.name: row.required_alignment for row in provider.pointer_formals}
                if any(type(row.read) is not bool for row in provider.pointer_formals):
                    raise UnsupportedCapture("User pointer read effects are not authoritative")
            else:
                writes, alignments = provider.pointer_writes, provider.pointer_alignments
                reads = None
            pointers = {argument.formal for argument in bound
                        if type(argument.source) in (InputSource, BufferSource)}
            if (not pointers.issubset(writes) or not pointers.issubset(alignments)
                    or any(type(writes[name]) is not bool or type(alignments[name]) is not int
                           or not 0 < alignments[name] <= 16 or alignments[name] & (alignments[name] - 1)
                           for name in pointers)):
                raise UnsupportedCapture("Pointer effects or supported alignment facts are incomplete")
            call_buffers, call_writes = set(), set()
            for argument in bound:
                source = argument.source
                if type(source) is InputSource:
                    if (type(source.index) is not int or source.index not in tensor_indices
                            or writes[argument.formal] is not False):
                        raise UnsupportedCapture("External Tensor sources must remain read-only")
                    first_use.setdefault(source.index, len(calls))
                elif type(source) is BufferSource:
                    if (source not in active or layouts.get(source) != active[source]
                            or _POINTER_DTYPES.get(argument.triton_type) != active[source].dtype):
                        raise UnsupportedCapture("Pointer has no matching live owned allocation")
                    if reads is not None and reads[argument.formal] and source not in written:
                        raise UnsupportedCapture("A user pointer reads an uninitialized owned buffer")
                    call_buffers.add(source)
                    if writes[argument.formal]:
                        call_writes.add(source)
                elif type(source) is ExpressionSource:
                    value = numeric.values[numeric.add(source.expression)]
                    bits = 32 if argument.triton_type == "i32" else 64
                    if not -(2 ** (bits - 1)) <= value < 2 ** (bits - 1):
                        raise UnsupportedCapture("Capture expression exceeds its selected scalar ABI")
            if not call_buffers.issubset(written | call_writes):
                raise UnsupportedCapture("An owned buffer is read before its first recorded writer")
            used.update(call_buffers)
            written.update(call_writes)
            prefix_buffers.update(call_buffers)
            abi = "".join("O" if type(argument.source) in (InputSource, BufferSource)
                          else {"i32": "i", "i64": "l"}[argument.triton_type] for argument in bound)
            if abi != module.arg_tys:
                raise UnsupportedCapture("Selected module does not match the complete argument ABI")
            scratch = []
            for present, size in ((module.has_global_scratch, module.global_scratch_size),
                                  (module.has_profile_scratch, module.profile_scratch_size)):
                if (type(present) is not bool or present and size is None
                        or size is not None and (type(size) is not int or size != 0)):
                    raise UnsupportedCapture("Mixed preparation requires empty launcher-owned scratch")
                if present:
                    scratch.append(bytes(struct.calcsize("P")))
            if any(type(value) is not IntExpr for value in event.grid):
                raise UnsupportedCapture("Each grid axis needs an explicit numeric recipe")
            grid = tuple(numeric.values[numeric.add(value)] for value in event.grid)
            if not (0 < grid[0] < 2 ** 31 and 0 < grid[1] <= 65535 and 0 < grid[2] <= 65535):
                raise UnsupportedCapture("Capture grid exceeds CUDA launch bounds")
            calls.append(_CaptureCall(event, provider, _BoundCall(bound, module, event.grid),
                                      module.function, grid, tuple(scratch)))
        elif type(event) is CuTeInvocation:
            if type(event.provider_key) is not str or event.provider_key not in providers:
                raise UnsupportedCapture("CuTe invocation has no exact selected provider")
            call, call_buffers, call_writes, call_inputs = _validate_cute_call(
                event, providers[event.provider_key], program, numeric, tensor_indices, active, layouts,
                written, prefix_buffers, example_inputs, compiler.destination if compiler is not None else None,
            )
            for index in call_inputs:
                first_use.setdefault(index, len(calls))
            used.update(call_buffers)
            written.update(call_writes)
            calls.append(call)
        else:
            raise UnsupportedCapture("Unsupported mixed host event")
    if (not calls or set(providers) != {call.event.provider_key for call in calls}
            or tuple(active.values()) != program.allocations or used != set(layouts) or written != set(layouts)
            or tuple(copies) != program.copies
            or any(copy.before_call != 0 and first_use.get(copy.input_index) != copy.before_call for copy in copies)):
        raise UnsupportedCapture("Host events do not completely cover their allocations, copies and providers")
    indices = {source: index for index, source in enumerate(layouts)}
    return _Plan(numeric, tuple(calls), tuple(indices[source] for source in outputs),
                 tuple(copy.input_index for copy in copies), dimensions)


def prepare_variant(program: ReplayProgram | MixedProgram, providers: dict[str, Any], example_inputs,
                    *, compiler_binding=None, compiler_program=None) -> Any:
    """Prepare one explicitly authorized variant on the caller's current stream.

    Compiler input metadata and the traced local branch remain caller-owned reuse
    preconditions. This cold function installs no dispatcher or hot Python checks.
    """
    compiler = None
    if compiler_program is not None and compiler_binding is None:
        raise UnsupportedCapture("Reader projection requires its original compiler binding")
    if compiler_binding is not None:
        from .lowering import _bind_compiler_program
        compiler = _bind_compiler_program(program, providers, compiler_binding, compiler_program=compiler_program)
    plan = _validate(program, providers, example_inputs, compiler=compiler)
    from torch.cuda import graphs

    if (not torch.cuda.is_initialized() or autograd_profiler._is_profiler_enabled or get_active_debug_mode()
            or any((graphs._global_capture_start_hooks, graphs._global_capture_end_hooks,
                    graphs._global_instantiate_hooks, graphs._global_replay_start_hooks,
                    graphs._global_replay_end_hooks, graphs._global_destroy_hooks))):
        raise UnsupportedCapture("Mixed preparation requires ordinary warmup without instrumentation")
    if torch.version.hip is not None or torch.version.cuda is None or tuple(map(int, torch.version.cuda.split("."))) < (12, 8):
        raise UnsupportedCapture("Native boxed preparation requires NVIDIA CUDA 12.8 or later")
    try:
        from cuda.bindings import runtime
    except ImportError as error:
        raise UnsupportedCapture("Graph upload requires cuda.bindings") from error
    normalize = torch._C._dynamo.guards.copy_if_misaligned
    state = _Preparation(program, (), tuple(example_inputs), list(example_inputs))
    try:
        if compiler is not None:
            compiler.check()
        cute_keys = {call.event.provider_key for call in plan.calls if type(call.event) is CuTeInvocation}
        for key, provider in providers.items():
            state.borrows.append(provider._borrow_for_cudagraph() if key in cute_keys else provider.borrow())
        with torch.cuda.device(program.device_index):
            state.stream = torch.cuda.current_stream()
            state.capture_stream = torch.cuda.Stream()
            for index in plan.copies:
                state.normalized[index] = normalize(state.originals[index])
            state.graph = torch.cuda.CUDAGraph(keep_graph=True)
            if compiler is not None:
                compiler.check()
            with torch.cuda.graph(state.graph, stream=state.capture_stream):
                for event in program.events:
                    if type(event) is Allocate:
                        size, stride = plan.dimensions[event.value_id]
                        state.buffers[BufferSource(event.value_id)] = torch._C._dynamo.guards._empty_strided_cuda(
                            size, stride, event.dtype,
                        )
                    elif type(event) is Reinterpret:
                        size, stride = plan.dimensions[event.result_id]
                        source = BufferSource(event.source_id)
                        state.buffers[BufferSource(event.result_id)] = torch._C._dynamo.guards._reinterpret_tensor(
                            state.buffers[source], size, stride, event.offset,
                        )
                        del state.buffers[source]
                    elif type(event) is Normalize:
                        value = state.normalized[event.input_index]
                        if normalize(value) is not value:
                            raise UnsupportedCapture("Pre-normalized input changed during capture")
                    else:
                        call = plan.calls[len(state.launches)]
                        call.provider.check()
                        physical = type(event) is CuTeInvocation
                        module = call.provider if physical else call.provider.module
                        if module is not call.bound.module or call.bound.module.function != call.function:
                            raise UnsupportedCapture("Owned provider changed before its capture occurrence")
                        arguments = []
                        sources = call.bound.fields if physical else event.arguments
                        for argument in sources:
                            source = argument.source
                            if type(source) is InputSource:
                                value = state.normalized[source.index]
                            elif type(source) is BufferSource:
                                value = state.buffers[source]
                            elif type(source) is IntegerSource:
                                value = source.value
                            else:
                                value = plan.numeric.values[plan.numeric.indices[source.expression]]
                            arguments.append(value)
                        if physical:
                            images = [bytearray(size) for size in call.provider.parameter_sizes]
                            for field, value in zip(call.bound.fields, arguments):
                                if field.kind == "pointer":
                                    payload = struct.pack("P", value.data_ptr())
                                else:
                                    payload = struct.pack({"i32": "i", "i64": "q"}[field.kind], value)
                                start = field.byte_offset
                                images[field.parameter][start:start + len(payload)] = payload
                            argument_bytes = tuple(bytes(image) for image in images)
                            arguments = argument_bytes
                        else:
                            argument_bytes = tuple(
                                struct.pack("P", arguments[arg.call_arg_index].data_ptr())
                                if type(arg.source) in (InputSource, BufferSource)
                                else struct.pack({"i32": "i", "i64": "q"}[arg.triton_type], arguments[arg.call_arg_index])
                                for arg in call.bound.arguments
                            ) + call.scratch
                        stream = state.capture_stream.cuda_stream
                        before = torch._C._cuda_get_capture_frontier(stream)
                        call.provider.launch(tuple(arguments), call.grid, stream)
                        after = torch._C._cuda_get_capture_frontier(stream)
                        call.provider.check()
                        state.launches.append(RecordedKernelLaunch(stream, before, after, call.function, argument_bytes))
                state.outputs = tuple(state.buffers[output.source] for output in program.outputs)
            if compiler is not None:
                compiler.check()
            if len(state.launches) != len(plan.calls) or set(state.buffers) != {layout.source for layout in program.allocations}:
                raise UnsupportedCapture("Captured occurrences or owning allocations are incomplete")
            for layout in program.allocations:
                value = state.buffers[layout.source]
                size, stride = plan.dimensions[layout.source.name]
                if (type(value) is not torch.Tensor or value._base is not None or value.storage_offset() != 0
                        or value.dtype != layout.dtype or value.device != torch.device("cuda", program.device_index)
                        or tuple(value.size()) != size or value.stride() != stride):
                    raise UnsupportedCapture("Captured allocation does not match its owning descriptor")
            state.graph.instantiate()
            state.instantiated = True
            _check_cuda_bindings(runtime.cudaGraphUpload(state.graph.raw_cuda_graph_exec(), state.stream.cuda_stream))
            state.stream.synchronize()
            state.capture_stream.synchronize()
            for provider in providers.values():
                provider.check()
            state.entry = _make_replay(
                state.graph, len(program.input_names), program.allocations, plan.outputs, plan.copies,
                tuple(call.bound for call in plan.calls), tuple(state.launches), state.buffers, state.stream,
                numeric=plan.numeric, copy_if_misaligned=normalize, resources=tuple(providers.values()),
            )
            if compiler is not None:
                compiler.check()
            state.entry._retire_capture_pool()
            if compiler is not None:
                compiler.check()
            state.borrows.clear()
            return state.entry
    except BaseException:
        state.abort()
        raise
