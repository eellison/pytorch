This draft connects a checked `BoundMixedProgram` to the existing native preparation path. It does not yet select a reader in the public compiler policy.

`compiler_binding` remains the original function/descriptor/selected-launcher authority. The separate `compiler_program` supplies the reader's verified ordered events, allocation names, and actual output projection. CuTe operands map through the binder's checked source correspondence to the original trace's Tensor identities. Generated pointer provenance is still checked against compiler names through that correspondence.

Native preparation reconstructs the complete program with the same projection and compares it before allocation or graph capture. Reader state is checked again at existing cold validation boundaries. No new work is added to native replay.

The CPU controls use real typed compiler fixtures and signatures with synthetic loaded handles/ABI data. They establish source mapping and preparation validation, not actual GPU execution or ABI discovery. The existing default records route remains available as a regression control. Public FX/retained policy integration and GPU tests follow separately.
