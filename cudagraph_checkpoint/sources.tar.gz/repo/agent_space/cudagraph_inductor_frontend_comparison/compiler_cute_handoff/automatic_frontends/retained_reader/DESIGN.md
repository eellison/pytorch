# Retained mixed wrapper reader

This candidate adds `compiler_cute_handoff.retained` without changing the frozen
compiler, FX reader, shared binder, policy, linker or native runtime. It is the
second outer reader, alongside `fx_adapter.trace_mixed_fx`/`lower_mixed_fx`.

`retain_mixed_wrapper(wrapper)` reads the final typed Python wrapper while its
compiler IR is alive and returns `MixedHostProgram`. The caller can retain that
data through `export_mixed_ir(program)` and `reconstruct_mixed_ir(text)`, then
call the existing `bind_mixed_program(original_binding, program)`. Attachment
emission and automatic policy selection are separate integration work.

The reader walks the actual wrapper lines in order. It obtains allocations from
`_cudagraph_owned_buffer`, calls from `_cudagraph_call_record`, normalization from
`InputAlignmentLine`, explicit releases from the free lines, and the complete
return projection from `_cudagraph_owned_outputs`. It checks exact typed
operation identities and complete scheduler occurrence coverage, including
multiple calls to one generated kernel global. `compiler_inputs` supplies the
original boxed Tensor/shape contract; `collect_descriptors` supplies the exact
owned CuTe entry and typed operand facts. Neither `collect_envelope` nor an
emitted envelope supplies the reader's event stream or outputs.

The supported program has an existing generated prefix, fresh allocations and
one terminal owned two-Tensor CuTe invocation. Copies stay before input use;
the original boxed shape indices remain unchanged. Unsupported interleavings,
reuse, streams, mutations, opaque instructions, user Triton calls or compiler
effects decline with `RetentionDeclined`. This draft adds no local guards and
checks that retention did not change the compiler's guard list.

Explicit free lines retain their positions. Any still-live non-output source
gets a release at function return. This is conservative lifetime extension for
the existing no-reuse subset, not an assertion of exact eager object lifetime.
All outputs remain explicit and ordered.

The payload contains immutable existing source/layout/IntExpr types and a small
set of versioned tuple carriers for mixed/input/CuTe events. It reuses the
existing retained-IR `_encode`/`_decode` codec without modifying its registry.
The codec has no owner, wrapper, real Tensor, example, selected executable or
live binding. Decode validates complete boxed slots, layouts, call/formal
structure, scalar origins, allocation/use/release order and full outputs.

Transport validation deliberately does not certify compiler initialization or
selected device effects/ABI. Only the frozen shared binder can join the
reader's complete ordered program to the original checked compiler envelope
and project its initialization facts. It supplies no missing calls, allocations,
copies or outputs. Selected kernel/ABI and CuTe host-IR proof remain the existing
later preparation work. Both outer readers will reuse the same inner CuTe
host-IR trace; this reader does not execute or specialize the CuTe host.

The CPU suite uses the qualified `mixed_envelope.CompilerFixture`: real typed
IR, compiler helpers, source attachments and shared correspondence binding, with
an unexecuted ordinary CuTe owner. It tests complete literal/symbolic transport,
equal-hint boxed origins, repeated globals, explicit/return releases, source and
output substitutions, omitted events, strict malformed data, stale attachment,
IR lifetime and exception behavior. It also demonstrates that representing an
uninitialized typed program as data does not authorize replay. It does not
claim a public compiler, selected-device ABI, SDK launch or native integration
test. The author performed only standard-library AST/hash/source checks.
