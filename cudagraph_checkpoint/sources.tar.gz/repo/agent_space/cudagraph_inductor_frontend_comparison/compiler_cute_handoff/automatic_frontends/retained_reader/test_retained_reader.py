from dataclasses import replace
import gc
import json
import pickle
import sys
from unittest import mock
import weakref

from retained_mixed_envelope_fixture import CompilerFixture
from compiler_cute_handoff import envelope, retained
from compiler_cute_handoff.envelope import bind_envelope, EnvelopeDeclined, GeneratedCall, Release
from compiler_cute_handoff.program import bind_mixed_program, MixedHostProgram, ProgramDeclined
from compiler_cute_handoff.retained import (
    export_mixed_ir, reconstruct_mixed_ir, retain_mixed_wrapper, RetentionDeclined, validate_mixed_ir,
)
import torch
from torch._inductor import config
from torch._inductor.codegen.common import ArgName, SizeArg, TensorArg
from torch._inductor.codegen.wrapper import AllocateLine, FreeLine, InputAlignmentLine, ReuseLine, TritonCallArgument
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, ExpressionSource, InputSource, IntExpr, KernelCallRecord, OwnedBuffer,
    pointwise_product,
)
from torch._inductor.virtualized import V
from torch.fx.experimental.symbolic_shapes import ShapeEnv
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


@instantiate_parametrized_tests
class TestRetainedMixedReader(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def read(self, fixture):
        before = fixture.state()
        with V.set_graph_handler(fixture.graph):
            result = retain_mixed_wrapper(fixture.wrapper)
        self.assertEqual(fixture.state(), before)
        return result

    @parametrize("dynamic", (False, True))
    @parametrize("return_prefix", (False, True))
    def test_live_ir_complete_program_and_transport(self, dynamic, return_prefix):
        fixture = CompilerFixture(self, dynamic=dynamic, return_prefix=return_prefix)
        invoked, previous = [], sys.getprofile()
        targets = (type(fixture.entry).invoke.__code__, fixture.entry.provider.run.__func__.__code__)

        def observe(frame, event, result):
            if event == "call" and frame.f_code in targets:
                invoked.append(frame.f_code.co_name)

        try:
            sys.setprofile(observe)
            with mock.patch.object(envelope, "collect_envelope", side_effect=AssertionError("No emitted-record reader")):
                program = self.read(fixture)
        finally:
            sys.setprofile(previous)
        self.assertEqual(invoked, [])
        self.assertIsNone(fixture.owner.selected)
        self.assertIs(type(program), MixedHostProgram)
        self.assertEqual([type(event).__name__ for event in program.events],
            ["AlignmentCopy", "OwnedBuffer", "KernelCallRecord", "OwnedBuffer", "KernelCallRecord", "CuTeCall", "Release"]
            + ([] if return_prefix else ["Release"]))
        outputs = (BufferSource("destination"), BufferSource("prefix")) if return_prefix else (BufferSource("destination"),)
        self.assertEqual(tuple(row.source for row in program.outputs), outputs)
        restored = reconstruct_mixed_ir(export_mixed_ir(program))
        self.assertEqual(restored, program)
        self.assertEqual(pickle.loads(pickle.dumps(restored)), program)
        function, _ = fixture.emit()
        checked = bind_envelope(function)
        bound = bind_mixed_program(checked, restored)
        supplied = tuple(event for event in restored.events if type(event) is KernelCallRecord)
        projected = tuple(event for event in bound.records.events if type(event) is GeneratedCall)
        self.assertEqual(len(supplied), 2)
        self.assertEqual(len(projected), len(supplied))
        for actual, expected in zip(projected, supplied):
            self.assertIs(actual.record, expected)
        self.assertEqual(bound.records.outputs, restored.outputs)
        bound.check()

    def test_original_boxed_symbols_survive_equal_hints(self):
        fixture = CompilerFixture(self, extra_integer=True)
        program = self.read(fixture)
        self.assertEqual(program.inputs.kinds, ("integer", "integer", "tensor"))
        self.assertEqual(program.inputs.tensor_inputs[0].size, (IntExpr("boxed", 1), 128))
        calls = tuple(event for event in program.events if type(event) is KernelCallRecord)
        self.assertEqual(calls[0].arguments[-1].source,
                         ExpressionSource(pointwise_product((IntExpr("boxed", 1), 128))))
        self.assertNotEqual(fixture.rows, fixture.other)

    def test_repeated_global_preserves_occurrences(self):
        fixture = CompilerFixture(self)
        fixture.output_call.kernel_name = fixture.prefix_call.kernel_name
        program = self.read(fixture)
        calls = tuple(event for event in program.events if type(event) is KernelCallRecord)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0].kernel_global, calls[1].kernel_global)
        self.assertEqual(tuple(call.occurrence for call in calls), (0, 1))
        function, _ = fixture.emit()
        bind_mixed_program(bind_envelope(function), program).check()

    def test_explicit_and_return_releases_are_distinct(self):
        fixture = CompilerFixture(self)
        source_free = next(line for line in fixture.wrapper.lines if type(line) is FreeLine and line.node is fixture.source)
        fixture.wrapper.lines.remove(source_free)
        fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.output_call), source_free)
        prefix_free = next(line for line in fixture.wrapper.lines if type(line) is FreeLine and line.node is fixture.prefix)
        fixture.wrapper.lines.remove(prefix_free)
        program = self.read(fixture)
        releases = tuple((index, event.source) for index, event in enumerate(program.events) if type(event) is Release)
        self.assertEqual(releases, ((4, InputSource(fixture.source_index)), (7, BufferSource("prefix"))))
        function, _ = fixture.emit()
        bind_mixed_program(bind_envelope(function), program).check()

    @parametrize("fault", ("missing_call", "missing_allocation", "missing_copy", "late_copy",
                            "missing_group", "duplicate_group", "same_name_node", "same_name_cute_operand"))
    def test_incomplete_or_substituted_live_ir_declines(self, fault):
        fixture = CompilerFixture(self)
        if fault == "missing_call":
            fixture.wrapper.lines.remove(fixture.prefix_call)
        elif fault == "missing_allocation":
            fixture.wrapper.lines = [line for line in fixture.wrapper.lines
                if not (type(line) is AllocateLine and line.node is fixture.prefix)]
        elif fault in ("missing_copy", "late_copy"):
            copy = next(line for line in fixture.wrapper.lines if type(line) is InputAlignmentLine)
            fixture.wrapper.lines.remove(copy)
            if fault == "late_copy":
                fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.output_call), copy)
        elif fault == "missing_group":
            fixture.prefix_call.cudagraph_computations = None
        elif fault == "duplicate_group":
            fixture.output_call.cudagraph_computations = fixture.prefix_call.cudagraph_computations
        elif fault == "same_name_node":
            fixture.prefix_call.cudagraph_computations = (fixture.computation("prefix", "source"),)
        else:
            fixture.op.inputs = [fixture.computation("prefix", "source"), fixture.destination]
        with self.assertRaises(RetentionDeclined):
            self.read(fixture)

    @parametrize("fault", ("unknown_line", "reuse", "late_call", "stream", "released_output", "aliased_output"))
    def test_unsupported_live_order_and_output_declines(self, fault):
        fixture = CompilerFixture(self)
        if fault == "unknown_line":
            fixture.wrapper.lines.insert(1, "opaque_host_work()")
        elif fault == "reuse":
            fixture.wrapper.lines.insert(2, ReuseLine(fixture.wrapper, fixture.prefix, fixture.destination, False))
        elif fault == "late_call":
            fixture.wrapper.lines.remove(fixture.output_call)
            fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.cute_line) + 1, fixture.output_call)
        elif fault == "stream":
            fixture.prefix_call.current_stream_idx = 1
        elif fault == "released_output":
            fixture.wrapper.lines.insert(-1, FreeLine(fixture.wrapper, fixture.destination))
        else:
            fixture.graph.graph_outputs = [fixture.destination, fixture.destination]
        with self.assertRaises(RetentionDeclined):
            self.read(fixture)

    @parametrize("fault", ("pointer", "boxed_scalar", "output_order"))
    def test_independently_read_changes_do_not_match_old_origin(self, fault):
        fixture = CompilerFixture(self, extra_integer=True, return_prefix=True)
        function, _ = fixture.emit()
        checked = bind_envelope(function)
        if fault == "pointer":
            line = fixture.output_call
            line.call_args = ("source", *line.call_args[1:])
            line.cudagraph_args = (TritonCallArgument(ArgName("in_ptr0"), TensorArg("in_ptr0", "source", torch.float32)),
                                   *line.cudagraph_args[1:])
            line.inductor_meta["cudagraph_parameter_provenance"]["in_ptr0"] = ("source", False, 16)
        elif fault == "boxed_scalar":
            line = fixture.output_call
            value = fixture.other * 128
            line.call_args = (*line.call_args[:-1], value)
            line.cudagraph_args = (*line.cudagraph_args[:-1], TritonCallArgument(ArgName("xnumel"), SizeArg("xnumel", value)))
        else:
            fixture.graph.graph_outputs.reverse()
        program = self.read(fixture)
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, program)

    def test_data_does_not_supply_initialization_proof(self):
        fixture = CompilerFixture(self, initialized=False)
        program = self.read(fixture)
        validate_mixed_ir(reconstruct_mixed_ir(export_mixed_ir(program)))
        with self.assertRaisesRegex(EnvelopeDeclined, "uninitialized"):
            fixture.collect()
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(None, program)

    @parametrize("fault", ("allocation", "call", "copy", "output"))
    def test_checked_origin_never_fills_reader_omissions(self, fault):
        fixture = CompilerFixture(self, return_prefix=True)
        program = self.read(fixture)
        function, _ = fixture.emit()
        if fault == "output":
            program = replace(program, outputs=program.outputs[:1])
        else:
            kind = {"allocation": OwnedBuffer, "call": KernelCallRecord, "copy": AlignmentCopy}[fault]
            index = next(index for index, event in enumerate(program.events) if type(event) is kind)
            program = replace(program, events=program.events[:index] + program.events[index + 1:])
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(bind_envelope(function), program)

    @parametrize("fault", ("list_source", "bool_source", "tuple_source", "unknown_event", "bad_formal",
                            "foreign_scalar", "scalar_type", "missing_release", "early_release", "output_layout"))
    def test_malformed_transport_declines_before_binding(self, fault):
        fixture = CompilerFixture(self)
        program = self.read(fixture)
        events = list(program.events)
        index = next(index for index, event in enumerate(events) if type(event) is KernelCallRecord)
        call = events[index]
        if fault in ("list_source", "bool_source", "tuple_source"):
            source = InputSource({"list_source": [], "bool_source": True, "tuple_source": (1,)}[fault])
            events[index] = replace(call, arguments=(replace(call.arguments[0], source=source), *call.arguments[1:]))
        elif fault == "unknown_event":
            events.insert(0, object())
        elif fault == "bad_formal":
            events[index] = replace(call, arguments=(replace(call.arguments[0], source_arg_index=True), *call.arguments[1:]))
        elif fault == "foreign_scalar":
            scalar = replace(call.arguments[-1], source=ExpressionSource(IntExpr("boxed", fixture.source_index)))
            events[index] = replace(call, arguments=(*call.arguments[:-1], scalar))
        elif fault == "scalar_type":
            events[index] = replace(call, arguments=(*call.arguments[:-1], replace(call.arguments[-1], triton_type="fp32")))
        elif fault == "missing_release":
            events = [event for event in events if type(event) is not Release]
        elif fault == "early_release":
            events.insert(0, Release(BufferSource("prefix")))
        else:
            program = replace(program, outputs=(replace(program.outputs[0], size=(7, 128)),))
        with self.assertRaises(RetentionDeclined):
            export_mixed_ir(replace(program, events=tuple(events)))

    @parametrize("schema", (None, False, 2))
    def test_unknown_schema_declines(self, schema):
        data = json.loads(export_mixed_ir(self.read(CompilerFixture(self))))
        data["mixed_schema"] = schema
        with self.assertRaises(RetentionDeclined):
            reconstruct_mixed_ir(json.dumps(data))

    @parametrize("fault", ("carrier", "arity", "extra_key", "broken_json"))
    def test_malformed_codec_declines(self, fault):
        data = json.loads(export_mixed_ir(self.read(CompilerFixture(self))))
        if fault == "carrier":
            data["program"]["tuple"][1] = "LiveOwner"
        elif fault == "arity":
            data["program"]["tuple"][2]["tuple"].pop()
        elif fault == "extra_key":
            data["owner"] = 1
        with self.assertRaises(RetentionDeclined):
            reconstruct_mixed_ir("{" if fault == "broken_json" else json.dumps(data))

    def test_original_attachment_remains_required_after_transport(self):
        fixture = CompilerFixture(self)
        program = reconstruct_mixed_ir(export_mixed_ir(self.read(fixture)))
        function, _ = fixture.emit()
        checked = bind_envelope(function)
        function.__globals__[program.events[2].kernel_global] = object()
        with self.assertRaises(ProgramDeclined):
            bind_mixed_program(checked, program)

    def test_payload_does_not_retain_live_ir(self):
        fixture = CompilerFixture(self)
        program = self.read(fixture)
        refs = tuple(weakref.ref(value) for value in (fixture.wrapper, fixture.prefix, fixture.destination, fixture.environment))
        fixture.entry.close()
        del fixture
        # ShapeEnv memoizers retain their instance independently of the retained payload.
        for method in vars(ShapeEnv).values():
            clear = getattr(method, "cache_clear", None)
            if clear is not None:
                clear()
        gc.collect()
        self.assertTrue(all(ref() is None for ref in refs))
        self.assertEqual(reconstruct_mixed_ir(export_mixed_ir(program)), program)

    def test_unexpected_helper_error_is_not_a_decline(self):
        fixture = CompilerFixture(self)
        error = ValueError("unexpected compiler bug")
        with mock.patch.object(retained, "compiler_inputs", side_effect=error):
            with self.assertRaises(ValueError) as caught:
                self.read(fixture)
        self.assertIs(caught.exception, error)

    def test_guard_mutation_is_an_error(self):
        fixture = CompilerFixture(self)
        original = retained.compiler_inputs

        def changed(wrapper):
            result = original(wrapper)
            fixture.environment.guards.append(object())
            return result

        with mock.patch.object(retained, "compiler_inputs", side_effect=changed):
            with self.assertRaisesRegex(RuntimeError, "changed compiler guards"):
                self.read(fixture)


if __name__ == "__main__":
    run_tests()
