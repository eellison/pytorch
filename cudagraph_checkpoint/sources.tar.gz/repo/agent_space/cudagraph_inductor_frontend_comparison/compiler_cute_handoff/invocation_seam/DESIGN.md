# Owned ordinary CuTe invocation

This candidate adds an ordinary invocation seam. Native preparation remains
unchanged and declines wrappers containing the new IR operation. The CPU stand-in
is explicitly separate from an actual CuTe compilation owner.

```python
entry = register_cute_entry(observed_ordinary_owner)
key = entry.key

def model(value):
    source = value.sin()
    destination = torch.empty_like(source)
    invoke_cute(key, source, destination)
    return destination
```

`InvocationEntry` owns the exact `ObservedOrdinaryEntry`. Registration captures
canonical `OrdinaryEntry.run` bound to that owner and seals its function/code;
an instance `run` override cannot become the registered implementation. A fixed
host calls the owner's actual PythonEntry with source and destination. The
ordinary owner supplies the current Stream, conversion, selected code, source
checks and compilation lifetime. `entry.close()` closes the owner before removing
its weak registry entry. A failed close leaves the registration available for
explicit retry. Generated modules hold the entry strongly; the registry does not. Invocation and
close use the saved provider, and the CuTe provider calls the saved canonical
run/host. Public diagnostic-field replacement cannot redirect those operations.

The invocation contract reads source and may read/write destination, with no
source mutation or alias between them. Destination allocation belongs to the
caller. Fake execution preserves Tensor metadata without invoking the provider;
functionalization clones destination and records its update. Tensor shape symbols
remain compiler operands through their layouts. Direct scalar/SymInt host
operands, autograd, and unsupported transform modes are outside this first API.
Direct source/destination aliases and stride-changing views are outside this
first proof. The new IR declares the provider contract; it does not analyze
arbitrary CuTe effects. Clone lowering permits normal layout optimization, so
general stride-preserving frontend support is not claimed. The real CuTe fixture
uses compact row-major operands, checked by the ordinary owner.
No per-hit pointer, shape, or alias scans are added by this seam. The existing
ordinary owner's conversion checks still run as before.

Dynamo recognizes the exact HOP objects and emits the entry key plus two Tensor
operands. Inductor lowers them into `UserDefinedCuTeKernel`, with the original
realized Tensor inputs and a `MutationOutput` for destination. The functional HOP
lowers through the existing clone operation. `CuTeCallLine` emits an invocation of
the exact entry bound in the generated module header. The HOP implementation
checks are cold; changing these implementations after compilation is unsupported.
The explicit CPU stand-in is an ordinary Python function used only to qualify
this orchestration. It is never accepted as CuTe or native-code authority.

`CuTeDescriptors` is a versioned, data-only logical record: boxed input names and
integer origins, Tensor dtype/device/size/stride facts, ordered entry formals and
source/destination sources, and compiler output sources. It contains no live
owner, examples, ShapeEnv, selected handle, kernel ABI offset, or launch predicate.
The key identifies a live registration generation; it is not portable cache
identity. Collection reads actual InputBuffer/ComputedBuffer/AllocateLine and
CuTeCallLine objects. A same-name IR replacement cannot establish correspondence.
The bounded collector requires a fresh allocation for destination and declines
views, reuse lines, unknown shape expressions, deferred assertion authority,
missing sources and malformed output/source associations. It does not certify
all operations in the wrapper or infer device effects.

An optional descriptor decline leaves ordinary wrapper execution available.
Unexpected source/ownership failures propagate. `bind_descriptors(function)`
checks the original function/code/attachment and its exact emitted entry globals,
then resolves each live generation cold. `BoundCuTeCalls` weakly references the
function, holds the entries, and has `check()`; it is not serializable. This is a
logical call binding, not a CompiledFxGraph/native preparation certificate.
Malformed optional schema is rejected by the cold reader after ordinary module
loading remains possible.

Both HOPs are non-cacheable. Existing FX `CacheabilityValidator` and AOT
`check_node_safe` reject them under the supported default cache configuration.
There is no codecache patch or policy-dependent emission. The explicit
`unsafe_marked_cacheable_functions` opt-out is unsupported; no portable key is
claimed. Python source loading in the same process must still resolve the exact
live entry. A future portable key/cache handoff is a separate change.

The six canonical sources are the new invocation/descriptor modules and isolated
Dynamo higher_order_ops, Inductor ir/lowering/codegen.wrapper overlays. The four
copied bases come from the actual qualified CFP manifest or its native source
root, recorded in `base_sources.json`. Existing compiler replay record emission
rejects the new operation; no predecessor policy, preparer, native library or
frontend reader changes.

CPU44 covers real eager/FakeTensor/proxy/functionalization/Dynamo/AOT-eager
execution with the stand-in; actual IR construction/lowering and emitted call
lines; both actual cache validators; real uncompiled CuTe-owner registration;
boxed symbols with equal hints; source/owner/schema substitution; ordinary and
cleanup failures; and storage/function/registry lifetime. The small IR graph
fixture explicitly stands in for GraphLowering orchestration. It does not claim
a complete Inductor compile or a CuTe launch. Root separately owns the public
Inductor-to-CuTe GPU proof. This source review performs no framework execution.

A later native adapter must join the compiler descriptor to the actual ordinary
CuTe compilation and independently checked device effects/ABI/launch expressions.
No M<4 or other test-specific host arm is encoded as eligibility here. Kernel-local
shape guards, native replay integration and a portable cache key remain separate.
