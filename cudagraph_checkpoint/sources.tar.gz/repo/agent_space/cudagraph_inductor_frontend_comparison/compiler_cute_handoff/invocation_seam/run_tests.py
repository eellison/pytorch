"""Run the ordinary CuTe invocation seam and inherited runtime regressions."""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import unittest


ROOT = Path(__file__).resolve().parent
FRONTENDS = ROOT.parents[1]
SPACE = FRONTENDS.parent
BOOTSTRAP = FRONTENDS / "production_bootstrap"


def digest(path):
    with Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("suite", choices=("cpu", "frontend_policy", "projection", "dynamic", "generated", "retained", "fx", "user", "parameters", "mapping", "records", "prepare", "static", "policy", "metadata", "installer", "frontend", "pipeline", "invocation"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cpu-result", type=Path)
    args = parser.parse_args()
    gpu_suite = args.suite in ("frontend", "pipeline", "invocation")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    result = {"accepted": False, "suite": args.suite, "command": sys.orig_argv,
              "started_utc": datetime.now(timezone.utc).isoformat()}
    owner, torch, initialize = None, None, None
    dependencies, guard, data = None, None, None
    sdk_module, setuptools_module, expected_path = None, None, None
    initialized_checked = False
    initial_path = tuple(sys.path)
    path_stages = {"initial": initial_path}
    cases, originals, snapshots = [], {}, {}
    expected, checked, exit_code = [], False, 1
    test_helpers = {}

    def recorder(name, status):
        original = getattr(unittest.TestResult, name)
        originals[name] = original

        def record(self, test, *values):
            cases.append({"id": test.id(), "result": status})
            return original(self, test, *values)

        return record

    try:
        if not gpu_suite and os.environ.get("CUDA_VISIBLE_DEVICES") != "":
            raise RuntimeError("CUDA must be hidden for compiler metadata controls")
        review_path = ROOT / "execution_review.json"
        review = json.loads(review_path.read_text())
        expected = review["cases"][args.suite]
        if not expected or len(expected) != len(set(expected)):
            raise RuntimeError("Expected a nonempty unique test inventory")
        files = review["files"] | {str(review_path): digest(review_path)}
        (output / "sources").mkdir()
        for index, (path, sha) in enumerate(files.items()):
            if digest(path) != sha:
                raise RuntimeError("Reviewed compiler metadata source changed: " + path)
            saved = output / "sources" / f"{index:03d}_{Path(path).name}"
            shutil.copy2(path, saved)
            if digest(saved) != sha:
                raise RuntimeError("Compiler policy snapshot changed: " + path)
            snapshots[path] = sha
        (output / "sources.json").write_text(json.dumps(snapshots, indent=2) + "\n")
        spec = importlib.util.spec_from_file_location("production_bootstrap", BOOTSTRAP / "__init__.py",
                                                      submodule_search_locations=[str(BOOTSTRAP)])
        if spec.name in sys.modules:
            raise RuntimeError("Expected a fresh bootstrap package")
        package = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = package
        spec.loader.exec_module(package)
        spec = importlib.util.spec_from_file_location("_metadata_dependency_setup", BOOTSTRAP / "run_gpu.py")
        setup = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(setup)
        data = json.loads((ROOT / "gpu_dependencies.json").read_text())
        manifest = package.load_manifest(ROOT / "manifest.json")
        if gpu_suite:
            if args.cpu_result is None:
                raise RuntimeError("Frontend controls require the compiler metadata CPU result")
            cpu = json.loads(args.cpu_result.read_text())
            if (cpu.get("accepted") is not True or cpu.get("suite") != "cpu"
                    or cpu.get("cuda_initialized") is not False or cpu.get("sources_unchanged") is not True
                    or sorted(row["id"] for row in cpu["cases"]) != sorted(review["cases"]["cpu"])
                    or any(row["result"] != "ok" for row in cpu["cases"])):
                raise RuntimeError("Compiler policy CPU controls have not passed")
            cpu_sources = json.loads(args.cpu_result.with_name("sources.json").read_text())
            if cpu_sources != snapshots:
                raise RuntimeError("Compiler policy sources differ from their CPU controls")
            if (cpu.get("manifest_sha256") != digest(ROOT / "manifest.json")
                    or cpu.get("native_source") != manifest["native"]["torch_python"]
                    or cpu.get("native_extension") != manifest["native"]["extension"]
                    or cpu.get("loaded_modules") != {name: row["path"] for name, row in manifest["modules"].items()}
                    or cpu.get("identities_checked") is not True):
                raise RuntimeError("CPU controls lack the full metadata installation")
            result["cpu_result"] = {"path": str(args.cpu_result.resolve()), "sha256": digest(args.cpu_result)}
            gpu = data["gpu"]
            native = json.loads(setup.checked_file(gpu["source_manifest"]).read_text())
            path = setup.checked_file(gpu["guard"])
            if (gpu["physical_gpu"] != 1 or gpu["uuid"] != native["gpu_uuid"]
                    or str(path) != native["gpu_guard"]
                    or os.environ.get("CUDA_VISIBLE_DEVICES") != gpu["uuid"]):
                raise RuntimeError("Unexpected GPU selection or idle guard")
            spec = importlib.util.spec_from_file_location("_compiler_input_gpu_guard", path)
            guard = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(guard)
            if guard.PHYSICAL_GPU != 1 or guard.GPU_UUID != gpu["uuid"]:
                raise RuntimeError("Unexpected physical GPU guard")
            state = guard.snapshot_gpu()
            guard.require_idle(state)
            (output / "gpu_before.json").write_text(json.dumps(state, indent=2) + "\n")
        owner = package.install(ROOT / "manifest.json")
        if tuple(sys.path) != initial_path:
            raise RuntimeError("Metadata bootstrap altered sys.path")
        if data is not None:
            dependencies = setup.Dependencies(data, owner)
            sys.meta_path.insert(0, dependencies)
        import torch as framework
        torch = framework
        if torch.cuda.is_initialized():
            raise RuntimeError("Torch initialized CUDA during import")
        initialize = torch._C._cuda_init

        def initialize_checked():
            nonlocal initialized_checked
            if not gpu_suite:
                raise RuntimeError("CUDA initialization is forbidden for CPU metadata controls")
            state = guard.snapshot_gpu()
            guard.require_idle(state)
            (output / "gpu_initialization.json").write_text(json.dumps(state, indent=2) + "\n")
            initialized_checked = True
            torch._C._cuda_init = initialize
            return initialize()

        torch._C._cuda_init = initialize_checked
        if dependencies is not None:
            sdk_path = setup.checked_file(data["sdk_compiler"])
            setuptools_path = setup.checked_file(data["setuptools"])
            path_stages["before_sdk"] = tuple(sys.path)
            after_sdk = tuple(sys.path) + (str(sdk_path.parent),)
            expected_path = after_sdk + (str(setuptools_path.parent / "_vendor"),)
            owner.activate_cute()
            path_stages["after_sdk"] = tuple(sys.path)
            sdk_module = sys.modules.get("cutlass.base_dsl.compiler")
            if (tuple(sys.path) != after_sdk or sdk_module is None
                    or sdk_module.__file__ != str(sdk_path) or sdk_module.__spec__.origin != str(sdk_path)):
                raise RuntimeError("CuTe activation changed its known import contract")
            owner.import_modules()
            for name in dependencies.modules:
                importlib.import_module(name)
            path_stages["after_imports"] = tuple(sys.path)
            setuptools_module = sys.modules.get("setuptools")
            if (tuple(sys.path) != expected_path or setuptools_module is None
                    or setuptools_module.__file__ != str(setuptools_path)
                    or setuptools_module.__spec__.origin != str(setuptools_path)):
                raise RuntimeError("Frontend imports changed their known import contract")
            dependencies.check()
        helper_map = json.loads((ROOT / "cpu_helpers.json").read_text())
        for name, row in helper_map.get(args.suite, {}).items():
            path = setup.checked_file(row)
            if name in sys.modules:
                raise RuntimeError("CPU test helper must start fresh: " + name)
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            test_helpers[name] = module
        for name, status in (("addSuccess", "ok"), ("addError", "error"), ("addFailure", "failure"),
                             ("addSkip", "skip"), ("addExpectedFailure", "expected_failure"),
                             ("addUnexpectedSuccess", "unexpected_success")):
            setattr(unittest.TestResult, name, recorder(name, status))
        scripts = {
            "cpu": ROOT / "test_invocation.py",
            "frontend_policy": FRONTENDS / "compiler_frontend_policy/test_frontend_policy.py",
            "projection": FRONTENDS / "compiler_user_frontend_projection/test_projection.py",
            "dynamic": FRONTENDS / "compiler_dynamic_user_handoff/test_dynamic_user_handoff.py",
            "generated": FRONTENDS / "generated_python/test_generated_trace.py",
            "retained": FRONTENDS / "retained_ir/test_retained_ir.py",
            "fx": FRONTENDS / "fx_adapter/test_fx_adapter.py",
            "user": FRONTENDS / "compiler_user_triton_handoff/test_user_handoff.py",
            "parameters": FRONTENDS / "compiler_parameter_handoff/test_parameter_handoff.py",
            "mapping": SPACE / "cudagraph_landing_bundle/review13/source/test/inductor/test_cudagraph_arg_mapping.py",
            "records": SPACE / "cudagraph_landing_bundle/review13/source/test/inductor/test_cudagraph_call_records.py",
            "prepare": SPACE / "cudagraph_landing_bundle/review13/source/test/inductor/test_cudagraph_prepare_from_warmed.py",
            "static": FRONTENDS / "compiler_static_handoff/test_static_metadata.py",
            "policy": FRONTENDS / "compiler_policy_handoff/test_policy.py",
            "metadata": FRONTENDS / "compiler_metadata_handoff/test_metadata.py",
            "installer": SPACE / "cudagraph_landing_bundle/review13/source/test/inductor/test_cudagraph_installer.py",
            "frontend": FRONTENDS / "compiler_frontend_policy/test_frontend.py",
            "pipeline": FRONTENDS / "compiler_metadata_handoff/test_pipeline.py",
            "invocation": ROOT / "test_invocation_gpu.py",
        }
        script = scripts[args.suite]
        if args.suite == "pipeline":
            os.environ["CUTE_DISPATCH_OUTPUT"] = str(output)
        sys.argv = [str(script), "-v", *(case.removeprefix("__main__.") for case in expected)]
        try:
            runpy.run_path(sys.argv[0], run_name="__main__")
            exit_code = 0
        except SystemExit as error:
            exit_code = error.code or 0
        owner.check()
        for name, module in test_helpers.items():
            path = helper_map[args.suite][name]["path"]
            if (sys.modules.get(name) is not module or module.__file__ != path
                    or module.__spec__.origin != path):
                raise RuntimeError("CPU test helper identity changed: " + name)
        result["loaded_test_helpers"] = {name: module.__file__ for name, module in test_helpers.items()}
        if dependencies is not None:
            dependencies.check()
            if (tuple(sys.path) != expected_path
                    or sys.modules.get("cutlass.base_dsl.compiler") is not sdk_module
                    or sys.modules.get("setuptools") is not setuptools_module):
                raise RuntimeError("Frontend dependency identity or import path changed")
        if (set(owner.modules) - set(owner.loaded)
                or sys.modules.get("compiler_input_contract.collector") is not owner.loaded.get("compiler_input_contract.collector")
                or sys.modules.get("compiler_metadata_handoff.metadata") is not owner.loaded.get("compiler_metadata_handoff.metadata")
                or sys.modules.get("compiler_policy_handoff.policy") is not owner.loaded.get("compiler_policy_handoff.policy")):
            raise RuntimeError("Tests did not load the complete reviewed metadata installation")
        path_stages["final"] = tuple(sys.path)
        checked = True
    except BaseException as error:
        result["exception"] = {"type": type(error).__name__, "message": str(error)}
        exit_code = 1
        raise
    finally:
        if initialize is not None:
            torch._C._cuda_init = initialize
        for name, original in originals.items():
            setattr(unittest.TestResult, name, original)
        unchanged = bool(snapshots) and all(Path(path).is_file() and digest(path) == sha
                                            for path, sha in snapshots.items())
        initialized = None if torch is None else torch.cuda.is_initialized()
        result.update(exit_code=exit_code, cases=cases, sources_unchanged=unchanged,
                      cuda_initialized=initialized, identities_checked=checked,
                      initialization_checked=initialized_checked, path_stages=path_stages,
                      finished_utc=datetime.now(timezone.utc).isoformat())
        if owner is not None:
            result.update(manifest_sha256=owner.manifest_sha256, native_source=owner.native["torch_python"],
                          native_extension=owner.native["extension"],
                          loaded_modules={name: module.__file__ for name, module in owner.loaded.items()
                                          if name in owner.modules})
        if dependencies is not None:
            result.update(loaded_dependencies={name: sys.modules[name].__file__
                                               for name in dependencies.modules if name in sys.modules},
                          expected_sys_path=expected_path, final_sys_path=tuple(sys.path))
        cuda_ok = initialized is False if not gpu_suite else initialized is True and initialized_checked
        result["accepted"] = (exit_code == 0 and checked and unchanged and cuda_ok
                              and sorted(row["id"] for row in cases) == sorted(expected)
                              and all(row["result"] == "ok" for row in cases))
        (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps({"accepted": result["accepted"], "cases": len(cases),
                          "result": str(output / "result.json")}))
    if not result["accepted"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
