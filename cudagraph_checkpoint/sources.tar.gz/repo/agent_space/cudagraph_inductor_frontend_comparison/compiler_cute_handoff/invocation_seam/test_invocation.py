from dataclasses import replace
import gc
import pickle
from types import SimpleNamespace
from unittest import mock
import weakref

from compiler_cute_handoff import descriptor, invocation
from compiler_cute_handoff.descriptor import (
    attach_descriptors, bind_descriptors, collect_descriptors, CuTeDescriptors,
    DescriptorDeclined, emit_descriptors,
)
from compiler_cute_handoff.invocation import (
    check_implementation, InvocationDeclined, invoke_cute, invoke_cute_functional,
    register_cpu_standin, register_cute_entry, resolve_entry,
)
import sympy
import torch
from torch._dynamo.source import LocalSource
from torch._functorch._aot_autograd.autograd_cache import BypassAOTAutogradCache, check_node_safe
from torch._inductor import ir, lowering
from torch._inductor.codecache import BypassFxGraphCache, CacheabilityValidator
from torch._inductor.codegen.wrapper import AllocateLine, CuTeCallLine, PythonWrapperCodegen
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, InputSource, IntExpr
from torch._inductor.sizevars import SizeVarAllocator
from torch._inductor.utils import IndentedBuffer
from torch._inductor.virtualized import V
from torch._subclasses.fake_tensor import FakeTensorMode
from torch.fx.experimental.proxy_tensor import make_fx
from torch.fx.experimental.symbolic_shapes import DimDynamic, ShapeEnv
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase


def copy_source(source, destination):
    destination.copy_(source + 1)


class CompilerFixture:
    def __init__(self, entry, dynamic=False):
        self.environment = ShapeEnv(duck_shape=False, specialize_zero_one=False)
        if dynamic:
            self.rows = self.environment.create_symbol(7, LocalSource("rows"), dynamic_dim=DimDynamic.DYNAMIC)
            self.columns = self.environment.create_symbol(7, LocalSource("columns"), dynamic_dim=DimDynamic.DYNAMIC)
            size, stride = (self.rows, self.columns), (self.columns, 1)
        else:
            self.rows = self.columns = None
            size, stride = (3, 4), (4, 1)
        layout = ir.FixedLayout(torch.device("cpu"), torch.float32, size, stride)
        self.source = ir.InputBuffer(name="source", layout=layout)
        self.destination = ir.ComputedBuffer(name="destination", layout=layout, data=None)
        self.source_box = ir.TensorBox.create(self.source)
        self.destination_box = ir.TensorBox.create(self.destination)
        self.operations = [self.destination]
        self.buffers = {"source": self.source, "destination": self.destination}
        self.mutated = []
        current = object()
        inputs = {"source": self.source_box}
        if dynamic:
            inputs = {"columns": self.columns, "source": self.source_box, "rows": self.rows}
        self.graph = SimpleNamespace(
            sizevars=SizeVarAllocator(self.environment), graph_inputs=inputs,
            graph_input_names=list(inputs), graph_outputs=[self.destination],
            current_node=SimpleNamespace(name="invocation"), cpp_wrapper=False, aot_mode=False,
            operations=self.operations, constants={},
            scheduler=SimpleNamespace(current_node=current, nodes=[current]),
            mark_buffer_mutated=self.mutated.append, register_buffer=self.register_buffer,
            register_operation=self.operations.append, is_unspec_arg=lambda name: False,
        )
        self.wrapper = PythonWrapperCodegen.__new__(PythonWrapperCodegen)
        self.wrapper.lines = []
        self.wrapper.header = IndentedBuffer()
        self.wrapper.cute_invocation_entries = {}
        with V.set_graph_handler(self.graph):
            self.op = ir.UserDefinedCuTeKernel(entry.key, self.source_box, self.destination_box)
            self.wrapper.lines.append(AllocateLine(self.wrapper, self.destination))
            self.op.codegen(self.wrapper)
        self.line = self.wrapper.lines[-1]

    def register_buffer(self, node):
        name = f"mutation_{len(self.buffers)}"
        self.buffers[name] = node
        return name

    def records(self):
        with V.set_graph_handler(self.graph):
            return collect_descriptors(self.wrapper)

    def state(self):
        env = self.environment
        return (tuple(env.guards), dict(env.replacements), dict(env.var_to_range),
                {key: tuple(value) for key, value in env.deferred_runtime_asserts.items()})

    def emit(self, records=None):
        records = self.records() if records is None else records
        code = IndentedBuffer()
        code.writeline("import torch")
        code.splice(self.wrapper.header)
        code.writeline("def call(box):")
        with code.indent():
            code.writeline(", ".join(self.graph.graph_input_names) + ("," if len(self.graph.graph_input_names) == 1 else "") + " = box")
            code.writeline("box.clear()")
            code.writeline("destination = torch.empty_like(source)")
            with V.set_graph_handler(self.graph):
                self.line.codegen(code)
            code.writeline("return (destination,)")
        emit_descriptors(code, "call", records)
        namespace = {}
        exec(compile(code.getvalue(), "<ordinary-cute-invocation>", "exec"), namespace)
        return namespace["call"], code.getvalue()


class TestCuTeInvocation(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(torch.no_grad())
        torch._dynamo.reset()
        self.addCleanup(torch._dynamo.reset)

    def entry(self, function=copy_source):
        entry = register_cpu_standin(function)
        self.addCleanup(entry.close)
        return entry

    def test_dense_exact_owned_destination(self):
        calls = []
        def implementation(source, destination):
            calls.append((source, destination))
            destination.copy_(source + 1)
        entry = self.entry(implementation)
        source, destination = torch.randn(3, 4), torch.empty(3, 4)
        self.assertIsNone(invoke_cute(entry.key, source, destination))
        self.assertEqual(destination, source + 1)
        self.assertEqual(len(calls), 1)
        self.assertIs(calls[0][0], source)
        self.assertIs(calls[0][1], destination)
        self.assertEqual(entry.kind, "cpu_standin")
        self.assertIs(resolve_entry(entry.key), entry)

    @parametrize("fault", ("missing", "closed", "key", "implementation", "fake"))
    def test_unavailable_or_changed_entry_declines(self, fault):
        entry = self.entry()
        if fault == "missing":
            with self.assertRaises(InvocationDeclined):
                resolve_entry("missing")
        elif fault == "closed":
            entry.close()
            with self.assertRaises(InvocationDeclined):
                resolve_entry(entry.key)
        elif fault == "key":
            with mock.patch.object(entry, "key", "foreign"), self.assertRaises(RuntimeError):
                entry.check()
        elif fault == "implementation":
            with mock.patch.dict(invoke_cute.py_kernels, {torch._C.DispatchKey.CompositeExplicitAutograd: lambda *a: None}), \
                    self.assertRaisesRegex(RuntimeError, "implementation"):
                check_implementation()
        else:
            from torch._higher_order_ops.utils import registered_hop_fake_fns
            with mock.patch.dict(registered_hop_fake_fns, {invoke_cute: lambda *a: None}), \
                    self.assertRaisesRegex(RuntimeError, "implementation"):
                check_implementation()

    def test_cute_provider_requires_actual_owner(self):
        with self.assertRaises(InvocationDeclined):
            register_cute_entry(SimpleNamespace(entry=copy_source))

    def test_real_cute_registration_binds_canonical_run_without_compilation(self):
        from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
        from cute_dispatch.fixtures import make_fixture
        from entry_signature import SignaturePolicy
        from ordinary_artifact_capture.owner import ObservedOrdinaryEntry

        python_entry, kernel, _ = make_fixture()
        layout = TensorPolicy((None, 128), (0, 1))
        owner = ObservedOrdinaryEntry(python_entry, kernel,
            policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout})
        self.addCleanup(owner.close)
        with mock.patch.object(owner, "run", side_effect=AssertionError("Instance run is not authority")) as override:
            entry = register_cute_entry(owner)
            self.addCleanup(entry.close)
            self.assertIs(entry.provider.run.__self__, owner)
            self.assertIs(entry.provider.run.__func__, OrdinaryEntry.run)
            self.assertIs(entry.provider.owner, owner)
            self.assertEqual(entry.kind, "cute")
            self.assertIs(resolve_entry(entry.key), entry)
            self.assertIsNone(owner.selected)
            override.assert_not_called()
        with mock.patch.object(entry.provider, "run", side_effect=AssertionError("Replacement run executed")) as replacement:
            OrdinaryEntry.close(owner)
            with self.assertRaisesRegex(RuntimeError, "closed"):
                entry.invoke(torch.ones(1), torch.empty(1))
            replacement.assert_not_called()
        entry.close()
        self.assertTrue(owner.closed)

    def test_emitted_call_keeps_sealed_provider_after_public_field_replacement(self):
        entry = self.entry()
        fixture = CompilerFixture(entry)
        original, _ = fixture.emit()
        def other(source, destination):
            raise AssertionError("Replacement provider executed")
        replacement = self.entry(other)
        provider = entry.provider
        with mock.patch.object(entry, "provider", replacement.provider), \
                mock.patch.object(provider, "close") as original_close, \
                mock.patch.object(replacement.provider, "close") as replacement_close:
            source = torch.randn(3, 4)
            result, = original([source])
            self.assertEqual(result, source + 1)
            with self.assertRaises(RuntimeError):
                bind_descriptors(original)
            entry.close()
            original_close.assert_called_once_with()
            replacement_close.assert_not_called()

    def test_entry_method_substitution_cannot_authorize_binding(self):
        entry = self.entry()
        with mock.patch.object(entry, "invoke", lambda *args: None), self.assertRaises(RuntimeError):
            resolve_entry(entry.key)

    def test_registry_is_weak_and_entry_is_not_transport(self):
        entry = register_cpu_standin(copy_source)
        key, weak = entry.key, weakref.ref(entry)
        with self.assertRaisesRegex(TypeError, "not cache transport"):
            pickle.dumps(entry)
        del entry
        gc.collect()
        self.assertIsNone(weak())
        with self.assertRaises(InvocationDeclined):
            resolve_entry(key)

    def test_failed_close_retains_registration_for_explicit_retry(self):
        entry = self.entry()
        error = RuntimeError("provider cleanup")
        with mock.patch.object(entry.provider, "close", side_effect=error) as close:
            with self.assertRaises(RuntimeError) as caught:
                entry.close()
            self.assertIs(caught.exception, error)
            self.assertEqual(close.call_count, 1)
            self.assertIs(resolve_entry(entry.key), entry)
            self.assertFalse(entry.closed)
        entry.close()
        self.assertTrue(entry.closed)

    def test_ordinary_failure_propagates_once(self):
        calls = []
        error = ValueError("ordinary implementation failure")
        def fail(source, destination):
            calls.append(1)
            raise error
        entry = self.entry(fail)
        with self.assertRaises(ValueError) as caught:
            invoke_cute(entry.key, torch.ones(2), torch.empty(2))
        self.assertIs(caught.exception, error)
        self.assertEqual(calls, [1])

    @parametrize("functional", (False, True))
    def test_fake_preserves_shapes_without_invocation(self, functional):
        def forbidden(source, destination):
            raise AssertionError("Fake execution called the stand-in")
        entry = self.entry(forbidden)
        with FakeTensorMode():
            source, destination = torch.empty(3, 4), torch.empty(3, 4)
            output = (invoke_cute_functional if functional else invoke_cute)(entry.key, source, destination)
            if functional:
                self.assertEqual(output.shape, destination.shape)
                self.assertIsNot(output, destination)
            else:
                self.assertIsNone(output)

    def test_proxy_and_functionalization_preserve_destination(self):
        entry = self.entry()
        def model(source, destination):
            invoke_cute(entry.key, source, destination)
            return source, destination
        source, destination = torch.randn(3, 4), torch.zeros(3, 4)
        graph = make_fx(torch.func.functionalize(model), tracing_mode="fake")(source, destination)
        calls = [node for node in graph.graph.nodes if node.target is invoke_cute_functional]
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0].args[0], entry.key)
        left, right = graph(source, destination)
        self.assertIs(left, source)
        self.assertEqual(right, source + 1)
        self.assertEqual(destination, right)

    @parametrize("backend", ("eager", "aot_eager"))
    def test_public_dynamo_and_aot_execute_standin_once(self, backend):
        calls = []
        def implementation(source, destination):
            calls.append(source.shape)
            destination.copy_(source + 1)
        entry = self.entry(implementation)
        key = entry.key
        def model(value):
            destination = torch.empty_like(value)
            invoke_cute(key, value, destination)
            return destination
        compiled = torch.compile(model, backend=backend, dynamic=True, fullgraph=True)
        for rows in (3, 7):
            source = torch.randn(rows, 4)
            self.assertEqual(compiled(source), source + 1)
        self.assertEqual(calls, [torch.Size((3, 4)), torch.Size((7, 4))])

    @parametrize("functional", (False, True))
    def test_actual_fx_and_aot_validators_bypass(self, functional):
        entry = self.entry()
        hop = invoke_cute_functional if functional else invoke_cute
        graph = torch.fx.Graph()
        source, destination = graph.placeholder("source"), graph.placeholder("destination")
        call = graph.call_function(hop, (entry.key, source, destination))
        graph.output(call if functional else destination)
        module = torch.fx.GraphModule({}, graph)
        self.assertFalse(hop.cacheable())
        with self.assertRaisesRegex(BypassFxGraphCache, "HigherOrderOperator"):
            CacheabilityValidator(module, require_shape_env=False).validate_graph(include_constants=False)
        with self.assertRaises(BypassAOTAutogradCache):
            check_node_safe(call)
        from torch._higher_order_ops.triton_kernel_wrap import triton_kernel_wrapper_mutation
        self.assertTrue(triton_kernel_wrapper_mutation.cacheable())

    @parametrize("kind", ("integer", "symbol"))
    def test_direct_scalar_host_operands_decline(self, kind):
        entry = self.entry()
        value = 7 if kind == "integer" else ShapeEnv().create_unbacked_symint()
        with self.assertRaisesRegex(InvocationDeclined, "scalar host operands"):
            invoke_cute(entry.key, value, torch.empty(3))

    @parametrize("dynamic", (False, True))
    def test_typed_ir_sources_mutation_and_emitted_call(self, dynamic):
        entry = self.entry()
        fixture = CompilerFixture(entry, dynamic)
        before = fixture.state()
        records = fixture.records()
        self.assertEqual(fixture.state(), before)
        self.assertIs(fixture.op.entry, entry)
        self.assertIs(fixture.op.inputs[0], fixture.source)
        self.assertIs(fixture.op.inputs[1], fixture.destination)
        self.assertEqual(fixture.mutated, ["destination"])
        self.assertEqual({row.name for row in fixture.op.get_read_writes().reads}, {"source", "destination"})
        self.assertEqual(fixture.op.mutation_outputs[0].get_mutation_names(), ["destination"])
        self.assertIs(type(fixture.line), CuTeCallLine)
        call, = records.calls
        self.assertEqual(call.formals, entry.formals)
        self.assertEqual(call.operands[0].source, InputSource(1 if dynamic else 0))
        self.assertEqual(call.operands[1].source, BufferSource("destination"))
        self.assertEqual(records.outputs, (BufferSource("destination"),))
        if dynamic:
            self.assertNotEqual(fixture.rows, fixture.columns)
            self.assertEqual(call.operands[0].size, (IntExpr("boxed", 2), IntExpr("boxed", 0)))
            self.assertEqual(call.operands[0].stride, (IntExpr("boxed", 0), 1))
        original, text = fixture.emit(records)
        self.assertIn(".invoke(source, destination)", text)
        binding = bind_descriptors(original)
        self.assertEqual(binding.records, records)
        self.assertEqual(binding.entries, (entry,))
        self.assertIsNone(original.__dict__.get("_cudagraph_call_records"))
        source = torch.randn(7, 7) if dynamic else torch.randn(3, 4)
        box = [7, source, 7] if dynamic else [source]
        result, = original(box)
        self.assertEqual(box, [])
        self.assertEqual(result, source + 1)
        binding.check()

    def test_lowering_uses_actual_typed_constructor(self):
        entry = self.entry()
        fixture = CompilerFixture(entry)
        count = len(fixture.operations)
        with V.set_graph_handler(fixture.graph):
            self.assertIsNone(lowering.cute_invocation(entry.key, fixture.source_box, fixture.destination_box))
        self.assertEqual(len(fixture.operations), count + 1)
        self.assertIs(type(fixture.operations[-1]), ir.UserDefinedCuTeKernel)
        self.assertIs(fixture.operations[-1].entry, entry)

    @parametrize("fault", ("same_name", "input_destination", "late_allocation", "foreign_operation", "output", "layout"))
    def test_compiler_source_substitution_declines(self, fault):
        fixture = CompilerFixture(self.entry())
        if fault == "same_name":
            fixture.op.inputs[0] = ir.InputBuffer(name="source", layout=fixture.source.get_layout())
        elif fault == "input_destination":
            fixture.op.inputs[1] = fixture.source
        elif fault == "late_allocation":
            fixture.wrapper.lines.reverse()
        elif fault == "foreign_operation":
            fixture.operations.remove(fixture.op)
        elif fault == "output":
            fixture.graph.graph_outputs = [ir.ComputedBuffer(name="destination", layout=fixture.destination.get_layout(), data=None)]
        else:
            fixture.destination.layout = ir.FixedLayout(torch.device("cpu"), torch.float32, (3, 4), (4, 1), offset=1)
        with self.assertRaises(DescriptorDeclined):
            fixture.records()

    def test_unknown_shape_origin_declines_without_guard_mutation(self):
        fixture = CompilerFixture(self.entry(), True)
        fixture.graph.graph_input_names.remove("rows")
        before = fixture.state()
        with self.assertRaises(DescriptorDeclined):
            fixture.records()
        self.assertEqual(fixture.state(), before)

    def test_simplified_unbacked_origin_declines(self):
        fixture = CompilerFixture(self.entry(), True)
        unbacked = fixture.environment.create_unbacked_symint().node.expr
        fixture.environment.replacements[fixture.rows] = unbacked
        before = fixture.state()
        with self.assertRaisesRegex(DescriptorDeclined, "boxed shape symbol"):
            fixture.records()
        self.assertEqual(fixture.state(), before)

    @parametrize("fault", ("short", "list"))
    def test_bound_entries_require_exact_complete_tuple(self, fault):
        fixture = CompilerFixture(self.entry())
        original, _ = fixture.emit()
        binding = bind_descriptors(original)
        entries = () if fault == "short" else list(binding.entries)
        malformed = descriptor.BoundCuTeCalls(original, binding.attachment, entries)
        with self.assertRaises(DescriptorDeclined):
            malformed.check()

    @parametrize("version", (0, True, 2))
    def test_unknown_optional_schema_keeps_ordinary_function(self, version):
        fixture = CompilerFixture(self.entry())
        original, _ = fixture.emit()
        namespace = dict(original.__globals__)
        exec("def other(box):\n    value, = box\n    box.clear()\n    return value\n", namespace)
        other = namespace["other"]
        attach_descriptors(other, replace(fixture.records(), version=version))
        source = torch.randn(2)
        box = [source]
        self.assertIs(other(box), source)
        self.assertEqual(box, [])
        with self.assertRaises(DescriptorDeclined):
            bind_descriptors(other)

    @parametrize("fault", ("global", "records", "code", "closed", "copied_attachment"))
    def test_cold_binding_checks_exact_callable_and_owner(self, fault):
        entry = self.entry()
        fixture = CompilerFixture(entry)
        original, _ = fixture.emit()
        binding = bind_descriptors(original)
        if fault == "global":
            original.__globals__[fixture.line.entry_global] = self.entry()
        elif fault == "records":
            original._cute_invocation_descriptors = replace(binding.records)
        elif fault == "code":
            def other(box):
                return box
            original.__code__ = other.__code__
        elif fault == "closed":
            entry.close()
        else:
            namespace = {}
            exec("def call(box):\n    return box\n", namespace)
            other = namespace["call"]
            other.__dict__.update(original.__dict__)
            with self.assertRaises(DescriptorDeclined):
                bind_descriptors(other)
            return
        with self.assertRaises((DescriptorDeclined, InvocationDeclined)):
            binding.check()

    def test_data_transport_does_not_retain_owner_or_tensors(self):
        entry = self.entry()
        fixture = CompilerFixture(entry)
        records = fixture.records()
        restored = pickle.loads(pickle.dumps(records))
        self.assertIs(type(restored), CuTeDescriptors)
        self.assertEqual(restored, records)
        original, _ = fixture.emit(restored)
        binding = bind_descriptors(original)
        source = torch.randn(3, 4)
        storage = StorageWeakRef(source.untyped_storage())
        result, = original([source])
        del source
        gc.collect()
        self.assertTrue(storage.expired())
        self.assertEqual(result.shape, (3, 4))
        weak = weakref.ref(original)
        del original
        gc.collect()
        self.assertIsNone(weak())
        with self.assertRaises(DescriptorDeclined):
            binding.check()
        with self.assertRaisesRegex(TypeError, "not cache transport"):
            pickle.dumps(binding)


instantiate_parametrized_tests(TestCuTeInvocation)

if __name__ == "__main__":
    run_tests()
