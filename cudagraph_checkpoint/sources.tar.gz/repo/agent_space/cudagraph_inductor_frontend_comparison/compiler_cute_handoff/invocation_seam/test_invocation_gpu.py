import gc
import json
import sys
from unittest import mock

import cutlass.cute as cute
from compiler_cute_handoff.descriptor import bind_descriptors
from compiler_cute_handoff.invocation import invoke_cute, register_cute_entry
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import SignaturePolicy
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._dynamo.utils import counters
from torch._inductor import config
from torch._inductor.runtime import cudagraph_prepare_from_warmed as preparation
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, InputSource, IntExpr
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase


class ObservingPolicy(NativeCUDAGraphPolicy):
    def __init__(self):
        super().__init__()
        self.artifacts = []

    def wrap_output(self, artifact):
        self.artifacts.append(artifact)
        return super().wrap_output(artifact)


class TestCuTeInvocation(TestCase):
    @parametrize("fast", (False, True))
    def test_owned_invocation(self, device, fast):
        fixture = fixture_module.TestReductionGraphReplayCUDA(f"test_generated_reduction_replay_fast_{fast}_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        policy = ObservingPolicy()
        self.addCleanup(policy.close)
        self.enterContext(config.patch(
            use_fast_triton_launcher=fast, cudagraph_policy=policy, fx_graph_cache=True,
            allow_buffer_reuse=False, inplace_buffers=False,
        ))
        self.enterContext(mock.patch.object(
            preparation, "prepare_from_warmed", side_effect=AssertionError("CuTe native handoff is not enabled")
        ))
        python_entry, kernel, _ = make_fixture()
        layout = TensorPolicy((None, 128), (0, 1))
        owner = ObservedOrdinaryEntry(
            python_entry, kernel, policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout},
        )
        self.addCleanup(owner.close)
        entry = register_cute_entry(owner)
        self.addCleanup(entry.close)
        self.assertIs(entry.provider.owner, owner)
        key = entry.key

        def model(value):
            source = value.sin()
            destination = torch.empty_like(source)
            invoke_cute(key, source, destination)
            return (destination,)

        compile_target, compile_calls = cute.compile, []
        invocations, borrowed = [], []
        run_code = OrdinaryEntry.run.__code__

        def observe_compile(target, *args, **kwargs):
            self.assertIs(target, python_entry.target)
            compile_calls.append(target)
            return compile_target(target, *args, **kwargs)

        def observe_run(frame, event, result):
            if event != "return" or frame.f_code is not run_code or frame.f_locals.get("self") is not owner:
                return
            if result is None:
                return
            source, destination = frame.f_locals["inputs"]
            self.assertIs(frame.f_locals["host"], entry.provider.host)
            self.assertEqual(source.shape, destination.shape)
            self.assertEqual(len(result.calls), 1)
            call, = result.calls
            self.assertIs(call.entry, python_entry)
            self.assertIs(call.arguments[0], source)
            self.assertIs(call.arguments[1], destination)
            invocations.append((source.shape[0], id(source), id(destination)))
            borrowed.extend((StorageWeakRef(source.untyped_storage()), StorageWeakRef(destination.untyped_storage())))

        self.enterContext(mock.patch.object(cute, "compile", observe_compile))
        previous_profile = sys.getprofile()
        self.assertIsNone(previous_profile)
        self.addCleanup(sys.setprofile, previous_profile)
        sys.setprofile(observe_run)
        warm = torch.randn((13, 128), device=device)
        torch._dynamo.mark_static(warm, 1)
        compiled = torch.compile(model, dynamic=True, fullgraph=True)
        input_storages, held = [], []
        selected, binding = None, None
        bypasses = counters["inductor"]["fxgraph_cache_bypass"]
        for batch in (13, 2, 7, 3):
            value = warm if batch == 13 else torch.randn((batch, 128), device=device)
            result, = compiled(value)
            expected = value.sin() * 2 + (64 if batch < 4 else 128)
            self.assertEqual(result, expected)
            self.assertEqual(len(policy.artifacts), 1)
            self.assertEqual(policy.installations, ())
            self.assertEqual(len(compile_calls), 1)
            if selected is None:
                selected = owner.selected
                artifact, = policy.artifacts
                binding = bind_descriptors(artifact.current_callable)
                self.assertEqual(len(binding.entries), 1)
                self.assertIs(binding.entries[0], entry)
                records = binding.records
                self.assertEqual(len(records.calls), 1)
                call, = records.calls
                self.assertEqual((call.entry_key, call.provider_kind, call.formals),
                                 (entry.key, "cute", entry.formals))
                inputs = [row for row in records.tensors if type(row.source) is InputSource]
                self.assertEqual(len(inputs), 1)
                self.assertEqual(len(records.integer_inputs), 1)
                dimension = IntExpr("boxed", records.integer_inputs[0].boxed_index)
                for fact in (*inputs, *call.operands):
                    self.assertEqual(fact.size, (dimension, 128))
                    self.assertEqual(fact.stride, (128, 1))
                    self.assertEqual(fact.dtype, torch.float32)
                    self.assertEqual(torch.device(fact.device), warm.device)
                self.assertIs(type(call.operands[0].source), BufferSource)
                self.assertIs(type(call.operands[1].source), BufferSource)
                self.assertNotEqual(call.operands[0].source, call.operands[1].source)
                self.assertEqual(records.outputs, (call.operands[1].source,))
            self.assertIsNotNone(binding)
            binding.check()
            self.assertIsNotNone(selected)
            self.assertIs(owner.selected, selected)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            held.append((result, expected))
            del result, expected, value
        self.assertIs(sys.getprofile(), observe_run)
        sys.setprofile(previous_profile)
        self.assertEqual([row[0] for row in invocations], [13, 2, 7, 3])
        self.assertGreater(counters["inductor"]["fxgraph_cache_bypass"], bypasses)
        self.assertFalse(invoke_cute.cacheable())
        self.assertIsNone(owner._calls)
        self.assertEqual(owner._capture.arguments, ())
        self.assertEqual(owner._capture.keywords, {})
        del warm
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        self.assertTrue(all(borrowed[index].expired() for index in range(0, len(borrowed), 2)))
        self.assertTrue(all(not borrowed[index].expired() for index in range(1, len(borrowed), 2)))
        entry.close()
        for output, expected in held:
            self.assertEqual(output, expected)
        del output, expected
        held.clear()
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in borrowed))
        print("CUTE_INVOCATION_RESULT=" + json.dumps({
            "fast": fast, "batches": [13, 2, 7, 3], "ordinary_compilations": len(compile_calls),
            "exact_owned_operands": True, "same_selected_callable": True,
            "single_compiled_artifact": True, "persistent_cache_bypassed": True,
            "symbolic_compiler_descriptors_checked": True, "buffer_reuse_disabled": True,
            "native_preparation_not_enabled": True, "input_and_temporary_storage_released": True,
            "held_outputs_correct_after_close": True, "output_storage_released": True,
        }, sort_keys=True))


instantiate_device_type_tests(TestCuTeInvocation, globals(), only_for=("cuda",))

if __name__ == "__main__":
    run_tests()
