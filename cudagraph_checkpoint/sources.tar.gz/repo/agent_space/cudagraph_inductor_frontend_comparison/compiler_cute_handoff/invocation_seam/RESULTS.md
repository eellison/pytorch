# Owned CuTe invocation through the compiler

Qualified: 467 CPU and 37 GPU cases passed, including 44 new CPU controls and
2 new real CuTe cases. Source and controller reviews were independent; the root
execution audit checked the same frozen inputs across all 19 processes.

The new public `torch.compile` cases run generated `sin`, a caller-owned output
allocation and an explicitly registered CuTe invocation. Both launcher modes
reuse one outer compiled artifact and one CuTe compilation across batches
13, 2, 7 and 3. Symbolic Tensor layouts, original boxed shape sources, exact
invocation operands and actual output projection pass. Input/temporary storage
is released; held outputs remain correct after close and release their storage
when dropped.

The implementation adds an inference-only invocation HOP, its typed compiler
operation and logical source descriptors. Fake execution and functionalization
preserve the invocation boundary. Generated modules retain the exact registered
entry; saved dispatch references prevent public diagnostic-field replacement
from changing the implementation. The existing FX and AOT cache validators
bypass these nonportable live entries.

The preceding 458 cases also pass with these hooks installed, including automatic
generated/user-Triton replay and both existing explicitly composed mixed
pipelines. Native binaries and the C++ replay path are unchanged.

This result establishes ordinary CuTe invocation through the compiler. Native
preparation for these new calls remains disabled. The positive GPU cases use
fresh row-major destinations with buffer reuse disabled. Direct aliases,
stride-changing views, scalar host formals, autograd, portable entry keys and
arbitrary device effects are outside this initial contract. There is no new
performance measurement or full-build/CI claim.

Next are the complete ordered mixed compiler program and the two-operand CuTe
symbolic trace, followed by native preparation and local variant installation.
The separate cold snapshot cleanup is not composed into this test manifest.

- [Design and API](DESIGN.md)
- [Source changes](source.diff)
- [Independent source review](source_independent_review.json)
- [Independent controller review](execution_independent_review.json)
- [Execution audit](evidence_review.json)
- [New GPU output](attempts/invocation_attempt1/output.log)
- [Native integration design](../NEXT_NATIVE.md)
