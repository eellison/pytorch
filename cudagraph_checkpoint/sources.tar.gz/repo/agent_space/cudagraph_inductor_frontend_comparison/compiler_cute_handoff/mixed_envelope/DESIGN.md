This candidate adds a complete logical compiler envelope for a generated Triton
prefix followed by one owned CuTe invocation. It copies the qualified invocation
wrapper and adds `compiler_cute_handoff.envelope`; the invocation, descriptor,
native preparer, policy and all predecessor files remain unchanged.

`collect_envelope(wrapper, descriptors)` runs while the final typed wrapper IR is
alive. It calls the existing compiler-input collector and independently collects
the CuTe descriptors again before accepting the supplied rows. The resulting
`MixedEnvelope` contains the canonical `InputContract`, those exact descriptors,
ordered allocation/alignment-copy/generated-call/CuTe/release events, and the
actual ordered fresh-output layouts. Its `generated_calls` and `allocations`
properties are projections of that event sequence. It never presents a partial
prefix as the complete `WrapperCallRecords` of the generated function.

The wrapper saves each generated call's exact scheduler `ComputedBuffer` group
in an optional `KernelCallLine.cudagraph_computations` field, only when the graph
contains a CuTe invocation. The collector requires those same objects in the
compiler graph, complete per-call argument/grid records from the existing
wrapper collector, and matching typed compiler read/write dependencies. All
nonempty computations must appear exactly once, and all external reads must
already be initialized in the actual call order. Fused internal values may stay
inside their one scheduler group; no source names are guessed from examples.
Missing typed associations decline. Ordinary generated wrappers keep the field
`None` and their existing record path.

An allocation does not initialize its contents. In particular, a generated clone
of an empty destination declines. Both terminal CuTe operands must already be
initialized, because the owned invocation's destination-mutation permission is
not proof that the device kernel writes every element before reading it. The
envelope preserves the compiler obligation; it does not duplicate or replace
the later selected-device effect analysis. A source-clone or other initialized
fresh destination can satisfy this first boundary. No write-only destination
optimization is introduced.

The supported compiler prefix may contain multiple generated calls and existing
pointwise/reduction computations. It retains the existing ordinary Python/CUDA,
single-stream, static-launcher and effect exclusions. It requires complete
zero-offset fixed allocation layouts, actual compiler normalization coverage,
and exact per-call sources. Reuse, aliases, input mutation, user Triton calls,
unknown host lines, missing computations, multiple/nonterminal CuTe calls and
nonfresh or uninitialized returned values decline. Declining this optional
envelope leaves ordinary wrapper emission and its existing CuTe descriptors
available. Unexpected collector and source-integrity failures propagate.

`emit_envelope` attaches the record separately from existing native metadata.
The emitted envelope refers to the function's exact already-attached CuTe
descriptor object. `bind_envelope(original_function)` returns
`BoundMixedEnvelope` with `.records`, `.inputs`, `.cute` and `.binding` (the
unchanged `BoundCuTeCalls`). `.check()` pins the original function/code, descriptor
attachment, envelope and InputContract identities, contents, generated kernel
globals and live CuTe registration. The binding holds no real input box or
compiler graph; the function reference is weak. Its logical record is data-only,
but the live binding cannot be serialized. The HOP's existing FX/AOT cache bypass
continues to apply. These compiler-emitted attachments assume the normal trusted
compiler emission path; manually attaching invented records is not a compiler
certificate.

The intended trace handoff is:

```python
bound = bind_envelope(original_function)
trace = trace_cute_invocation(bound.binding, bound.inputs, observed_box)
bound.check()
```

That trace remains a separate cold intermediate proof. Actual ordinary capsule
and ABI binding, selected pointer effects, local host guards, output projection
into native capture, owner borrowing and public policy installation are not
implemented here. There are no new native operations, host scalar formals,
partitioning or memory planning.

The 37 proposed CPU controls use actual typed compiler buffers, loop bodies,
ShapeEnv/SizeVarAllocator, scheduler-node identity and the existing per-call/input
collectors. They use real uncompiled CuTe registrations, but a minimal graph
fixture and emitted attachment-only function; no generated CUDA body or CuTe
compilation runs. They check complete multiple-call order, static/dynamic input
facts and original boxed slots, missing calls/arguments/copies, typed source and
allocation identity, uninitialized reads and destinations, outputs, source-owner
changes, transport and release of compiler IR. Root owns all framework execution
and the separate real public compiler-envelope/trace qualification.
