from dataclasses import replace
import gc
import pickle
from types import SimpleNamespace
from unittest import mock
import weakref

from compiler_cute_handoff import envelope
from compiler_cute_handoff.descriptor import collect_descriptors, emit_descriptors
from compiler_cute_handoff.envelope import (
    attach_envelope, bind_envelope, collect_envelope, emit_envelope, EnvelopeDeclined,
    GeneratedCall, Release,
)
from compiler_cute_handoff.invocation import register_cute_entry
from cute_dispatch.entry import TensorPolicy
from cute_dispatch.fixtures import make_fixture
from entry_signature import SignaturePolicy
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
import sympy
import torch
from torch._dynamo.source import LocalSource
from torch._inductor import config, ir
from torch._inductor.codegen.common import ArgName, SizeArg, TensorArg
from torch._inductor.codegen.wrapper import (
    AllocateLine, EnterDeviceContextManagerLine, ExitDeviceContextManagerLine,
    FreeLine, InputAlignmentLine, KernelCallLine, PythonWrapperCodegen, ReuseLine,
    TritonCallArgument,
)
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, ExpressionSource, InputSource, IntExpr, OwnedBuffer,
    pointwise_product,
)
from torch._inductor.scheduler import SchedulerNode
from torch._inductor.sizevars import SizeVarAllocator
from torch._inductor.utils import IndentedBuffer
from torch._inductor.virtualized import ops, V
from torch.fx.experimental.symbolic_shapes import DimDynamic, ShapeEnv
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
from torch.utils._sympy.numbers import int_oo


class CompilerFixture:
    def __init__(self, test, *, dynamic=True, extra_integer=False, initialized=True, return_prefix=False):
        python_entry, kernel, _ = make_fixture()
        layout_policy = TensorPolicy((None, 128), (0, 1))
        self.owner = ObservedOrdinaryEntry(python_entry, kernel,
            policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout_policy, "destination": layout_policy})
        self.entry = register_cute_entry(self.owner)
        test.addCleanup(self.entry.close)
        self.environment = ShapeEnv(duck_shape=False, specialize_zero_one=False)
        self.rows = self.environment.create_symbol(13, LocalSource("rows"), dynamic_dim=DimDynamic.DYNAMIC) if dynamic else 13
        self.other = self.environment.create_symbol(13, LocalSource("other"), dynamic_dim=DimDynamic.DYNAMIC) if extra_integer else None
        if dynamic:
            self.environment.constrain_symbol_range(self.rows, 1, int_oo)
            self.environment.evaluate_expr(sympy.Le(self.rows * 128, 2 ** 31 - 1))
        if extra_integer:
            self.environment.constrain_symbol_range(self.other, 1, int_oo)
        self.device = torch.device("cuda:0")
        self.layout = ir.FixedLayout(self.device, torch.float32, (self.rows, 128), (128, 1))
        self.source = ir.InputBuffer(name="source", layout=self.layout)
        self.prefix = self.computation("prefix", "source")
        self.destination = self.computation("destination", "prefix")
        self.empty = self.computation("empty_destination", None, empty=True) if not initialized else None
        if self.empty is not None:
            self.destination.data = self.computation("unused", "empty_destination").data
        self.buffers = {node.get_name(): node for node in (self.source, self.prefix, self.destination)}
        if self.empty is not None:
            self.buffers[self.empty.get_name()] = self.empty
        self.operations = [self.prefix, self.destination] if initialized else [self.prefix, self.empty, self.destination]
        inputs = {"source": ir.TensorBox.create(self.source)}
        if dynamic:
            inputs = {"rows": self.rows, **inputs}
        if extra_integer:
            inputs = {"other": self.other, **inputs}
        self.source_index = list(inputs).index("source")
        self.prefix_scheduler = SchedulerNode.__new__(SchedulerNode)
        self.prefix_scheduler.node = self.prefix
        self.output_scheduler = SchedulerNode.__new__(SchedulerNode)
        self.output_scheduler.node = self.destination
        scheduler = SimpleNamespace(current_node=self.prefix_scheduler,
            nodes=[self.prefix_scheduler, self.output_scheduler], current_stream_idx=0)
        outputs = [self.destination, self.prefix] if return_prefix else [self.destination]
        self.graph = SimpleNamespace(name="cpu_compiler_fixture", sizevars=SizeVarAllocator(self.environment),
            graph_inputs=inputs, graph_input_names=list(inputs), graph_outputs=outputs,
            current_node=SimpleNamespace(name="invocation"), cpp_wrapper=False, aot_mode=False,
            operations=self.operations, constants={}, partition_maps=[], effectful_ops={}, mutated_inputs=set(),
            inputs_to_check=[self.source_index], scheduler=scheduler, is_unspec_arg=lambda name: False,
            mark_buffer_mutated=lambda name: None, register_buffer=self.register_buffer,
            register_operation=self.operations.append, get_allocation_size=lambda node: node.get_size(),
            try_get_buffer=self.buffers.get, get_dtype=lambda name: self.buffers[name].get_dtype(),
            get_current_device_or_throw=lambda: self.device)
        self.wrapper = PythonWrapperCodegen.__new__(PythonWrapperCodegen)
        self.wrapper.lines = []
        self.wrapper.header = IndentedBuffer()
        self.wrapper.cute_invocation_entries = {}
        self.wrapper._collect_cute_prefix = True
        self.wrapper._multistream_alignment_copies = set()
        self.wrapper.args_to_buffers = {}
        with V.set_graph_handler(self.graph):
            self.op = ir.UserDefinedCuTeKernel(self.entry.key, ir.TensorBox.create(self.prefix),
                                              ir.TensorBox.create(self.destination))
            self.wrapper.lines.extend((EnterDeviceContextManagerLine(0, None), InputAlignmentLine("source")))
            self.wrapper.lines.append(AllocateLine(self.wrapper, self.prefix))
            self.prefix_call = self.call("prefix_kernel", self.source, self.prefix)
            scheduler.current_node = self.output_scheduler
            if self.empty is not None:
                self.wrapper.lines.append(AllocateLine(self.wrapper, self.empty))
            self.wrapper.lines.append(AllocateLine(self.wrapper, self.destination))
            self.output_call = self.call("clone_kernel", self.prefix if initialized else self.empty, self.destination)
            self.op.codegen(self.wrapper)
            self.cute_line = self.wrapper.lines[-1]
            self.wrapper.lines.append(FreeLine(self.wrapper, self.source))
            if not return_prefix:
                self.wrapper.lines.append(FreeLine(self.wrapper, self.prefix))
            self.wrapper.lines.append(ExitDeviceContextManagerLine())

    def computation(self, name, source, empty=False):
        def body(index):
            if source is None:
                return ops.constant(0, torch.float32)
            return ops.sin(ops.load(source, index[0] * 128 + index[1]))
        data = ir.Pointwise(device=self.device, dtype=torch.float32, inner_fn=body,
                            ranges=(0, 0) if empty else (self.rows, 128))
        return ir.ComputedBuffer(name=name, layout=self.layout, data=data)

    def register_buffer(self, node):
        name = f"mutation_{len(self.buffers)}"
        self.buffers[name] = node
        return name

    def call(self, name, source, destination):
        names = ("in_ptr0", "out_ptr0", "xnumel")
        arguments = (source.get_name(), destination.get_name(), self.rows * 128)
        signatures = (TensorArg(names[0], arguments[0], torch.float32),
                      TensorArg(names[1], arguments[1], torch.float32), SizeArg(names[2], arguments[2]))
        self.wrapper.generate_kernel_call(name, arguments, device=self.device, arg_types=[], raw_keys=(), raw_args=(),
            triton_meta={"signature": dict(zip(names, ("*fp32", "*fp32", "i32"))), "constants": {}},
            inductor_meta={"grid_type": "Grid1D", "cudagraph_formal_indices": dict(zip(names, range(3))),
                "cudagraph_parameter_provenance": {names[0]: (arguments[0], False, 16), names[1]: (arguments[1], True, 16)}},
            original_fxnode_name=name, cudagraph_args=tuple(TritonCallArgument(ArgName(formal), signature)
                                                          for formal, signature in zip(names, signatures)))
        return self.wrapper.lines[-1]

    def collect(self, descriptors=None):
        with V.set_graph_handler(self.graph):
            if descriptors is None:
                descriptors = collect_descriptors(self.wrapper)
            return collect_envelope(self.wrapper, descriptors)

    def state(self):
        env = self.environment
        return (tuple(env.guards), dict(env.replacements), dict(env.var_to_range),
                {key: tuple(value) for key, value in env.deferred_runtime_asserts.items()})

    def emit(self, records=None):
        records = self.collect() if records is None else records
        code = IndentedBuffer()
        code.writeline("import torch")
        code.splice(self.wrapper.header)
        code.writeline("def call(box):")
        with code.indent():
            code.writeline("raise AssertionError('CPU source fixture must not execute the generated CUDA wrapper')")
        emit_descriptors(code, "call", records.cute)
        emit_envelope(code, "call", records)
        kernels = {call.kernel_global: object() for call in records.generated_calls}
        exec(compile(code.getvalue(), "<mixed-compiler-envelope>", "exec"), kernels)
        return kernels["call"], code.getvalue()


@instantiate_parametrized_tests
class TestMixedCompilerEnvelope(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    @parametrize("dynamic", (False, True))
    def test_complete_order_and_actual_outputs(self, dynamic):
        fixture = CompilerFixture(self, dynamic=dynamic, return_prefix=True)
        before = fixture.state()
        records = fixture.collect()
        self.assertEqual(fixture.state(), before)
        self.assertEqual(len(records.generated_calls), 2)
        self.assertEqual([type(event).__name__ for event in records.events],
            ["AlignmentCopy", "OwnedBuffer", "GeneratedCall", "OwnedBuffer", "GeneratedCall", "CuTeCall", "Release"])
        self.assertEqual(tuple(row.source for row in records.outputs), (BufferSource("destination"), BufferSource("prefix")))
        self.assertEqual(records.cute.outputs, tuple(row.source for row in records.outputs))
        first, second = [event for event in records.events if type(event) is GeneratedCall]
        self.assertEqual(first.operations, ("prefix",))
        self.assertEqual(first.reads, (InputSource(fixture.source_index),))
        self.assertEqual(first.writes, second.reads)
        self.assertEqual(second.writes, (BufferSource("destination"),))
        self.assertIs(fixture.prefix_call.cudagraph_computations[0], fixture.prefix)
        self.assertIs(fixture.output_call.cudagraph_computations[0], fixture.destination)
        if dynamic:
            self.assertEqual(first.record.arguments[-1].source,
                             ExpressionSource(pointwise_product((IntExpr("boxed", 0), 128))))
        self.assertIsNone(fixture.owner.selected)

    def test_independent_equal_hints_keep_original_boxed_slots(self):
        fixture = CompilerFixture(self, extra_integer=True)
        before = fixture.state()
        records = fixture.collect()
        self.assertEqual(records.inputs.kinds, ("integer", "integer", "tensor"))
        self.assertEqual(records.inputs.tensor_inputs[0].size, (IntExpr("boxed", 1), 128))
        self.assertEqual(tuple(row.index for row in records.inputs.integer_ranges), (0, 1))
        self.assertEqual(records.generated_calls[0].arguments[-1].source,
                         ExpressionSource(pointwise_product((IntExpr("boxed", 1), 128))))
        self.assertNotEqual(fixture.rows, fixture.other)
        self.assertEqual(fixture.state(), before)

    @parametrize("fault", ("missing_call", "missing_argument", "missing_copy", "late_copy", "wrong_source", "missing_group", "duplicate_group"))
    def test_incomplete_or_changed_prefix_declines(self, fault):
        fixture = CompilerFixture(self)
        before = fixture.state()
        line = fixture.prefix_call
        if fault == "missing_call":
            fixture.wrapper.lines.remove(line)
        elif fault == "missing_argument":
            line.call_args = line.call_args[1:]
            line.cudagraph_args = line.cudagraph_args[1:]
        elif fault == "missing_copy":
            fixture.wrapper.lines = [line for line in fixture.wrapper.lines if type(line) is not InputAlignmentLine]
        elif fault == "late_copy":
            copy = next(line for line in fixture.wrapper.lines if type(line) is InputAlignmentLine)
            fixture.wrapper.lines.remove(copy)
            fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.output_call), copy)
        elif fault == "wrong_source":
            line = fixture.output_call
            line.call_args = ("source", *line.call_args[1:])
            line.cudagraph_args = (TritonCallArgument(ArgName("in_ptr0"), TensorArg("in_ptr0", "source", torch.float32)), *line.cudagraph_args[1:])
            line.inductor_meta["cudagraph_parameter_provenance"]["in_ptr0"] = ("source", False, 16)
        elif fault == "missing_group":
            line.cudagraph_computations = None
        else:
            fixture.output_call.cudagraph_computations = line.cudagraph_computations
        with self.assertRaises(EnvelopeDeclined):
            fixture.collect()
        self.assertEqual(fixture.state(), before)

    def test_uninitialized_clone_cannot_be_authorized_by_terminal_write(self):
        fixture = CompilerFixture(self, initialized=False)
        with self.assertRaisesRegex(EnvelopeDeclined, "uninitialized"):
            fixture.collect()

    @parametrize("boundary", ("compiler", "transport"))
    def test_destination_mutation_does_not_prove_complete_initialization(self, boundary):
        fixture = CompilerFixture(self)
        if boundary == "compiler":
            fixture.wrapper.lines.remove(fixture.output_call)
            fixture.destination.data = replace(fixture.destination.data, ranges=(0, 0))
            with self.assertRaisesRegex(EnvelopeDeclined, "initialization"):
                fixture.collect()
        else:
            records = fixture.collect()
            records = replace(records, events=tuple(event for event in records.events
                if not (type(event) is GeneratedCall and event.record.kernel_global == "clone_kernel")))
            with self.assertRaisesRegex(EnvelopeDeclined, "initialized"):
                envelope._check_envelope(records)

    @parametrize("fault", ("same_name_node", "changed_read", "wrong_extent", "source_write", "missing_allocation"))
    def test_typed_computation_and_allocation_correspondence(self, fault):
        fixture = CompilerFixture(self)
        if fault == "same_name_node":
            fixture.prefix_call.cudagraph_computations = (fixture.computation("prefix", "source"),)
        elif fault == "changed_read":
            fixture.destination.data = fixture.computation("unused", "source").data
        elif fault == "wrong_extent":
            fixture.prefix.data = replace(fixture.prefix.data, ranges=(1, 128))
        elif fault == "source_write":
            fixture.prefix_call.inductor_meta["cudagraph_parameter_provenance"]["in_ptr0"] = ("source", True, 16)
        else:
            fixture.wrapper.lines = [line for line in fixture.wrapper.lines
                                     if not (type(line) is AllocateLine and line.node is fixture.prefix)]
        with self.assertRaises((EnvelopeDeclined, envelope.DescriptorDeclined)):
            fixture.collect()

    @parametrize("fault", ("source", "output", "integer", "layout"))
    def test_passed_descriptor_cannot_replace_live_compiler_facts(self, fault):
        fixture = CompilerFixture(self)
        with V.set_graph_handler(fixture.graph):
            records = collect_descriptors(fixture.wrapper)
        if fault == "source":
            call = records.calls[0]
            input_fact = next(row for row in records.tensors if type(row.source) is InputSource)
            records = replace(records, calls=(replace(call, operands=(input_fact, call.operands[1])),))
        elif fault == "output":
            records = replace(records, outputs=(BufferSource("prefix"),))
        elif fault == "integer":
            records = replace(records, integer_inputs=())
        else:
            records = replace(records, tensors=(replace(records.tensors[0], size=(17, 128)), *records.tensors[1:]))
        with self.assertRaisesRegex(EnvelopeDeclined, "live compiler sources"):
            fixture.collect(records)

    @parametrize("fault", ("later_call", "reuse", "unknown_line", "unknown_operation", "output_alias", "output_released"))
    def test_unsupported_order_or_output_declines(self, fault):
        fixture = CompilerFixture(self)
        if fault == "later_call":
            line = fixture.output_call
            fixture.wrapper.lines.remove(line)
            fixture.wrapper.lines.insert(fixture.wrapper.lines.index(fixture.cute_line) + 1, line)
        elif fault == "reuse":
            fixture.wrapper.lines.insert(2, ReuseLine(fixture.wrapper, fixture.prefix, fixture.destination))
        elif fault == "unknown_line":
            fixture.wrapper.lines.insert(2, "unrecorded_host_call()")
        elif fault == "unknown_operation":
            fixture.operations.append(object())
        elif fault == "output_alias":
            fixture.graph.graph_outputs = [fixture.destination, fixture.destination]
        else:
            fixture.wrapper.lines.insert(-1, FreeLine(fixture.wrapper, fixture.destination))
        with self.assertRaises((EnvelopeDeclined, envelope.DescriptorDeclined)):
            fixture.collect()

    def test_emitted_binding_preserves_exact_shared_contract_and_descriptors(self):
        fixture = CompilerFixture(self)
        original, source = fixture.emit()
        bound = bind_envelope(original)
        bound.check()
        self.assertIs(bound.records, original._cute_mixed_envelope)
        self.assertIs(bound.inputs, bound.records.inputs)
        self.assertIs(bound.cute, original._cute_invocation_descriptors)
        self.assertIs(bound.binding.records, bound.cute)
        self.assertIs(bound.binding.function(), original)
        self.assertIs(bound.binding.entries[0], fixture.entry)
        self.assertIn("call._cute_invocation_descriptors", source)
        with self.assertRaises(TypeError):
            pickle.dumps(bound)
        self.assertIsNone(fixture.owner.selected)

    @parametrize("fault", ("kernel", "code", "descriptor", "envelope", "contract", "closed"))
    def test_cold_binding_rejects_source_and_owner_changes(self, fault):
        fixture = CompilerFixture(self)
        original, _ = fixture.emit()
        bound = bind_envelope(original)
        if fault == "kernel":
            original.__globals__[bound.records.generated_calls[0].kernel_global] = object()
        elif fault == "code":
            namespace = {}
            exec("def call(box):\n    return ()\n", namespace)
            original.__code__ = namespace["call"].__code__
        elif fault == "descriptor":
            original._cute_invocation_descriptors = replace(bound.cute)
        elif fault == "envelope":
            original._cute_mixed_envelope = replace(bound.records)
        elif fault == "contract":
            bound.inputs = replace(bound.inputs)
        else:
            fixture.entry.close()
        with self.assertRaises((EnvelopeDeclined, envelope.DescriptorDeclined)):
            bound.check()

    def test_transport_and_binding_do_not_retain_compiler_ir(self):
        fixture = CompilerFixture(self)
        records = fixture.collect()
        restored = pickle.loads(pickle.dumps(records))
        self.assertEqual(restored, records)
        original, _ = fixture.emit(records)
        bound = bind_envelope(original)
        references = [weakref.ref(fixture.environment), weakref.ref(fixture.prefix), weakref.ref(fixture.wrapper)]
        del fixture, records, restored
        # ShapeEnv memoizers retain their instance independently of compiler records.
        for method in vars(ShapeEnv).values():
            clear = getattr(method, "cache_clear", None)
            if clear is not None:
                clear()
        gc.collect()
        self.assertTrue(all(reference() is None for reference in references))
        bound.check()
        function = weakref.ref(original)
        del original
        gc.collect()
        self.assertIsNone(function())
        with self.assertRaisesRegex(EnvelopeDeclined, "expired"):
            bound.check()

    def test_typed_decline_does_not_hide_unexpected_collector_error(self):
        fixture = CompilerFixture(self)
        error = ValueError("unexpected compiler failure")
        with mock.patch.object(fixture.prefix, "get_read_writes", side_effect=error):
            with self.assertRaises(ValueError) as caught:
                fixture.collect()
        self.assertIs(caught.exception, error)


if __name__ == "__main__":
    run_tests()
