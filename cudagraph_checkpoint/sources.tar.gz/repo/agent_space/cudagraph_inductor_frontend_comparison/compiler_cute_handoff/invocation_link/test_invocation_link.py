from dataclasses import replace
import gc
from threading import Lock
from types import SimpleNamespace
from unittest import mock
import weakref

from cfg_values import read_cfg_function
from compiler_cute_handoff.envelope import bind_envelope, GeneratedCall, Release
from cute_bridge import preparation
from cute_bridge.lowering import _bind_compiler_program, _Operands, link_cute_invocation
from cute_bridge.numeric import Comparison
from cute_bridge.provider import CuTeKernelOwner, PointerEffect, SitePointerEffects
from cute_bridge.tracing import trace_cute_invocation
from cudagraph_cute_runtime.artifact import (
    ArtifactSite, ConstantProperty, Consumer, FieldSource, Formal, IntegerField,
    Leaf, NodeFields, Padding, Parameter, PointerField,
)
from cutlass._mlir import ir as mlir
from decoded_values import prepare_decodings
from entry_signature import build_entry_signature
from host_program import Allocate, Normalize
from invocation_link_envelope_fixture import CompilerFixture
from overflow_properties import bind_properties
from owned_numeric import freeze_numeric
from selected_kernel import SelectedKernel
import torch
from torch._inductor import config
from torch._inductor.runtime.cudagraph_arg_mapping import (
    AlignmentCopy, BufferSource, ExpressionSource, InputSource,
    IntExpr, LauncherArgument, pointwise_product,
)
from torch._inductor.runtime.cudagraph_launch_association import UnsupportedCapture
from torch._inductor.runtime.static_triton_launcher import StaticallyLaunchedCudaKernel
from torch._inductor.runtime.triton_heuristics import CachingAutotuner
from torch.testing._internal.common_utils import instantiate_parametrized_tests, parametrize, run_tests, TestCase
from user_triton.linking import _Expressions, GeneratedProvider, LinkDeclined


def freeze(source, order):
    with mlir.Context(), mlir.Location.unknown(), mlir.raw_values():
        module = mlir.Module.parse(source)
        if not module.operation.verify():
            raise AssertionError("Expected valid numeric fixture IR")
        cfg = read_cfg_function(module, "probe")
        return freeze_numeric(bind_properties(cfg), prepare_decodings(cfg), order)


class SchemaArtifact:
    """Real signature and numeric CFGs; synthetic ABI, no compiled CuTe binary."""

    def __init__(self, signature, *, destination_read=False, source_write=False):
        self.signature = signature
        typ = "!llvm.struct<(ptr<1>, i32, i64)>"
        formals, pointers, integers, effects, parameters = [], [], [], [], []
        for index, (name, source_index) in enumerate((("source", 5), ("destination", 9))):
            leaves = (Leaf((0,), "!llvm.ptr<1>", "pointer", (), 0, 8, 8),
                      Leaf((1,), "i32", "shape", (0,), 8, 4, 4),
                      Leaf((2,), "i64", "stride", (0,), 16, 8, 8))
            formals.append(Formal(source_index, index, index, name, (index,), "Tensor", typ, typ,
                (("symbol", index), ("constant", 128)), (("constant", 128), ("constant", 1)),
                ("f32", 32, 1), ("f32", 32, 1), "global", 0, 16, 24, 8, leaves,
                (ConstantProperty("shape", (1,), "i32", 128, 4),
                 ConstantProperty("stride", (1,), "i64", 1, 8))))
            origins = tuple(FieldSource("tensor_property", source_index, name, (index,), leaf.property,
                                         leaf.property_path, leaf.llvm_type, leaf.path) for leaf in leaves)
            pointers.append(PointerField(index, 0, origins[0]))
            integers.extend((IntegerField(index, 8, "i32", origins[1]), IntegerField(index, 16, "i64", origins[2])))
            effects.append(PointerEffect(index, 0, origins[0], index, "!llvm.ptr<1>", 16,
                                         index == 0 or destination_read, index == 1 or source_write))
            parameters.append(Parameter(index, typ, source_index, index, 24, 8))
        self.formals = tuple(formals)
        rows = freeze(f'''module {{ llvm.func @probe(%arg: {typ}) -> i32 {{
          %rows = llvm.extractvalue %arg[1] : {typ}
          llvm.return %rows : i32
        }} }}''', (5,))
        one = freeze('''module { llvm.func @probe(%unused: !llvm.ptr) -> i32 {
          %one = llvm.mlir.constant(1 : i32) : i32
          llvm.return %one : i32
        } }''', (5,))
        predicate = freeze(f'''module {{ llvm.func @probe(%arg: {typ}) -> i1 {{
          %rows = llvm.extractvalue %arg[1] : {typ}
          %four = llvm.mlir.constant(4 : i32) : i32
          %small = llvm.icmp "slt" %rows, %four : i32
          llvm.return %small : i1
        }} }}''', (9,))
        self.consumers = tuple(Consumer(index, f"grid_{index}", 0, "grid", index, "i32", (5,), numeric)
                               for index, numeric in enumerate((rows, one, one))) + (
            Consumer(3, "predicate", None, "predicate", 0, "i1", (9,), predicate),)
        fields = NodeFields(0, "cpu_schema", (24, 24), tuple(pointers), tuple(integers), (),
                            (Padding(0, 12, 4), Padding(1, 12, 4)))
        self.site = ArtifactSite(0, True, 0, ("cpu_schema",), None, tuple(parameters), fields,
                                 (0, 1, 2), (), 2, ())
        certificate = object.__new__(SitePointerEffects)
        values = tuple(effects)
        for name, value in (("_artifact", self), ("_site", self.site), ("_fields", values),
                            ("_seal", (self, self.site, values))):
            object.__setattr__(certificate, name, value)
        self.effects = certificate

    def check_site(self, site):
        if site is not self.site:
            raise RuntimeError("CPU schema site changed")
        self.signature.check()
        for consumer in self.consumers:
            consumer.numeric.check()


class SchemaLoader:
    """Supply only loader checks/close; no driver or real resource lifetime."""

    def __init__(self, artifact):
        self.artifact = artifact
        self.closed = False
        self._graphs = set()

    def check(self):
        if self.closed:
            raise RuntimeError("CPU schema loader is closed")
        self.artifact.check_site(self.artifact.site)

    def close(self):
        self.closed = True


def generated_provider(test, record, names, *, input_write=False):
    module = StaticallyLaunchedCudaKernel.__new__(StaticallyLaunchedCudaKernel)
    module.function, module.module = 31, 17
    module.functions, module.modules = {}, {}
    module.device_agnostic, module._has_tensordesc = False, False
    module._graph_borrows = 0
    module.arg_tys = "OOi"
    module.has_global_scratch = module.has_profile_scratch = False
    module.global_scratch_size = module.profile_scratch_size = 0
    module.C_impl = SimpleNamespace(_unload_kernel=mock.Mock())
    test.addCleanup(module.close)
    namespace = {"runner": module.run}
    exec("def launcher(x, out, n, *, stream):\n    raise AssertionError('CPU fixture cannot launch')\n", namespace)
    launcher = namespace["launcher"]
    launcher._cudagraph_arg_info = tuple(LauncherArgument(row.formal, row.source_arg_index,
        row.call_arg_index, row.triton_type, index, None) for index, row in enumerate(record.arguments))
    launcher._cudagraph_grid_recipe = (IntExpr("ceildiv", args=(IntExpr("formal", "xnumel"),
        IntExpr("constant", 128))), IntExpr("constant", 1), IntExpr("constant", 1))
    launcher._expected_positional_count = len(record.arguments)
    launcher._is_static = True
    launcher.config = SimpleNamespace(pre_hook=None, ir_override=None)
    kernel = CachingAutotuner.__new__(CachingAutotuner)
    kernel.launchers, kernel._cached_launcher = [launcher], launcher
    kernel._cache_eligible, kernel._plugins = True, ()
    provenance = {}
    for index, row in enumerate(record.arguments[:2]):
        name = names[row.source.index] if type(row.source) is InputSource else row.source.name
        provenance[row.formal] = (name, index == 1 or input_write, 16)
    kernel.inductor_meta = {"grid_type": "Grid1D", "cudagraph_parameter_provenance": provenance}
    return GeneratedProvider(SelectedKernel.from_warmed(kernel))


@instantiate_parametrized_tests
class TestCompilerCuTeLink(TestCase):
    def setUp(self):
        super().setUp()
        self.enterContext(torch.no_grad())
        self.enterContext(config.patch(graph_partition=False, use_static_triton_launcher=True))
        self.assertFalse(torch.cuda.is_initialized())

    def tearDown(self):
        self.assertFalse(torch.cuda.is_initialized())
        super().tearDown()

    def fixture(self, *, return_prefix=True, extra_integer=False, missing_copy=False, dynamic=True,
                destination_read=False, source_write=False, input_write=False, pointer_dtype=False):
        compiler = CompilerFixture(self, return_prefix=return_prefix, extra_integer=extra_integer, dynamic=dynamic)
        records = compiler.collect()
        if missing_copy:
            records = replace(records, events=tuple(event for event in records.events if type(event) is not AlignmentCopy))
        if pointer_dtype:
            first = next(event for event in records.events if type(event) is GeneratedCall)
            record = replace(first.record, arguments=(replace(first.record.arguments[0], triton_type="*fp64"),
                                                      *first.record.arguments[1:]))
            records = replace(records, events=tuple(replace(first, record=record) if event is first else event
                                                    for event in records.events))
        generated = tuple(generated_provider(self, call, records.cute.input_names,
            input_write=input_write and index == 0) for index, call in enumerate(records.generated_calls))
        _, source = compiler.emit(records)
        namespace = {row.kernel_global: provider.selection.identity[0]
                     for row, provider in zip(records.generated_calls, generated)}
        namespace["copy_if_misaligned"] = torch._C._dynamo.guards.copy_if_misaligned
        exec(compile(source, "<compiler-invocation-link-fixture>", "exec"), namespace)
        function = namespace["call"]
        checked = bind_envelope(function)
        box = [13 if kind == "integer" else torch.empty(1) for kind in checked.inputs.kinds]
        trace = trace_cute_invocation(checked.binding, checked.inputs, box)
        signature = build_entry_signature(trace, trace.calls[0], policy=compiler.owner.policy)
        artifact = SchemaArtifact(signature, destination_read=destination_read, source_write=source_write)
        owner = CuTeKernelOwner.__new__(CuTeKernelOwner)
        owner._artifact, owner._site = artifact, artifact.site
        owner._block, owner._shared = (128, 1, 1), 0
        owner._lock, owner._phase = Lock(), "ready"
        owner._loader = SchemaLoader(artifact)
        owner._kernel = SimpleNamespace(function=19, parameter_layout=((0, 24), (24, 24)))
        owner._owners = owner._state()
        self.addCleanup(owner.close)
        providers = {row.kernel_global: provider for row, provider in zip(records.generated_calls, generated)}
        providers["user_cute"] = owner
        return SimpleNamespace(compiler=compiler, function=function, checked=checked, box=box,
            trace=trace, artifact=artifact, owner=owner, effects=artifact.effects,
            generated=generated, providers=providers)

    def link(self, fixture):
        return link_cute_invocation(fixture.checked, fixture.trace, fixture.generated, fixture.owner, fixture.effects)

    @parametrize("return_prefix", (False, True))
    def test_real_projection_keeps_compiler_allocations_outputs_and_releases(self, return_prefix):
        fixture = self.fixture(return_prefix=return_prefix)
        records = fixture.checked.records
        linked = self.link(fixture)
        program = linked.program
        self.assertIs(program.outputs, records.outputs)
        self.assertEqual(program.allocations, records.allocations)
        self.assertEqual(len(program.calls), len(records.generated_calls) + 1)
        self.assertEqual(sum(type(event) is Allocate for event in program.events), len(records.allocations))
        self.assertTrue(any(type(event) is Release for event in records.events))
        self.assertFalse(any(type(event) is Release for event in program.events))
        self.assertEqual(sum(type(event) is Normalize for event in program.events), len(program.copies))
        pointers = [field.source for field in program.calls[-1].bound.fields if field.kind == "pointer"]
        self.assertEqual(pointers, [row.source for row in fixture.trace.descriptor.operands])
        context = _bind_compiler_program(program, fixture.providers, fixture.checked)
        plan = preparation._validate(program, fixture.providers, fixture.box, compiler=context)
        self.assertEqual(len(plan.calls), 3)
        self.assertEqual(tuple(plan.calls[-1].grid), (13, 1, 1))
        self.assertEqual(tuple(program.allocations[index] for index in plan.outputs), records.outputs)

    def test_equal_hints_preserve_the_actual_boxed_origin(self):
        fixture = self.fixture(extra_integer=True)
        linked = self.link(fixture)
        origin = fixture.checked.inputs.tensor_inputs[0].size[0]
        self.assertEqual(origin, IntExpr("boxed", 1))
        dynamic = [field for field in linked.program.calls[-1].bound.fields if type(field.source) is ExpressionSource]
        self.assertEqual([field.source.expression for field in dynamic], [origin, origin])
        self.assertEqual(linked.predicate.expression, Comparison("slt", "i32", origin, IntExpr("constant", 4)))
        self.assertEqual(linked.program.calls[-1].bound.grid[0], origin)
        self.assertEqual(tuple(row.boxed_index for row in linked.program.integer_inputs), (0, 1))

    def test_old_path_still_rejects_initialized_prefix_writes(self):
        fixture = self.fixture()
        program = self.link(fixture).program
        with self.assertRaisesRegex(UnsupportedCapture, "writes into its prefix"):
            preparation._validate(program, fixture.providers, fixture.box)

    def test_destination_read_needs_existing_compiler_initialization(self):
        fixture = self.fixture(destination_read=True)
        program = self.link(fixture).program
        context = _bind_compiler_program(program, fixture.providers, fixture.checked)
        plan = preparation._validate(program, fixture.providers, fixture.box, compiler=context)
        self.assertEqual(plan.calls[-1].bound.module, fixture.owner)
        missing = replace(program, events=tuple(event for event in program.events if not (
            hasattr(event, "provider_key") and event.provider_key == "clone_kernel")))
        with self.assertRaises(LinkDeclined):
            _bind_compiler_program(missing, fixture.providers, fixture.checked)

    @parametrize("fault", ("source_write", "input_write", "missing_copy", "pointer_dtype"))
    def test_independent_effect_or_normalization_mismatch(self, fault):
        fixture = self.fixture(**{fault: True})
        with self.assertRaises(LinkDeclined):
            self.link(fixture)

    @parametrize("fault", ("outputs", "pointer_swap", "sampled_grid", "missing_copy", "extra_allocation"))
    def test_changed_program_declines_before_graph_creation(self, fault):
        fixture = self.fixture()
        program = self.link(fixture).program
        if fault == "outputs":
            program = replace(program, outputs=tuple(reversed(program.outputs)))
        elif fault in ("pointer_swap", "sampled_grid"):
            call = program.calls[-1]
            if fault == "pointer_swap":
                fields = list(call.bound.fields)
                indices = [index for index, row in enumerate(fields) if row.kind == "pointer"]
                left, right = indices
                fields[left], fields[right] = (replace(fields[left], source=fields[right].source),
                                              replace(fields[right], source=fields[left].source))
                bound = replace(call.bound, fields=tuple(fields))
            else:
                bound = replace(call.bound, grid=(IntExpr("constant", 13), *call.bound.grid[1:]))
            program = replace(program, events=tuple(replace(call, bound=bound) if event is call else event
                                                   for event in program.events))
        elif fault == "missing_copy":
            program = replace(program, copies=(), events=tuple(event for event in program.events if type(event) is not Normalize))
        else:
            layout = replace(program.allocations[0], source=BufferSource("unrecorded"))
            program = replace(program, allocations=(*program.allocations, layout))
        with mock.patch.object(torch.cuda, "CUDAGraph", side_effect=AssertionError("Invalid projection reached CUDA")) as create:
            with self.assertRaises(LinkDeclined):
                preparation.prepare_variant(program, fixture.providers, fixture.box, compiler_binding=fixture.checked)
            create.assert_not_called()

    @parametrize("fault", ("foreign_binding", "foreign_effects", "foreign_provider", "kernel_global", "normalizer"))
    def test_equal_metadata_does_not_replace_source_authority(self, fault):
        fixture = self.fixture()
        if fault in ("foreign_binding", "foreign_effects", "foreign_provider"):
            other = self.fixture()
            if fault == "foreign_binding":
                fixture.checked = other.checked
            elif fault == "foreign_effects":
                fixture.effects = other.effects
            else:
                fixture.generated = other.generated
        elif fault == "kernel_global":
            fixture.function.__globals__["prefix_kernel"] = object()
        else:
            fixture.function.__globals__["copy_if_misaligned"] = lambda value: value
        with self.assertRaises(ValueError):
            self.link(fixture)

    @parametrize("fault", ("closed_owner", "closed_entry", "provider_map", "kernel_global"))
    def test_transaction_rechecks_live_sources(self, fault):
        fixture = self.fixture()
        program = self.link(fixture).program
        context = _bind_compiler_program(program, fixture.providers, fixture.checked)
        if fault == "closed_owner":
            fixture.owner.close()
        elif fault == "closed_entry":
            fixture.compiler.entry.close()
        elif fault == "provider_map":
            fixture.providers["user_cute"] = object()
        else:
            fixture.function.__globals__["prefix_kernel"] = object()
        with self.assertRaises((ValueError, RuntimeError)):
            context.check()

    def test_unsupported_metadata_product_does_not_use_the_hint(self):
        fixture = self.fixture()
        expressions = _Expressions(fixture.trace, {row.index for row in fixture.checked.inputs.integer_ranges})
        operands = _Operands(fixture.trace, fixture.artifact, {}, expressions)
        with self.assertRaisesRegex(LinkDeclined, "range proofs"):
            operands.numeric_value(pointwise_product((IntExpr("boxed", 0), 2)))

    def test_static_layout_is_not_given_an_invented_integer(self):
        fixture = self.fixture(dynamic=False)
        self.assertEqual(fixture.checked.cute.integer_inputs, ())
        with self.assertRaises(LinkDeclined):
            self.link(fixture)

    def test_source_change_after_state_creation_uses_existing_abort(self):
        fixture = self.fixture()
        program = self.link(fixture).program
        state_type = preparation._Preparation
        original_abort = state_type.abort
        states = []

        def create_state(*args, **kwargs):
            state = state_type(*args, **kwargs)
            states.append(state)
            fixture.function.__globals__["prefix_kernel"] = object()
            return state

        with mock.patch.object(torch.cuda, "is_initialized", return_value=True), mock.patch.object(
            torch.cuda, "device", side_effect=AssertionError("Changed source reached CUDA")
        ) as device, mock.patch.object(preparation, "_Preparation", side_effect=create_state), mock.patch.object(
            state_type, "abort", autospec=True, side_effect=original_abort
        ) as abort:
            with self.assertRaises(ValueError):
                preparation.prepare_variant(program, fixture.providers, fixture.box, compiler_binding=fixture.checked)
            device.assert_not_called()
            self.assertEqual(len(states), 1)
            abort.assert_called_once_with(states[0])
            self.assertEqual(states[0].borrows, [])
            self.assertIsNone(states[0].graph)

    def test_link_and_context_do_not_retain_real_tensor_examples(self):
        fixture = self.fixture()
        program = self.link(fixture).program
        context = _bind_compiler_program(program, fixture.providers, fixture.checked)
        index = fixture.checked.inputs.tensor_inputs[0].index
        tensor = weakref.ref(fixture.box[index])
        fixture.box.clear()
        gc.collect()
        self.assertIsNone(tensor())
        context.check()


if __name__ == "__main__":
    run_tests()
