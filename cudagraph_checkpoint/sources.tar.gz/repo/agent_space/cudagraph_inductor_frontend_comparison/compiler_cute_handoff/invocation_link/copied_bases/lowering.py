"""Join recorded Python operands to compiler-owned CuTe parameter fields."""

from dataclasses import dataclass

import torch
from fx_adapter.contract import AllocateEvent
from host_program import Allocate
from python_entry import EntryCall
from torch._inductor.runtime.cudagraph_arg_mapping import (
    BufferSource, ExpressionSource, IntegerSource, IntExpr, OwnedBuffer, pointwise_product,
)
from torch._inductor.runtime.cudagraph_boxed_replay import _PhysicalCall, _PhysicalField
from user_triton.contract import ReplayProgram
from user_triton.linking import _Expressions, LinkDeclined

from .contract import CuTeInvocation, MixedProgram
from .numeric import lower_numeric, NumericSource, RangeObligation
from .tracing import CuteHostTrace, DetachEvent


@dataclass(frozen=True)
class LinkedCuTe:
    program: MixedProgram
    trace: CuteHostTrace
    owner: object
    predicate: object
    obligations: tuple[RangeObligation, ...]


class _Operands:
    def __init__(self, trace, artifact, tensors, expressions):
        self.trace = trace
        self.artifact = artifact
        self.tensors = tensors
        self.expressions = expressions
        self.formals = {formal.source_arg_index: formal for formal in artifact.formals}
        self.ranges = {row.index: row for row in trace.input_contract.integer_ranges}
        if len(self.formals) != len(artifact.formals):
            raise LinkDeclined("CuTe compiler formals have duplicate original indices")

    def tensor(self, formal):
        operand = self.artifact.signature.operands[formal.operand_index]
        if (formal.kind != "Tensor" or operand.name != formal.name or operand.tensor is None
                or id(operand.tensor.value) not in self.tensors):
            raise LinkDeclined("CuTe formal has no recorded Python Tensor identity")
        return operand.tensor

    def property(self, formal, name, path):
        tensor = self.tensor(formal)
        if name == "pointer" and path == ():
            return self.tensors[id(tensor.value)]
        if name not in ("shape", "stride") or len(path) != 1:
            raise LinkDeclined("Unsupported CuTe Tensor property path")
        uses = tensor.shape if name == "shape" else tensor.strides
        if type(path[0]) is not int or not 0 <= path[0] < len(uses):
            raise LinkDeclined("CuTe Tensor property path exceeds its original operand")
        return self.expressions(uses[path[0]].value)

    def field(self, source):
        formal = self.formals.get(source.ir_arg_index)
        if (formal is None or source.kind != "tensor_property" or source.formal_name != formal.name
                or source.metadata_path != formal.metadata_path):
            raise LinkDeclined("CuTe field lost its exact original formal")
        leaves = [leaf for leaf in formal.leaves if leaf.path == source.component_path]
        if len(leaves) != 1:
            raise LinkDeclined("CuTe field lacks one compiler-identified aggregate leaf")
        leaf, = leaves
        if (source.llvm_type, source.property, source.property_path) != (
                leaf.llvm_type, leaf.property, leaf.property_path):
            raise LinkDeclined("CuTe field property differs from its compiler leaf")
        return self.property(formal, source.property, source.property_path)

    def numeric(self, source_index, path):
        formal = self.formals.get(source_index)
        if formal is None:
            raise LinkDeclined("CuTe computation has no original formal")
        leaves = [leaf for leaf in formal.leaves if leaf.path == path]
        if len(leaves) != 1 or leaves[0].property == "pointer":
            raise LinkDeclined("CuTe computation is not a recorded integer metadata leaf")
        leaf, = leaves
        value = self.property(formal, leaf.property, leaf.property_path)
        return self.numeric_value(value)

    def numeric_value(self, value):
        if type(value) is int:
            return NumericSource(IntExpr("constant", value), value, value)
        if type(value) is IntExpr and value.op == "boxed" and value.value in self.ranges:
            row = self.ranges[value.value]
            return NumericSource(value, row.lower, row.upper)
        raise LinkDeclined("CuTe metadata expression needs broader per-operation range proofs")


def link_cute(prefix, trace, owner, effects, *, provider_key="user_cute"):
    if type(prefix) is not ReplayProgram or type(trace) is not CuteHostTrace:
        raise LinkDeclined("Expected an independently constructed prefix and its live CuTe trace")
    if (trace.input_layout not in prefix.allocations or type(provider_key) is not str
            or provider_key in {call.provider_key for call in prefix.calls}):
        raise LinkDeclined("CuTe input or provider key lacks a unique prefix binding")
    trace.check()
    owner.check()
    effects.check()
    artifact, site = owner.artifact, owner.site
    signature = artifact.signature
    if (signature.trace is not trace or len(trace.calls) != 1 or signature.call is not trace.calls[0]
            or effects.artifact is not artifact or effects.site is not site):
        raise LinkDeclined("CuTe artifact differs from its original trace or selected effects")
    expressions = _Expressions(trace, {row.boxed_index for row in prefix.integer_inputs})
    tensors = {id(trace.input_tensor): trace.input_layout.source}
    operands = _Operands(trace, artifact, tensors, expressions)
    allocations, events = list(prefix.allocations), list(prefix.events)
    names = {layout.source.name for layout in allocations}
    fresh, obligations = set(), []
    invoked = False
    predicate = None
    for event in trace.events:
        if type(event) is AllocateEvent:
            if event.device != torch.device("cuda", prefix.device_index) or id(event.tensor) in tensors:
                raise LinkDeclined("CuTe allocation changed device or reused a Tensor identity")
            name = f"{provider_key}_buffer_{len(fresh)}"
            if name in names:
                raise LinkDeclined("CuTe allocation identifier conflicts with its prefix")
            layout = OwnedBuffer(BufferSource(name), event.dtype, tuple(expressions(v) for v in event.size),
                                 tuple(expressions(v) for v in event.stride))
            if (len(layout.size) != 2 or layout.stride != (layout.size[1], 1)
                    or pointwise_product(layout.size) is None):
                raise LinkDeclined("CuTe allocation requires a contiguous rank-two descriptor")
            names.add(name)
            tensors[id(event.tensor)] = layout.source
            fresh.add(layout.source)
            allocations.append(layout)
            events.append(Allocate(name, layout.dtype, layout.size, layout.stride))
        elif type(event) is DetachEvent:
            if id(event.source) not in tensors or id(event.result) in tensors:
                raise LinkDeclined("CuTe detach lost its recorded Tensor correspondence")
            tensors[id(event.result)] = tensors[id(event.source)]
        elif type(event) is EntryCall:
            if invoked or event is not signature.call:
                raise LinkDeclined("Expected the one original CuTe entry invocation")
            invoked = True
            fields = []
            for field in site.fields.pointers:
                source = operands.field(field.source)
                if type(source) is not BufferSource:
                    raise LinkDeclined("CuTe pointers must name recorded owned buffers")
                fields.append(_PhysicalField(field.parameter, field.byte_offset, "pointer", source))
            for field in site.fields.integers:
                value = operands.field(field.source)
                source = ExpressionSource(value) if type(value) is IntExpr else IntegerSource(value)
                fields.append(_PhysicalField(field.parameter, field.byte_offset, field.dtype, source))
                numeric = operands.numeric_value(value)
                bits = {"i32": 32, "i64": 64}.get(field.dtype)
                if bits is None:
                    raise LinkDeclined("CuTe integer field has an unsupported physical width")
                minimum, maximum = -(2 ** (bits - 1)), 2 ** (bits - 1) - 1
                if (numeric.lower is None or numeric.lower < minimum
                        or numeric.upper is None or numeric.upper > maximum):
                    obligations.append(RangeObligation(numeric.expression, minimum, maximum,
                                                      "CuTe physical integer field"))
            grids = {}
            for consumer in artifact.consumers:
                if consumer.site_id == site.site_id and consumer.role == "grid":
                    value = lower_numeric(consumer.numeric, operands.numeric)
                    if len(value.values) != 1 or type(value.values[0].expression) is not IntExpr:
                        raise LinkDeclined("CuTe grid did not lower to one native integer recipe")
                    grids[consumer.index] = value.values[0].expression
                    obligations.extend(value.obligations)
                elif consumer.site_id is None and consumer.role == "predicate":
                    value = lower_numeric(consumer.numeric, operands.numeric)
                    if predicate is not None or len(value.values) != 1:
                        raise LinkDeclined("CuTe artifact lacks one exact dispatch predicate")
                    predicate = value.values[0]
                    obligations.extend(value.obligations)
            if set(grids) != {0, 1, 2} or predicate is None:
                raise LinkDeclined("CuTe launch lacks complete grid or dispatch computations")
            bound = _PhysicalCall(tuple(fields), owner, tuple(grids[index] for index in range(3)),
                                  tuple(tuple(row) for row in site.fields.padding))
            events.append(CuTeInvocation(provider_key, owner, bound, effects))
        else:
            raise LinkDeclined("Unsupported pre-JIT CuTe host event")
    if not invoked or len(trace.outputs) != 1 or tensors.get(id(trace.outputs[0])) not in fresh:
        raise LinkDeclined("CuTe host must return its recorded independent allocation")
    source = tensors[id(trace.outputs[0])]
    output = next(layout for layout in allocations if layout.source == source)
    program = MixedProgram(prefix.device_index, prefix.input_names, prefix.integer_inputs,
                           tuple(allocations), (*prefix.outputs, output), prefix.copies,
                           tuple(events), prefix.input_assertions)
    return LinkedCuTe(program, trace, owner, predicate, tuple(dict.fromkeys(obligations)))
