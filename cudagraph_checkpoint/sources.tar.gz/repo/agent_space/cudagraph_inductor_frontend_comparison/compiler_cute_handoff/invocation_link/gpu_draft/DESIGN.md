# Native invocation-link GPU control

This draft contains four device-generic cases: normal/fast generated launchers,
each with a cloned or `empty_like` destination. It uses the ordinary public
CuTe fixture from `symbolic_program/test_symbolic_program_gpu.py`. The empty
source form must retain the compiler's real no-read destination initializer;
it is not treated as an uninitialized buffer.

Each case obtains one original generated function and its true boxed arguments
by passive code-and-globals profile observation. `bind_envelope` supplies that
function's exact input contract and descriptor binding to
`trace_cute_invocation`. The actual ordinary CuTe compilation supplies the
entry signature, metadata binding, correspondence, normalized invocation,
target/stream layouts and dispatch artifact. Source, compiled-module and
selected binary bytes are checked against this compilation. CuTe is compiled
only once.

Actual warmed generated kernels provide `SelectedKernel`/`GeneratedProvider`
objects. Each actual CuTe site provides a `CuTeKernelOwner`, selected pointer
effects and a `link_cute_invocation` result. Compiled guard functions select
the two capture examples, M2 and M4, before `prepare_variant` receives the
checked compiler binding. Both calls retain exactly the original allocation
and output projection. No prefix is represented as the original function.

The capture observer independently reconstructs all generated scalar/pointer
parameters and all CuTe aggregate bytes, including zero padding, from the true
box and captured buffers. It compares them to both launch records and actual
CUDA node snapshots. Every grid is checked against its expression evaluated
from the actual boxed integers; only the CuTe grid is specifically required
to equal `(M, 1, 1)`. Generated grids may differ.

Replay uses the native C++ dispatcher and those same compiled predicates.
Python guard objects and the C++ code cache are released first. New M3, M7,
M35 and M36 boxes each come from an actual ordinary public admission under
the same original function and selected kernels. The test then invokes the
native dispatcher directly, with all Python call frames observed and Python
launch/preparation paths trapped. It checks exact outputs, consumed boxes,
both local arms, fresh output storage, expired input/ordinary temporary
storage, unchanged poisoned capture buffers, live graph borrows and held
outputs after dispatcher/entry/kernel/ordinary-owner close.
After releasing those held outputs, their weak storage references must also
expire while the closed entry objects remain live.

This is a standalone native linker proof. Ordinary execution is deliberately
used to obtain every admitted box before the separate native call; the test
does not demonstrate public native policy installation or its performance.
The fixed subset remains float32, positive dynamic row count, literal width
128, row-major source/destination, fresh outputs and no reuse or aliasing.
Compiler releases are conservatively extended to graph enqueue by the
existing linker. No eager peak-memory equivalence is claimed. Current cold
cost is unmeasured by this draft.

The controller needs no new helper aliases: the existing symbolic-program
manifest plus the two invocation-link overlays and its existing nine
dependency modules provide every imported module. It must snapshot this test
and route it through the existing physical-GPU-1 idle/native/source guards.
Only the parent executes framework or GPU work.
