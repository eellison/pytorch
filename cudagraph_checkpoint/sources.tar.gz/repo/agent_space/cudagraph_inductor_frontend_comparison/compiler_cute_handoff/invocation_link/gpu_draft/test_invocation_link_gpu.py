from contextlib import ExitStack
import ctypes
import gc
from hashlib import sha256
import json
import struct
import sys
from types import FunctionType
from unittest import mock

import cutlass.cute as cute
from compiler_cute_handoff.envelope import bind_envelope, GeneratedCall
from compiler_cute_handoff.invocation import invoke_cute, register_cute_entry
from compiler_policy_handoff.policy import NativeCUDAGraphPolicy
from cute_bridge import preparation
from cute_bridge.guard_export import prepare_guard
from cute_bridge.lowering import link_cute_invocation
from cute_bridge.provider import _constant_consumer, CuTeKernelOwner, extract_pointer_effects
from cute_bridge.tracing import trace_cute_invocation
from cute_dispatch.entry import OrdinaryEntry, TensorPolicy
from cute_dispatch.fixtures import make_fixture
from cudagraph_cute_runtime.factory import prepare_dispatch_artifact
from entry_signature import build_entry_signature, SignaturePolicy
from ordinary_artifact_adapter.invocation import normalize_artifact_invocation
from ordinary_artifact_capture.owner import ObservedOrdinaryEntry
from ordinary_artifact_reuse.binding import bind_ordinary_metadata
from ordinary_artifact_reuse.correspondence import join_ordinary_correspondence
from selected_kernel import SelectedKernel
from stream_layout import compile_stream_layout
from target_layout import compile_target_layout
import test_cudagraph_reduction_replay as fixture_module
import torch
from torch._dynamo.utils import counters
from torch._inductor import config
from torch._inductor.codecache import CppCodeCache
from torch._inductor.runtime import cudagraph_prepare_from_warmed as generated_preparation
from torch._inductor.runtime.cudagraph_arg_mapping import BufferSource, ExpressionSource, InputSource, IntegerSource
from torch._inductor.runtime.cudagraph_launch_association import associate_kernel_launches
from torch.multiprocessing.reductions import StorageWeakRef
from torch.testing._internal.common_device_type import instantiate_device_type_tests
from torch.testing._internal.common_utils import parametrize, run_tests, TestCase
from user_triton.linking import GeneratedProvider


class ObservingPolicy(NativeCUDAGraphPolicy):
    def __init__(self):
        super().__init__()
        self.artifacts = []

    def wrap_output(self, artifact):
        self.artifacts.append(artifact)
        return super().wrap_output(artifact)


class TestCuTeInvocationLink(TestCase):
    def integer_value(self, expression, box):
        if expression.op == "constant":
            return expression.value
        if expression.op == "boxed":
            self.assertIs(type(box[expression.value]), int)
            return box[expression.value]
        left, right = (self.integer_value(arg, box) for arg in expression.args)
        if expression.op == "multiply":
            return left * right
        self.assertEqual(expression.op, "ceildiv")
        return (left + right - 1) // right

    def prepare_checked(self, linked, providers, checked, box):
        program, owner = linked.program, linked.owner
        binder = preparation._make_replay
        buffers, evidence = [], []

        def observe(graph, input_count, allocations, outputs, copies, calls, launches, captured, stream, **kwargs):
            self.assertEqual(input_count, len(box))
            self.assertIs(allocations, program.allocations)
            self.assertEqual(outputs, tuple(allocations.index(row) for row in checked.records.outputs))
            self.assertEqual(copies, tuple(row.input_index for row in program.copies))
            self.assertEqual((len(calls), len(launches)), (len(program.calls), len(program.calls)))
            nodes = tuple(launch.after[3][0][0] for launch in launches)
            actual = associate_kernel_launches(launches, graph._inspect_captured_kernel_nodes(nodes))

            def value(source):
                if type(source) is InputSource:
                    tensor = box[source.index]
                    self.assertIs(torch._C._dynamo.guards.copy_if_misaligned(tensor), tensor)
                    return tensor
                if type(source) is BufferSource:
                    return captured[source]
                if type(source) is IntegerSource:
                    return source.value
                self.assertIs(type(source), ExpressionSource)
                return self.integer_value(source.expression, box)

            for index, (bound, launch, captured_call) in enumerate(zip(calls, launches, actual)):
                snapshot = captured_call.snapshot
                grid = tuple(self.integer_value(axis, box) for axis in bound.grid)
                self.assertEqual(snapshot[1], bound.module.function)
                self.assertEqual(snapshot[4], grid)
                if index == len(calls) - 1:
                    self.assertIs(bound.module, owner)
                    self.assertEqual(grid, (box[checked.inputs.integer_ranges[0].index], 1, 1))
                    self.assertEqual(snapshot[5:7], (owner.block, owner.shared))
                    self.assertEqual(tuple((offset, size) for offset, size, _ in snapshot[8]), owner.parameter_layout)
                    images = [bytearray(size) for size in owner.parameter_sizes]
                    for field in bound.fields:
                        argument = value(field.source)
                        payload = (struct.pack("P", argument.data_ptr()) if field.kind == "pointer"
                                   else struct.pack({"i32": "i", "i64": "q"}[field.kind], argument))
                        start = field.byte_offset
                        images[field.parameter][start:start + len(payload)] = payload
                    expected = tuple(bytes(image) for image in images)
                else:
                    self.assertEqual(snapshot[5:7], ((bound.module.num_warps * 32, 1, 1), bound.module.shared))
                    expected = tuple(
                        struct.pack("P", value(row.source).data_ptr())
                        if type(row.source) in (InputSource, BufferSource)
                        else struct.pack({"i32": "i", "i64": "q"}[row.triton_type], value(row.source))
                        for row in bound.arguments
                    )
                    for present in (bound.module.has_global_scratch, bound.module.has_profile_scratch):
                        if present:
                            expected += (bytes(struct.calcsize("P")),)
                self.assertEqual(launch.argument_bytes, expected)
                self.assertEqual(tuple(payload for _, _, payload in snapshot[8]), expected)
                evidence.append({
                    "occurrence": index, "grid": grid, "block": snapshot[5], "shared": snapshot[6],
                    "parameter_layout": [(offset, size) for offset, size, _ in snapshot[8]],
                    "parameter_bytes": [payload.hex() for payload in expected],
                })
            buffers.extend(captured[row.source] for row in allocations)
            return binder(graph, input_count, allocations, outputs, copies, calls, launches, captured, stream, **kwargs)

        with mock.patch.object(preparation, "_make_replay", observe):
            native = preparation.prepare_variant(program, providers, box, compiler_binding=checked)
        self.addCleanup(native.close)
        self.assertEqual(len(evidence), len(program.calls))
        return native, tuple(buffers), evidence

    @parametrize("fast", (False, True))
    @parametrize("clone_destination", (False, True))
    def test_native_compiler_invocation(self, device, fast, clone_destination):
        fixture = fixture_module.TestReductionGraphReplayCUDA(f"test_generated_reduction_replay_fast_{fast}_cuda")
        self.addCleanup(lambda: self.assertTrue(fixture.doCleanups()))
        fixture.setUp()
        policy = ObservingPolicy()
        self.addCleanup(policy.close)
        self.enterContext(config.patch(
            use_fast_triton_launcher=fast, cudagraph_policy=policy, fx_graph_cache=True,
            allow_buffer_reuse=False, inplace_buffers=False,
        ))
        self.enterContext(mock.patch.object(
            generated_preparation, "prepare_from_warmed",
            side_effect=AssertionError("This proof does not install a public CuTe native policy"),
        ))
        python_entry, kernel, _ = make_fixture()
        layout = TensorPolicy((None, 128), (0, 1))
        ordinary = ObservedOrdinaryEntry(
            python_entry, kernel, policy=SignaturePolicy(32, 64, 16, "stream"),
            tensor_policies={"source": layout, "destination": layout},
        )
        self.addCleanup(ordinary.close)
        registration = register_cute_entry(ordinary)
        self.addCleanup(registration.close)
        key = registration.key

        def model(value):
            source = value.sin()
            destination = source.clone() if clone_destination else torch.empty_like(source)
            invoke_cute(key, source, destination)
            return (destination,)

        compile_target, compile_calls = cute.compile, []
        boxes, ordinary_storages, input_storages, admissions = [], [], [], []
        original, checked, selected = None, None, None
        run_code = OrdinaryEntry.run.__code__

        def compile_once(target, *args, **kwargs):
            self.assertIs(target, python_entry.target)
            compile_calls.append(target)
            self.assertEqual(len(compile_calls), 1)
            return compile_target(target, *args, **kwargs)

        def observe(frame, event, result):
            if event == "call" and policy.artifacts:
                function = policy.artifacts[0].current_callable
                if (type(function) is FunctionType and frame.f_code is function.__code__
                        and frame.f_globals is function.__globals__):
                    box = frame.f_locals[function.__code__.co_varnames[0]]
                    self.assertIs(type(box), list)
                    boxes.append(tuple(box))
            if event == "return" and frame.f_code is run_code and frame.f_locals.get("self") is ordinary:
                if result is not None:
                    self.assertIs(frame.f_locals["host"], registration.provider.host)
                    source, destination = frame.f_locals["inputs"]
                    call, = result.calls
                    self.assertIs(call.entry, python_entry)
                    self.assertIs(call.arguments[0], source)
                    self.assertIs(call.arguments[1], destination)
                    ordinary_storages.extend((StorageWeakRef(source.untyped_storage()),
                                              StorageWeakRef(destination.untyped_storage())))

        self.enterContext(mock.patch.object(cute, "compile", compile_once))
        previous_profile = sys.getprofile()
        self.assertIsNone(previous_profile)
        self.addCleanup(sys.setprofile, previous_profile)
        compiled = torch.compile(model, dynamic=True, fullgraph=True)
        bypasses = counters["inductor"]["fxgraph_cache_bypass"]

        def admit(batch):
            value = torch.randn((batch, 128), device=device)
            torch._dynamo.mark_static(value, 1)
            sys.setprofile(observe)
            try:
                result = compiled(value)
            finally:
                sys.setprofile(previous_profile)
            self.assertIs(type(result), tuple)
            expected = (value.sin() * 2 + (64 if batch < 4 else 128),)
            self.assertEqual(result, expected)
            self.assertEqual((len(policy.artifacts), len(boxes), len(compile_calls)), (1, 1, 1))
            self.assertEqual(len(ordinary_storages), 2 * (len(admissions) + 1))
            self.assertEqual(policy.installations, ())
            box = list(boxes.pop())
            if original is not None:
                self.assertIs(policy.artifacts[0].current_callable, original)
                self.assertIs(ordinary.selected, selected)
                self.assertIs(box[checked.inputs.tensor_inputs[0].index], value)
                self.assertEqual(box[checked.inputs.integer_ranges[0].index], batch)
                for provider in generated.values():
                    provider.check()
            admissions.append(batch)
            input_storages.append(StorageWeakRef(value.untyped_storage()))
            return box, expected

        warm_box, warm_expected = admit(13)
        original = policy.artifacts[0].current_callable
        selected = ordinary.selected
        checked = bind_envelope(original)
        checked.check()
        self.assertIs(checked.function(), original)
        self.assertIs(checked.binding.entries[0], registration)
        self.assertEqual((len(checked.inputs.tensor_inputs), len(checked.inputs.integer_ranges)), (1, 1))
        self.assertEqual(warm_box[checked.inputs.integer_ranges[0].index], 13)
        self.assertEqual(tuple(warm_box[checked.inputs.tensor_inputs[0].index].shape), (13, 128))
        self.assertEqual(tuple(row.source for row in checked.records.outputs), checked.cute.outputs)
        self.assertEqual(checked.cute.outputs, (checked.cute.calls[0].operands[1].source,))
        if not clone_destination:
            destination = checked.cute.calls[0].operands[1].source
            self.assertTrue(any(type(event) is GeneratedCall and not event.reads and destination in event.writes
                                for event in checked.records.events))
        trace = trace_cute_invocation(checked.binding, checked.inputs, warm_box)
        self.assertIs(trace.binding, checked.binding)
        self.assertIs(trace.input_contract, checked.inputs)
        self.assertEqual(trace.outputs, ())
        signature = build_entry_signature(trace, trace.calls[0], policy=ordinary.policy)
        capsule = ordinary.compilation()
        bound = bind_ordinary_metadata(signature, capsule)
        invocation = normalize_artifact_invocation(join_ordinary_correspondence(bound))
        major, minor = torch.cuda.get_device_capability(device)
        self.assertEqual(invocation.program.arch, f"sm_{major}{minor}")
        target = compile_target_layout(invocation.plan)
        stream_target = compile_stream_layout(invocation.formals, invocation.stream_source_index)
        artifact = prepare_dispatch_artifact(invocation, target, stream_target)
        self.assertIs(invocation.bound.compilation, capsule)
        self.assertIs(artifact.signature, signature)
        self.assertEqual(artifact.source_sha256, sha256(capsule.source_bytecode).hexdigest())
        self.assertEqual(artifact.compiled_sha256, sha256(capsule.module_bytecode).hexdigest())
        binaries = invocation.joined.mapping.flow.binaries
        self.assertEqual(len(artifact.binaries), len(binaries))
        for image, binary in zip(artifact.binaries, binaries):
            self.assertEqual(tuple(image), tuple(getattr(binary, name) for name in image._fields))
            self.assertEqual(sha256(image.data).hexdigest(), image.sha256)
        del warm_box, warm_expected

        generated = {}
        for call in checked.records.generated_calls:
            if call.kernel_global not in generated:
                selection = SelectedKernel.from_warmed(original.__globals__[call.kernel_global])
                generated[call.kernel_global] = GeneratedProvider(selection)
                fixture.modules[id(selection.identity[3])] = selection.identity[3]
        ordered = tuple(generated[call.kernel_global] for call in checked.records.generated_calls)
        owners, linked_calls, guards = [], [], []
        self.assertEqual(len(artifact.sites), 2)
        for site in artifact.sites:
            block = tuple(_constant_consumer(artifact, site, "block", axis) for axis in range(3))
            shared = _constant_consumer(artifact, site, "shared", 0)
            owner = CuTeKernelOwner(artifact, site, stream=torch.cuda.current_stream().cuda_stream,
                                    block=block, shared=shared)
            self.addCleanup(owner.close)
            owners.append(owner)
            effects = extract_pointer_effects(invocation, artifact, site)
            linked = link_cute_invocation(checked, trace, ordered, owner, effects)
            self.assertIs(linked.program.outputs, checked.records.outputs)
            self.assertEqual(linked.program.allocations, checked.records.allocations)
            self.assertEqual(len(linked.program.calls), len(ordered) + 1)
            linked_calls.append(linked)
            guards.append(prepare_guard(linked))

        guard_addresses = tuple((guard.boxed_integer_indices, guard.function_address) for guard in guards)
        guard_expressions = tuple(guard.expressions for guard in guards)

        def matching(box):
            matches = []
            for index, (indices, address) in enumerate(guard_addresses):
                values = (ctypes.c_int64 * len(indices))(*(box[position] for position in indices))
                predicate = ctypes.CFUNCTYPE(ctypes.c_int8, ctypes.POINTER(ctypes.c_int64),
                                            ctypes.POINTER(ctypes.c_double))(address)
                if predicate(values, None):
                    matches.append(index)
            self.assertEqual(len(matches), 1)
            chosen, = matches
            batch = box[checked.inputs.integer_ranges[0].index]
            self.assertEqual(bool(owners[chosen].site.arm), batch < 4)
            return chosen

        prepared, capture_buffers, captures = {}, [], []
        for batch in (2, 4):
            box, expected = admit(batch)
            index = matching(box)
            self.assertNotIn(index, prepared)
            linked = linked_calls[index]
            native, buffers, evidence = self.prepare_checked(
                linked, {**generated, "user_cute": owners[index]}, checked, box)
            prepared[index] = native
            capture_buffers.extend(buffers)
            captures.append({"batch": batch, "site_id": owners[index].site.site_id,
                             "arm": bool(owners[index].site.arm), "launches": evidence})
            del box, expected
        self.assertEqual(set(prepared), set(range(len(guards))))
        misses = []

        def miss(box):
            misses.append(tuple(box))
            raise AssertionError("An admitted batch missed the compiled CuTe guards")

        dispatch = torch._C._cuda_make_boxed_dispatch(
            tuple((prepared[index], guard.registration) for index, guard in enumerate(guards)), miss)
        self.addCleanup(dispatch.close)
        for owner in owners:
            with self.assertRaisesRegex(RuntimeError, "borrowed"):
                owner.close()
        guards.clear()
        CppCodeCache.cache_clear()
        poison = []
        for index, buffer in enumerate(capture_buffers):
            buffer.fill_(1000 + index)
            poison.append(buffer.clone())
        del buffer
        capture_pointers = {buffer.data_ptr() for buffer in capture_buffers}
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        self.assertTrue(all(storage.expired() for storage in ordinary_storages))

        held, frames, replay_sites, native_storages = [], [], [], []

        def profile(frame, event, result):
            if event == "call":
                frames.append((frame.f_code.co_filename, frame.f_code.co_name))

        def calibration():
            return None

        sys.setprofile(profile)
        calibration()
        sys.setprofile(previous_profile)
        self.assertTrue(any(name == "calibration" for _, name in frames))
        frames.clear()
        for batch in (3, 7, 35, 36):
            box, expected = admit(batch)
            replay_sites.append(matching(box))
            with ExitStack() as stack:
                forbidden = AssertionError("A native dispatcher hit entered Python preparation or launch")
                stack.enter_context(mock.patch.object(cute, "compile", side_effect=forbidden))
                stack.enter_context(mock.patch.object(OrdinaryEntry, "run", side_effect=forbidden))
                stack.enter_context(mock.patch.object(preparation, "prepare_variant", side_effect=forbidden))
                for provider in (*generated.values(), *owners):
                    stack.enter_context(mock.patch.object(provider, "launch", side_effect=forbidden))
                for provider in generated.values():
                    stack.enter_context(mock.patch.object(provider.selection.identity[0], "run", side_effect=forbidden))
                sys.setprofile(profile)
                try:
                    result = dispatch(box)
                finally:
                    sys.setprofile(previous_profile)
            self.assertEqual(frames, [])
            self.assertEqual(box, [])
            self.assertIs(type(result), tuple)
            self.assertEqual(result, expected)
            self.assertEqual(len(result), len(checked.records.outputs))
            for output in result:
                self.assertEqual((tuple(output.shape), output.stride(), output.storage_offset()),
                                 ((batch, 128), (128, 1), 0))
                self.assertIsNone(output._base)
                self.assertNotIn(output.data_ptr(), capture_pointers)
                native_storages.append(StorageWeakRef(output.untyped_storage()))
            held.append((result, expected))
            del box, result, expected, output
        self.assertEqual(set(replay_sites), set(prepared))
        self.assertEqual(misses, [])
        self.assertEqual(len(compile_calls), 1)
        self.assertIs(ordinary.selected, selected)
        self.assertIs(ordinary.compilation(), capsule)
        self.assertGreater(counters["inductor"]["fxgraph_cache_bypass"], bypasses)
        self.assertFalse(invoke_cute.cacheable())
        self.assertIsNone(ordinary._calls)
        self.assertEqual((ordinary._capture.arguments, ordinary._capture.keywords), ((), {}))
        torch.cuda.synchronize(device)
        gc.collect()
        self.assertTrue(all(storage.expired() for storage in input_storages))
        self.assertTrue(all(storage.expired() for storage in ordinary_storages))
        for buffer, value in zip(capture_buffers, poison):
            self.assertEqual(buffer, value)
        del buffer, value
        self.assertEqual(len({output.data_ptr() for result, _ in held for output in result}), len(held))
        dispatch.close()
        for native in prepared.values():
            native.close()
        for owner in owners:
            owner.close()
        registration.close()
        for result, expected in held:
            self.assertEqual(result, expected)
        del result, expected
        held.clear()
        gc.collect()
        self.assertEqual(len(native_storages), 4)
        self.assertTrue(all(storage.expired() for storage in native_storages))
        print("CUTE_INVOCATION_LINK_RESULT=" + json.dumps({
            "fast": fast, "clone_destination": clone_destination, "ordinary_compilations": len(compile_calls),
            "single_compiled_artifact": len(policy.artifacts) == 1, "admitted_batches": admissions,
            "capture_batches": [2, 4], "replay_batches": [3, 7, 35, 36], "replay_sites": replay_sites,
            "captures": captures, "guard_expressions": guard_expressions,
            "source_sha256": artifact.source_sha256, "compiled_sha256": artifact.compiled_sha256,
            "binary_sha256": [image.sha256 for image in artifact.binaries],
            "generated_calls": len(ordered), "output_count": len(checked.records.outputs),
            "exact_original_envelope": True, "same_ordinary_compilation": True,
            "complete_capture_bytes_and_grids": True, "compiled_guards_select_both_arms": True,
            "dispatcher_retains_guard_libraries": True,
            "native_python_frames": frames, "capture_buffers_unchanged": True,
            "ordinary_and_input_storage_expired": True, "held_outputs_after_close": True,
            "native_output_storage_expired_after_release": True,
            "temporary_lifetimes_extended_to_enqueue": True, "public_native_policy_installed": False,
        }, sort_keys=True))


instantiate_device_type_tests(TestCuTeInvocationLink, globals(), only_for="cuda")


if __name__ == "__main__":
    run_tests()
