The isolated candidate implements the prior DESIGN.md in two overlays:
`cute_bridge.lowering` and `cute_bridge.preparation`. MixedProgram, native code,
ordinary owner/capture, compiler envelope, tracing, policy and cache sources are
unchanged. `overlays.json` contains only these two module paths.

`link_cute_invocation(checked, trace, generated, owner, effects)` returns the
existing LinkedCuTe. It requires the exact envelope binding, InputContract,
descriptor, recorded operands, signature, owner/site/effects and original
generated kernel globals. Generated calls use the existing warmed selection,
argument and grid binders; selected writer/dtype/alignment facts are compared
to the independent compiler source facts. The result preserves compiler
allocations, integer origins and the exact output tuple. Checked releases are
omitted, extending temporary lifetimes through enqueue in this no-alias/no-reuse
subset. No computation or output is discarded.

The old physical field/grid/predicate block is extracted without changing its
AST. The old link_cute function is AST-identical after inlining that block.
_Operands remains unchanged, including its literal/direct-boxed metadata limit.
The generated prefix remains Grid1D; the mixed executor still requires boxed
integers and its existing supported layouts/ordinary Tensor boxes.

`prepare_variant(..., compiler_binding=checked)` reconstructs and compares the
complete compiler projection at this new caller operation. Its private context
is local to this preparation and freshly checks live binding/trace/provider
associations across allocating stages and after native entry construction.
It is not a memo for successful source checks. Only the exact terminal compiler
destination may bypass the old prefix-write restriction, and it must already
be initialized, live, independently allocated and returned. Source writes
decline. All physical ABI, field/padding, metadata, grid and owner checks remain.
Without the keyword, the old validation/capture path is unchanged; stripping
only the new conditional context checks reproduces its original AST.

The existing capture transaction still owns abort/failed-cleanup behavior.
The linker takes no borrows, closes no providers and retains no real examples.
The new context is not returned or attached to the native entry. Local guard
export and caller-owned outer compiler preconditions remain required; no
dispatcher, publication or registration-borrow integration is added here.

The 27 proposed CPU cases import only CompilerFixture from the exact ME test
helper selected in cpu_helpers.json. That helper includes the corrected positive
symbol ranges and its existing fixture cleanup. They use actual typed compiler
collection/emission/binding, two-operand FakeTensor tracing, EntrySignature,
SelectedKernel.from_warmed/GeneratedProvider checks, and parsed/frozen numeric
CFGs. Synthetic CUDA module handles and a synthetic CuTe ABI/loader stand in
for driver-loaded binaries. They cannot prove real compiled ABI ownership,
device numerics, native capture association or native storage lifetime.

Controls cover exact outputs/allocations/order and release retention, distinct
equal-hint origins, initialized destination reads/writes, the unchanged default
write rejection, independent writer/dtype/copy mismatches, paired pointer swaps,
sampled grids, foreign source authorities, closed/replaced owners and providers,
unsupported metadata products/static input, early abort on source change after
state creation and release of real example Tensor references. They do not run
the generated wrapper, a device kernel or cute.compile.

Only stdlib AST, ASCII, constructor-arity, diff and hash checks were performed
by the author. No framework/GPU/build/test execution or performance measurement
has occurred. Root owns the controller and qualification. The design-only
source_inputs.json remains a historical reference; source_review.json pins this
implementation and its current helper.
