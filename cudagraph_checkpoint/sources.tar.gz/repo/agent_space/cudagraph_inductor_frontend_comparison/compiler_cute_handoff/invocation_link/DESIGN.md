The next increment can reuse the existing `MixedProgram`, physical CuTe ABI,
numeric lowering, guard exporter and native executor. It needs a separate
compiler-envelope linker and one narrowly scoped Python validation change for
the initialized destination. This is a source-only proposal; no candidate code,
framework execution, capture, timing or policy/cache change is included.

The source paths and hashes used below are in `source_inputs.json`. In this note,
`lowering.py` and `preparation.py` mean the selected `cute_bridge` modules, not
Inductor's operator lowering. The current symbolic-program run is still pending;
its ordinary/envelope/trace proof must not be described as native qualification.

Proposed cold API, alongside the old `link_cute`:

```python
link_cute_invocation(
    checked: BoundMixedEnvelope,
    trace: CuteInvocationTrace,
    generated: tuple[GeneratedProvider, ...],  # one row per generated occurrence
    owner: CuTeKernelOwner,
    effects: SitePointerEffects,
    *, provider_key: str = "user_cute",
) -> LinkedCuTe
```

The caller obtains `checked = bind_envelope(original_function)` and traces with
`trace_cute_invocation(checked.binding, checked.inputs, observed_box)`. The linker
requires those two trace fields by identity, plus
`trace.descriptor is checked.cute.calls[0]`. It checks the binding and trace at
entry and exit, and requires the actual signature to hold this trace and its one
`EntryCall`. Equal layouts, equal integer hints or matching names do not join
independent compiler owners.

The ordinary artifact remains upstream and unchanged:

```python
signature = build_entry_signature(trace, trace.calls[0], policy=ordinary_owner.policy)
bound = bind_ordinary_metadata(signature, ordinary_owner.compilation())
invocation = normalize_artifact_invocation(join_ordinary_correspondence(bound))
target = compile_target_layout(invocation.plan)
stream = compile_stream_layout(invocation.formals, invocation.stream_source_index)
artifact = prepare_dispatch_artifact(invocation, target, stream)
```

Here `ordinary_owner` is the exact owner of the descriptor's sealed provider,
not a separately constructed entry. For each candidate site the caller uses
`_constant_consumer`, `CuTeKernelOwner` and
`extract_pointer_effects(invocation, artifact, site)`. The linker requires the
effects' artifact/site to be the owner's exact artifact/site. Actual shape32,
stride64, Stream, aggregate offsets/padding, selected binary registration,
alignment, read/write effects and the dispatch predicate still come from this
chain. It performs no second `cute.compile` and no retained-host compilation.

Minimal lowering refactor

Extract the physical-call portion of `link_cute`, currently `lowering.py:136`,
into one private helper such as
`_lower_cute_call(artifact, site, owner, operands)`. It returns the `_PhysicalCall`,
the lowered predicate and range obligations. Keep the exact existing field,
formal/leaf/property, integer-width, consumer, three-axis grid and predicate
checks. Keep `_Operands` and `lower_numeric` unchanged. The old linker retains
its existing input, host-allocation and appended-output behavior and calls the
same helper. Broaden only `LinkedCuTe.trace`'s annotation to the two supported
trace types; the guard exporter already consumes their shared checked fields.

For the new path, seed `_Operands` from the two actual recorded FakeTensors:
`id(trace.operand_tensors[i]) -> checked.cute.calls[0].operands[i].source`.
Require the trace's `tensor_sources` to contain exactly those associations and
the signature operands to be the exact recorded formals. Both sources must be
distinct compiler-owned buffers with their full original layouts. The trace
must contain only its `EntryCall` and have empty `outputs`; it contributes no
allocation or output to the enclosing program.

Translate the validated envelope in its original order:

| Envelope fact | Existing mixed-program representation |
| --- | --- |
| `OwnedBuffer` | Same allocation descriptor; `Allocate(source.name, dtype, size, stride)` event |
| `AlignmentCopy` | Same copy row and `Normalize(input_index, before_call)` event |
| `GeneratedCall` | `Invocation` with the exact original formals/arguments and selected bound grid |
| Terminal `CuTeCall` | One `CuTeInvocation` from the shared physical lowering helper |
| `Release` | Check original liveness; omit from execution under the restrictions below |
| `outputs` | The envelope's exact tuple, unchanged and in the same order |

Construct `MixedProgram` directly with `checked.inputs.device_index`,
`checked.cute.input_names`, `checked.cute.integer_inputs`,
`checked.records.allocations`, `checked.records.outputs`, the original copy rows
and translated events. Derive `InputAssertion` rows from the actual
`InputContract.tensor_inputs`; these express the existing caller-owned compiler
preconditions, not new hot Tensor checks. Preserve original boxed indices and
expressions. Do not manufacture `WrapperCallRecords` or `HostProgram` for an
internal prefix, call `generated_program` on such a fiction, or run the original
wrapper again during linking. Do not append either operand or prefix outputs.

Selected generated providers

The smallest supported prefix uses the existing
`GeneratedProvider(SelectedKernel.from_warmed(original.__globals__[name]))`.
`GeneratedProvider.check` rechecks the actual selected/cached launcher, module,
argument identity, grid recipe, writes and alignment. This API currently accepts
only `Grid1D`, so explicitly decline envelope `Grid2D`/`Grid3D` in this increment;
do not weaken it or infer selection from an equal launcher. The older
`NEXT_NATIVE.md` suggestion to call `_selected_calls` directly is not usable with
an envelope: that function expects a complete `WrapperCallRecords`, including
allocation/output coverage.

Require one provider row per generated occurrence, with its selected kernel
identical to the binding's unchanged original global. Repeated globals may share
the same provider object; their occurrence order and argument rows remain
separate. Reject extra/missing providers and a conflicting CuTe provider key.
Use `bind_wrapper_arguments(record, provider.arguments)` and
`bind_grid_recipe(record, provider.arguments, provider.selection.grid_recipe)`;
neither may decline. Preserve the returned grid's original boxed expressions.
Check the selected positional count and grid type against the actual call row,
the selected module/argument references, and complete pointer/scalar ABI.

Compare selected pointer provenance through each bound formal to the independent
envelope reads/writes: no input writes, exact generated buffer-writer set and no
uninitialized reads. Require complete supported alignment facts. Any external
pointer needing alignment greater than one must have a recorded normalization
copy before first use; sampled alignment or an omitted static-input copy is not
authority. The envelope's compiler initialization proof remains necessary;
selected `written=True` alone is not a general complete-write certificate.
Freeze no inferred effects and compile no replacement kernel.

Destination validation needed before capture

The current validator adds every generated-call buffer to `prefix_buffers`
(`preparation.py:375`) and rejects every CuTe write to that set (`:174`). That
rejects the initialized compiler destination, even though it is fresh owning
storage and exactly the declared mutation target. Removing the restriction
globally would also weaken the old explicit-host route.

Propose an optional keyword-only `compiler_binding=None` on the existing
`prepare_variant(program, providers, example_inputs)` and an internal matching
validation path. When absent, preserve every old check. When present, require
an exact live `BoundMixedEnvelope`, prove this program is its complete translated
projection, and recover the terminal trace from the selected artifact. Check the
trace/binding/contract/descriptor identities above, generated provider
associations and the unchanged original function. This is a checked compiler
context, not a caller-supplied set of writable buffers or a boolean exemption.

Only then permit a prefix-buffer write if that source is the terminal
descriptor's exact destination, is a distinct fresh live `OwnedBuffer`, is
already initialized by the preceding compiler program and is in the actual
output projection. Every selected pointer effect must map through the exact
formal/field to the declared source or destination; source writes still decline.
Destination reads are allowed only with the existing initialization proof.
Do not require destination `written=True` to mean complete coverage: both
operands are initialized already, and actual selected effects decide what is
read or modified. Retain all parameter-byte coverage, layout/symbol, scalar
width, grid, alignment and owner checks in `_validate_cute_call`.

Bracket allocating preparation/capture stages with this exact source binding's
checks, as the existing frontend preparer brackets its original attachment.
Preserve per-launch provider checks and existing `_Preparation.abort()` cleanup.
This needs no new native argument, `MixedProgram` field or portable metadata
schema. A small private projection checker shared with the linker avoids a
second independent interpretation of envelope order/layouts/output authority.

Releases and remaining bounds

The envelope forbids aliasing and reuse and checks that released sources are
never subsequently consumed or returned. Therefore omitting its Release events
can conservatively extend temporary lifetimes. Existing preparation already
retains all allocations in `state.buffers`, passes them to `_make_replay`, and
the native executor owns their enqueue lifetime. Preserve every allocation and
write; do not drop a kernel just because its result is later released. This can
increase peak memory relative to ordinary execution. It does not reproduce
eager deallocation timing and makes no allocator-planning or peak-memory claim.

Keep the current numeric subset explicit. `_Operands.numeric_value` accepts
literal or direct boxed Tensor metadata only; products in shape/stride metadata
must still decline until their range proof is implemented. Generated scalar
products supported by `bind_grid_recipe` need not be removed. Existing mixed
preparation also requires at least one boxed integer, positive contiguous rank
one/two allocations and exact ordinary Tensor boxes; static no-integer cases,
Parameter boxes, aliases, duplicate/non-Tensor outputs and broader layouts stay
outside this first native linker. No fixture names, dimensions, kernel names or
observed arm constants may define eligibility.

`prepare_guard(linked)` remains required: it exports full local ShapeEnv guards,
the exact selected arm and every numeric range obligation against original boxed
integers. In particular, do not discard an i32 bound because the ordinary hint
fits or infer stride width from shape width. Preparation alone does not install
that predicate or enforce the outer compiler contract. Publication, miss routing,
registration/native-borrow coordination, cache rearming and partitioning remain
separate work; retain the original wrapper and owners through the cold transaction.
The linker itself neither acquires nor closes providers and retains no real box.

Focused proof for implementation

- Compare the old linker before/after factoring on the same real artifact: every
  physical field, grid, predicate and range obligation must remain equal.
- Use the real two-operand trace and checked envelope to prove exact source and
  destination field mapping, actual output tuple identity/order, no added
  allocations and no invented boxed integer. Include equal hints at different
  boxed indices and i32 boundary/range obligations.
- Reject a foreign binding/contract/trace/owner/site/effect receipt, swapped
  equal-layout operands, substituted generated global/provider, missing call,
  grid/formal mismatch, missing copy and unsupported metadata expressions.
- Exercise initialized destination writes and reads, source-write rejection,
  empty-destination rejection, changed output order and old-route prefix-write
  rejection. A merely matching source name must not authorize the exception.
- Include a released temporary followed by no use and an actual retained output;
  check complete allocation/call preservation. A later use or output of a
  released source must fail before normalization/capture.
- Root's later GPU control should use actual compiler envelope/ordinary capsule,
  both selected CuTe arms and both launchers, inspect full captured bytes/grids,
  compare the original output tuple on unseen batches, and check input/temporary
  expiry plus held outputs after close. Keep cleanup-failure ownership explicit.

CPU stand-ins can validate translation and failure ordering but cannot certify
real selected ABI, capture association, native lifetime or numerical behavior.
No test in this proposal has been run and no performance improvement is claimed.
