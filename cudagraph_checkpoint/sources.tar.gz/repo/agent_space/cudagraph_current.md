# Current CUDA graph runtime prototype

Latest qualification: **280 CPU and 11 CUDA tests pass**, with root and independent audits.
[Detailed results](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/output_slots/cache_restoration/local_fx_revision1/RESULTS.md) and [exact selected implementation](/data/eellison/src/pytorch/agent_space/cudagraph_inductor_frontend_comparison/compiler_cute_handoff/multiple_calls/backward_contract/automatic_origin/attachment_candidate/native_candidate/dynamic_release/output_slots/cache_restoration/local_fx_revision1/qualification2/manifest.json).

Generated dynamic backward reaches native C++ replay through both generated-host FX tracing and retained Inductor IR. A four-kernel backward warms at width 13, then replays at widths 2, 7, 35 and 36. Physical None gradient slots, symbolic allocations and launch expressions are preserved.

A real local FX cache miss/save followed by hit/load now restores the compiler-produced saved-input release schedule and installs a fresh native entry. Both entries preserve numerical gradients, optional input-release semantics, and held outputs after close. Cache keys carry stable classifications; live source authority remains scoped to compilation.

The same qualification keeps nine release, disabled and retained-graph controls. The earlier broader suite (252 CPU / 44 CUDA) also covers user-Triton, CuTe, and direct CUDA argument/grid updates; these suite counts overlap. A separate serializer regression passed 252 CPU / 2 CUDA controls.

Forward remains ordinary Inductor in this backward workload. Remote FX and AOT caches are excluded. No new performance or peak-memory claim is made. Results use the pinned CUDA 13 / GB300 environment with CuTe 4.6.2.

Next: broader representative workloads and a smaller, reviewable integration. General CUDA host registration, graph partitioning and allocator memory planning remain deferred.

- [User milestone plan](/home/eellison/cudagraph_plan.md)
- [Machine-readable qualification](/data/eellison/src/pytorch/agent_space/cudagraph_latest_qualification.json)
- [Checkpoint note](/data/eellison/src/pytorch/agent_space/cudagraph_checkpoint_2026-09-14.md)
- [Earlier checkpoints and benchmarks](/data/eellison/src/pytorch/agent_space/cudagraph_status_archive/2026-09-14_before_dynamic_backward_qualification.md)

Use the selected manifest and native launcher together. Activating the ordinary environment alone does not select the experimental overlays.
