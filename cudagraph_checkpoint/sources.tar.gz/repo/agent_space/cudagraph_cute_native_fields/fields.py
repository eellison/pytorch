from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from argument_flow import ValueFlow
from marked_flow import MarkedArgumentFlow


@dataclass(frozen=True)
class FieldSource:
    kind: str
    ir_arg_index: int | None
    formal_name: str | None
    metadata_path: tuple[int, ...]
    property: str
    property_path: tuple[int, ...]
    value: ValueFlow


@dataclass(frozen=True)
class PointerField:
    parameter: int
    byte_offset: int
    source: FieldSource


@dataclass(frozen=True)
class IntegerField:
    parameter: int
    byte_offset: int
    dtype: str
    source: FieldSource


@dataclass(frozen=True)
class FixedField:
    """A required capture/source guard, not proof that this value is fixed."""

    parameter: int
    byte_offset: int
    byte_size: int
    dtype: str
    source: FieldSource


@dataclass(frozen=True)
class Padding:
    """Bytes to preserve from checked capture; never an inferred scalar field."""

    parameter: int
    byte_offset: int
    byte_size: int


@dataclass(frozen=True)
class StaticProperty:
    ir_arg_index: int
    formal_name: str
    property: str
    property_path: tuple[int, ...]
    value: ValueFlow


@dataclass(frozen=True)
class NodeFields:
    launch: int
    kernel_symbol: str
    parameter_sizes: tuple[int, ...]
    pointers: tuple[PointerField, ...]
    integers: tuple[IntegerField, ...]
    fixed: tuple[FixedField, ...]
    padding: tuple[Padding, ...]

    @property
    def pointer_descriptors(self):
        return tuple((item.parameter, item.byte_offset) for item in self.pointers)

    @property
    def scalar_descriptors(self):
        return tuple((item.parameter, item.byte_offset, item.dtype) for item in self.integers)


def _derive(flow: Any, formals: Any, layout: Any) -> tuple[tuple[NodeFields, ...], tuple[StaticProperty, ...]]:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import llvm

    if type(flow) is not MarkedArgumentFlow:
        raise TypeError("Expected the genuine checked marked argument flow")
    flow.check()
    formals.check()
    layout.check()
    program = formals.program
    aggregate = layout.query.plan
    if (flow.experiment is not program.experiment or flow.module is not program.module
            or aggregate.mapping.program is not program or layout.query.host_target != program.host_target):
        raise ValueError("Native fields require one original/compiled/layout owner")
    by_llvm = {item.llvm_arg_index: item for item in formals.formals}
    typed = {item.source_arg_index: item for item in aggregate.formals}
    layouts = {item.source_arg_index: item for item in layout.formals}
    if (len(by_llvm) != len(formals.formals) or set(by_llvm) != set(range(len(flow.host_types)))
            or any(by_llvm[index].llvm_type != typ for index, typ in enumerate(flow.host_types))
            or set(typed) != set(layouts)):
        raise ValueError("Original formal and target layout coverage disagree")
    marker_slots = {(item.kernel_symbol, item.device_parameter_index): item for item in flow.marker_slots}
    static = []
    for index, tensor in typed.items():
        original = next(item for item in formals.formals if item.ir_arg_index == index)
        for component in tensor.constants:
            spec = component.spec
            static.append(StaticProperty(index, original.metadata.name, spec.property, spec.property_path, component.source))
    nodes = []
    for launch in flow.launches:
        pointers, integers, fixed, padding, sizes = [], [], [], [], []
        for parameter in launch.parameters:
            if parameter.index != len(sizes) or parameter.llvm_type != parameter.source.llvm_type:
                raise ValueError("Device parameters must retain their exact typed slot order")
            value = parameter.source
            if value.kind == "marker":
                slot = marker_slots.get((launch.registration.kernel_symbol, parameter.index))
                if slot is None or slot.symbol != value.value or slot.llvm_type not in ("i32", "i64"):
                    raise ValueError("Marker does not identify a supported exact scalar slot")
                source = FieldSource("marker", None, None, (), "launch_operand", (slot.source_parameter_index,), value)
                integers.append(IntegerField(parameter.index, 0, slot.llvm_type, source))
                sizes.append(int(slot.llvm_type[1:]) // 8)
                continue
            if value.kind != "argument" or value.argument not in by_llvm or value.operands or value.attributes or value.value is not None:
                raise ValueError("Native fields require direct original arguments/components or checked markers")
            original = by_llvm[value.argument]
            source_index = original.ir_arg_index
            if source_index in typed:
                tensor, target = typed[source_index], layouts[source_index]
                leaves = {item.path: item for item in tensor.leaves}
                fields = {item.path: item for item in target.fields}
                if tensor.llvm_type != original.llvm_type or target.llvm_type != original.llvm_type or set(leaves) != set(fields):
                    raise ValueError("Tensor fields do not cover the exact forwarded aggregate")
                if value.path:
                    if value.path not in leaves or value.llvm_type != leaves[value.path].llvm_type:
                        raise ValueError("Partial aggregates and unresolved component paths are unsupported")
                    selected = ((leaves[value.path], fields[value.path], 0),)
                    size = fields[value.path].size
                else:
                    if value.llvm_type != tensor.llvm_type:
                        raise ValueError("Whole-formal forwarding changed the aggregate type")
                    selected = tuple((leaves[item.path], item, item.offset) for item in target.fields)
                    size = target.size
                intervals = []
                for leaf, target_field, offset in selected:
                    if target_field.llvm_type != leaf.llvm_type:
                        raise ValueError("Component layout changed the exact scalar type")
                    spec = leaf.component.spec
                    source = FieldSource("tensor_property", source_index, original.metadata.name, original.metadata.path,
                                         spec.property, spec.property_path, leaf.component.source)
                    if spec.property == "pointer":
                        with program.context:
                            pointer_type = ir.Type.parse(leaf.llvm_type)
                        if spec.property_path or not isinstance(pointer_type, llvm.PointerType) or target_field.size != 8:
                            raise ValueError("Native pointer fields require an exact 8-byte effective pointer")
                        pointers.append(PointerField(parameter.index, offset, source))
                    elif spec.property in ("shape", "stride") and leaf.llvm_type in ("i32", "i64"):
                        if target_field.size != int(leaf.llvm_type[1:]) // 8:
                            raise ValueError("Native scalar width differs from the compiler layout")
                        integers.append(IntegerField(parameter.index, offset, leaf.llvm_type, source))
                    else:
                        raise ValueError("Unsupported mutable tensor property or integer width")
                    intervals.append((offset, offset + target_field.size))
                cursor = 0
                for begin, end in sorted(intervals):
                    if begin < cursor or end > size:
                        raise ValueError("Native fields overlap or exceed the actual parameter")
                    if begin > cursor:
                        padding.append(Padding(parameter.index, cursor, begin - cursor))
                    cursor = end
                if cursor < size:
                    padding.append(Padding(parameter.index, cursor, size - cursor))
                sizes.append(size)
            else:
                if value.path or original.metadata.kind != "Var" or value.llvm_type != original.llvm_type:
                    raise ValueError("Unsupported pointer, aggregate or transformed scalar formal")
                source = FieldSource("scalar_formal", source_index, original.metadata.name, original.metadata.path,
                                     "value", (), value)
                if value.llvm_type in ("i32", "i64"):
                    integers.append(IntegerField(parameter.index, 0, value.llvm_type, source))
                    sizes.append(int(value.llvm_type[1:]) // 8)
                elif value.llvm_type == "f32":
                    fixed.append(FixedField(parameter.index, 0, 4, "f32", source))
                    sizes.append(4)
                else:
                    raise ValueError("Unsupported native scalar width or floating mutability")
        nodes.append(NodeFields(launch.index, launch.registration.kernel_symbol, tuple(sizes),
                                tuple(pointers), tuple(integers), tuple(fixed), tuple(padding)))
    return tuple(nodes), tuple(static)


@dataclass(frozen=True)
class NativeFieldPlan:
    flow: Any = field(repr=False)
    formals: Any = field(repr=False)
    layout: Any = field(repr=False)
    nodes: tuple[NodeFields, ...]
    static_properties: tuple[StaticProperty, ...]
    _owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        owned = (self.flow, self.formals, self.layout, self.nodes, self.static_properties)
        if len(self._owners) != len(owned) or any(item is not original for item, original in zip(owned, self._owners)):
            raise RuntimeError("Native field descriptor ownership changed")
        if _derive(self.flow, self.formals, self.layout) != (self.nodes, self.static_properties):
            raise RuntimeError("Native fields changed their exact compiler-derived sources or offsets")


def derive_native_fields(flow: Any, formals: Any, layout: Any) -> NativeFieldPlan:
    """Describe updates and explicit capture obligations; this does not admit native replay."""
    nodes, static = _derive(flow, formals, layout)
    return NativeFieldPlan(flow, formals, layout, nodes, static, (flow, formals, layout, nodes, static))
