from __future__ import annotations

import io
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any

from branch_abi import _allocation, _calls, _exact_uses, _function, _gep_indices, _integer, _ordered, _owner, _uses
from torch._inductor.runtime.cutedsl_parameter_analysis import _raw_value, _walk_block


FLOW_VERSION = 1
_LAUNCHES = {"_cudaLaunchKernelEx": (3, 1, 2), "_cudaLaunchKernel": (10, 0, 7)}
_HOST_CALLS = frozenset(_LAUNCHES) | {
    "printf", "_cudaGetDevice", "_cudaDeviceGetAttribute", "_cuKernelGetAttribute",
    "_cudaFuncSetAttribute", "_cudaKernelSetAttributeForDevice", "_cudaOccupancyMaxActiveBlocksPerMultiprocessor",
}
_UNARY = {"llvm.trunc", "llvm.zext", "llvm.sext", "llvm.bitcast", "llvm.addrspacecast",
          "llvm.fptrunc", "llvm.fpext", "llvm.fptosi", "llvm.fptoui", "llvm.sitofp", "llvm.uitofp",
          "llvm.ptrtoint", "llvm.inttoptr"}
_BINARY = {"llvm.add", "llvm.sub", "llvm.mul", "llvm.udiv", "llvm.sdiv", "llvm.urem", "llvm.srem",
           "llvm.shl", "llvm.lshr", "llvm.ashr", "llvm.and", "llvm.or", "llvm.xor", "llvm.icmp",
           "llvm.fadd", "llvm.fsub", "llvm.fmul", "llvm.fdiv", "llvm.frem", "llvm.fcmp"}


@dataclass(frozen=True)
class ValueFlow:
    kind: str
    llvm_type: str
    argument: int | None = None
    path: tuple[int, ...] = ()
    value: str | None = None
    operands: tuple[ValueFlow, ...] = ()
    attributes: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class ParameterFlow:
    index: int
    llvm_type: str
    source: ValueFlow


@dataclass(frozen=True)
class BinaryImage:
    library_slot: int
    global_name: str
    sha256: str
    data: bytes = field(repr=False)


@dataclass(frozen=True)
class KernelRegistration:
    kernel_symbol: str
    handle_global: str
    library_slot: int
    binary_global: str
    binary_sha256: str


@dataclass(frozen=True)
class LaunchFlow:
    index: int
    block_index: int
    operation_index: int
    callee: str
    registration: KernelRegistration
    parameters: tuple[ParameterFlow, ...]


def _snapshot(module: Any) -> tuple[str, bytes]:
    buffer = io.BytesIO()
    module.operation.write_bytecode(buffer)
    return str(module), buffer.getvalue()


@dataclass(frozen=True)
class ArgumentFlow:
    module: Any = field(repr=False)
    context: Any = field(repr=False)
    function_name: str
    host_types: tuple[str, ...]
    binaries: tuple[BinaryImage, ...]
    registrations: tuple[KernelRegistration, ...]
    launches: tuple[LaunchFlow, ...]
    module_sha256: str
    _text: str = field(repr=False)
    _bytecode: bytes = field(repr=False)
    _owners: tuple[Any, Any] = field(repr=False)
    _fingerprint: str = field(repr=False)

    def _digest(self) -> str:
        state = (FLOW_VERSION, self.function_name, self.host_types, self.binaries, self.registrations,
                 self.launches, self.module_sha256)
        return sha256(repr(state).encode()).hexdigest()

    def check(self) -> None:
        if (self.module is not self._owners[0] or self.context is not self._owners[1]
                or self.module.context != self.context or self._digest() != self._fingerprint
                or sha256(self._bytecode).hexdigest() != self.module_sha256
                or any(sha256(image.data).hexdigest() != image.sha256 for image in self.binaries)):
            raise RuntimeError("Argument-flow source association changed")
        with self.context:
            if _snapshot(self.module) != (self._text, self._bytecode):
                raise RuntimeError("The owned argument-flow Module changed")


def _plain_memory(op: Any) -> None:
    from cutlass._mlir import ir

    if set(op.attributes) - {"alignment", "ordering"}:
        raise ValueError("Unsupported memory access attributes in argument packing")
    ordering = op.attributes.get("ordering")
    if ordering is not None and (not isinstance(ordering, ir.IntegerAttr) or ordering.value != 0):
        raise ValueError("Atomic ABI storage accesses are unsupported")


def _local_allocation(value: Any, count: int, typ: Any) -> Any:
    op = _allocation(value, count, typ)
    if set(op.attributes) - {"elem_type", "alignment"}:
        raise ValueError("Unsupported ABI allocation attributes")
    return op


def _library_slot(value: Any, argument: Any) -> tuple[int, Any]:
    from cutlass._mlir.dialects import llvm

    gep = _owner(value, "llvm.getelementptr")
    indices = _gep_indices(gep)
    if (gep.operands[0] != argument or len(indices) != 1 or indices[0] < 0
            or gep.attributes["elem_type"].value != llvm.PointerType.get()):
        raise ValueError("Expected a constant library-array slot")
    return indices[0], gep


def _registrations(module: Any) -> tuple[tuple[BinaryImage, ...], tuple[KernelRegistration, ...]]:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import llvm

    globals_by_name = {}
    for view in module.body.operations:
        op = view.operation
        if op.name == "llvm.mlir.global":
            name = op.attributes["sym_name"].value
            if name in globals_by_name:
                raise ValueError("Duplicate LLVM global name")
            globals_by_name[name] = op
    counter = _function(module, "cuda_num_binaries")
    counter_ops = [view.operation for view in counter.regions[0].blocks[0].operations]
    if (len(counter.regions[0].blocks) != 1 or len(counter_ops) != 2
            or counter_ops[-1].name != "llvm.return" or len(counter_ops[-1].operands) != 1):
        raise ValueError("Expected a constant compiler library count")
    count = _integer(counter_ops[-1].operands[0])
    if count <= 0:
        raise ValueError("Expected at least one embedded library")
    init = _function(module, "cuda_init")
    init_calls = _calls(init, "_cudaLibraryLoadData")
    if len(init_calls) != count or not init.regions[0].blocks[0].arguments:
        raise ValueError("Library count and initializer calls disagree")
    images = {}
    for call in init_calls:
        if len(call.operands) != 8:
            raise ValueError("Unsupported library-load calling convention")
        index, slot = _library_slot(call.operands[0], init.regions[0].blocks[0].arguments[0])
        address = _owner(call.operands[1], "llvm.mlir.addressof")
        name = address.attributes["global_name"].value
        global_op = globals_by_name.get(name)
        value = None if global_op is None else global_op.attributes.get("value")
        if (index in images or index >= count or not isinstance(value, ir.StringAttr) or not value.value_bytes
                or "constant" not in global_op.attributes
                or global_op.attributes["global_type"].value != ir.Type.parse(f"!llvm.array<{len(value.value_bytes)} x i8>")):
            raise ValueError("Library initialization lacks an exact immutable image")
        _ordered(slot, call)
        _ordered(address, call)
        _exact_uses(slot.results[0], [(call, 0)])
        _exact_uses(address.results[0], [(call, 1)])
        images[index] = BinaryImage(index, name, sha256(value.value_bytes).hexdigest(), value.value_bytes)
    if set(images) != set(range(count)):
        raise ValueError("Incomplete library-slot initialization")

    mapping = None
    registration_calls = []
    for entry in ("cuda_load", "cuda_load_to_device"):
        loader = _function(module, entry)
        if not loader.regions[0].blocks[0].arguments:
            raise ValueError("Loader has no library-array formal")
        current = {}
        for call in _calls(loader, "_cudaLibraryGetKernel"):
            if len(call.operands) != 3:
                raise ValueError("Unsupported kernel-registration calling convention")
            address = _owner(call.operands[0], "llvm.mlir.addressof")
            name = address.attributes["global_name"].value
            library = _owner(call.operands[1], "llvm.load")
            _plain_memory(library)
            index, slot = _library_slot(library.operands[0], loader.regions[0].blocks[0].arguments[0])
            if index not in images:
                raise ValueError("Kernel registration references an uninitialized library")
            memory = call.operands[2]
            stores = [op for op, operand in _uses(memory) if op.name == "llvm.store" and operand == 1]
            if len(stores) != 1:
                raise ValueError("Kernel symbol storage must have one writer")
            store = stores[0]
            _plain_memory(store)
            literal = _owner(store.operands[0], "llvm.mlir.constant")
            text = literal.attributes.get("value")
            if not isinstance(text, ir.StringAttr) or not text.value_bytes.endswith(b"\0") or b"\0" in text.value_bytes[:-1]:
                raise ValueError("Kernel symbol must be an exact NUL-terminated literal")
            symbol = text.value_bytes[:-1].decode("utf-8")
            if not symbol or name in current or any(item.kernel_symbol == symbol and item.library_slot == index for item in current.values()):
                raise ValueError("Ambiguous kernel symbol or handle registration")
            typ = literal.results[0].type
            if typ != ir.Type.parse(f"!llvm.array<{len(text.value_bytes)} x i8>"):
                raise ValueError("Kernel symbol literal has an inconsistent type")
            allocation = _local_allocation(memory, 1, typ)
            _ordered(allocation, store, call)
            _ordered(literal, store)
            _ordered(address, call)
            _ordered(slot, library, call)
            _exact_uses(memory, [(store, 1), (call, 2)])
            _exact_uses(slot.results[0], [(library, 0)])
            _exact_uses(library.results[0], [(call, 1)])
            image = images[index]
            current[name] = KernelRegistration(symbol, name, index, image.global_name, image.sha256)
            registration_calls.append(call)
        if not current or (mapping is not None and current != mapping):
            raise ValueError("Compiler loader entry points disagree on exact kernel registrations")
        mapping = current
    for name in mapping:
        op = globals_by_name.get(name)
        if op is None or op.attributes["global_type"].value != llvm.PointerType.get():
            raise ValueError("Kernel registration does not name a pointer global")
    image_names = {image.global_name for image in images.values()}
    for op in _walk_block(module.body):
        if op.name != "llvm.mlir.addressof":
            continue
        name = op.attributes["global_name"].value
        if name in image_names:
            if any(use not in init_calls or operand != 1 for use, operand in _uses(op.results[0])):
                raise ValueError("Unknown binary-image writer or escaped address")
        if name in mapping:
            for use, operand in _uses(op.results[0]):
                if use in registration_calls and operand == 0:
                    continue
                if use.name != "llvm.load" or operand != 0:
                    raise ValueError("Unknown kernel-handle writer or escaped address")
                _plain_memory(use)
    return tuple(images[index] for index in range(count)), tuple(mapping[name] for name in sorted(mapping))


class _Values:
    def __init__(self, arguments: Any) -> None:
        self.arguments = {_raw_value(value): index for index, value in enumerate(arguments)}
        self.cache: dict[Any, ValueFlow] = {}
        self.active: set[Any] = set()

    def read(self, value: Any) -> ValueFlow:
        from cutlass._mlir import ir

        value = _raw_value(value)
        if value in self.cache:
            return self.cache[value]
        if value in self.active:
            raise ValueError("Cyclic argument provenance is unsupported")
        typ = str(value.type)
        if value in self.arguments:
            result = ValueFlow("argument", typ, self.arguments[value])
        else:
            op = value.owner
            if isinstance(op, ir.OpView):
                op = op.operation
            if not isinstance(op, ir.Operation):
                raise ValueError("Non-entry block arguments and merged provenance are unsupported")
            if len(op.results) != 1 or op.regions or op.successors:
                raise ValueError("Unsupported multi-result or control-flow provenance")
            self.active.add(value)
            try:
                attrs = tuple((name, str(op.attributes[name])) for name in sorted(op.attributes))
                if op.name == "llvm.mlir.constant" and not op.operands and set(op.attributes) == {"value"}:
                    result = ValueFlow("constant", typ, value=str(op.attributes["value"]))
                elif op.name == "llvm.mlir.zero" and not op.operands and not op.attributes:
                    result = ValueFlow("zero", typ)
                elif op.name == "llvm.extractvalue" and len(op.operands) == 1 and set(op.attributes) == {"position"}:
                    source = self.read(op.operands[0])
                    path = tuple(op.attributes["position"])
                    if not path or any(index < 0 for index in path):
                        raise ValueError("Invalid aggregate component path")
                    result = (ValueFlow("argument", typ, source.argument, source.path + path)
                              if source.kind == "argument" else ValueFlow(op.name, typ, path=path, operands=(source,)))
                elif op.name == "llvm.insertvalue" and len(op.operands) == 2 and set(op.attributes) == {"position"}:
                    result = ValueFlow(op.name, typ, path=tuple(op.attributes["position"]),
                                       operands=tuple(self.read(item) for item in op.operands))
                elif ((op.name in _UNARY and len(op.operands) == 1)
                      or (op.name in _BINARY and len(op.operands) == 2)
                      or (op.name == "llvm.getelementptr" and op.operands)):
                    result = ValueFlow(op.name, typ, operands=tuple(self.read(item) for item in op.operands), attributes=attrs)
                else:
                    raise ValueError(f"Unresolved or unsupported parameter provenance: {op.name}")
            finally:
                self.active.remove(value)
        self.cache[value] = result
        return result


def _pack(call: Any, calls: list[Any], values: _Values) -> tuple[ParameterFlow, ...]:
    from cutlass._mlir.dialects import llvm

    callee = call.attributes["callee"].value
    array = call.operands[_LAUNCHES[callee][2]]
    allocation = _owner(array, "llvm.alloca")
    count = _integer(allocation.operands[0])
    if count < 0:
        raise ValueError("Negative kernel parameter count")
    _local_allocation(array, count, llvm.PointerType.get())
    _ordered(allocation, call)
    projections = [op for op, operand in _uses(array) if op.name == "llvm.getelementptr" and operand == 0]
    consumers = [(other, _LAUNCHES[other.attributes["callee"].value][2]) for other in calls
                 if other.operands[_LAUNCHES[other.attributes["callee"].value][2]] == array]
    _exact_uses(array, [(op, 0) for op in projections] + consumers)
    if len(projections) != count:
        raise ValueError("Kernel parameter array has missing or extra slot projections")
    parameters = {}
    for projection in projections:
        indices = _gep_indices(projection)
        if (len(indices) != 1 or not 0 <= indices[0] < count or indices[0] in parameters
                or projection.attributes["elem_type"].value != llvm.PointerType.get()):
            raise ValueError("Ambiguous or out-of-range parameter-array index")
        uses = _uses(projection.results[0])
        if len(uses) != 1 or uses[0][0].name != "llvm.store" or uses[0][1] != 1:
            raise ValueError("A parameter-array slot needs exactly one pointer store")
        pointer_store = uses[0][0]
        _plain_memory(pointer_store)
        memory = pointer_store.operands[0]
        stores = [op for op, operand in _uses(memory) if op.name == "llvm.store" and operand == 1]
        if len(stores) != 1:
            raise ValueError("Parameter bytes need one complete dominating writer")
        store = stores[0]
        _plain_memory(store)
        typ = store.operands[0].type
        backing = _local_allocation(memory, 1, typ)
        _exact_uses(memory, [(store, 1), (pointer_store, 0)])
        _ordered(backing, store, pointer_store, call)
        _ordered(allocation, projection, pointer_store, call)
        for consumer, _ in consumers:
            _ordered(pointer_store, consumer)
        index = indices[0]
        parameters[index] = ParameterFlow(index, str(typ), values.read(store.operands[0]))
    return tuple(parameters[index] for index in range(count))


def analyze_argument_flow(module: Any, function_name: str) -> ArgumentFlow:
    from cutlass._mlir import ir

    if not isinstance(module, ir.Module) or type(function_name) is not str or not function_name:
        raise TypeError("Expected an explicitly owned LLVM-dialect Module and host function name")
    context = module.context
    with context, ir.raw_values():
        text, bytecode = _snapshot(module)
        if not module.operation.verify():
            raise ValueError("LLVM-dialect Module failed verification")
        host = _function(module, function_name)
        blocks = list(host.regions[0].blocks)
        host_types = tuple(str(value.type) for value in blocks[0].arguments)
        calls = []
        positions = {}
        for block_index, block in enumerate(blocks):
            for op_index, view in enumerate(block.operations):
                op = view.operation
                if op.regions:
                    raise ValueError("Nested regions in a lowered host function are unsupported")
                if op.name != "llvm.call":
                    continue
                callee = op.attributes.get("callee")
                if callee is None or callee.value not in _HOST_CALLS:
                    raise ValueError("Unknown or indirect host call may contain an unobserved invocation")
                if callee.value in _LAUNCHES:
                    if len(op.operands) != _LAUNCHES[callee.value][0]:
                        raise ValueError("Unsupported kernel-launch calling convention")
                    calls.append(op)
                    positions[op] = (block_index, op_index)
        if not calls:
            raise ValueError("Host function contains no supported kernel invocation")
        binaries, registrations = _registrations(module)
        handles = {record.handle_global: record for record in registrations}
        values = _Values(blocks[0].arguments)
        launches = []
        for index, call in enumerate(calls):
            callee = call.attributes["callee"].value
            handle = _owner(call.operands[_LAUNCHES[callee][1]], "llvm.load")
            _plain_memory(handle)
            address = _owner(handle.operands[0], "llvm.mlir.addressof")
            name = address.attributes["global_name"].value
            if name not in handles:
                raise ValueError("Launch function lacks an exact binary/symbol registration")
            launches.append(LaunchFlow(index, *positions[call], callee, handles[name], _pack(call, calls, values)))
        if _snapshot(module) != (text, bytecode):
            raise RuntimeError("Argument-flow inspection changed the Module")
    result = ArgumentFlow(module, context, function_name, host_types, binaries, registrations, tuple(launches),
                          sha256(bytecode).hexdigest(), text, bytecode, (module, context), "")
    object.__setattr__(result, "_fingerprint", result._digest())
    result.check()
    return result
