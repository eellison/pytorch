from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from frontend import _Collector, _TRACE_LOCK
from launch_events import CloneBundle


def _snapshot(module: Any) -> tuple[str, bytes]:
    buffer = io.BytesIO()
    module.operation.write_bytecode(buffer)
    return str(module), buffer.getvalue()


@dataclass(frozen=True)
class CompiledProgram:
    bundle: CloneBundle = field(repr=False)
    source_module: Any = field(repr=False)
    source_context: Any = field(repr=False)
    source_artifact: Any = field(repr=False)
    source_text: str = field(repr=False)
    source_bytecode: bytes = field(repr=False)
    artifact: Any = field(repr=False)
    module: Any = field(repr=False)
    context: Any = field(repr=False)
    compiled_bytecode: bytes = field(repr=False)
    module_text: str = field(repr=False)
    module_bytecode: bytes = field(repr=False)
    function_name: str
    arch: str
    source_sha256: str
    compiled_sha256: str

    def check(self) -> None:
        import cutlass.compiler as compiler

        self.bundle.check_originals()
        if not self.source_artifact.is_consumed or self.artifact.is_consumed:
            raise RuntimeError("Unexpected compiler artifact lifecycle")
        if (type(self.artifact) is not compiler.CompiledMlirArtifact
                or self.artifact.get_bitcode() != self.compiled_bytecode
                or sha256(self.compiled_bytecode).hexdigest() != self.compiled_sha256
                or sha256(self.source_bytecode).hexdigest() != self.source_sha256):
            raise RuntimeError("Original compiled payload changed")
        for module, context, expected in (
            (self.source_module, self.source_context, (self.source_text, self.source_bytecode)),
            (self.module, self.context, (self.module_text, self.module_bytecode)),
        ):
            if module.context != context:
                raise RuntimeError("Original Module context changed")
            with context:
                if _snapshot(module) != expected:
                    raise RuntimeError("Original compiler Module changed")


def compile_program(host: Any, kernel: Any, *arguments: Any, arch: str = "sm_80") -> CompiledProgram:
    import cutlass.compiler as compiler
    import cutlass.cute as cute
    from cutlass._mlir import ir
    from cutlass.cutlass_dsl.cutlass import CuTeDSL

    if version("nvidia-cutlass-dsl") != "4.6.2":
        raise RuntimeError("Expected the inspected CuTe compiler version")
    if type(arch) is not str or re.fullmatch(r"sm_[0-9]+[af]?", arch) is None:
        raise ValueError("Expected an explicit CUDA architecture")
    if ir.Context.current is not None or not _TRACE_LOCK.acquire(blocking=False):
        raise RuntimeError("Compilation requires an isolated frontend context")
    try:
        bundle = CloneBundle.create(host, kernel)
        dsl = CuTeDSL._get_dsl()
        if (type(dsl) is not CuTeDSL or dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get()
                or dsl.envar.keep_ir_clean):
            raise RuntimeError("Compilation requires an isolated standard frontend")
        collector = _Collector(dsl)
        try:
            source = cute.compile.to_precompiled_mlir(
                bundle.host, *arguments, options=f"--gpu-arch {arch}",
                no_jit_engine=True, trace_finalize_hooks=collector,
            )
        finally:
            bundle.check_originals()
            if dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get():
                raise RuntimeError("Frontend hook scope was not restored")
        if (collector.calls != 1 or collector.module is None
                or type(source) is not compiler.PreCompiledMlirArtifact or source.is_consumed
                or source.get_bitcode() != collector.bytecode):
            raise RuntimeError("Expected the original precompiled artifact and Module")
        names = tuple(metadata.symbol_name for metadata in source.metadata)
        if names != (collector.function_name,):
            raise RuntimeError("Original metadata does not identify the traced host")
    finally:
        _TRACE_LOCK.release()
    native = compiler.CuteCompiler()
    native.set_device_target(arch)
    native.set_host_target(compiler.Compiler.detect_host_triple())
    native.set_abi(compiler.Abi.CutlassCall)
    compiled = native.compile_to(source, compiler.ArtifactType.CompiledMlir)
    if (not source.is_consumed or type(compiled) is not compiler.CompiledMlirArtifact or compiled.is_consumed
            or tuple(metadata.symbol_name for metadata in compiled.metadata) != names):
        raise RuntimeError("Expected the original compiled continuation")
    bytecode = compiled.get_bitcode()
    context = ir.Context()
    with context, ir.Location.unknown(), ir.raw_values():
        module = ir.Module.parse(bytecode)
        if not module.operation.verify():
            raise RuntimeError("Compiled Module failed verification")
        text, module_bytecode = _snapshot(module)
    result = CompiledProgram(
        bundle, collector.module, collector.context, source, collector.text, collector.bytecode,
        compiled, module, context, bytecode, text, module_bytecode, collector.function_name, arch,
        sha256(collector.bytecode).hexdigest(), sha256(bytecode).hexdigest(),
    )
    result.check()
    return result
