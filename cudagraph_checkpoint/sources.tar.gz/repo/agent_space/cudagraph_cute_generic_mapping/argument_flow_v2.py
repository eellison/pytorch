from __future__ import annotations

from typing import Any

import argument_flow as baseline
from argument_flow import ArgumentFlow


FLOW_POLICY_VERSION = 2
_HOST_OPS = baseline._UNARY | baseline._BINARY | {
    "llvm.alloca", "llvm.load", "llvm.store", "llvm.call", "llvm.getelementptr",
    "llvm.br", "llvm.cond_br", "llvm.return", "llvm.unreachable", "llvm.intr.trap",
    "llvm.mlir.addressof", "llvm.mlir.constant", "llvm.mlir.zero", "llvm.mlir.undef", "llvm.mlir.poison",
    "llvm.extractvalue", "llvm.insertvalue", "llvm.select",
}
# These are the emitted compiler/runtime entry ABIs, independent of user kernels.
_RUNTIME_ABI = {
    "_cudaLaunchKernelEx": "i32 (ptr, ptr, ptr)",
    "_cudaLaunchKernel": "i32 (ptr, i32, i32, i32, i32, i32, i32, ptr, i64, ptr)",
    "_cudaLibraryLoadData": "i32 (ptr, ptr, ptr, ptr, i32, ptr, ptr, i32)",
    "_cudaLibraryGetKernel": "i32 (ptr, ptr, ptr)",
    "_cudaOccupancyMaxActiveBlocksPerMultiprocessor": "i32 (ptr, ptr, i32, i64)",
    "_cuKernelGetAttribute": "i32 (ptr, i32, ptr, i32)",
    "_cudaDeviceGetAttribute": "i32 (ptr, i32, i32)",
    "_cudaGetDevice": "i32 (ptr)",
    "_cudaKernelSetAttributeForDevice": "i32 (ptr, i32, i32, i32)",
    "_cudaFuncSetAttribute": "i32 (ptr, i32, i32)",
    "printf": "i32 (ptr, ...)",
}


def analyze_argument_flow(module: Any, function_name: str) -> ArgumentFlow:
    from cutlass._mlir import ir

    if not isinstance(module, ir.Module) or type(function_name) is not str or not function_name:
        raise TypeError("Expected an explicitly owned LLVM-dialect Module and host function name")
    with module.context, ir.raw_values():
        before = baseline._snapshot(module)
        if not module.operation.verify():
            raise ValueError("LLVM-dialect Module failed verification")
        c_convention = ir.Attribute.parse("#llvm.cconv<ccc>")
        functions = {}
        for view in module.body.operations:
            op = view.operation
            if op.name == "llvm.func":
                name = op.attributes["sym_name"].value
                if name in functions:
                    raise ValueError("Duplicate LLVM function symbol")
                functions[name] = op
        for name, signature in _RUNTIME_ABI.items():
            if name not in functions:
                continue
            function = functions[name]
            if any(region.blocks for region in function.regions):
                raise ValueError(f"Runtime callee must be an external declaration: {name}")
            if function.attributes["function_type"].value != ir.Type.parse(f"!llvm.func<{signature}>"):
                raise ValueError(f"Runtime callee has an unsupported emitted ABI: {name}")
            convention = function.attributes.get("CConv")
            if convention is not None and convention != c_convention:
                raise ValueError(f"Runtime callee has an unsupported calling convention: {name}")
        for function in functions.values():
            for region in function.regions:
                for block in region.blocks:
                    for view in block.operations:
                        op = view.operation
                        if op.regions or op.name not in _HOST_OPS:
                            raise ValueError(f"Unsupported host operation or effect: {op.name}")
                        if op.name != "llvm.call":
                            continue
                        callee = op.attributes.get("callee")
                        if callee is None or callee.value not in functions:
                            raise ValueError("Unknown or indirect host call is unsupported")
                        target = functions[callee.value]
                        if callee.value not in _RUNTIME_ABI and not any(region.blocks for region in target.regions):
                            raise ValueError(f"Unknown external host effect: {callee.value}")
                        convention = op.attributes.get("CConv")
                        if callee.value in _RUNTIME_ABI and convention is not None:
                            if convention != c_convention:
                                raise ValueError(f"Runtime call has an unsupported calling convention: {callee.value}")
        if baseline._snapshot(module) != before:
            raise RuntimeError("Host-effect admission changed the Module")
    # Control-flow guards remain the host-plan reader's responsibility.
    return baseline.analyze_argument_flow(module, function_name)
