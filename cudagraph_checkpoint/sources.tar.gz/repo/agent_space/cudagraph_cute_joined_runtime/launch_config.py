from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from hashlib import sha256
from typing import Any

from accessors import _function, _snapshot, _tagged_arguments, SOURCE_ARGUMENT
from argument_flow import ValueFlow


LAUNCH_CONFIG_VERSION = 1
_PROJECTIONS = {
    "cute.get_iter", "cute.get_layout", "cute.get_shape", "cute.get_stride",
    "cute.get_leaves", "cute.get_scalars", "cute.make_int_tuple", "cute.make_tile",
    "cute.ceil_div", "cute.to_int_tuple", "cute.size", "cute.tuple_add", "cute.tuple_mul",
}
_INTEGER_OPS = {
    "arith.addi", "arith.subi", "arith.muli", "arith.divsi", "arith.divui",
    "arith.remsi", "arith.remui", "arith.andi", "arith.ori", "arith.xori",
    "arith.shli", "arith.shrsi", "arith.shrui", "arith.extsi", "arith.extui",
    "arith.trunci", "arith.select",
}
_OVERFLOW_OPS = {"arith.addi", "arith.subi", "arith.muli", "arith.shli", "arith.trunci"}
_DEFAULT_ATTRIBUTES = {
    "cuda.launch_cfg.cooperative", "cuda.launch_cfg.programmatic_stream_serialization_allowed",
}
_LOWERED = {
    "llvm.mlir.constant", "llvm.mlir.zero", "llvm.extractvalue", "llvm.trunc", "llvm.sext", "llvm.zext",
    "llvm.add", "llvm.sub", "llvm.mul", "llvm.sdiv", "llvm.udiv", "llvm.srem", "llvm.urem",
    "llvm.and", "llvm.or", "llvm.xor", "llvm.shl", "llvm.ashr", "llvm.lshr", "llvm.icmp", "llvm.select",
}


def _owner(value: Any) -> Any:
    from cutlass._mlir import ir

    owner = value.owner
    return owner.operation if isinstance(owner, ir.OpView) else owner


def _constant(value: Any, width: int) -> int:
    from cutlass._mlir import ir

    owner = _owner(value)
    if (not isinstance(owner, ir.Operation) or owner.name != "arith.constant" or owner.operands
            or len(owner.results) != 1 or set(owner.attributes) != {"value"}
            or value.type != ir.IntegerType.get_signless(width)):
        raise ValueError("Expected a typed integer constant in the launch protocol")
    attribute = owner.attributes["value"]
    if not isinstance(attribute, ir.IntegerAttr) or attribute.type != value.type:
        raise ValueError("Launch constant has an incompatible attribute type")
    return attribute.value


def _pure(operation: Any, callee: tuple[str, ...]) -> bool:
    from cutlass._mlir import ir

    if operation.regions or operation.successors:
        return False
    name = operation.name
    if name in _OVERFLOW_OPS:
        return (set(operation.attributes) <= {"overflowFlags"}
                and ("overflowFlags" not in operation.attributes
                     or operation.attributes["overflowFlags"] == ir.Attribute.parse("#arith.overflow<none>")))
    if name in _PROJECTIONS or name in _INTEGER_OPS:
        return not operation.attributes
    if name == "arith.constant":
        return set(operation.attributes) == {"value"}
    if name == "arith.cmpi":
        return set(operation.attributes) == {"predicate"}
    if name == "cute.kernel_smem_size":
        return (not operation.operands and len(operation.results) == 1
                and str(operation.results[0].type) == "i64"
                and set(operation.attributes) == {"kernel_name"}
                and tuple(operation.attributes["kernel_name"].value) == callee)
    return False


def _diagnostic(operation: Any, shared: Any, callee: tuple[str, ...]) -> tuple[Any, str]:
    from cutlass._mlir import ir

    if (operation.name != "scf.if" or operation.results or operation.successors or operation.attributes
            or len(operation.operands) != 1 or len(operation.regions) != 2):
        raise ValueError("User host control flow is unsupported in the one-launch subset")
    predicate = operation.operands[0]
    comparison = _owner(predicate)
    if (not isinstance(comparison, ir.Operation) or comparison.name != "arith.cmpi"
            or set(comparison.attributes) != {"predicate"} or comparison.attributes["predicate"].value != 4
            or len(comparison.operands) != 2 or comparison.operands[0] != shared
            or str(predicate.type) != "i1"):
        raise ValueError("Only the compiler shared-memory upper-bound diagnostic is supported")
    limit = _constant(comparison.operands[1], 64)
    first, second = operation.regions
    if len(first.blocks) != 1 or first.blocks[0].arguments or second.blocks:
        raise ValueError("Unexpected compiler diagnostic control-flow structure")
    body = tuple(view.operation for view in first.blocks[0].operations)
    if (len(body) != 2 or body[0].name != "cute.print" or body[1].name != "scf.yield"
            or any(op.results or op.regions or op.successors for op in body)
            or tuple(body[0].operands) != (shared,) or set(body[0].attributes) != {"fmt"}
            or body[1].operands or body[1].attributes or limit <= 0):
        raise ValueError("Unexpected compiler diagnostic effects")
    text = body[0].attributes["fmt"].value
    prefix = f"\nError: kernel '@{callee[0]}::@{callee[1]}' launch shared memory exceeds current GPU arch "
    suffix = f" allowed. Allocated: {{}} bytes. Max: {limit} bytes.\n\n"
    if not text.startswith(prefix) or not text.endswith(suffix):
        raise ValueError("Host diagnostic does not match the compiler launch check")
    arch = text[len(prefix):-len(suffix)]
    if re.fullmatch(r"sm_[0-9]+[af]?", arch) is None:
        raise ValueError("Host diagnostic lacks an explicit compiler architecture")
    return predicate, arch


def _source(module: Any, function_name: str, metadata: Any) -> tuple[Any, ...]:
    from branch_abi import _exact_uses
    from cutlass._mlir import ir

    host = _function(module, function_name, "func.func")
    if (len(host.regions[0].blocks) != 1
            or set(host.attributes) - {"sym_name", "function_type", "llvm.emit_c_interface", "arg_attrs"}):
        raise ValueError("Expected a single-block original host with standard attributes")
    block = host.regions[0].blocks[0]
    arguments = tuple(block.arguments)
    indices = [param.ir_arg_index for param in metadata.params if param.ir_arg_index is not None]
    if (metadata.symbol_name != function_name or len(indices) != len(set(indices))
            or set(indices) != set(range(len(arguments)))):
        raise ValueError("Compiler metadata must identify every original source formal")
    operations = tuple(view.operation for view in block.operations)
    launches = [op for op in operations if op.name == "cuda.launch_ex"]
    configs = [op for op in operations if op.name == "cuda.launch_cfg.create"]
    if len(launches) != 1 or len(configs) != 1:
        raise ValueError("Expected exactly one unconditional source launch and configuration")
    launch, config = launches[0], configs[0]
    if (set(launch.attributes) != {"callee", "assume_kernel_attr"}
            or str(launch.attributes["assume_kernel_attr"]) != "#cuda.assume_kernel_attr<true>"
            or launch.regions or launch.successors or len(launch.results) != 1
            or str(launch.results[0].type) != "!cuda.result"):
        raise ValueError("Unsupported source launch attributes or result")
    callee = tuple(launch.attributes["callee"].value)
    if len(callee) != 2:
        raise ValueError("Launch requires an exact module and kernel symbol")
    gpu = _function(module, callee[0], "gpu.module")
    kernels = [view.operation for view in gpu.regions[0].blocks[0].operations
               if view.operation.name == "cuda.kernel" and view.operation.attributes["sym_name"].value == callee[1]]
    if (len(kernels) != 1 or tuple(kernels[0].attributes["function_type"].value.inputs)
            != tuple(value.type for value in launch.operands[1:])):
        raise ValueError("Launch operand types do not identify the original kernel signature")
    if (len(config.operands) != 8 or len(config.results) != 1 or config.regions or config.successors
            or set(config.attributes) != {"maxNumAttrs"}
            or not isinstance(config.attributes["maxNumAttrs"], ir.IntegerAttr)
            or config.attributes["maxNumAttrs"].value < 2
            or tuple(str(value.type) for value in config.operands) != (
                "i32", "i32", "i32", "i64", "i32", "i32", "i32", "!cuda.stream")
            or not launch.operands or launch.operands[0] != config.results[0]
            or operations.index(config) >= operations.index(launch)):
        raise ValueError("Unsupported semantic launch-configuration fields")
    stream = config.operands[7]
    stream_indices = [index for index, value in enumerate(arguments) if value == stream]
    if len(stream_indices) != 1:
        raise ValueError("Launch stream must be an original host formal")
    attributes = [op for op in operations if op.name in _DEFAULT_ATTRIBUTES]
    if len(attributes) != 2 or {op.name for op in attributes} != _DEFAULT_ATTRIBUTES:
        raise ValueError("Expected explicit disabled cooperative and programmatic launch attributes")
    for op in attributes:
        if (op.results or op.regions or op.successors or op.attributes or len(op.operands) != 2
                or op.operands[0] != config.results[0] or _constant(op.operands[1], 32) != 0
                or not operations.index(config) < operations.index(op) < operations.index(launch)):
            raise ValueError("Nondefault or misplaced launch attributes are unsupported")
    _exact_uses(config.results[0], [(op, 0) for op in attributes] + [(launch, 0)])
    diagnostics = [op for op in operations if op.name == "scf.if"]
    if len(diagnostics) != 1 or operations.index(diagnostics[0]) >= operations.index(config):
        raise ValueError("Expected one compiler shared-memory diagnostic before launch")
    condition, arch = _diagnostic(diagnostics[0], config.operands[3], callee)
    suffix = operations[operations.index(launch) + 1:]
    if (len(suffix) != 4 or [op.name for op in suffix] != [
            "cuda.cast", "cuda.return_if_error", "arith.constant", "func.return"]
            or tuple(suffix[0].operands) != (launch.results[0],) or len(suffix[0].results) != 1
            or str(suffix[0].results[0].type) != "i32"
            or tuple(suffix[1].operands) != (suffix[0].results[0],) or suffix[1].results
            or len(suffix[2].results) != 1 or len(suffix[3].operands) != 1 or suffix[3].results
            or suffix[3].operands[0] != suffix[2].results[0] or _constant(suffix[3].operands[0], 32) != 0
            or any(op.regions or op.successors for op in suffix)
            or any(op.attributes for op in (suffix[0], suffix[1], suffix[3]))):
        raise ValueError("Unsupported source launch error/result protocol")
    _exact_uses(launch.results[0], [(suffix[0], 0)])
    _exact_uses(suffix[0].results[0], [(suffix[1], 0)])
    special = {launch, config, *attributes, *diagnostics, *suffix}
    for op in operations:
        if op not in special and not _pure(op, callee):
            attrs = {name: str(op.attributes[name]) for name in op.attributes}
            raise ValueError(f"Unsupported source host operation or effect: {op.name}, attributes={attrs}, "
                             f"regions={len(op.regions)}, successors={len(op.successors)}")
    outputs = [("block", axis, value) for axis, value in enumerate(config.operands[:3])]
    outputs += [("grid", axis, value) for axis, value in enumerate(config.operands[4:7])]
    outputs += [("shared", 0, config.operands[3]), ("guard", 0, condition)]
    return host, arguments, operations, callee, stream_indices[0], arch, tuple(outputs)


def _origin(value: Any, arguments: tuple[Any, ...], operations: tuple[Any, ...]) -> tuple[str, int, int]:
    for index, argument in enumerate(arguments):
        if value == argument:
            return "argument", index, 0
    owner = _owner(value)
    if owner not in operations:
        raise ValueError("Launch expression escapes the original host block")
    return "result", operations.index(owner), tuple(owner.results).index(value)


@dataclass(frozen=True)
class LaunchHelper:
    symbol: str
    role: str
    axis: int
    source: tuple[str, int, int]
    result_type: str
    operation: Any = field(repr=False, compare=False)
    body: tuple[str, bytes] = field(repr=False)


@dataclass(frozen=True)
class LaunchSpec:
    module: Any = field(repr=False, compare=False)
    context: Any = field(repr=False, compare=False)
    function_name: str
    callee: tuple[str, ...]
    source_types: tuple[str, ...]
    stream_source_arg_index: int
    diagnostic_arch: str
    metadata: Any
    helpers: tuple[LaunchHelper, ...]
    _host_body: tuple[str, ...] = field(repr=False)
    _owners: tuple[Any, ...] = field(repr=False)
    _fingerprint: str = field(repr=False)

    def _digest(self) -> str:
        state = (LAUNCH_CONFIG_VERSION, self.function_name, self.callee, self.source_types,
                 self.stream_source_arg_index, self.diagnostic_arch, self.metadata, self.helpers, self._host_body)
        return sha256(repr(state).encode()).hexdigest()

    def check(self) -> None:
        from cutlass._mlir import ir

        if (any(value is not owner for value, owner in zip(
                (self.module, self.context, self.metadata, self.helpers), self._owners))
                or self.module.context != self.context or self._digest() != self._fingerprint):
            raise RuntimeError("Launch specification ownership or fields changed")
        with self.context, ir.raw_values():
            _, arguments, operations, callee, stream, arch, outputs = _source(self.module, self.function_name, self.metadata)
            if (tuple(str(arg.type) for arg in arguments) != self.source_types or callee != self.callee
                    or stream != self.stream_source_arg_index or arch != self.diagnostic_arch
                    or tuple(str(op) for op in operations) != self._host_body
                    or len(outputs) != len(self.helpers)):
                raise RuntimeError("Original launch host computation changed")
            for helper, (role, axis, value) in zip(self.helpers, outputs):
                if ((helper.role, helper.axis, helper.source, helper.result_type)
                        != (role, axis, _origin(value, arguments, operations), str(value.type))
                        or _function(self.module, helper.symbol, "func.func") != helper.operation
                        or _snapshot(helper.operation) != helper.body):
                    raise RuntimeError("Launch accessor no longer represents its original SSA use")


def _emit_helper(module: Any, symbol: str, arguments: tuple[Any, ...], operations: tuple[Any, ...],
                 value: Any, callee: tuple[str, ...]) -> Any:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import func

    needed = set()

    def visit(item: Any) -> None:
        if item in arguments:
            return
        op = _owner(item)
        if op not in operations or not _pure(op, callee):
            raise ValueError("Launch value depends on unsupported host effects or control flow")
        if op not in needed:
            needed.add(op)
            for operand in op.operands:
                visit(operand)

    visit(value)
    with ir.InsertionPoint(module.body):
        function = func.FuncOp(symbol, ([arg.type for arg in arguments], [value.type]), visibility="public")
    try:
        function.operation.attributes["no_inline"] = ir.UnitAttr.get()
        function.arg_attrs = [ir.DictAttr.get({SOURCE_ARGUMENT: ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), index)}) for index in range(len(arguments))]
        block = function.add_entry_block()
        mapping = dict(zip(arguments, block.arguments))
        with ir.InsertionPoint(block):
            for op in operations:
                if op in needed:
                    clone = ir.Operation.create(op.name, results=list(op.results.types),
                                                operands=[mapping[item] for item in op.operands],
                                                attributes={name: op.attributes[name] for name in op.attributes},
                                                loc=op.location)
                    mapping.update(zip(op.results, clone.results))
            func.ReturnOp([mapping[value]])
        if not function.operation.verify():
            raise ValueError("Generated launch accessor failed verification")
        return function.operation
    except BaseException:
        function.operation.erase()
        raise


def emit_launch_accessors(module: Any, function_name: str, metadata: Any) -> LaunchSpec:
    """Append exact launch SSA slices before serializing the original artifact."""
    from cutlass._mlir import ir
    from entry_signature import snapshot_metadata

    signature = snapshot_metadata(metadata)
    with module.context, ir.Location.unknown(), ir.raw_values():
        if not module.operation.verify():
            raise ValueError("Original launch Module failed verification")
        _, arguments, operations, callee, stream, arch, outputs = _source(module, function_name, signature)
        original = tuple((view.operation, _snapshot(view.operation)) for view in module.body.operations)
        before = _snapshot(module.operation)
        names = {op.attributes["sym_name"].value for op, _ in original if "sym_name" in op.attributes}
        prefix = "__cudagraph_launch_" + sha256(function_name.encode()).hexdigest()[:16]
        generated, helpers = [], []
        try:
            for role, axis, value in outputs:
                symbol = f"{prefix}_{role}{axis}"
                if symbol in names:
                    raise ValueError("Launch accessor symbol already exists")
                names.add(symbol)
                function = _emit_helper(module, symbol, arguments, operations, value, callee)
                generated.append(function)
                helpers.append(LaunchHelper(symbol, role, axis, _origin(value, arguments, operations),
                                            str(value.type), function, _snapshot(function)))
            if (tuple(view.operation for view in module.body.operations) != tuple(op for op, _ in original) + tuple(generated)
                    or any(_snapshot(op) != state for op, state in original) or not module.operation.verify()):
                raise RuntimeError("Launch accessor emission changed preexisting host or device IR")
        except BaseException:
            for function in reversed(generated):
                function.erase()
            if _snapshot(module.operation) != before:
                raise RuntimeError("Failed launch emission did not restore the original Module") from None
            raise
        helpers = tuple(helpers)
        result = LaunchSpec(module, module.context, function_name, callee, tuple(str(arg.type) for arg in arguments),
                            stream, arch, signature, helpers, tuple(str(op) for op in operations),
                            (module, module.context, signature, helpers), "")
        result = replace(result, _fingerprint=result._digest())
    result.check()
    return result


def _lowered_value(function: Any, helper: LaunchHelper, host_arguments: dict[int, Any]) -> ValueFlow:
    from argument_flow import _Values
    from cutlass._mlir import ir

    if len(function.regions[0].blocks) != 1:
        raise ValueError("Lowered launch accessor must contain one pure block")
    arguments = _tagged_arguments(function)
    if set(arguments) != set(host_arguments) or any(arguments[index].type != host_arguments[index].type for index in arguments):
        raise ValueError("Launch helper and original host formal identities or types differ")
    operations = tuple(view.operation for view in function.regions[0].blocks[0].operations)
    if (not operations or operations[-1].name != "llvm.return" or len(operations[-1].operands) != 1
            or operations[-1].results or operations[-1].attributes
            or str(operations[-1].operands[0].type) != helper.result_type):
        raise ValueError("Launch helper must return its original scalar type")
    for op in operations:
        if op.regions or op.successors or (op.name not in _LOWERED and op != operations[-1]):
            raise ValueError(f"Unsupported lowered launch helper operation: {op.name}")
    host_positions = {source_index: position for position, source_index in enumerate(host_arguments)}
    remap = tuple(host_positions[source_index] for source_index in arguments)

    class Values(_Values):
        def read(self, value: Any) -> ValueFlow:
            op = _owner(value)
            if isinstance(op, ir.Operation) and op.name == "llvm.select":
                attrs = {name: op.attributes[name] for name in op.attributes}
                if (attrs not in ({}, {"fastmathFlags": ir.Attribute.parse("#llvm.fastmath<none>")})
                        or len(op.operands) != 3 or len(op.results) != 1 or op.regions or op.successors):
                    raise ValueError(f"Unsupported lowered launch select attributes: {attrs}")
                return ValueFlow(op.name, str(value.type), operands=tuple(self.read(item) for item in op.operands),
                                 attributes=tuple((name, str(value)) for name, value in attrs.items()))
            return super().read(value)

    def bind(flow: ValueFlow) -> ValueFlow:
        if flow.kind == "argument":
            return replace(flow, argument=remap[flow.argument])
        return replace(flow, operands=tuple(bind(item) for item in flow.operands))

    return bind(Values(tuple(arguments.values())).read(operations[-1].operands[0]))


@dataclass(frozen=True)
class LaunchConfiguration:
    program: Any = field(repr=False)
    spec: LaunchSpec
    argument_flow: Any = field(repr=False)
    kernel_symbol: str
    host_types: tuple[str, ...]
    stream_source_arg_index: int
    block: tuple[ValueFlow, ...]
    grid: tuple[ValueFlow, ...]
    shared: ValueFlow
    guards: tuple[tuple[ValueFlow, bool], ...]
    _owners: tuple[Any, ...] = field(repr=False)
    _fingerprint: str = field(repr=False)

    def _digest(self) -> str:
        return sha256(repr((LAUNCH_CONFIG_VERSION, self.kernel_symbol, self.host_types,
                            self.stream_source_arg_index, self.block, self.grid, self.shared, self.guards)).encode()).hexdigest()

    def check(self) -> None:
        if (any(value is not owner for value, owner in zip(
                (self.program, self.spec, self.argument_flow), self._owners)) or self._digest() != self._fingerprint):
            raise RuntimeError("Launch configuration ownership or expression graph changed")
        self.program.check()
        self.spec.check()
        self.argument_flow.check()
        if (self.program.source_module is not self.spec.module or self.program.source_context is not self.spec.context
                or self.program.module is not self.argument_flow.module
                or self.program.function_name != self.spec.function_name
                or self.program.arch != self.spec.diagnostic_arch):
            raise RuntimeError("Launch configuration belongs to another original compilation")


def analyze_launch_accessors(program: Any, spec: LaunchSpec) -> LaunchConfiguration:
    from argument_flow_v2 import analyze_argument_flow
    from cutlass._mlir import ir
    from entry_signature import snapshot_metadata

    program.check()
    spec.check()
    if (program.source_module is not spec.module or program.source_context is not spec.context
            or program.function_name != spec.function_name or program.arch != spec.diagnostic_arch):
        raise ValueError("Launch accessors do not belong to the original compiled artifact")
    metadata = [item for item in program.source_metadata if item.symbol_name == spec.function_name]
    if len(metadata) != 1:
        raise ValueError("Expected original compiler-owned launch signature metadata")
    actual = snapshot_metadata(metadata[0])
    if (actual.params, actual.symbols, actual.ret) != (spec.metadata.params, spec.metadata.symbols, spec.metadata.ret):
        raise ValueError("Launch accessor metadata differs from the original compiler signature")
    with program.context, ir.raw_values():
        host = _function(program.module, program.function_name, "llvm.func")
        arguments = _tagged_arguments(host)
        if set(arguments) != set(range(len(spec.source_types))):
            raise ValueError("Original launch host lowering split, dropped, or invented formals")
        values = { (helper.role, helper.axis): _lowered_value(
            _function(program.module, helper.symbol, "llvm.func"), helper, arguments,
        ) for helper in spec.helpers }
        host_types = tuple(str(value.type) for value in arguments.values())
        argument_flow = analyze_argument_flow(program.module, program.function_name)
    if (len(argument_flow.launches) != 1 or argument_flow.launches[0].registration.kernel_symbol != spec.callee[1]
            or argument_flow.host_types != host_types):
        raise ValueError("Lowered launch does not identify the original source kernel and formals")
    result = LaunchConfiguration(program, spec, argument_flow, spec.callee[1], host_types,
                                 spec.stream_source_arg_index, tuple(values["block", i] for i in range(3)),
                                 tuple(values["grid", i] for i in range(3)), values["shared", 0],
                                 ((values["guard", 0], False),), (program, spec, argument_flow), "")
    result = replace(result, _fingerprint=result._digest())
    result.check()
    return result
