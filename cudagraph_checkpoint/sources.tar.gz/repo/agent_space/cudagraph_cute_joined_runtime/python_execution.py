from __future__ import annotations

import math
import operator
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

import torch
from entry_signature import EntrySignature, OperandBinding, ValueUse
from python_entry import opaque_entry
from python_entry_v2 import PythonHostTrace
from torch.fx import Interpreter, Node


EXECUTION_VERSION = 1
_INTEGER_OPS = frozenset((operator.add, operator.sub, operator.mul, operator.floordiv, operator.mod, operator.neg))
_ATEN_OPS = frozenset((
    torch.ops.aten.empty.memory_format,
    torch.ops.aten.empty_strided.default,
    torch.ops.aten.empty_like.default,
    torch.ops.aten.slice.Tensor,
    torch.ops.aten.view.default,
    torch.ops.aten.as_strided.default,
    torch.ops.aten.transpose.int,
    torch.ops.aten.permute.default,
    torch.ops.aten.select.int,
    torch.ops.aten.unsqueeze.default,
    torch.ops.aten.squeeze.dim,
    torch.ops.aten.detach.default,
    torch.ops.aten.alias.default,
    torch.ops.aten.sym_numel.default,
    torch.ops.aten.sym_size.int,
    torch.ops.aten.sym_stride.int,
    torch.ops.aten.sym_storage_offset.default,
))


class PythonGuardMismatch(ValueError):
    pass


@dataclass(frozen=True, eq=False)
class ConcreteValue:
    use: ValueUse
    value: int | float


@dataclass(frozen=True, eq=False)
class ExecutedHost:
    signature: EntrySignature
    arguments: Mapping[str, Any]
    output: Any
    values: tuple[ConcreteValue, ...]
    allocation_stream: int
    _owners: tuple[Any, ...] = field(repr=False)
    _snapshot: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        return (tuple((name, _concrete_state(value)) for name, value in self.arguments.items()),
                _concrete_state(self.output),
                tuple((id(item), id(item.use), _concrete_state(item.value)) for item in self.values),
                _concrete_state(self.allocation_stream))

    def check(self) -> None:
        owned = self.signature, self.arguments, self.output, self.values, self.allocation_stream
        if len(owned) != len(self._owners) or any(value is not owner for value, owner in zip(owned, self._owners)):
            raise RuntimeError("Executed host packet ownership changed")
        self.signature.check()
        if self._state() != self._snapshot:
            raise RuntimeError("Executed host packet metadata, pointers, or values changed")
        current = _validate_arguments(self.signature, self.arguments)
        if len(current) != len(self.values) or any(
            actual.use is not saved.use or _concrete_state(actual.value) != _concrete_state(saved.value)
            for actual, saved in zip(current, self.values)
        ):
            raise RuntimeError("Executed host packet lost its concrete source-use association")


def _concrete_state(value: Any) -> Any:
    if type(value) is torch.Tensor:
        storage = value.untyped_storage()
        return ("tensor", id(value), value.dtype, value.device, value.layout, tuple(value.shape), value.stride(),
                value.storage_offset(), value.requires_grad, value.is_conj(), value.is_neg(), value.data_ptr(),
                storage._cdata, storage.nbytes())
    if value is None or type(value) in (int, bool, str):
        return type(value), value
    if type(value) is float and math.isfinite(value):
        return float, value.hex()
    if type(value) in (tuple, list):
        return type(value), id(value), tuple(_concrete_state(item) for item in value)
    if type(value) is dict and all(type(key) is str for key in value):
        return dict, id(value), tuple((key, _concrete_state(item)) for key, item in value.items())
    raise ValueError("Unsupported concrete host packet value")


def _record_value(use: ValueUse, value: Any, values: list[ConcreteValue]) -> None:
    expected_type = int if use.shape_env is not None else type(use.value)
    if type(value) is not expected_type or expected_type not in (int, float):
        raise ValueError("Concrete entry value has a different scalar type")
    if use.shape_env is None and value != use.value:
        raise ValueError("Concrete entry value differs from its traced constant")
    if type(value) is float and not math.isfinite(value):
        raise ValueError("Concrete entry floating value is not finite")
    values.append(ConcreteValue(use, value))


def _tensor_values(source: OperandBinding, tensor: Any, signature: EntrySignature,
                   values: list[ConcreteValue]) -> None:
    spec = source.tensor
    if spec is None or type(tensor) is not torch.Tensor or tensor.layout != torch.strided:
        raise ValueError("Concrete entry operands must be exact strided Tensors")
    if (tensor.device.type != spec.required_device or tensor.device != spec.device
            or tensor.dtype != spec.dtype or tensor.ndim != len(spec.shape)
            or tensor.requires_grad != spec.value.requires_grad
            or tensor.is_conj() or tensor.is_neg()):
        raise ValueError("Concrete Tensor dtype, device, rank, or view state changed")
    if tensor.storage_offset() < 0:
        raise ValueError("Concrete Tensor storage offset is negative")
    # data_ptr is already the effective pointer of a view, including its offset.
    if tensor.data_ptr() % spec.assumed_alignment:
        raise ValueError("Concrete Tensor effective-pointer alignment guard failed")
    for uses, actual, bits in ((spec.shape, tuple(tensor.shape), signature.policy.shape_bits),
                              (spec.strides, tensor.stride(), signature.policy.stride_bits)):
        if len(uses) != len(actual):
            raise ValueError("Concrete Tensor property rank changed")
        for use, number in zip(uses, actual):
            if type(number) is not int or not 0 <= number < 2 ** (bits - 1):
                raise ValueError("Concrete Tensor property exceeds its declared integer width")
            _record_value(use, number, values)
    _record_value(spec.storage_offset, tensor.storage_offset(), values)


def _validate_arguments(signature: EntrySignature, arguments: Mapping[str, Any]) -> tuple[ConcreteValue, ...]:
    values: list[ConcreteValue] = []
    pointers = {}
    for source in signature.operands:
        value = arguments[source.name]
        if source.tensor is not None:
            _tensor_values(source, value, signature, values)
            pointers[source.path] = value.data_ptr()
        elif source.scalar is not None:
            spec = source.scalar
            _record_value(spec.use, value, values)
            if spec.kind == "integer":
                if type(value) is not int or not -(2 ** (spec.bits - 1)) <= value < 2 ** (spec.bits - 1):
                    raise ValueError("Concrete scalar exceeds its declared integer width")
            elif spec.kind != "float" or type(value) is not float:
                raise ValueError("Unsupported concrete scalar kind")
        elif source.origin != "environment_stream" or type(value) is not int or not 0 <= value < 2**64:
            raise ValueError("The environment stream requires a nonnegative raw handle")
    by_path = {item.use.path: item.value for item in values}
    if len(by_path) != len(values):
        raise RuntimeError("Entry runtime requirements have ambiguous source paths")
    for requirement in signature.requirements:
        if requirement.kind == "effective_pointer_alignment":
            if (requirement.path not in pointers or requirement.alignment is None
                    or pointers[requirement.path] % requirement.alignment):
                raise ValueError("Concrete Tensor effective-pointer alignment requirement failed")
        elif requirement.kind in ("integer_range", "storage_offset_nonnegative"):
            number = by_path.get(requirement.path)
            if (type(number) is not int
                    or requirement.minimum is not None and number < requirement.minimum
                    or requirement.maximum is not None and number > requirement.maximum):
                raise ValueError("Concrete integer range requirement failed")
        else:
            raise ValueError(f"Unsupported entry runtime requirement: {requirement.kind}")
    return tuple(values)


class _HostInterpreter(Interpreter):
    def __init__(self, signature: EntrySignature, stream: int) -> None:
        super().__init__(signature.trace.graph_module)
        self.signature = signature
        self.stream = stream
        self.arguments: dict[str, Any] | None = None
        self.values: tuple[ConcreteValue, ...] = ()
        self.extra_traceback = False

    def run_node(self, node: Node) -> Any:
        if node is not self.signature.call.node:
            return super().run_node(node)
        if self.arguments is not None:
            raise RuntimeError("The admitted entry was reached more than once")
        args, kwargs = self.fetch_args_kwargs_from_env(node)
        if not args or type(args[0]) is not int or args[0] != self.signature.call.entry_index:
            raise RuntimeError("The concrete entry lost its original invocation identity")
        bound = self.signature.signature.bind_partial(*args[1:], **kwargs)
        if self.signature.policy.stream_name is not None:
            name = self.signature.policy.stream_name
            if name in bound.arguments:
                raise RuntimeError("The environment stream replaced a traced source")
            bound.arguments[name] = self.stream
        bound.apply_defaults()
        if set(bound.arguments) != set(self.signature.signature.parameters):
            raise RuntimeError("The concrete entry has missing original formals")
        arguments = dict(bound.arguments)
        for source in self.signature.operands:
            if source.origin == "environment_stream":
                continue
            expected = self.env[source.fx_argument] if isinstance(source.fx_argument, Node) else source.fx_argument
            actual = arguments[source.name]
            if isinstance(expected, torch.Tensor):
                if actual is not expected:
                    raise RuntimeError("Tensor formal lost its exact FX source")
            elif type(actual) is not type(expected) or actual != expected:
                raise RuntimeError("Scalar formal lost its exact FX source")
        self.values = _validate_arguments(self.signature, arguments)
        self.arguments = arguments
        return None

    def call_function(self, target: Any, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        if target in _INTEGER_OPS:
            arity = 1 if target is operator.neg else 2
            if kwargs or len(args) != arity or any(type(value) is not int for value in args):
                raise ValueError("Admitted Python arithmetic requires only concrete integer operands")
        elif target not in _ATEN_OPS:
            raise RuntimeError("Unexpected callable during admitted host execution")
        return super().call_function(target, args, kwargs)


class PythonExecution:
    def __init__(self, signature: EntrySignature) -> None:
        if type(signature) is not EntrySignature or type(signature.trace) is not PythonHostTrace:
            raise TypeError("Expected an entry signature with the complete Python host guard contract")
        self.signature = signature
        self._signature = signature
        self.active = False
        self.check()

    def check(self) -> None:
        if self.signature is not self._signature:
            raise RuntimeError("Python execution signature ownership changed")
        signature = self.signature
        signature.check()
        if len(signature.trace.calls) != 1 or signature.trace.calls[0] is not signature.call:
            raise ValueError("Host execution currently requires exactly one owned opaque entry")
        nodes = tuple(signature.trace.graph_module.graph.nodes)
        if sum(node.op == "output" for node in nodes) != 1 or nodes[-1].op != "output":
            raise ValueError("Host execution requires one terminal FX output")
        found = 0
        for node in nodes:
            if node.op in ("placeholder", "output"):
                continue
            if node.op != "call_function":
                raise ValueError(f"Unsupported host FX node: {node.op}")
            if node is signature.call.node:
                if node.target is not opaque_entry or node.users:
                    raise ValueError("The owned opaque entry must have an unused no-value result")
                found += 1
            elif node.target not in _ATEN_OPS and node.target not in _INTEGER_OPS:
                raise ValueError(f"Unsupported host FX operation: {node.target}")
        if found != 1:
            raise RuntimeError("Host execution lost its exact opaque entry node")

    def accepts(self, inputs: tuple[torch.Tensor, ...] | list[torch.Tensor]) -> bool:
        if self.signature is not self._signature:
            raise RuntimeError("Python execution signature ownership changed")
        if not self.signature.trace.accepts(inputs):
            return False
        self.check()
        return True

    def run(self, inputs: tuple[torch.Tensor, ...] | list[torch.Tensor], *, stream: int = 0) -> ExecutedHost:
        if self.active:
            raise RuntimeError("Python host execution cannot reenter")
        if type(stream) is not int or not 0 <= stream < 2**64:
            raise ValueError("Expected a nonnegative raw stream handle")
        if not self.accepts(inputs):
            raise PythonGuardMismatch("Local Python host guards rejected the invocation")
        devices = {value.device for value in inputs}
        if len(devices) != 1 or next(iter(devices)).type != "cuda":
            raise ValueError("Host execution currently requires inputs on one CUDA device")
        device = next(iter(devices))
        if any(source.tensor is not None and source.tensor.device != device for source in self.signature.operands):
            raise ValueError("Host inputs and entry operands must use the same CUDA device")
        allocation_stream = torch.cuda.current_stream(device).cuda_stream
        self.active = True
        interpreter = None
        try:
            interpreter = _HostInterpreter(self.signature, stream)
            output = interpreter.run(*inputs, enable_io_processing=False)
            if interpreter.arguments is None:
                raise RuntimeError("Host graph did not reach its owned opaque entry")
            arguments = MappingProxyType(dict(interpreter.arguments))
            values = interpreter.values
            result = ExecutedHost(self.signature, arguments, output, values, allocation_stream,
                                  (self.signature, arguments, output, values, allocation_stream), ())
            object.__setattr__(result, "_snapshot", result._state())
            result.check()
            return result
        finally:
            if interpreter is not None:
                interpreter.env.clear()
                interpreter.args_iter = iter(())
                interpreter.arguments = None
                interpreter.values = ()
            self.active = False
