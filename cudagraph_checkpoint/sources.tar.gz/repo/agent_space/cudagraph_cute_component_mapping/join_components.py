from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from accessors import analyze_accessors, Component, ComponentMapping
from argument_flow_v2 import analyze_argument_flow
from component_owner import ComponentCompilation, compile_component_program
from entry_signature import EntrySignature, OperandBinding, ValueUse
from joined import _compose, JoinedInvocation
from lowering import bind_host_formals


@dataclass(frozen=True)
class SymbolicComponent:
    component: Component
    source: OperandBinding
    use: ValueUse | None


def _bind_properties(invocation: JoinedInvocation, mapping: ComponentMapping) -> tuple[SymbolicComponent, ...]:
    by_index = {parameter.metadata.ir_arg_index: parameter.source for parameter in invocation.bound.params
                if parameter.metadata.ir_arg_index is not None}
    result = []
    for component in mapping.components:
        spec = component.spec
        source = by_index[spec.source_arg_index]
        if source.tensor is None:
            raise ValueError("Tensor component refers to a non-Tensor source")
        if spec.property == "pointer" and not spec.property_path:
            use = None
        elif spec.property in ("shape", "stride") and len(spec.property_path) == 1:
            values = source.tensor.shape if spec.property == "shape" else source.tensor.strides
            index = spec.property_path[0]
            if not 0 <= index < len(values):
                raise ValueError("Tensor component property path is outside the original source")
            use = values[index]
        else:
            raise ValueError("Unsupported tensor component property")
        result.append(SymbolicComponent(component, source, use))
    return tuple(result)


@dataclass(frozen=True)
class JoinedComponents:
    invocation: JoinedInvocation
    compilation: ComponentCompilation
    mapping: ComponentMapping
    properties: tuple[SymbolicComponent, ...]
    _owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        values = self.invocation, self.compilation, self.mapping, self.properties
        if any(value is not owner for value, owner in zip(values, self._owners)):
            raise RuntimeError("Joined component ownership changed")
        self.invocation.check()
        self.compilation.check()
        self.mapping.check()
        if (self.invocation.program is not self.compilation.program
                or self.mapping.program is not self.compilation.program
                or self.mapping.specs is not self.compilation.accessors
                or _bind_properties(self.invocation, self.mapping) != self.properties):
            raise RuntimeError("Tensor component lost its original symbolic source")


def join_components(signature: EntrySignature, kernel: Any, *, arch: str) -> JoinedComponents:
    from cutlass.base_dsl.typing import get_mlir_types

    signature.check()
    compilation = compile_component_program(signature.target, kernel, *signature.fake_args,
                                            arch=arch, **signature.fake_kwargs)
    program = compilation.program
    bound = signature.bind_metadata(program.source_metadata[0])
    arguments = signature.signature.bind(*signature.fake_args, **signature.fake_kwargs)
    with program.source_context:
        types = tuple(str(typ) for name in signature.signature.parameters
                      for typ in get_mlir_types(arguments.arguments[name]))
    lowering = bind_host_formals(program, program.source_metadata[0], types)
    flow = analyze_argument_flow(program.module, program.function_name)
    invocation = JoinedInvocation(signature, program, bound, lowering, flow,
                                  _compose(bound, lowering, flow), (signature, program, bound, lowering, flow))
    mapping = analyze_accessors(program, compilation.accessors)
    properties = _bind_properties(invocation, mapping)
    result = JoinedComponents(invocation, compilation, mapping, properties,
                              (invocation, compilation, mapping, properties))
    result.check()
    return result
