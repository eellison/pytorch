from __future__ import annotations

import inspect
import re
from dataclasses import dataclass, field
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from accessors import emit_accessors
from compiler_boundary import _snapshot
from compiler_owner import _TaggedCollector, TaggedProgram
from entry_signature import snapshot_metadata
from frontend import _TRACE_LOCK
from launch_events import CloneBundle


class _ComponentCollector(_TaggedCollector):
    def __init__(self, owner: Any, signature: inspect.Signature, args: tuple[Any, ...], kwargs: dict[str, Any]):
        super().__init__(owner)
        self.signature = signature
        self.args = args
        self.kwargs = kwargs
        self.metadata: Any = None
        self.accessors: tuple[Any, ...] = ()

    def __call__(self, owner: Any, module: Any, function_name: str) -> None:
        from cutlass.cute.metadata import build_function_metadata

        hooks = tuple(owner._trace_finalize_hooks) + tuple(owner._scoped_trace_finalize_hooks.get())
        if owner is not self.owner or self.calls or hooks != (self,):
            raise RuntimeError("Expected one isolated component-accessor hook")
        self.metadata = build_function_metadata(
            function_name=function_name, signature=self.signature, args=self.args, kwonlyargs=self.kwargs,
        )
        self.accessors = emit_accessors(module, function_name, self.metadata)
        super().__call__(owner, module, function_name)


@dataclass(frozen=True)
class ComponentCompilation:
    program: TaggedProgram
    accessors: tuple[Any, ...]
    metadata: Any = field(repr=False)
    _owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        if any(value is not owner for value, owner in zip((self.program, self.accessors, self.metadata), self._owners)):
            raise RuntimeError("Component compilation association changed")
        self.program.check()
        expected = snapshot_metadata(self.metadata)
        actual = snapshot_metadata(self.program.source_metadata[0])
        if expected.params != actual.params or expected.symbols != actual.symbols or expected.ret != actual.ret:
            raise RuntimeError("Accessor signature differs from the original compiler metadata")


def compile_component_program(host: Any, kernel: Any, *arguments: Any, arch: str = "sm_80", **keywords: Any) -> ComponentCompilation:
    import cutlass.compiler as compiler
    import cutlass.cute as cute
    from cutlass._mlir import ir
    from cutlass.cutlass_dsl.cutlass import CuTeDSL

    if version("nvidia-cutlass-dsl") != "4.6.2":
        raise RuntimeError("Expected the inspected CuTe compiler version")
    if type(arch) is not str or re.fullmatch(r"sm_[0-9]+[af]?", arch) is None:
        raise ValueError("Expected an explicit CUDA architecture")
    if ir.Context.current is not None or not _TRACE_LOCK.acquire(blocking=False):
        raise RuntimeError("Compilation requires an isolated frontend context")
    try:
        bundle = CloneBundle.create(host, kernel)
        dsl = CuTeDSL._get_dsl()
        if (type(dsl) is not CuTeDSL or dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get()
                or dsl.envar.keep_ir_clean):
            raise RuntimeError("Compilation requires an isolated standard frontend")
        signature = inspect.signature(bundle.original_host.__wrapped__, follow_wrapped=False)
        collector = _ComponentCollector(dsl, signature, arguments, keywords)
        try:
            source = cute.compile.to_precompiled_mlir(
                bundle.host, *arguments, **keywords, options=f"--gpu-arch {arch}",
                no_jit_engine=True, trace_finalize_hooks=collector,
            )
        finally:
            bundle.check_originals()
            if dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get():
                raise RuntimeError("Frontend hook scope was not restored")
        if (collector.calls != 1 or collector.module is None or not collector.accessors
                or type(source) is not compiler.PreCompiledMlirArtifact or source.is_consumed
                or source.get_bitcode() != collector.bytecode):
            raise RuntimeError("Expected the original precompiled artifact and accessor Module")
        names = tuple(metadata.symbol_name for metadata in source.metadata)
        if names != (collector.function_name,):
            raise RuntimeError("Original metadata does not identify the traced host")
    finally:
        _TRACE_LOCK.release()
    source_serialized = compiler.serialize_compilation_artifact(source)
    source_snapshot = compiler.deserialize_compilation_artifact(source_serialized)
    if (type(source_snapshot) is not compiler.PreCompiledMlirArtifact or source_snapshot.is_consumed
            or source_snapshot.get_bitcode() != collector.bytecode
            or compiler.serialize_compilation_artifact(source_snapshot) != source_serialized):
        raise RuntimeError("Native source snapshot differs from the original artifact")
    source_metadata = tuple(source_snapshot.metadata)
    native = compiler.CuteCompiler()
    native.set_device_target(arch)
    native.set_host_target(compiler.Compiler.detect_host_triple())
    native.set_abi(compiler.Abi.CutlassCall)
    compiled = native.compile_to(source, compiler.ArtifactType.CompiledMlir)
    if (not source.is_consumed or type(compiled) is not compiler.CompiledMlirArtifact or compiled.is_consumed
            or tuple(metadata.symbol_name for metadata in compiled.metadata) != names):
        raise RuntimeError("Expected the original compiled continuation")
    bytecode = compiled.get_bitcode()
    context = ir.Context()
    with context, ir.Location.unknown(), ir.raw_values():
        module = ir.Module.parse(bytecode)
        if not module.operation.verify():
            raise RuntimeError("Compiled Module failed verification")
        text, module_bytecode = _snapshot(module)
    program = TaggedProgram(
        bundle, collector.module, collector.context, source, collector.text, collector.bytecode,
        compiled, module, context, bytecode, text, module_bytecode, collector.function_name, arch,
        sha256(collector.bytecode).hexdigest(), sha256(bytecode).hexdigest(),
        source_snapshot, source_metadata, source_serialized,
        compiler.serialize_compilation_artifact(compiled), (source_snapshot, source_metadata),
    )
    result = ComponentCompilation(program, collector.accessors, collector.metadata,
                                  (program, collector.accessors, collector.metadata))
    result.check()
    return result
