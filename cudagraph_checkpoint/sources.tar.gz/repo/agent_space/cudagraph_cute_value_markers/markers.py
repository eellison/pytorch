from __future__ import annotations

import io
from dataclasses import dataclass, field
from hashlib import sha256
from importlib.metadata import version
from typing import Any

import argument_flow as flow
from argument_flow_v2 import _HOST_OPS, _RUNTIME_ABI
from branch_abi import _exact_uses, _ordered, _owner, _uses
from compiler_boundary import _snapshot
from entry_signature import snapshot_metadata
from frontend import _Collector, _TRACE_LOCK
from launch_events import CloneBundle


MARKER_VERSION = 1


def _operation_snapshot(operation: Any) -> tuple[str, bytes]:
    buffer = io.BytesIO()
    operation.write_bytecode(buffer)
    return str(operation), buffer.getvalue()


def _function(module: Any, name: str, kind: str) -> Any:
    matches = [view.operation for view in module.body.operations
               if view.operation.name == kind and view.operation.attributes["sym_name"].value == name]
    if len(matches) != 1:
        raise ValueError(f"Missing or ambiguous {kind} marker/function: {name}")
    return matches[0]


@dataclass(frozen=True)
class Marker:
    symbol: str
    parameter_index: int
    source_type: str
    kernel: tuple[str, ...]
    source_value: Any = field(repr=False, compare=False)


@dataclass(frozen=True)
class MarkerSlot:
    symbol: str
    source_parameter_index: int
    device_parameter_index: int
    llvm_type: str
    kernel_symbol: str
    call_location: tuple[int, int]
    store_location: tuple[int, int]
    launch_location: tuple[int, int]


@dataclass(frozen=True)
class MarkerExperiment:
    bundle: Any = field(repr=False)
    original_artifact: Any = field(repr=False)
    original_module: Any = field(repr=False)
    original_context: Any = field(repr=False)
    original_text: str = field(repr=False)
    original_bytecode: bytes = field(repr=False)
    original_serialized: bytes = field(repr=False)
    metadata_owner: Any = field(repr=False)
    metadata_snapshot: tuple[Any, ...]
    instrumented_artifact: Any = field(repr=False)
    instrumented_module: Any = field(repr=False)
    instrumented_context: Any = field(repr=False)
    instrumented_text: str = field(repr=False)
    instrumented_bytecode: bytes = field(repr=False)
    instrumented_serialized: bytes = field(repr=False)
    compiled_artifact: Any = field(repr=False)
    module: Any = field(repr=False)
    context: Any = field(repr=False)
    compiled_text: str = field(repr=False)
    compiled_bytecode: bytes = field(repr=False)
    module_bytecode: bytes = field(repr=False)
    compiled_serialized: bytes = field(repr=False)
    function_name: str
    markers: tuple[Marker, ...]
    device_snapshots: tuple[tuple[str, bytes], ...] = field(repr=False)
    _seal: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        fields = tuple((name, id(getattr(self, name))) for name in self.__dataclass_fields__ if name != "_seal")
        markers = tuple((item.symbol, item.parameter_index, item.source_type, item.kernel, id(item.source_value))
                        for item in self.markers)
        return fields, markers

    def check(self) -> None:
        import cutlass.compiler as compiler
        from cutlass._mlir import ir

        if self._state() != self._seal:
            raise RuntimeError("Marker experiment source or ownership record changed")
        self.bundle.check_originals()
        if (self.original_artifact.is_consumed or self.metadata_owner.is_consumed
                or not self.instrumented_artifact.is_consumed or self.compiled_artifact.is_consumed
                or compiler.serialize_compilation_artifact(self.original_artifact) != self.original_serialized
                or compiler.serialize_compilation_artifact(self.metadata_owner) != self.original_serialized
                or compiler.serialize_compilation_artifact(self.compiled_artifact) != self.compiled_serialized
                or self.compiled_artifact.get_bitcode() != self.compiled_bytecode
                or tuple(snapshot_metadata(item) for item in self.compiled_artifact.metadata) != self.metadata_snapshot):
            raise RuntimeError("Marker experiment artifact or metadata changed")
        for module, context, text, bytecode in (
            (self.original_module, self.original_context, self.original_text, self.original_bytecode),
            (self.instrumented_module, self.instrumented_context, self.instrumented_text, self.instrumented_bytecode),
            (self.module, self.context, self.compiled_text, self.module_bytecode),
        ):
            with context, ir.raw_values():
                if module.context != context or _snapshot(module) != (text, bytecode):
                    raise RuntimeError("A retained marker experiment Module changed")
        with self.original_context, ir.raw_values():
            host = _function(self.original_module, self.function_name, "func.func")
            launches = [view.operation for view in host.regions[0].blocks[0].operations
                        if view.operation.name == "cuda.launch_ex"]
            if len(launches) != 1:
                raise RuntimeError("Original launch identity changed")
            for marker in self.markers:
                if (launches[0].operands[marker.parameter_index + 1] != marker.source_value
                        or str(marker.source_value.type) != marker.source_type):
                    raise RuntimeError("Original scalar launch use changed")


def _instrument(module: Any, original: Any, function_name: str) -> tuple[Marker, ...]:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import func

    source = _function(original, function_name, "func.func")
    host = _function(module, function_name, "func.func")
    if len(host.regions[0].blocks) != 1 or len(source.regions[0].blocks) != 1:
        raise ValueError("Markers currently require one structured host block")
    launches = [view.operation for view in host.regions[0].blocks[0].operations
                if view.operation.name == "cuda.launch_ex"]
    originals = [view.operation for view in source.regions[0].blocks[0].operations
                 if view.operation.name == "cuda.launch_ex"]
    if len(launches) != 1 or len(originals) != 1:
        raise ValueError("Markers currently require one unconditional launch")
    launch = launches[0]
    callee = tuple(launch.attributes["callee"].value)
    if len(callee) != 2:
        raise ValueError("Expected an exact source device module and symbol")
    gpu = _function(module, callee[0], "gpu.module")
    kernels = [view.operation for view in gpu.regions[0].blocks[0].operations
               if view.operation.name == "cuda.kernel" and view.operation.attributes["sym_name"].value == callee[1]]
    if (len(kernels) != 1 or tuple(kernels[0].attributes["function_type"].value.inputs)
            != tuple(value.type for value in launch.operands[1:])):
        raise ValueError("Original launch and device formal types disagree")
    names = {view.operation.attributes["sym_name"].value for view in module.body.operations
             if "sym_name" in view.operation.attributes}
    prefix = "__cudagraph_value_" + sha256(function_name.encode()).hexdigest()[:16]
    result = []
    for index, value in enumerate(tuple(launch.operands)[1:]):
        if not isinstance(value.type, ir.IntegerType):
            continue
        if value.type.width not in (1, 8, 16, 32, 64):
            raise ValueError("Unsupported integer launch operand width")
        symbol = f"{prefix}_{index}"
        if symbol in names:
            raise ValueError("Source marker symbol collision")
        with ir.InsertionPoint(module.body):
            helper = func.FuncOp(symbol, ([value.type], [value.type]), visibility="private")
            helper.no_inline = True
            block = helper.add_entry_block()
            with ir.InsertionPoint(block):
                func.ReturnOp([block.arguments[0]])
        with ir.InsertionPoint(launch):
            call = func.CallOp(helper, [value])
            call.no_inline = True
        launch.operands[index + 1] = call.results[0]
        result.append(Marker(symbol, index, str(value.type), callee, originals[0].operands[index + 1]))
    if not result or not module.operation.verify():
        raise ValueError("Expected verified integer marker instrumentation")
    return tuple(result)


def _verify_rewrite(original_text: str, instrumented_bytecode: bytes, function_name: str, markers: tuple[Marker, ...]) -> None:
    from cutlass._mlir import ir

    context = ir.Context()
    with context, ir.Location.unknown(), ir.raw_values():
        audit = ir.Module.parse(instrumented_bytecode)
        host = _function(audit, function_name, "func.func")
        launch = next(view.operation for view in host.regions[0].blocks[0].operations
                      if view.operation.name == "cuda.launch_ex")
        for marker in markers:
            call = _owner(launch.operands[marker.parameter_index + 1], "func.call")
            helper = _function(audit, marker.symbol, "func.func")
            block = helper.regions[0].blocks[0]
            body = tuple(view.operation for view in block.operations)
            if (call.attributes["callee"].value != marker.symbol or "no_inline" not in call.attributes
                    or len(call.operands) != 1 or str(call.operands[0].type) != marker.source_type
                    or "no_inline" not in helper.attributes or len(body) != 1
                    or body[0].name != "func.return" or tuple(body[0].operands) != tuple(block.arguments)):
                raise RuntimeError("Instrumented call does not wrap the exact scalar type")
            _exact_uses(call.results[0], [(launch, marker.parameter_index + 1)])
            launch.operands[marker.parameter_index + 1] = call.operands[0]
            call.erase()
            helper.erase()
        if not audit.operation.verify() or str(audit) != original_text:
            raise RuntimeError("Instrumentation changed more than the explicit identity calls")


def compile_marked(host: Any, kernel: Any, *arguments: Any) -> MarkerExperiment:
    import cutlass.compiler as compiler
    import cutlass.cute as cute
    from cutlass._mlir import ir
    from cutlass.cutlass_dsl.cutlass import CuTeDSL

    if version("nvidia-cutlass-dsl") != "4.6.2" or ir.Context.current is not None:
        raise RuntimeError("Expected the isolated inspected CuTe frontend")
    if not _TRACE_LOCK.acquire(blocking=False):
        raise RuntimeError("Frontend is already active")
    try:
        bundle = CloneBundle.create(host, kernel)
        dsl = CuTeDSL._get_dsl()
        if type(dsl) is not CuTeDSL or dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get() or dsl.envar.keep_ir_clean:
            raise RuntimeError("Expected an isolated unmodified frontend pipeline")
        collector = _Collector(dsl)
        try:
            original = cute.compile.to_precompiled_mlir(bundle.host, *arguments, options="--gpu-arch sm_80",
                                                       no_jit_engine=True, trace_finalize_hooks=collector)
        finally:
            bundle.check_originals()
            if dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get():
                raise RuntimeError("Frontend hook scope was not restored")
        if (collector.calls != 1 or collector.module is None or original.is_consumed
                or type(original) is not compiler.PreCompiledMlirArtifact or original.get_bitcode() != collector.bytecode):
            raise RuntimeError("Expected the actual untouched frontend artifact")
    finally:
        _TRACE_LOCK.release()
    serialized = compiler.serialize_compilation_artifact(original)
    metadata_owner = compiler.deserialize_compilation_artifact(serialized)
    metadata = tuple(snapshot_metadata(item) for item in metadata_owner.metadata)
    if tuple(item.symbol_name for item in metadata_owner.metadata) != (collector.function_name,):
        raise ValueError("Original metadata does not identify its exact host")
    context = ir.Context()
    with context, ir.Location.unknown(), ir.raw_values():
        module = ir.Module.parse(collector.bytecode)
        if str(module) != collector.text:
            raise RuntimeError("The separate source copy differs before instrumentation")
        devices = tuple(_operation_snapshot(view.operation) for view in module.body.operations if view.operation.name == "gpu.module")
        markers = _instrument(module, collector.module, collector.function_name)
        if tuple(_operation_snapshot(view.operation) for view in module.body.operations if view.operation.name == "gpu.module") != devices:
            raise RuntimeError("Instrumentation changed the original device module")
        text, bytecode = _snapshot(module)
    _verify_rewrite(collector.text, bytecode, collector.function_name, markers)
    artifact = compiler.PreCompiledMlirArtifact.from_bitcode(bytecode)
    for item in metadata_owner.metadata:
        artifact.metadata.append(item)
    if tuple(snapshot_metadata(item) for item in artifact.metadata) != metadata:
        raise RuntimeError("Copied artifact metadata changed the original signature")
    instrumented_serialized = compiler.serialize_compilation_artifact(artifact)
    native = compiler.CuteCompiler()
    native.set_device_target("sm_80")
    native.set_host_target(compiler.Compiler.detect_host_triple())
    native.set_abi(compiler.Abi.CutlassCall)
    compiled = native.compile_to(artifact, compiler.ArtifactType.CompiledMlir)
    compiled_bytes = compiled.get_bitcode()
    compiled_context = ir.Context()
    with compiled_context, ir.Location.unknown(), ir.raw_values():
        compiled_module = ir.Module.parse(compiled_bytes)
        if not compiled_module.operation.verify():
            raise RuntimeError("Instrumented compilation failed MLIR verification")
        compiled_text, normalized_bytes = _snapshot(compiled_module)
    result = MarkerExperiment(bundle, original, collector.module, collector.context, collector.text, collector.bytecode,
                              serialized, metadata_owner, metadata, artifact, module, context, text, bytecode,
                              instrumented_serialized, compiled, compiled_module, compiled_context,
                              compiled_text, compiled_bytes, normalized_bytes, compiler.serialize_compilation_artifact(compiled),
                              collector.function_name, markers, devices, ())
    object.__setattr__(result, "_seal", result._state())
    result.check()
    return result


class _MarkerValues(flow._Values):
    def __init__(self, arguments: Any, calls: dict[Any, str]) -> None:
        super().__init__(arguments)
        self.marker_calls = calls

    def read(self, value: Any) -> flow.ValueFlow:
        if value in self.marker_calls:
            return flow.ValueFlow("marker", str(value.type), value=self.marker_calls[value])
        return super().read(value)


def analyze_markers(experiment: MarkerExperiment) -> tuple[MarkerSlot, ...]:
    from cutlass._mlir import ir

    experiment.check()
    with experiment.context, ir.Location.unknown(), ir.raw_values():
        module = experiment.module
        host = _function(module, experiment.function_name, "llvm.func")
        blocks = tuple(host.regions[0].blocks)
        positions = {view.operation: (index, offset) for index, block in enumerate(blocks)
                     for offset, view in enumerate(block.operations)}
        markers = {item.symbol: item for item in experiment.markers}
        c_convention = ir.Attribute.parse("#llvm.cconv<ccc>")
        for view in module.body.operations:
            definition = view.operation
            if definition.name != "llvm.func":
                continue
            name = definition.attributes["sym_name"].value
            convention = definition.attributes.get("CConv")
            if name in _RUNTIME_ABI and (any(region.blocks for region in definition.regions)
                    or definition.attributes["function_type"].value != ir.Type.parse(f"!llvm.func<{_RUNTIME_ABI[name]}>")
                    or (convention is not None and convention != c_convention)):
                raise ValueError("Runtime callee is not its exact external ABI declaration")
        for op in positions:
            if op.regions or op.name not in _HOST_OPS:
                raise ValueError(f"Unsupported lowered host operation: {op.name}")
        marker_calls = {}
        launches = []
        for op in positions:
            if op.name != "llvm.call":
                continue
            callee = op.attributes.get("callee")
            if callee is None or callee.value not in flow._HOST_CALLS | markers.keys():
                raise ValueError("Unknown lowered host call in marker experiment")
            if callee.value in markers:
                marker = markers[callee.value]
                definition = _function(module, marker.symbol, "llvm.func")
                regions = definition.regions
                if len(regions) != 1 or len(regions[0].blocks) != 1:
                    raise ValueError("Retained marker must have one identity block")
                block = regions[0].blocks[0]
                body = tuple(view.operation for view in block.operations)
                definition_convention = definition.attributes.get("CConv")
                call_convention = op.attributes.get("CConv")
                if (len(block.arguments) != 1 or str(block.arguments[0].type) != marker.source_type
                        or len(body) != 1 or body[0].name != "llvm.return"
                        or tuple(body[0].operands) != tuple(block.arguments)
                        or body[0].attributes or body[0].results or body[0].regions
                        or len(op.operands) != 1 or len(op.results) != 1
                        or str(op.operands[0].type) != marker.source_type or op.results[0].type != op.operands[0].type
                        or "no_inline" not in op.attributes
                        or definition.attributes["function_type"].value != ir.Type.parse(f"!llvm.func<{marker.source_type} ({marker.source_type})>")
                        or (definition_convention is not None and definition_convention != c_convention)
                        or (call_convention is not None and call_convention != c_convention)):
                    raise ValueError("Retained marker call/definition is not the typed no-inline identity")
                marker_calls[op.results[0]] = marker.symbol
            elif callee.value in flow._LAUNCHES:
                launches.append(op)
        if (len(launches) != 1 or len(marker_calls) != len(markers)
                or set(marker_calls.values()) != set(markers)):
            raise ValueError("The compiler erased, duplicated, or lost a scalar marker")
        _, registrations = flow._registrations(module)
        handles = {item.handle_global: item for item in registrations}
        values = _MarkerValues(blocks[0].arguments, marker_calls)
        launch = launches[0]
        callee = launch.attributes["callee"].value
        handle = _owner(launch.operands[flow._LAUNCHES[callee][1]], "llvm.load")
        flow._plain_memory(handle)
        address = _owner(handle.operands[0], "llvm.mlir.addressof")
        registration = handles[address.attributes["global_name"].value]
        parameters = flow._pack(launch, launches, values)
        result = []
        for parameter in parameters:
            if parameter.source.kind != "marker":
                continue
            marker = markers[parameter.source.value]
            matched = [value for value, symbol in marker_calls.items() if symbol == marker.symbol]
            value = matched[0]
            uses = _uses(value)
            if len(uses) != 1 or uses[0][0].name != "llvm.store" or uses[0][1] != 0:
                raise ValueError("Marker result must have one exact parameter-byte store")
            store = uses[0][0]
            call = _owner(value, "llvm.call")
            _ordered(store, launch)
            result.append(MarkerSlot(marker.symbol, marker.parameter_index, parameter.index, parameter.llvm_type,
                                     registration.kernel_symbol, positions[call], positions[store], positions[launch]))
        if len(result) != len(markers) or {item.symbol for item in result} != set(markers):
            raise ValueError("A scalar marker does not reach one actual device parameter slot")
        return tuple(result)
