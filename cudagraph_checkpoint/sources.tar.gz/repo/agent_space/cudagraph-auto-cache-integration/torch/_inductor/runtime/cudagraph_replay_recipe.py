from __future__ import annotations

import hashlib
import operator
import pickle
import types
from dataclasses import dataclass
from typing import Any


RECIPE_VERSION = 1
_BINARY = {
    "add": operator.add,
    "sub": operator.sub,
    "mul": operator.mul,
    "floordiv": operator.floordiv,
    "mod": operator.mod,
}
_COMPARE = {"eq": operator.eq, "le": operator.le, "ge": operator.ge}


@dataclass(frozen=True)
class IntExpr:
    op: str
    value: int | tuple[int, int] | None = None
    args: tuple[IntExpr, ...] = ()

    def evaluate(self, inputs: list[Any], depth: int = 0) -> int:
        if depth > 32 or type(self.args) is not tuple:
            raise ValueError("Unsupported integer expression structure")
        if self.op in ("constant", "boxed"):
            if type(self.value) is not int or self.args:
                raise ValueError("Integer leaves require exact integers")
            if self.op == "constant":
                result = self.value
            else:
                if not 0 <= self.value < len(inputs):
                    raise ValueError("Invalid boxed scalar index")
                result = inputs[self.value]
        elif self.op in ("size", "stride"):
            if (
                type(self.value) is not tuple or len(self.value) != 2 or self.args
                or any(type(value) is not int for value in self.value)
            ):
                raise ValueError("Tensor metadata leaves require a slot and dimension")
            slot, dimension = self.value
            if not 0 <= slot < len(inputs) or dimension not in (0, 1):
                raise ValueError("Unsupported tensor metadata index")
            tensor = inputs[slot]
            result = tensor.shape[dimension] if self.op == "size" else tensor.stride()[dimension]
        else:
            arity = 1 if self.op == "neg" else 2
            if self.value is not None or len(self.args) != arity or any(type(arg) is not IntExpr for arg in self.args):
                raise ValueError("Unsupported integer operation arguments")
            values = tuple(arg.evaluate(inputs, depth + 1) for arg in self.args)
            if self.op == "neg":
                result = -values[0]
            elif self.op in _BINARY:
                result = _BINARY[self.op](*values)
            else:
                raise ValueError("Unknown integer expression operation")
        if type(result) is not int or not -(2**63) <= result < 2**63:
            raise ValueError("Integer expression must produce an exact signed int64")
        return result


@dataclass(frozen=True)
class Guard:
    op: str
    left: IntExpr
    right: IntExpr

    def evaluate(self, inputs: list[Any]) -> bool:
        if self.op not in _COMPARE or type(self.left) is not IntExpr or type(self.right) is not IntExpr:
            raise ValueError("Unsupported recipe guard")
        return _COMPARE[self.op](self.left.evaluate(inputs), self.right.evaluate(inputs))


@dataclass(frozen=True)
class TensorInput:
    boxed_index: int
    shape: tuple[IntExpr, ...]
    stride: tuple[IntExpr, ...]
    alignment: int


@dataclass(frozen=True)
class Allocation:
    shape: tuple[IntExpr, ...]
    stride: tuple[IntExpr, ...]
    before_launch: int


@dataclass(frozen=True)
class PointerBinding:
    formal: str
    source: int
    written: bool
    alignment: int


@dataclass(frozen=True)
class ScalarBinding:
    formal: str
    dtype: str
    value: IntExpr


@dataclass(frozen=True)
class KernelIdentity:
    compiled_hash: str
    function: int
    abi_types: str
    block: tuple[int, int, int]
    shared: int
    launcher_code: types.CodeType
    metadata_sha256: str


@dataclass(frozen=True)
class Launch:
    kernel_name: str
    pointers: tuple[PointerBinding, ...]
    scalars: tuple[ScalarBinding, ...]
    grid: tuple[IntExpr, IntExpr, IntExpr]
    identity: KernelIdentity


@dataclass(frozen=True)
class ReplayRecipe:
    r"""Bound allocation and launch expressions for one selected generated call.

    Source zero is the Tensor input; subsequent sources are allocation owners in
    tuple order. Allocation timing describes observed helper calls, not frees.
    Compiler aliases use the same source. This in-process recipe retains exact
    code identities and does not replace the outer Dynamo guards.
    """

    version: int
    device_index: int
    boxed_input_count: int
    tensor_inputs: tuple[TensorInput, ...]
    guards: tuple[Guard, ...]
    allocations: tuple[Allocation, ...]
    launches: tuple[Launch, ...]
    output_sources: tuple[int, ...]
    call_code: types.CodeType


@dataclass(frozen=True)
class TemplateLaunch:
    kernel_name: str
    pointers: tuple[PointerBinding, ...]
    scalars: tuple[ScalarBinding, ...]


@dataclass(frozen=True)
class RecipeTemplate:
    version: int
    device_index: int
    boxed_input_count: int
    tensor_inputs: tuple[TensorInput, ...]
    guards: tuple[Guard, ...]
    allocations: tuple[Allocation, ...]
    launches: tuple[TemplateLaunch, ...]
    output_sources: tuple[int, ...]

    def bind(self, call: types.FunctionType) -> ReplayRecipe:
        launches = []
        guards = list(self.guards)
        for launch in self.launches:
            selected = select_kernel(launch.kernel_name, call.__globals__.get(launch.kernel_name))
            if len(launch.scalars) != len(selected.formals) - selected.pointer_count:
                raise ValueError("Recipe scalars differ from the selected generated ABI")
            extent = launch.scalars[1 if selected.is_reduction else 0].value
            if selected.reduction_block is not None:
                guard = Guard("le", launch.scalars[2].value, IntExpr("constant", selected.reduction_block))
                if guard not in guards:
                    guards.append(guard)
            launches.append(Launch(
                launch.kernel_name, launch.pointers, launch.scalars,
                selected.grid(extent), selected.identity,
            ))
        return ReplayRecipe(
            self.version, self.device_index, self.boxed_input_count, self.tensor_inputs,
            tuple(guards), self.allocations, tuple(launches), self.output_sources, call.__code__,
        )


@dataclass(frozen=True)
class SelectedKernel:
    name: str
    kernel: Any
    launcher: types.FunctionType
    owner: Any
    formals: tuple[tuple[str, str], ...]
    pointer_count: int
    written: tuple[bool, ...]
    alignments: tuple[int, ...]
    identity: KernelIdentity
    config: tuple[tuple[str, Any], ...]
    info: tuple[tuple[int, int, str], ...]
    is_reduction: bool
    reduction_block: int | None

    def check(self) -> None:
        current = select_kernel(self.name, self.kernel).identity
        if current != self.identity or current.launcher_code is not self.identity.launcher_code:
            raise ValueError("Selected generated kernel changed")

    def grid(self, scalar: IntExpr) -> tuple[IntExpr, IntExpr, IntExpr]:
        block = dict(self.config)["XBLOCK"]
        return (
            IntExpr("neg", args=(IntExpr("floordiv", args=(scalar, IntExpr("constant", -block))),)),
            IntExpr("constant", 1), IntExpr("constant", 1),
        )


def select_kernel(name: str, kernel: Any, *, allow_uncached: bool = False) -> SelectedKernel:
    from .static_triton_launcher import StaticallyLaunchedCudaKernel
    from .triton_heuristics import CachingAutotuner

    if not isinstance(kernel, CachingAutotuner) or len(kernel.launchers) != 1 or len(kernel.compile_results) != 1:
        raise ValueError("Warm exactly one selected generated launcher")
    launcher = kernel.launchers[0]
    cached = kernel._cached_launcher
    if allow_uncached and cached is None:
        cached = launcher
    if type(launcher) is not types.FunctionType or type(cached) is not types.FunctionType:
        raise ValueError("Expected a warmed static Python launcher")
    owner = getattr(launcher.__globals__.get("runner"), "__self__", None)
    result = kernel.compile_results[0]
    meta = result.compile_meta
    formals = tuple((formal, dtype) for formal, dtype in meta["signature"].items() if dtype != "constexpr")
    constexprs = tuple(formal for formal, dtype in meta["signature"].items() if dtype == "constexpr")
    heuristic = kernel.heuristic_type.name
    is_reduction = heuristic in ("PERSISTENT_REDUCTION", "REDUCTION")
    if not is_reduction and heuristic != "POINTWISE":
        raise ValueError("Unsupported generated kernel heuristic")
    pointer_count = 2 if is_reduction else len(formals) - 1
    scalar_types = ("i64", "i32", "i32") if is_reduction else ("i32",)
    expected_constexprs = ("XBLOCK", "R0_BLOCK") if heuristic == "REDUCTION" else ("XBLOCK",)
    info = getattr(launcher, "_cudagraph_param_info", None)
    provenance = kernel.inductor_meta.get("cudagraph_parameter_provenance")
    configuration = launcher.config.all_kwargs()
    reduction_block = kernel.inductor_meta.get("cudagraph_persistent_reduction_block")
    if heuristic == "PERSISTENT_REDUCTION":
        if type(reduction_block) is not int or reduction_block <= 0 or reduction_block & (reduction_block - 1):
            raise ValueError("Persistent reduction requires its exact emitted power-of-two block")
    elif "cudagraph_persistent_reduction_block" in kernel.inductor_meta:
        raise ValueError("Only a persistent reduction may carry an embedded reduction bound")
    if (
        type(owner) is not StaticallyLaunchedCudaKernel or result.kernel is not owner
        or result.config is not launcher.config or pointer_count not in (1, 2)
        or owner.arg_tys != ("OOlii" if is_reduction else "O" * pointer_count + "i") or owner.function is None
        or tuple(dtype for _, dtype in formals) != ("*fp32",) * pointer_count + scalar_types
        or constexprs != expected_constexprs
        or owner.full_constexprs != list(range(len(formals), len(formals) + len(constexprs)))
        or owner.device_agnostic or owner._has_tensordesc or (not is_reduction and owner.shared)
        or owner.global_scratch_size or owner.profile_scratch_size
        or meta.get("launch_pdl") or meta.get("launch_cooperative_grid")
        or kernel.inductor_meta.get("extra_launcher_args")
        or kernel.inductor_meta.get("num_reduction", 0) != int(is_reduction)
        or kernel.inductor_meta.get("atomic_add_found", False)
        or kernel.inductor_meta.get("grid_type") != "Grid1D"
        or not provenance or set(provenance) != {formal for formal, _ in formals[:pointer_count]}
        or info != tuple((index, index, formal) for index, (formal, _) in enumerate(formals[:pointer_count]))
        or len(meta["configs"]) != 1 or any(meta["configs"][0].get((i,)) for i in range(pointer_count, len(formals)))
        or any(type(configuration.get(key)) is not int or configuration[key] <= 0 for key in constexprs)
        or configuration.get("num_ctas") != 1
        or meta["constants"] != {key: configuration[key] for key in constexprs}
    ):
        raise ValueError("Unsupported generated ABI or specialization")
    if cached is not launcher and (
        cached.__code__ is not launcher.__code__
        or getattr(cached, "_static_kernel_owner", None) is not owner
        or getattr(cached, "config", None) is not launcher.config
        or getattr(cached, "_cudagraph_param_info", None) != info
    ):
        raise ValueError("Cached launcher differs from the selected kernel")
    written = tuple(provenance[formal][1] for formal, _ in formals[:pointer_count])
    if any(type(value) is not bool for value in written) or written != ((False, True) if pointer_count == 2 else (True,)):
        raise ValueError("Expected ordinary load/store formals")
    alignments = []
    for index, (formal, _) in enumerate(formals[:pointer_count]):
        alignment = provenance[formal][2]
        if type(alignment) is not int:
            raise ValueError("Invalid pointer alignment")
        for attribute, value in meta["configs"][0].get((index,), ()):
            if attribute != "tt.divisibility" or type(value) is not int:
                raise ValueError("Unsupported pointer specialization")
            alignment = max(alignment, value)
        if alignment not in (1, 2, 4, 8, 16):
            raise ValueError("Unsupported pointer alignment")
        alignments.append(alignment)
    metadata = pickle.dumps((meta, configuration, provenance, info, heuristic, reduction_block), protocol=5)
    identity = KernelIdentity(
        owner.hash, owner.function, owner.arg_tys, (owner.num_warps * 32, 1, 1),
        owner.shared, cached.__code__, hashlib.sha256(metadata).hexdigest(),
    )
    return SelectedKernel(
        name, kernel, cached, owner, formals, pointer_count, written, tuple(alignments),
        identity, tuple(configuration.items()), info, is_reduction, reduction_block,
    )
