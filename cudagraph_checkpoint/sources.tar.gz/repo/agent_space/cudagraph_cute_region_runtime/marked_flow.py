from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any

import argument_flow as flow
from branch_abi import _owner
from markers import _MarkerValues, analyze_markers


@dataclass(frozen=True)
class MarkedArgumentFlow(flow.ArgumentFlow):
    experiment: Any = field(repr=False)
    marker_slots: tuple[Any, ...]
    _marker_owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        super().check()
        if (len(self._marker_owners) != 2 or self.experiment is not self._marker_owners[0]
                or self.marker_slots is not self._marker_owners[1]):
            raise RuntimeError("Marked argument flow lost its instrumentation owner")
        self.experiment.check()
        if (self.module is not self.experiment.module or self.context is not self.experiment.context
                or self.function_name != self.experiment.function_name
                or analyze_markers(self.experiment) != self.marker_slots):
            raise RuntimeError("Marked arguments changed their original compiler association")


def analyze_marked_flow(experiment: Any) -> MarkedArgumentFlow:
    from cutlass._mlir import ir

    slots = analyze_markers(experiment)
    module, context = experiment.module, experiment.context
    with context, ir.raw_values():
        text, bytecode = flow._snapshot(module)
        host = flow._function(module, experiment.function_name)
        blocks = tuple(host.regions[0].blocks)
        positions = {view.operation: (block_index, op_index)
                     for block_index, block in enumerate(blocks) for op_index, view in enumerate(block.operations)}
        names = {marker.symbol for marker in experiment.markers}
        calls, markers = [], {}
        for operation in positions:
            if operation.name != "llvm.call":
                continue
            name = operation.attributes["callee"].value
            if name in names:
                markers[operation.results[0]] = name
            elif name in flow._LAUNCHES:
                if len(operation.operands) != flow._LAUNCHES[name][0]:
                    raise ValueError("Unsupported marked launch calling convention")
                calls.append(operation)
        if len(calls) != 1:
            raise ValueError("Marked flow requires one unconditional source launch")
        binaries, registrations = flow._registrations(module)
        handles = {item.handle_global: item for item in registrations}
        values = _MarkerValues(blocks[0].arguments, markers)
        call = calls[0]
        callee = call.attributes["callee"].value
        handle = _owner(call.operands[flow._LAUNCHES[callee][1]], "llvm.load")
        flow._plain_memory(handle)
        address = _owner(handle.operands[0], "llvm.mlir.addressof")
        registration = handles[address.attributes["global_name"].value]
        parameters = flow._pack(call, calls, values)
        by_name = {marker.symbol: marker for marker in experiment.markers}
        for slot in slots:
            parameter = parameters[slot.device_parameter_index]
            source = by_name[slot.symbol]
            if (parameter.index != slot.device_parameter_index or parameter.llvm_type != slot.llvm_type
                    or parameter.source.kind != "marker" or parameter.source.value != slot.symbol
                    or source.parameter_index != slot.source_parameter_index
                    or source.source_type != slot.llvm_type or source.kernel[1] != registration.kernel_symbol
                    or slot.kernel_symbol != registration.kernel_symbol):
                raise ValueError("Scalar marker lost its exact source operand or device parameter slot")
        launches = (flow.LaunchFlow(0, *positions[call], callee, registration, parameters),)
        host_types = tuple(str(value.type) for value in blocks[0].arguments)
        if flow._snapshot(module) != (text, bytecode):
            raise RuntimeError("Marked flow analysis changed the compiler Module")
    result = MarkedArgumentFlow(module, context, experiment.function_name, host_types, binaries, registrations,
                                launches, sha256(bytecode).hexdigest(), text, bytecode, (module, context), "",
                                experiment, slots, (experiment, slots))
    object.__setattr__(result, "_fingerprint", result._digest())
    result.check()
    return result
