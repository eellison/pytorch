from dataclasses import dataclass, replace
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from torch._inductor.runtime.cudagraph_replay_recipe import IntExpr
from torch._inductor.runtime.cutedsl_parameter_analysis import (
    ANALYSIS_VERSION,
    KernelAnalysis,
    _inspect_kernel,
    _walk_block,
)


PROGRAM_TRACE_VERSION = 1
_TRACE_ATTR = 'torch.cudagraph.program_trace_sha256'
_VERSION_ATTR = 'torch.cudagraph.program_trace_version'
_DEVICE_VERSION_ATTR = 'torch.cudagraph.program_device_analysis_version'


@dataclass(frozen=True)
class BranchDispatch:
    predicate: str
    width: int
    left: IntExpr
    right: IntExpr
    true_symbol: str
    false_symbol: str


@dataclass(frozen=True)
class ProgramAnalysis:
    function_name: str
    gpu_module: str
    compiled_hash: str
    trace_sha256: str
    compiler_version: str
    analyzer_version: int
    kernels: tuple[KernelAnalysis, ...]
    supported: bool
    reason: str


class CuTeProgramTrace:
    def __init__(self) -> None:
        self.trace_mlir = ''
        self._calls = 0
        self._analysis = ProgramAnalysis(
            '', '', '', '', version('nvidia-cutlass-dsl'), ANALYSIS_VERSION,
            (), False, 'The program has not been traced',
        )

    def __call__(self, owner: Any, module: Any, function_name: str) -> None:
        from cutlass._mlir import ir
        from cutlass.cutlass_dsl.cutlass import CuTeDSL

        self._calls += 1
        result = replace(self._analysis, function_name=function_name, kernels=(), supported=False)
        try:
            if self._calls != 1 or type(owner) is not CuTeDSL:
                raise ValueError('Expected one ordinary CuTe compilation')
            if any(name in module.operation.attributes for name in (_TRACE_ATTR, _VERSION_ATTR, _DEVICE_VERSION_ATTR)):
                raise ValueError('The module already carries a program certificate')
            hooks = tuple(owner._trace_finalize_hooks) + tuple(owner._scoped_trace_finalize_hooks.get())
            if hooks != (self,):
                raise ValueError('Additional trace hooks could change the certified program')
            hosts = [view.operation for view in module.body.operations
                     if view.operation.name == 'func.func'
                     and view.operation.attributes['sym_name'].value == function_name]
            gpu = [view.operation for view in module.body.operations if view.operation.name == 'gpu.module']
            if len(hosts) != 1 or len(gpu) != 1:
                raise ValueError('Expected the original host function and one GPU module')
            gpu = gpu[0]
            result = replace(result, gpu_module=gpu.attributes['sym_name'].value)
            if len(gpu.regions) != 1 or len(gpu.regions[0].blocks) != 1:
                raise ValueError('Unsupported GPU module structure')
            kernels = [view.operation for view in gpu.regions[0].blocks[0].operations]
            if not 1 <= len(kernels) <= 2 or any(op.name != 'cuda.kernel' for op in kernels):
                raise ValueError('Expected one or two original kernels without helpers or globals')
            symbols = [op.attributes['sym_name'].value for op in kernels]
            if len(set(symbols)) != len(symbols):
                raise ValueError('Device symbols must be distinct')
            analyses = []
            with module.context, module.operation.location:
                for kernel in kernels:
                    formals = _inspect_kernel(kernel)
                    analyses.append(KernelAnalysis(
                        compiled_hash='', trace_sha256='',
                        compiler_version=result.compiler_version,
                        kernel_symbol=kernel.attributes['sym_name'].value,
                        kernel_signature=tuple(str(typ) for typ in kernel.attributes['function_type'].value.inputs),
                        supported=True, reason='Supported original device symbol',
                        pointer_formals=formals,
                        operations=tuple(sorted({op.name for region in kernel.regions
                                                 for block in region.blocks for op in _walk_block(block)})),
                        analyzer_version=ANALYSIS_VERSION,
                        cuda_abi_verified=False, host_mapping_verified=False,
                    ))
                if not module.operation.verify():
                    raise ValueError('CuTe program verification failed')
            result = replace(result, kernels=tuple(analyses), supported=True,
                             reason='Supported device symbols; host guards and ABI require independent validation')
        except Exception as error:
            self._analysis = replace(result, supported=False, kernels=(), reason=f'{type(error).__name__}: {error}')
            return
        try:
            self.trace_mlir = str(module)
            digest = sha256(self.trace_mlir.encode()).hexdigest()
            with module.context:
                module.operation.attributes[_TRACE_ATTR] = ir.StringAttr.get(digest)
                module.operation.attributes[_VERSION_ATTR] = ir.IntegerAttr.get(
                    ir.IntegerType.get_signless(32), PROGRAM_TRACE_VERSION,
                )
                module.operation.attributes[_DEVICE_VERSION_ATTR] = ir.IntegerAttr.get(
                    ir.IntegerType.get_signless(32), ANALYSIS_VERSION,
                )
            result = replace(result, trace_sha256=digest,
                             kernels=tuple(replace(kernel, trace_sha256=digest) for kernel in result.kernels))
        except Exception as error:
            result = replace(result, supported=False, kernels=(), reason=f'{type(error).__name__}: {error}')
        self._analysis = result

    def finish(self, compiled: Any) -> ProgramAnalysis:
        from cutlass._mlir import ir
        from cutlass.cutlass_dsl.cuda_jit_executor import CudaDialectJitCompiledFunction

        result = self._analysis
        if not result.supported:
            return result
        try:
            if self._calls != 1 or type(compiled) is not CudaDialectJitCompiledFunction:
                raise ValueError('Expected the compilation observed by this program trace')
            if compiled.load_from_binary or compiled.total_added_arguments or compiled.kernel_extra_args:
                raise ValueError('Loaded artifacts or added workspace arguments are unsupported')
            if (
                compiled.function_name != result.function_name
                or tuple(compiled.kernel_info) != tuple(kernel.kernel_symbol for kernel in result.kernels)
                or result.compiler_version != version('nvidia-cutlass-dsl')
                or result.analyzer_version != ANALYSIS_VERSION
            ):
                raise ValueError('Selected host, compiler or complete device symbol identity changed')
            attrs = compiled.ir_module.operation.attributes
            if (
                not isinstance(attrs.get(_TRACE_ATTR), ir.StringAttr)
                or attrs[_TRACE_ATTR].value != result.trace_sha256
                or not isinstance(attrs.get(_VERSION_ATTR), ir.IntegerAttr)
                or attrs[_VERSION_ATTR].value != PROGRAM_TRACE_VERSION
                or not isinstance(attrs.get(_DEVICE_VERSION_ATTR), ir.IntegerAttr)
                or attrs[_DEVICE_VERSION_ATTR].value != ANALYSIS_VERSION
                or sha256(self.trace_mlir.encode()).hexdigest() != result.trace_sha256
            ):
                raise ValueError('Missing or mismatched original program trace identity')
            binaries = [view.operation.attributes.get('value') for view in compiled.ir_module.body.operations
                        if view.operation.name == 'llvm.mlir.global'
                        and view.operation.attributes['sym_name'].value == f'{result.gpu_module}_binary']
            if len(binaries) != 1 or not isinstance(binaries[0], ir.StringAttr) or not binaries[0].value_bytes:
                raise ValueError('Expected the original embedded CUDA program binary')
            digest = sha256(binaries[0].value_bytes).hexdigest()
            return replace(result, compiled_hash=digest,
                           kernels=tuple(replace(kernel, compiled_hash=digest) for kernel in result.kernels))
        except Exception as error:
            return replace(result, supported=False, kernels=(), reason=f'{type(error).__name__}: {error}')
