from __future__ import annotations

import ctypes
import sys
from dataclasses import dataclass
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from program_analysis import (
    PROGRAM_TRACE_VERSION,
    BranchDispatch,
    ProgramAnalysis,
    _DEVICE_VERSION_ATTR,
    _TRACE_ATTR,
    _VERSION_ATTR,
)
from torch._inductor.runtime.cudagraph_replay_recipe import IntExpr
from torch._inductor.runtime.cutedsl_parameter_analysis import ANALYSIS_VERSION, _raw_value, _walk_block
from torch._inductor.runtime.cutedsl_replay_recipe import KernelABI


@dataclass(frozen=True)
class LaunchSiteABI:
    arm: bool
    kernel_symbol: str
    handle_global: str
    abi: KernelABI


def _owner(value: Any, name: str) -> Any:
    from cutlass._mlir import ir

    op = _raw_value(value).owner
    if isinstance(op, ir.OpView):
        op = op.operation
    if not isinstance(op, ir.Operation) or op.name != name:
        raise ValueError(f"Expected {name} for ABI provenance")
    return op


def _integer(value: Any) -> int:
    from cutlass._mlir import ir

    op = _owner(value, "llvm.mlir.constant")
    attr = op.attributes.get("value")
    if op.operands or not isinstance(attr, ir.IntegerAttr):
        raise ValueError("Expected an exact lowered integer constant")
    return attr.value


def _uses(value: Any) -> list[tuple[Any, int]]:
    return [(use.owner.operation, use.operand_number) for use in _raw_value(value).uses]


def _exact_uses(value: Any, expected: list[tuple[Any, int]]) -> None:
    actual = _uses(value)
    if len(actual) != len(expected) or any(item not in expected for item in actual):
        raise ValueError("Unexpected alias, escape or additional use of ABI storage")


def _ordered(*ops: Any) -> None:
    if not ops or any(op.block != ops[0].block for op in ops):
        raise ValueError("ABI allocation, initialization and use must share a block")
    body = [view.operation for view in ops[0].block.operations]
    positions = [body.index(op) for op in ops]
    if any(left >= right for left, right in zip(positions, positions[1:])):
        raise ValueError("ABI storage initialization must precede its use")


def _gep_indices(op: Any) -> tuple[int, ...]:
    from cutlass._mlir import ir

    raw = op.attributes.get("rawConstantIndices")
    if op.name != "llvm.getelementptr" or not isinstance(raw, ir.DenseI32ArrayAttr):
        raise ValueError("Expected typed constant ABI pointer indexing")
    dynamic = iter(op.operands[1:])
    indices = []
    for index in raw:
        if index == -(2**31):
            value = next(dynamic, None)
            if value is None:
                raise ValueError("Missing ABI pointer index")
            index = _integer(value)
        indices.append(index)
    if next(dynamic, None) is not None:
        raise ValueError("Unexpected ABI pointer index operands")
    return tuple(indices)


def _allocation(value: Any, count: int, element: Any) -> Any:
    op = _owner(value, "llvm.alloca")
    if (
        len(op.operands) != 1 or _integer(op.operands[0]) != count
        or op.attributes["elem_type"].value != element
    ):
        raise ValueError("Unexpected ABI allocation element type or count")
    return op


def _function(module: Any, name: str) -> Any:
    found = [view.operation for view in module.body.operations
             if view.operation.name == "llvm.func"
             and view.operation.attributes["sym_name"].value == name]
    if len(found) != 1 or len(found[0].regions) != 1 or not found[0].regions[0].blocks:
        raise ValueError(f"Expected the original lowered function {name}")
    return found[0]


def _calls(function: Any, callee: str) -> list[Any]:
    return [op for block in function.regions[0].blocks for op in _walk_block(block)
            if op.name == "llvm.call" and op.attributes.get("callee") is not None
            and op.attributes["callee"].value == callee]


def _slot_zero(value: Any, argument: Any) -> Any:
    from cutlass._mlir.dialects import llvm

    gep = _owner(value, "llvm.getelementptr")
    if (
        gep.operands[0] != argument or _gep_indices(gep) != (0,)
        or gep.attributes["elem_type"].value != llvm.PointerType.get()
    ):
        raise ValueError("Expected library slot zero of the original library array")
    return gep


def _registrations(module: Any, gpu_module: str, kernel_symbols: tuple[str, str]) -> dict[str, str]:
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import llvm

    count = _function(module, "cuda_num_binaries")
    body = [view.operation for view in count.regions[0].blocks[0].operations]
    if (len(count.regions[0].blocks) != 1 or len(body) != 2 or body[-1].name != "llvm.return"
            or len(body[-1].operands) != 1 or _integer(body[-1].operands[0]) != 1):
        raise ValueError("Expected exactly one original CUDA library")
    init = _function(module, "cuda_init")
    init_calls = _calls(init, "_cudaLibraryLoadData")
    if len(init_calls) != 1 or len(init_calls[0].operands) != 8:
        raise ValueError("Expected one original CUDA library initialization")
    call = init_calls[0]
    slot = _slot_zero(call.operands[0], init.regions[0].blocks[0].arguments[0])
    binary = _owner(call.operands[1], "llvm.mlir.addressof")
    if binary.attributes["global_name"].value != f"{gpu_module}_binary":
        raise ValueError("Library initialization does not use the certified whole binary")
    _ordered(slot, call)
    _ordered(binary, call)
    _exact_uses(slot.results[0], [(call, 0)])
    _exact_uses(binary.results[0], [(call, 1)])

    mapping = None
    registration_calls = []
    for name in ("cuda_load", "cuda_load_to_device"):
        loader = _function(module, name)
        calls = _calls(loader, "_cudaLibraryGetKernel")
        if len(calls) != 2:
            raise ValueError("Both loader entry points must register both original kernels")
        current = {}
        for call in calls:
            if len(call.operands) != 3:
                raise ValueError("Unexpected kernel registration ABI")
            address = _owner(call.operands[0], "llvm.mlir.addressof")
            global_name = address.attributes["global_name"].value
            library = _owner(call.operands[1], "llvm.load")
            slot = _slot_zero(library.operands[0], loader.regions[0].blocks[0].arguments[0])
            _ordered(slot, library, call)
            _ordered(address, call)
            _exact_uses(slot.results[0], [(library, 0)])
            _exact_uses(library.results[0], [(call, 1)])
            memory = call.operands[2]
            stores = [op for op, operand in _uses(memory) if op.name == "llvm.store" and operand == 1]
            if len(stores) != 1:
                raise ValueError("Kernel registration name must be stored exactly once")
            store = stores[0]
            literal = _owner(store.operands[0], "llvm.mlir.constant")
            value = literal.attributes.get("value")
            if not isinstance(value, ir.StringAttr):
                raise ValueError("Kernel registration name must be a literal")
            matches = [symbol for symbol in kernel_symbols if value.value_bytes == symbol.encode() + b"\0"]
            if len(matches) != 1 or global_name in current or matches[0] in current.values():
                raise ValueError("Kernel registration literal does not match distinct certified symbols")
            typ = literal.results[0].type
            if typ != ir.Type.parse(f"!llvm.array<{len(value.value_bytes)} x i8>"):
                raise ValueError("Kernel registration name has an unexpected LLVM type")
            allocation = _allocation(memory, 1, typ)
            _ordered(allocation, store, call)
            _ordered(literal, store)
            _exact_uses(memory, [(store, 1), (call, 2)])
            current[global_name] = matches[0]
            registration_calls.append(call)
        if mapping is not None and mapping != current:
            raise ValueError("Loader entry points disagree on kernel-symbol registration")
        mapping = current

    globals_by_name = {view.operation.attributes["sym_name"].value: view.operation
                       for view in module.body.operations if view.operation.name == "llvm.mlir.global"}
    for name in mapping:
        global_op = globals_by_name.get(name)
        if global_op is None or global_op.attributes["global_type"].value != llvm.PointerType.get():
            raise ValueError("Kernel handle registration must target an original pointer global")
    for op in _walk_block(module.body):
        if op.name != "llvm.mlir.addressof" or op.attributes["global_name"].value not in mapping:
            continue
        for use, operand in _uses(op.results[0]):
            if use in registration_calls and operand == 0:
                continue
            if use.name != "llvm.load" or operand != 0:
                raise ValueError("Unrecognized writer or alias of a registered kernel global")
    return mapping


def _check_pack(call: Any, arguments: list[Any]) -> KernelABI:
    from cutlass._mlir.dialects import llvm

    array = call.operands[2]
    allocation = _allocation(array, 2, llvm.PointerType.get())
    _ordered(allocation, call)
    projections = [op for op, operand in _uses(array) if op.name == "llvm.getelementptr" and operand == 0]
    if len(projections) != 2:
        raise ValueError("Expected exactly two kernel argument array projections")
    _exact_uses(array, [(op, 0) for op in projections] + [(call, 2)])
    seen = set()
    for projection in projections:
        indices = _gep_indices(projection)
        if (len(indices) != 1 or indices[0] not in (0, 1) or indices[0] in seen
                or projection.attributes["elem_type"].value != llvm.PointerType.get()):
            raise ValueError("Expected distinct kernel argument slots zero and one")
        index = indices[0]
        seen.add(index)
        uses = _uses(projection.results[0])
        if len(uses) != 1 or uses[0][0].name != "llvm.store" or uses[0][1] != 1:
            raise ValueError("Each kernel argument slot must have one pointer store")
        pointer_store = uses[0][0]
        memory = pointer_store.operands[0]
        aggregate = _allocation(memory, 1, arguments[index].type)
        stores = [op for op, operand in _uses(memory) if op.name == "llvm.store" and operand == 1]
        if len(stores) != 1 or stores[0].operands[0] != arguments[index]:
            raise ValueError("Host-to-device formal order or complete aggregate bytes changed")
        store = stores[0]
        _exact_uses(memory, [(store, 1), (pointer_store, 0)])
        _ordered(aggregate, store, pointer_store, call)
        _ordered(allocation, projection, pointer_store, call)
    return KernelABI(
        ((0, 16), (16, 16)), ((0, 0), (1, 0)),
        ((0, 8, "i32"), (1, 8, "i32")), ((0, 12, 4), (1, 12, 4)),
    )


def _reach(start: int, successors: list[tuple[int, ...]]) -> set[int]:
    reached = set()
    pending = [start]
    while pending:
        block = pending.pop()
        if block not in reached:
            reached.add(block)
            pending.extend(successors[block])
    return reached


def _check_status(call: Any) -> None:
    status = _raw_value(call.results[0])
    body = [view.operation for view in call.block.operations]
    terminator = body[-1]
    if terminator.name != "llvm.cond_br" or len(terminator.operands) != 1 or len(terminator.successors) != 2:
        raise ValueError("Expected direct launch-status control flow")
    comparison = _owner(terminator.operands[0], "llvm.icmp")
    if (comparison.attributes["predicate"].value != 0 or len(comparison.operands) != 2
            or _raw_value(comparison.operands[0]) != status or _integer(comparison.operands[1]) != 0):
        raise ValueError("Launch status must select success or its own error return")
    _ordered(call, comparison, terminator)
    error_ops = [view.operation for view in terminator.successors[1].operations]
    if len(error_ops) != 1 or error_ops[0].name != "llvm.return" or [_raw_value(value) for value in error_ops[0].operands] != [status]:
        raise ValueError("Launch failure must return its unchanged status")
    _exact_uses(status, [(comparison, 0), (error_ops[0], 0)])
    current = terminator.successors[0]
    visited = []
    while current not in visited:
        visited.append(current)
        ops = [view.operation for view in current.operations]
        if len(ops) == 1 and ops[0].name == "llvm.br" and not ops[0].operands:
            current = ops[0].successors[0]
            continue
        if (len(ops) == 1 or (len(ops) == 2 and ops[0].name == "llvm.mlir.constant")) and ops[-1].name == "llvm.return":
            if len(ops[-1].operands) == 1 and _integer(ops[-1].operands[0]) == 0:
                return
        raise ValueError("Expected a launch-free success join returning zero")
    raise ValueError("Launch success cannot enter a control-flow cycle")


def _check_lowered_structure(
    module: Any, *, function_name: str, gpu_module: str,
    kernel_symbols: tuple[str, str], dispatch: BranchDispatch,
) -> tuple[LaunchSiteABI, LaunchSiteABI]:
    # Structural checks on arbitrary IR do not establish compiled-owner provenance.
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import llvm

    if not module.operation.verify():
        raise ValueError("Lowered module failed verification")
    if (type(dispatch) is not BranchDispatch or dispatch.predicate != "slt" or dispatch.width != 32
            or dispatch.left != IntExpr("boxed", 0) or type(dispatch.right) is not IntExpr
            or dispatch.right.op != "constant" or dispatch.right.args
            or type(dispatch.right.value) is not int or not -(2**31) <= dispatch.right.value < 2**31
            or len(kernel_symbols) != 2 or len(set(kernel_symbols)) != 2
            or {dispatch.true_symbol, dispatch.false_symbol} != set(kernel_symbols)):
        raise ValueError("Expected one original signed-int32 input-extent dispatch")
    host = _function(module, function_name)
    blocks = list(host.regions[0].blocks)
    arguments = [_raw_value(value) for value in blocks[0].arguments]
    types = [value.type for value in arguments]
    if len(types) != 3 or types[0] != types[1] or types[2] != llvm.PointerType.get():
        raise ValueError("Expected two equal tensor aggregates and the original stream")
    aggregate = types[0]
    if not isinstance(aggregate, llvm.StructType) or aggregate.packed or len(aggregate.body) != 2:
        raise ValueError("Unsupported tensor aggregate")
    pointer, layout = aggregate.body
    if pointer != llvm.PointerType.get(address_space=1) or not isinstance(layout, llvm.StructType) or layout.packed or len(layout.body) != 2:
        raise ValueError("Expected a global pointer followed by the dynamic layout")
    extent, empty = layout.body
    if (extent != ir.IntegerType.get_signless(32) or not isinstance(empty, llvm.StructType)
            or empty.packed or empty.body or ctypes.sizeof(ctypes.c_void_p) != 8 or sys.byteorder != "little"):
        raise ValueError("Expected a signed-int32 extent with no dynamic stride on little-endian 64-bit host")
    ops = [[view.operation for view in block.operations] for block in blocks]
    branch = ops[0][-1]
    if branch.name != "llvm.cond_br" or len(branch.operands) != 1 or len(branch.successors) != 2:
        raise ValueError("Expected original two-arm entry dispatch")
    compare = _owner(branch.operands[0], "llvm.icmp")
    if (compare.attributes["predicate"].value != 2 or len(compare.operands) != 2
            or any(value.type != extent for value in compare.operands)
            or _integer(compare.operands[1]) != dispatch.right.value):
        raise ValueError("Lowered dispatch predicate differs from the original typed predicate")
    projection = _owner(compare.operands[0], "llvm.extractvalue")
    if list(projection.operands) != [arguments[0]] or list(projection.attributes["position"]) != [1, 0]:
        raise ValueError("Lowered dispatch must read the original input extent field")
    _ordered(projection, compare, branch)
    calls = _calls(host, "_cudaLaunchKernelEx")
    if len(calls) != 2 or any(len(call.operands) != 3 or len(call.results) != 1 for call in calls):
        raise ValueError("Expected exactly two original extended CUDA launch sites")
    successors = [tuple(blocks.index(block) for block in body[-1].successors) for body in ops]
    roots = [blocks.index(block) for block in branch.successors]
    reachable = [_reach(root, successors) for root in roots]
    if 0 in reachable[0] | reachable[1] or _reach(0, successors) != set(range(len(blocks))):
        raise ValueError("Unexpected dispatch backedge or unreachable lowered host blocks")
    registrations = _registrations(module, gpu_module, kernel_symbols)
    records = []
    for arm_index, symbol in enumerate((dispatch.true_symbol, dispatch.false_symbol)):
        reached = reachable[arm_index]
        selected = [call for call in calls if blocks.index(call.block) in reached]
        if len(selected) != 1:
            raise ValueError("Each dispatch arm must reach only its own launch")
        call = selected[0]
        index = blocks.index(call.block)
        if index in reachable[1 - arm_index] or any(index in _reach(next_block, successors) for next_block in successors[index]):
            raise ValueError("Launch sites cannot be shared across arms or belong to a cycle")
        loaded = _owner(call.operands[1], "llvm.load")
        address = _owner(loaded.operands[0], "llvm.mlir.addressof")
        global_name = address.attributes["global_name"].value
        if registrations.get(global_name) != symbol:
            raise ValueError("Dispatch arm and registered selected kernel symbol disagree")
        _ordered(address, loaded, call)
        _exact_uses(address.results[0], [(loaded, 0)])
        _exact_uses(loaded.results[0], [(call, 1)])
        abi = _check_pack(call, arguments)
        _check_status(call)
        records.append(LaunchSiteABI(arm_index == 0, symbol, global_name, abi))
    return tuple(records)


def check_guarded_lowered_abi(
    compiled: Any, analysis: ProgramAnalysis, dispatch: BranchDispatch,
) -> tuple[LaunchSiteABI, LaunchSiteABI]:
    from cutlass._mlir import ir
    from cutlass.cutlass_dsl.cuda_jit_executor import CudaDialectJitCompiledFunction

    if (type(compiled) is not CudaDialectJitCompiledFunction or type(analysis) is not ProgramAnalysis
            or not analysis.supported or not analysis.compiled_hash or len(analysis.kernels) != 2
            or compiled.load_from_binary or compiled.total_added_arguments or compiled.kernel_extra_args):
        raise ValueError("Expected the original supported whole CuTe compilation")
    symbols = tuple(kernel.kernel_symbol for kernel in analysis.kernels)
    if (compiled.function_name != analysis.function_name or tuple(compiled.kernel_info) != symbols
            or any(compiled.kernel_info[symbol] for symbol in symbols)
            or analysis.compiler_version != version("nvidia-cutlass-dsl") or analysis.analyzer_version != ANALYSIS_VERSION
            or any(not kernel.supported or kernel.compiled_hash != analysis.compiled_hash
                   or kernel.trace_sha256 != analysis.trace_sha256 or kernel.compiler_version != analysis.compiler_version
                   or kernel.analyzer_version != analysis.analyzer_version for kernel in analysis.kernels)):
        raise ValueError("Whole-program owner, symbols or per-symbol certificate identity changed")
    module = compiled.ir_module
    with module.context, module.operation.location:
        attrs = module.operation.attributes
        if (not isinstance(attrs.get(_TRACE_ATTR), ir.StringAttr) or attrs[_TRACE_ATTR].value != analysis.trace_sha256
                or not isinstance(attrs.get(_VERSION_ATTR), ir.IntegerAttr) or attrs[_VERSION_ATTR].value != PROGRAM_TRACE_VERSION
                or not isinstance(attrs.get(_DEVICE_VERSION_ATTR), ir.IntegerAttr) or attrs[_DEVICE_VERSION_ATTR].value != ANALYSIS_VERSION):
            raise ValueError("Original program trace stamps are missing or changed")
        binaries = [view.operation.attributes.get("value") for view in module.body.operations
                    if view.operation.name == "llvm.mlir.global"
                    and view.operation.attributes["sym_name"].value == f"{analysis.gpu_module}_binary"]
        if (len(binaries) != 1 or not isinstance(binaries[0], ir.StringAttr) or not binaries[0].value_bytes
                or sha256(binaries[0].value_bytes).hexdigest() != analysis.compiled_hash):
            raise ValueError("The original whole CUDA binary changed")
        return _check_lowered_structure(
            module, function_name=analysis.function_name, gpu_module=analysis.gpu_module,
            kernel_symbols=symbols, dispatch=dispatch,
        )
