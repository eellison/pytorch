from dataclasses import dataclass, field
from typing import Any

from aggregate_plan import AggregatePlan
from checked_metadata import evaluate_checked_cfg as evaluate_metadata_cfg
from continuation import DispatchCompilation
from metadata_regions import MetadataAggregate, UnavailablePointer, _check_computation
from stream_layout import StreamLayout
from target_layout import TargetLayout
from values import ScalarValue, evaluate, scalar


@dataclass(frozen=True)
class TensorProperties:
    shape: tuple[int, ...]
    stride: tuple[int, ...]


def _owners(components: Any, layout: TargetLayout, stream_layout: StreamLayout) -> None:
    components.check()
    if (type(components.dispatch) is not DispatchCompilation or type(components.plan) is not AggregatePlan
            or type(layout) is not TargetLayout or type(stream_layout) is not StreamLayout):
        raise TypeError("Expected the original dispatch, component and compiler layout owners")
    layout.check()
    stream_layout.check()
    dispatch = components.dispatch
    if (components.plan.mapping.program is not dispatch.program or layout.query.plan is not components.plan
            or stream_layout.formals is not dispatch.joined.mapping.formals):
        raise ValueError("Dispatch metadata layouts belong to another compiler program")
    if any(site.source.stream_source_arg_index != stream_layout.source_index for site in dispatch.joined.sites):
        raise ValueError("Dispatch sites must use the same original environment stream")


@dataclass(frozen=True)
class DispatchInputs:
    components: Any = field(repr=False)
    layout: TargetLayout = field(repr=False)
    stream_layout: StreamLayout = field(repr=False)
    properties: tuple[tuple[int, TensorProperties], ...]
    values: tuple[tuple[int, MetadataAggregate | UnavailablePointer], ...] = field(repr=False)
    _owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        owned = self.components, self.layout, self.stream_layout, self.properties, self.values
        if len(owned) != len(self._owners) or any(value is not owner for value, owner in zip(owned, self._owners)):
            raise RuntimeError("Dispatch metadata values changed their original owners")
        _owners(self.components, self.layout, self.stream_layout)


def bind_properties(components: Any, layout: TargetLayout, stream_layout: StreamLayout,
                    properties: dict[int, TensorProperties]) -> DispatchInputs:
    _owners(components, layout, stream_layout)
    dispatch = components.dispatch
    metadata = dispatch.joined.admission.source.metadata
    tensor_params = {item.ir_arg_index: item for item in metadata.params if item.kind == "Tensor"}
    if (type(properties) is not dict or any(type(index) is not int for index in properties)
            or set(properties) != set(tensor_params)):
        raise ValueError("Tensor properties must identify every original tensor formal exactly")
    streams = [item for item in metadata.params if item.kind == "EnvStream"]
    if (len(streams) != 1 or streams[0].ir_arg_index != stream_layout.source_index
            or any(item.kind not in {"Tensor", "EnvStream"} for item in metadata.params)):
        raise ValueError("This metadata subset requires tensor formals and one environment stream")
    symbols = {}
    for index, parameter in tensor_params.items():
        value = properties[index]
        if type(value) is not TensorProperties:
            raise TypeError("Expected explicit tensor shape and stride metadata")
        for prop, actual, dimensions in (("shape", value.shape, parameter.shape),
                                         ("stride", value.stride, parameter.strides)):
            if type(actual) is not tuple or len(actual) != len(dimensions):
                raise ValueError("Tensor metadata changed its compiler rank")
            for number, (kind, constant) in zip(actual, dimensions):
                if type(number) is not int or number < (1 if prop == "shape" else 0):
                    raise ValueError("This metadata subset requires positive shapes and nonnegative strides")
                if kind == "constant":
                    if number != constant:
                        raise ValueError("Tensor metadata violates a static compiler property")
                elif kind == "symbol":
                    if not 0 <= constant < len(metadata.symbols):
                        raise ValueError("Tensor property lost its compiler dimension symbol")
                    _, bits, divisibility = metadata.symbols[constant]
                    if not 0 <= number < 2**(bits - 1):
                        raise ValueError("Tensor metadata exceeds its signed compiler dimension width")
                    if divisibility is not None and (divisibility <= 0 or number % divisibility):
                        raise ValueError("Tensor metadata violates compiler dimension divisibility")
                    if constant in symbols and symbols[constant] != number:
                        raise ValueError("Tensor metadata disagrees on a shared compiler dimension symbol")
                    symbols[constant] = number
                else:
                    raise ValueError("Unsupported compiler tensor dimension")
    formal_layouts = {item.source_arg_index: item for item in layout.formals}
    values = {}
    for formal in components.plan.formals:
        index = formal.source_arg_index
        value = properties[index]
        fields = {item.path: item for item in formal_layouts[index].fields}
        leaves = []
        for leaf in formal.leaves:
            spec = leaf.component.spec
            field_layout = fields[leaf.path]
            if field_layout.llvm_type != leaf.llvm_type:
                raise ValueError("Compiler tensor leaf and target layout types differ")
            if spec.property == "pointer":
                if not leaf.llvm_type.startswith("!llvm.ptr"):
                    raise ValueError("Pointer accessor lost its exact compiler pointer type")
                item = UnavailablePointer(leaf.llvm_type, field_layout.size)
            elif spec.property in {"shape", "stride"} and len(spec.property_path) == 1:
                numbers = value.shape if spec.property == "shape" else value.stride
                number = numbers[spec.property_path[0]]
                if leaf.llvm_type not in {"i32", "i64"} or not 0 <= number < 2**(int(leaf.llvm_type[1:]) - 1):
                    raise ValueError("Tensor property exceeds its actual lowered integer leaf")
                item = scalar(leaf.llvm_type, number)
                if item.size != field_layout.size:
                    raise ValueError("Numeric tensor leaf differs from its compiler storage width")
            else:
                raise ValueError("Unsupported compiler tensor property projection")
            leaves.append((leaf.path, item))
        for component in formal.constants:
            spec = component.spec
            if spec.property not in {"shape", "stride"} or len(spec.property_path) != 1:
                raise ValueError("Unsupported constant tensor property projection")
            expected = evaluate(component.source, (), dispatch.program.context)
            actual = (value.shape if spec.property == "shape" else value.stride)[spec.property_path[0]]
            if type(expected) is not ScalarValue or expected.integer() != actual:
                raise ValueError("Tensor metadata differs from the actual compiled constant accessor")
        values[index] = MetadataAggregate(formal.llvm_type, tuple(leaves))
    values[stream_layout.source_index] = UnavailablePointer(stream_layout.llvm_type, stream_layout.size)
    formals = dispatch.joined.mapping.formals.formals
    if (set(values) != {item.ir_arg_index for item in formals}
            or any(values[item.ir_arg_index].llvm_type != item.llvm_type for item in formals)):
        raise ValueError("Dispatch metadata lacks exact original formal coverage")
    props, ordered = tuple(sorted(properties.items())), tuple(sorted(values.items()))
    owners = components, layout, stream_layout, props, ordered
    result = DispatchInputs(*owners, owners)
    result.check()
    return result


@dataclass(frozen=True)
class DispatchSelection:
    inputs: DispatchInputs = field(repr=False)
    site: Any = field(repr=False)
    grid: tuple[int, int, int]
    block: tuple[int, int, int]
    shared: int
    kernel_smem: int
    evaluated: tuple[str, ...]
    values: tuple[tuple[str, int, ScalarValue], ...] = field(repr=False)
    _owners: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        owned = self.inputs, self.site, self.grid, self.block, self.shared, self.kernel_smem, self.evaluated, self.values
        if len(owned) != len(self._owners) or any(value is not owner for value, owner in zip(owned, self._owners)):
            raise RuntimeError("Selected dispatch changed its original metadata or site")
        self.inputs.check()
        if not any(self.site is site for site in self.inputs.components.dispatch.joined.sites):
            raise ValueError("Selected dispatch lost its exact source and registered kernel")


def select_dispatch(inputs: DispatchInputs) -> DispatchSelection:
    if type(inputs) is not DispatchInputs:
        raise TypeError("Expected compiler-derived dispatch metadata inputs")
    inputs.check()
    dispatch = inputs.components.dispatch
    source_values = dict(inputs.values)
    for bound in dispatch.consumers:
        _check_computation(bound.cfg)
    evaluated, values = [], []

    def compute(bound):
        result = evaluate_metadata_cfg(bound.cfg, tuple(source_values[index] for index in bound.source_order))
        if len(result) != 1 or result[0].llvm_type != bound.helper.result_type:
            raise ValueError("Dispatch helper changed its exact scalar result type")
        evaluated.append(bound.helper.symbol)
        values.append((bound.role, bound.index, result[0]))
        return result[0]

    predicates = [bound for bound in dispatch.consumers if bound.site is None]
    if len(predicates) != 1 or predicates[0].role != "predicate":
        raise ValueError("Dispatch requires its exact original root predicate")
    predicate = compute(predicates[0])
    if predicate.llvm_type != "i1":
        raise ValueError("Dispatch predicate must return its original i1 value")
    arm = bool(predicate.integer(signed=False))
    sites = [site for site in dispatch.joined.sites if site.source.arm is arm]
    if len(sites) != 1:
        raise ValueError("Dispatch predicate does not select exactly one source site")
    site = sites[0]
    selected = {}
    for bound in dispatch.consumers:
        if bound.site is site.source:
            selected[bound.role, bound.index] = compute(bound)

    def integer(role, index, llvm_type):
        value = selected[role, index]
        if value.llvm_type != llvm_type:
            raise ValueError("Dispatch launch field changed its exact compiler width")
        return value.integer()

    grid = tuple(integer("grid", axis, "i32") for axis in range(3))
    block = tuple(integer("block", axis, "i32") for axis in range(3))
    shared = integer("shared", 0, "i64")
    kernel_smem = integer("kernel_smem", 0, "i64")
    for index, diagnostic in enumerate(site.source.diagnostics):
        value = selected["diagnostic", index]
        if value.llvm_type != "i1":
            raise ValueError("Dispatch diagnostic changed its original predicate width")
        if bool(value.integer(signed=False)) is not diagnostic.expected:
            raise ValueError(f"Original compiler shared-memory diagnostic rejected dispatch: {diagnostic.kind}")
    if any(value <= 0 for value in (*grid, *block)) or not 0 <= shared < 2**32 or kernel_smem < 0:
        raise ValueError("Dispatch launch dimensions or shared-memory values are invalid")
    owners = inputs, site, grid, block, shared, kernel_smem, tuple(evaluated), tuple(values)
    result = DispatchSelection(*owners, owners)
    result.check()
    return result
