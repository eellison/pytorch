from typing import Any

from cfg_values import CFGProgram
from metadata_regions import MetadataAggregate, _check_computation, _validate
from values import ScalarValue, evaluate, integer_width


def _no_overflow(flow: Any, slots: list[Any]) -> None:
    if flow.kind not in {"llvm.add", "llvm.sub", "llvm.mul", "llvm.shl", "llvm.trunc"}:
        return
    operands = []
    for operand in flow.operands:
        if operand.kind != "argument" or operand.path or operand.operands or operand.attributes:
            raise ValueError("Overflow checks require exact compiler instruction operand slots")
        value = slots[operand.argument]
        if type(value) is not ScalarValue or value.llvm_type != operand.llvm_type:
            raise ValueError("Overflow checks require concrete typed integer operands")
        operands.append(value)
    width = integer_width(flow.llvm_type)
    if flow.kind == "llvm.trunc":
        if (len(operands) != 1 or integer_width(operands[0].llvm_type) <= width
                or not 0 <= operands[0].integer() < 2**(width - 1)):
            raise ValueError("Conservative no-overflow domain rejects integer truncation")
        return
    if len(operands) != 2 or any(value.llvm_type != flow.llvm_type for value in operands):
        raise ValueError("Overflow checks require two operands with the exact result width")
    a, b = (value.integer() for value in operands)
    u, v = (value.integer(signed=False) for value in operands)
    if flow.kind == "llvm.add":
        signed, unsigned = a + b, u + v
    elif flow.kind == "llvm.sub":
        signed, unsigned = a - b, u - v
    elif flow.kind == "llvm.mul":
        signed, unsigned = a * b, u * v
    else:
        if v >= width:
            raise ValueError("Undefined integer shift in the host computation")
        signed, unsigned = a * 2**v, u * 2**v
    if not -(2**(width - 1)) <= signed < 2**(width - 1) or not 0 <= unsigned < 2**width:
        raise ValueError(f"Conservative no-overflow domain rejects {flow.kind}")


def evaluate_checked_cfg(cfg: CFGProgram, arguments: tuple[Any, ...]) -> tuple[ScalarValue, ...]:
    """Use the intersection of none/nsw/nuw domains while property access is unavailable."""
    _check_computation(cfg)
    if type(arguments) is not tuple or len(arguments) != len(cfg.argument_types):
        raise ValueError("Metadata helper arguments differ from its original signature")
    slots = [None] * len(cfg.types)
    block_index, incoming = 0, arguments
    for _ in cfg.blocks:
        block = cfg.blocks[block_index]
        if len(incoming) != len(block.arguments):
            raise ValueError("Metadata helper edge lost its block arguments")
        for slot, value in zip(block.arguments, incoming):
            _validate(value, cfg.types[slot])
            slots[slot] = value
        for instruction in block.instructions:
            flow = instruction.expression
            if flow.kind == "argument":
                result = slots[flow.argument]
                if flow.path:
                    if type(result) is not MetadataAggregate:
                        raise ValueError("Metadata projection requires its original aggregate")
                    result = dict(result.fields)[flow.path]
            else:
                _no_overflow(flow, slots)
                numeric = tuple(value if type(value) is ScalarValue and not value.llvm_type.startswith("!llvm.ptr")
                                else None for value in slots)
                result = evaluate(flow, numeric, cfg.context)
            _validate(result, cfg.types[instruction.result])
            slots[instruction.result] = result
        terminator = block.terminator
        if terminator.kind == "return":
            result = tuple(slots[slot] for slot in terminator.values)
            if (any(type(value) is not ScalarValue for value in result)
                    or tuple(value.llvm_type for value in result) != cfg.result_types):
                raise ValueError("Metadata helper may return only its exact numeric scalar types")
            return result
        selected = 0
        if terminator.kind == "conditional":
            condition = slots[terminator.values[0]]
            if type(condition) is not ScalarValue or condition.llvm_type != "i1":
                raise ValueError("Metadata helper requires a concrete i1 branch")
            selected = 0 if condition.integer(signed=False) else 1
        elif terminator.kind != "jump":
            raise ValueError("Unsupported metadata helper terminator")
        edge = terminator.edges[selected]
        incoming = tuple(slots[slot] for slot in edge.arguments)
        block_index = edge.block
    raise RuntimeError("Acyclic metadata helper did not reach a return")
