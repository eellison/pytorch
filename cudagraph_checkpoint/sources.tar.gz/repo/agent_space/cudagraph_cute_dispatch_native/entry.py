from dataclasses import dataclass
from typing import Any

from component_owner import ComponentCompilation
from components import DispatchComponents, compile_dispatch_components
from entry_signature import EntrySignature
from join_components import JoinedComponents, _bind_properties
from joined import JoinedInvocation, _compose


@dataclass(frozen=True)
class DispatchEntry:
    components: DispatchComponents
    joined: JoinedComponents

    def check(self) -> None:
        self.components.check()
        self.joined.check()
        dispatch = self.components.dispatch
        if (self.joined.invocation.program is not dispatch.program
                or self.joined.invocation.lowering is not dispatch.joined.mapping.formals
                or self.joined.invocation.flow is not dispatch.joined.mapping.flow
                or self.joined.mapping is not self.components.plan.mapping):
            raise ValueError("Dispatch entry lost its original symbolic or compiler owners")


def join_dispatch_entry(signature: EntrySignature, kernel: Any, *, arch: str) -> DispatchEntry:
    signature.check()
    components = compile_dispatch_components(signature.target, kernel, *signature.fake_args,
                                             arch=arch, **signature.fake_kwargs)
    dispatch = components.dispatch
    program = dispatch.program
    formals, flow = dispatch.joined.mapping.formals, dispatch.joined.mapping.flow
    metadata = program.source_metadata[0]
    bound = signature.bind_metadata(metadata)
    invocation = JoinedInvocation(signature, program, bound, formals, flow, _compose(bound, formals, flow),
                                  (signature, program, bound, formals, flow))
    mapping = components.plan.mapping
    compilation = ComponentCompilation(program, mapping.specs, metadata, (program, mapping.specs, metadata))
    properties = _bind_properties(invocation, mapping)
    joined = JoinedComponents(invocation, compilation, mapping, properties,
                              (invocation, compilation, mapping, properties))
    result = DispatchEntry(components, joined)
    result.check()
    return result
