from __future__ import annotations

from typing import Any

import python_entry as _v1
import torch
from python_entry import EntryCall, Operand, opaque_entry, PythonEntry, PythonHostUnsupported
from torch._ops import _len_torch_dispatch_stack_pre_dispatch
from torch.overrides import _get_current_function_mode_stack
from torch.utils._python_dispatch import _get_current_dispatch_mode_stack


def _ambient_state() -> tuple[torch.dtype, bool, bool]:
    if _get_current_function_mode_stack():
        raise PythonHostUnsupported("Python host tracing requires no TorchFunctionMode or DeviceContext override")
    if _get_current_dispatch_mode_stack() or _len_torch_dispatch_stack_pre_dispatch():
        raise RuntimeError("Python host tracing requires isolated TorchDispatch mode stacks")
    if (getattr(torch._GLOBAL_DEVICE_CONTEXT, "device_context", None) is not None
            or torch._C._get_default_device() != "cpu"):
        raise PythonHostUnsupported("Python host tracing requires the baseline CPU default device")
    return torch.get_default_dtype(), torch.is_grad_enabled(), torch.is_inference_mode_enabled()


class PythonHostTrace(_v1.PythonHostTrace):
    def __init__(self, trace: _v1.PythonHostTrace, ambient_state: tuple[torch.dtype, bool, bool]) -> None:
        super().__init__(trace.graph_module, trace.shape_env, trace.fake_mode, trace.guards,
                         trace.calls, trace.entries, trace._dependencies, trace._input_contract)
        self.ambient_state = ambient_state
        self._ambient_guard = ambient_state

    def check(self) -> None:
        current = _ambient_state()
        if self.ambient_state is not self._ambient_guard or current != self._ambient_guard:
            raise RuntimeError("Python host ambient state changed")
        super().check()

    def accepts(self, tensors: tuple[torch.Tensor, ...] | list[torch.Tensor]) -> bool:
        current = _ambient_state()
        if self.ambient_state is not self._ambient_guard:
            raise RuntimeError("Python host ambient guard association changed")
        if current != self._ambient_guard:
            return False
        return super().accepts(tensors)


def trace_python_host(host: Any, example_tensors: tuple[torch.Tensor, ...] | list[torch.Tensor],
                      entries: tuple[PythonEntry, ...] | list[PythonEntry]) -> PythonHostTrace:
    ambient_state = _ambient_state()
    trace = _v1.trace_python_host(host, example_tensors, entries)
    result = PythonHostTrace(trace, ambient_state)
    result.check()
    return result
