from dataclasses import dataclass, field
from typing import Any

from accessors import _function, _tagged_arguments
from cfg_values import read_cfg_function
from region_helpers import RegionIf
from values import ScalarValue


@dataclass(frozen=True)
class BoundLeaf:
    source: Any
    cfg: Any
    local_order: tuple[int, ...]


@dataclass(frozen=True)
class RegionEvaluation:
    value: ScalarValue
    branches: tuple[tuple[Any, bool], ...]


@dataclass(frozen=True)
class BoundRegion:
    program: Any
    output: Any
    plan: Any
    leaves: tuple[BoundLeaf, ...]
    _owners: tuple[Any, ...] = field(repr=False)
    _orders: tuple[tuple[int, ...], ...] = field(repr=False)

    def check(self) -> None:
        from cutlass._mlir import ir

        if (len(self._owners) != 4 or any(value is not owner for value, owner in zip(
                (self.program, self.output, self.plan, self.leaves), self._owners))
                or tuple(leaf.local_order for leaf in self.leaves) != self._orders):
            raise RuntimeError("Source-region binding ownership or formal order changed")
        self.program.check()
        self.output.check()
        self.plan.check()
        if (self.plan.source_helper is not self.output.helper or self.plan.module is not self.program.source_module
                or self.plan.requested_source != self.output.source):
            raise RuntimeError("Region plan lost the exact original output source")
        with self.program.context, ir.raw_values():
            host = _tagged_arguments(_function(self.program.module, self.program.function_name, "llvm.func"))
            original = dict(zip(self.plan.formals, self.plan.source_ids))
            for bound in self.leaves:
                leaf, cfg = bound.source, bound.cfg
                leaf.check()
                cfg.check()
                function = _function(self.program.module, leaf.symbol, "llvm.func")
                arguments = _tagged_arguments(function)
                if (cfg.module is not self.program.module or cfg.function_name != leaf.symbol
                        or tuple(arguments) != bound.local_order
                        or set(arguments) != set(range(len(leaf.input_origin)))
                        or cfg.result_types != (leaf.result_type,)):
                    raise ValueError("Leaf helper lost its original compiler signature")
                for index, value in arguments.items():
                    source = leaf.input_origin[index]
                    expected = host[original[source]].type if source in original else source.type
                    if str(value.type) != str(expected):
                        raise ValueError("Leaf helper input lost its original tensor or scalar type")

    def evaluate(self, source_arguments: dict[int, Any]) -> RegionEvaluation:
        self.check()
        if type(source_arguments) is not dict or set(source_arguments) != set(self.plan.source_ids):
            raise ValueError("Region inputs must identify every original source formal")
        environment = {value: source_arguments[index] for value, index in zip(self.plan.formals, self.plan.source_ids)}
        helpers = {id(bound.source): bound for bound in self.leaves}
        branches = []

        def leaf_value(leaf: Any, values: dict[Any, Any]) -> ScalarValue:
            bound = helpers[id(leaf)]
            if any(value not in values for value in leaf.input_origin):
                raise ValueError("Region helper needs an unavailable scalar merge value")
            inputs = tuple(values[leaf.input_origin[index]] for index in bound.local_order)
            result = bound.cfg.evaluate(inputs)
            if len(result) != 1 or type(result[0]) is not ScalarValue or result[0].llvm_type != leaf.result_type:
                raise ValueError("Region helper did not produce its exact scalar result")
            return result[0]

        def run_block(block: Any, incoming: dict[Any, Any]) -> tuple[ScalarValue, ...]:
            local = dict(incoming)
            for step in block.steps:
                if type(step) is not RegionIf:
                    raise ValueError("Unsupported source region control operation")
                condition = leaf_value(step.condition, local)
                if condition.llvm_type != "i1":
                    raise ValueError("Source region branch requires an i1 condition")
                selected = bool(condition.integer(signed=False))
                branches.append((step.operation, selected))
                results = run_block(step.true_block if selected else step.false_block, local)
                if len(results) != len(step.results):
                    raise RuntimeError("Selected source yields do not cover the original merge results")
                for value, result in zip(step.results, results):
                    if str(value.type) != result.llvm_type:
                        raise ValueError("Selected source yield changed its merge type")
                    local[value] = result
            return tuple(leaf_value(leaf, local) for leaf in block.yield_helpers)

        result = run_block(self.plan.root, environment)
        if len(result) != 1:
            raise RuntimeError("Expected one requested original source scalar")
        return RegionEvaluation(result[0], tuple(branches))


def bind_region_outputs(program: Any, outputs: tuple[tuple[Any, Any], ...]) -> tuple[BoundRegion, ...]:
    from cutlass._mlir import ir

    program.check()
    result = []
    with program.context, ir.raw_values():
        for output, plan in outputs:
            output.check()
            plan.check()
            leaves = []

            def visit(block: Any) -> None:
                for step in block.steps:
                    leaves.append(step.condition)
                    visit(step.true_block)
                    visit(step.false_block)
                leaves.extend(block.yield_helpers)

            visit(plan.root)
            leaves = tuple(dict((id(leaf), leaf) for leaf in leaves).values())
            bound = []
            for leaf in leaves:
                function = _function(program.module, leaf.symbol, "llvm.func")
                bound.append(BoundLeaf(leaf, read_cfg_function(program.module, leaf.symbol), tuple(_tagged_arguments(function))))
            bound = tuple(bound)
            item = BoundRegion(program, output, plan, bound, (program, output, plan, bound),
                               tuple(leaf.local_order for leaf in bound))
            item.check()
            result.append(item)
    return tuple(result)
