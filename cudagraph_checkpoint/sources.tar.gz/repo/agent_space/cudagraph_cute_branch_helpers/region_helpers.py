from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from typing import Any

from emitter_v2 import SOURCE_ARGUMENT, _op, _snapshot, _validate_tree, _walk


@dataclass(frozen=True)
class LeafHelper:
    symbol: str
    operation: Any = field(repr=False, compare=False)
    source_helper: Any = field(repr=False, compare=False)
    module: Any = field(repr=False, compare=False)
    context: Any = field(repr=False, compare=False)
    input_origin: tuple[Any, ...] = field(repr=False, compare=False)
    output_origin: Any = field(repr=False, compare=False)
    source_types: tuple[str, ...]
    result_type: str
    _body: tuple[str, bytes] = field(repr=False)
    _seal: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        return (self.symbol, id(self.operation), id(self.source_helper), id(self.module), id(self.context),
                tuple(id(value) for value in self.input_origin), id(self.output_origin), self.source_types,
                self.result_type, self._body)

    def check(self) -> None:
        from cutlass._mlir import ir

        if (self._state() != self._seal or self.module is not self.source_helper.module
                or self.context is not self.source_helper.context):
            raise RuntimeError("Region leaf source or compiler association changed")
        self.source_helper.check()
        with self.context, ir.raw_values():
            matches = [view.operation for view in self.module.body.operations
                       if "sym_name" in view.operation.attributes and view.operation.attributes["sym_name"].value == self.symbol]
            if (matches != [self.operation] or _snapshot(self.operation) != self._body
                    or tuple(str(value.type) for value in self.input_origin) != self.source_types
                    or str(self.output_origin.type) != self.result_type):
                raise RuntimeError("Region leaf operation or typed SSA origin changed")


@dataclass(frozen=True)
class RegionIf:
    operation: Any = field(repr=False, compare=False)
    condition_value: Any = field(repr=False, compare=False)
    condition: LeafHelper
    true_block: RegionBlock
    false_block: RegionBlock
    results: tuple[Any, ...] = field(repr=False, compare=False)
    true_yield: tuple[Any, ...] = field(repr=False, compare=False)
    false_yield: tuple[Any, ...] = field(repr=False, compare=False)
    _seal: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        return (id(self.operation), id(self.condition_value), id(self.condition), id(self.true_block),
                id(self.false_block), tuple(id(value) for value in self.results),
                tuple(id(value) for value in self.true_yield), tuple(id(value) for value in self.false_yield))


@dataclass(frozen=True)
class RegionBlock:
    source_block: Any = field(repr=False, compare=False)
    steps: tuple[RegionIf, ...]
    yield_values: tuple[Any, ...] = field(repr=False, compare=False)
    yield_helpers: tuple[LeafHelper, ...]
    _seal: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        return (id(self.source_block), tuple(id(step) for step in self.steps),
                tuple(id(value) for value in self.yield_values), tuple(id(helper) for helper in self.yield_helpers))


def _check_block(block: RegionBlock) -> tuple[LeafHelper, ...]:
    if block._state() != block._seal:
        raise RuntimeError("Source region block or yield association changed")
    operations = tuple(view.operation for view in block.source_block.operations)
    if (tuple(op for op in operations if op.name == "scf.if") != tuple(step.operation for step in block.steps)
            or not operations or operations[-1].name not in {"func.return", "scf.yield"}
            or tuple(operations[-1].operands) != block.yield_values
            or len(block.yield_helpers) != len(block.yield_values)
            or any(helper.output_origin != value for helper, value in zip(block.yield_helpers, block.yield_values))):
        raise RuntimeError("Source region structure or exact yield operands changed")
    helpers = []
    for branch in block.steps:
        op = branch.operation
        if (branch._state() != branch._seal or tuple(op.operands) != (branch.condition_value,)
                or branch.condition.output_origin != branch.condition_value
                or tuple(op.results) != branch.results
                or op.regions[0].blocks[0] != branch.true_block.source_block
                or op.regions[1].blocks[0] != branch.false_block.source_block
                or branch.true_yield != branch.true_block.yield_values
                or branch.false_yield != branch.false_block.yield_values):
            raise RuntimeError("Source conditional or yield-to-result association changed")
        helpers.append(branch.condition)
        helpers.extend(_check_block(branch.true_block))
        helpers.extend(_check_block(branch.false_block))
    helpers.extend(block.yield_helpers)
    return tuple(helpers)


@dataclass(frozen=True)
class RegionPlan:
    source_helper: Any = field(repr=False, compare=False)
    source_function: Any = field(repr=False, compare=False)
    module: Any = field(repr=False, compare=False)
    context: Any = field(repr=False, compare=False)
    formals: tuple[Any, ...] = field(repr=False, compare=False)
    source_ids: tuple[int, ...]
    requested_source: Any = field(repr=False, compare=False)
    final_value: Any = field(repr=False, compare=False)
    root: RegionBlock
    helpers: tuple[LeafHelper, ...]
    _seal: tuple[Any, ...] = field(repr=False)

    def _state(self) -> tuple[Any, ...]:
        return (id(self.source_helper), id(self.source_function), id(self.module), id(self.context),
                tuple(id(value) for value in self.formals), self.source_ids, id(self.requested_source),
                id(self.final_value), id(self.root), tuple(id(helper) for helper in self.helpers))

    def check(self) -> None:
        from cutlass._mlir import ir

        if (self._state() != self._seal or self.module is not self.source_helper.module
                or self.context is not self.source_helper.context or self.source_function is not self.source_helper.operation
                or self.source_ids != self.source_helper.source_ids
                or self.source_helper.output_values != (self.requested_source,)):
            raise RuntimeError("Region plan source or requested-use association changed")
        self.source_helper.check()
        with self.context, ir.raw_values():
            block = self.source_function.regions[0].blocks[0]
            if (block != self.root.source_block or tuple(block.arguments) != self.formals
                    or self.root.yield_values != (self.final_value,) or _check_block(self.root) != self.helpers):
                raise RuntimeError("Region plan control or final result changed")
            for helper in self.helpers:
                if helper.source_helper is not self.source_helper or helper.input_origin[:len(self.formals)] != self.formals:
                    raise RuntimeError("Region leaf has foreign source formals")
                helper.check()


def emit_region_helpers(source_helper: Any, symbol_prefix: str) -> RegionPlan:
    """Keep source SCF control and append pure scalar leaves with explicit merge inputs."""
    from cutlass._mlir import ir
    from cutlass._mlir.dialects import func

    if type(symbol_prefix) is not str or re.fullmatch(r"[A-Za-z_][A-Za-z_0-9.]*", symbol_prefix) is None:
        raise ValueError("Expected an ordinary region-helper symbol prefix")
    source_helper.check()
    module, context, source = source_helper.module, source_helper.context, source_helper.operation
    with context, ir.Location.unknown(), ir.raw_values():
        if len(source_helper.output_values) != 1 or not module.operation.verify():
            raise ValueError("Region plans require one verified owned source scalar helper")
        block = source.regions[0].blocks[0]
        formals = tuple(block.arguments)
        body = tuple(view.operation for view in block.operations)
        if (not body or body[-1].name != "func.return" or len(body[-1].operands) != 1
                or not isinstance(body[-1].operands[0].type, ir.IntegerType)
                or body[-1].attributes or body[-1].results or body[-1].regions or body[-1].successors):
            raise ValueError("Expected one pure source scalar return")
        kernels = {}
        for op in body[:-1]:
            _validate_tree(module, op, kernels)
        all_operations = set(_walk(source))
        merge_values = {value for op in all_operations if op.name == "scf.if" for value in op.results}
        original = tuple((view.operation, _snapshot(view.operation)) for view in module.body.operations)
        before = _snapshot(module.operation)
        names = {op.attributes["sym_name"].value for op, _ in original if "sym_name" in op.attributes}
        generated, helpers = [], []

        def leaf(output: Any, available: set[Any]) -> LeafHelper:
            if not isinstance(output.type, ir.IntegerType):
                raise ValueError("Only scalar integer source conditions and yields are supported")
            ordered, visited, visiting, lifted = [], set(), set(), []

            def require(value: Any) -> None:
                if value in formals:
                    return
                if value in merge_values:
                    if value not in available:
                        raise ValueError("Region leaf depends on an unavailable or inactive merge value")
                    if value not in lifted:
                        lifted.append(value)
                    return
                op = _op(value.owner)
                if op not in all_operations or op.regions or op.successors:
                    raise ValueError("Region leaf dependency escapes its pure source function")
                if op in visited:
                    return
                if op in visiting:
                    raise ValueError("Cyclic source scalar dependency")
                visiting.add(op)
                _validate_tree(module, op, kernels)
                for operand in op.operands:
                    require(operand)
                visiting.remove(op)
                visited.add(op)
                ordered.append(op)

            require(output)
            inputs = (*formals, *lifted)
            symbol = f"{symbol_prefix}_{len(helpers)}"
            if symbol in names:
                raise ValueError("Region leaf symbol already exists")
            names.add(symbol)
            with ir.InsertionPoint(module.body):
                function = func.FuncOp(symbol, ([value.type for value in inputs], [output.type]), visibility="public")
            generated.append(function.operation)
            function.operation.attributes["no_inline"] = ir.UnitAttr.get()
            function.arg_attrs = [ir.DictAttr.get({SOURCE_ARGUMENT: ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index)})
                                  for index in range(len(inputs))]
            target = function.add_entry_block()
            mapping = dict(zip(inputs, target.arguments))
            for op in ordered:
                cloned = op.clone(ip=ir.InsertionPoint(target))
                for index, operand in enumerate(op.operands):
                    cloned.operands[index] = mapping[operand]
                mapping.update(zip(op.results, cloned.results))
            with ir.InsertionPoint(target):
                func.ReturnOp([mapping[output]])
            result = LeafHelper(symbol, function.operation, source_helper, module, context, inputs, output,
                                tuple(str(value.type) for value in inputs), str(output.type), _snapshot(function.operation), ())
            result = replace(result, _seal=result._state())
            helpers.append(result)
            return result

        def region(current: Any, incoming: set[Any]) -> RegionBlock:
            available, steps = set(incoming), []
            ops = tuple(view.operation for view in current.operations)
            for op in ops[:-1]:
                if op.name != "scf.if":
                    continue
                condition_value = op.operands[0]
                condition = leaf(condition_value, available)
                true_block = region(op.regions[0].blocks[0], available)
                false_block = region(op.regions[1].blocks[0], available)
                results = tuple(op.results)
                branch = RegionIf(op, condition_value, condition, true_block, false_block, results,
                                  true_block.yield_values, false_block.yield_values, ())
                branch = replace(branch, _seal=branch._state())
                steps.append(branch)
                available.update(results)
            yields = tuple(ops[-1].operands)
            yield_helpers = tuple(leaf(value, available) for value in yields)
            result = RegionBlock(current, tuple(steps), yields, yield_helpers, ())
            return replace(result, _seal=result._state())

        try:
            root = region(block, set())
            if (tuple(view.operation for view in module.body.operations) != tuple(op for op, _ in original) + tuple(generated)
                    or any(_snapshot(op) != state for op, state in original) or not module.operation.verify()):
                raise RuntimeError("Region helper emission changed original IR or failed verification")
            result = RegionPlan(source_helper, source, module, context, formals, source_helper.source_ids,
                                source_helper.output_values[0], body[-1].operands[0], root, tuple(helpers), ())
            result = replace(result, _seal=result._state())
            result.check()
            return result
        except BaseException:
            for function in reversed(generated):
                function.erase()
            if _snapshot(module.operation) != before:
                raise RuntimeError("Failed region emission did not restore the original Module") from None
            raise
