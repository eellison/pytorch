from __future__ import annotations

import io
import inspect
import re
import threading
from dataclasses import dataclass, field
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from launch_events import CloneBundle


FRONTEND_VERSION = 1
COMPILER_VERSION = "4.6.2"
_TRACE_LOCK = threading.Lock()


def _snapshot(module: Any) -> tuple[str, bytes]:
    bytecode = io.BytesIO()
    module.operation.write_bytecode(bytecode)
    return str(module), bytecode.getvalue()


@dataclass(frozen=True)
class TensorSignature:
    index: int
    name: str
    dtype: str
    stride: tuple[int, ...]
    alignment: int
    static_extent: int | None
    extent_width: int | None
    extent_divisibility: int
    extent_symbol: str | None


@dataclass(frozen=True)
class SignatureGuard:
    tensors: tuple[TensorSignature, TensorSignature]
    shared_extent: bool
    stream_index: int
    stream_name: str
    stream_uses_environment: bool


def _signature_guard(bundle: CloneBundle, args: tuple[Any, ...], kwargs: dict[str, Any]) -> SignatureGuard:
    from cutlass import Float32, cute
    from cutlass.cute.typing import SymInt

    signature = inspect.signature(bundle.original_host.__wrapped__)
    bound = signature.bind(*args, **kwargs)
    bound.apply_defaults()
    parameters = tuple(bound.arguments.items())
    if len(parameters) != 3:
        raise ValueError("Expected two fake tensor parameters followed by one fake stream")
    tensors = []
    extents = []
    for index, (name, value) in enumerate(parameters[:2]):
        if (type(value) is not cute.runtime._FakeTensor or value.element_type is not Float32
                or value.memspace != cute.AddressSpace.gmem or value.stride != (1,)
                or type(value.shape) is not tuple or len(value.shape) != 1):
            raise ValueError("Expected rank-one global-memory fp32 fake tensors with unit stride")
        alignment = value._assumed_align
        if type(alignment) is not int or alignment < 1 or alignment & (alignment - 1):
            raise ValueError("Expected a positive power-of-two fake pointer alignment")
        extent = value.shape[0]
        extents.append(extent)
        if type(extent) is int and extent > 0:
            static_extent, width, divisibility, symbol = extent, None, 1, None
        elif type(extent) is SymInt:
            static_extent, width, divisibility, symbol = None, extent.width, extent.divisibility, extent.symbol
            if (type(width) is not int or width not in (32, 64)
                    or type(divisibility) is not int or divisibility < 1
                    or (symbol is not None and type(symbol) is not str)):
                raise ValueError("Unsupported symbolic extent metadata")
        else:
            raise ValueError("Expected a positive static extent or a CuTe SymInt")
        tensors.append(TensorSignature(index, name, "float32", (1,), alignment,
                                       static_extent, width, divisibility, symbol))
    stream_name, stream = parameters[2]
    if type(stream) is not cute.runtime._FakeStream or type(stream.use_tvm_ffi_env_stream) is not bool:
        raise ValueError("Expected an explicit CuTe fake stream")
    return SignatureGuard((tensors[0], tensors[1]),
                          type(extents[0]) is SymInt and extents[0] is extents[1],
                          2, stream_name, stream.use_tvm_ffi_env_stream)


@dataclass(frozen=True)
class HostIRTrace:
    module: Any = field(repr=False)
    context: Any = field(repr=False)
    dsl_owner: Any = field(repr=False)
    function_name: str
    bundle: CloneBundle = field(repr=False)
    artifact: Any = field(repr=False)
    metadata: tuple[Any, ...] = field(repr=False)
    signature_guard: SignatureGuard
    text: str = field(repr=False)
    bytecode: bytes = field(repr=False)
    sha256: str
    compiler_version: str
    compiler_options: str
    hook_calls: int

    def check(self) -> None:
        self.bundle.check_originals()
        if self.module.context != self.context:
            raise RuntimeError("The host IR module context changed")
        with self.context:
            if _snapshot(self.module) != (self.text, self.bytecode):
                raise RuntimeError("The captured host IR changed after frontend tracing")


class _Collector:
    def __init__(self, owner: Any) -> None:
        self.owner = owner
        self.module: Any = None
        self.context: Any = None
        self.function_name = ""
        self.text = ""
        self.bytecode = b""
        self.calls = 0

    def __call__(self, owner: Any, module: Any, function_name: str) -> None:
        from cutlass._mlir import ir

        self.calls += 1
        hooks = tuple(owner._trace_finalize_hooks) + tuple(owner._scoped_trace_finalize_hooks.get())
        if owner is not self.owner or self.calls != 1 or hooks != (self,):
            raise RuntimeError("Expected one isolated CuTe frontend hook")
        if not isinstance(module, ir.Module) or not isinstance(function_name, str) or not function_name:
            raise RuntimeError("Expected the live typed host module and its function name")
        hosts = [op for op in module.body.operations
                 if op.operation.name == "func.func" and op.attributes["sym_name"].value == function_name]
        if len(hosts) != 1:
            raise RuntimeError("The frontend hook does not identify one host definition")
        self.module = module
        self.context = module.context
        self.function_name = function_name
        self.text, self.bytecode = _snapshot(module)


def trace_host_ir(
    host: Any,
    kernel: Any,
    *signature_args: Any,
    options: str = "--gpu-arch sm_80",
    **signature_kwargs: Any,
) -> HostIRTrace:
    from cutlass import cute
    from cutlass._mlir import ir
    from cutlass._mlir._mlir_libs import _cutlass_ir
    from cutlass.cutlass_dsl.cutlass import CuTeDSL

    compiler_version = version("nvidia-cutlass-dsl")
    if compiler_version != COMPILER_VERSION:
        raise RuntimeError(f"This frontend adapter requires CuTe DSL {COMPILER_VERSION}")
    if ir.Context.current is not None:
        raise RuntimeError("Host frontend tracing requires no ambient MLIR context")
    if type(options) is not str or re.fullmatch(r"--gpu-arch sm_[0-9]+[af]?", options) is None:
        raise ValueError("Only an explicit CUDA architecture option is supported")
    if not callable(getattr(cute.compile, "to_precompiled_mlir", None)):
        raise RuntimeError("The precompiled-MLIR stage API is unavailable")
    controls = {
        "compile_only", "no_cache", "no_jit_engine", "compile_to_precompiled_mlir",
        "trace_finalize_hooks", "pipeline", "gpu_module_attrs", "export_name", "is_experimental",
    }
    if controls.intersection(signature_kwargs):
        raise ValueError("Signature arguments may not override frontend compilation controls")
    if not _TRACE_LOCK.acquire(blocking=False):
        raise RuntimeError("A host frontend trace is already active")
    try:
        bundle = CloneBundle.create(host, kernel)
        signature_guard = _signature_guard(bundle, signature_args, signature_kwargs)
        owner = CuTeDSL._get_dsl()
        if type(owner) is not CuTeDSL:
            raise RuntimeError("Expected the standard CuTe DSL frontend")
        if owner._trace_finalize_hooks or owner._scoped_trace_finalize_hooks.get():
            raise RuntimeError("Host frontend tracing requires an isolated trace-hook scope")
        if owner.envar.keep_ir_clean:
            raise RuntimeError("Clean-IR dumping would run compiler passes during frontend tracing")
        collector = _Collector(owner)
        try:
            artifact = cute.compile.to_precompiled_mlir(
                bundle.host, *signature_args, **signature_kwargs,
                options=options, no_jit_engine=True, trace_finalize_hooks=collector,
            )
        finally:
            bundle.check_originals()
            if owner._trace_finalize_hooks or owner._scoped_trace_finalize_hooks.get():
                raise RuntimeError("CuTe did not restore the frontend trace-hook scope")
        if collector.calls != 1 or collector.module is None:
            raise RuntimeError("CuTe did not return a live frontend module")
        if not isinstance(artifact, _cutlass_ir.PreCompiledMlirArtifact):
            raise RuntimeError("CuTe returned an artifact beyond the requested frontend stage")
        metadata = tuple(artifact.metadata)
        if len(metadata) != 1 or metadata[0].symbol_name != collector.function_name:
            raise RuntimeError("Precompiled input metadata does not identify the captured host")
        if _signature_guard(bundle, signature_args, signature_kwargs) != signature_guard:
            raise RuntimeError("Supplied signature metadata changed during frontend tracing")
        trace = HostIRTrace(
            collector.module, collector.context, owner, collector.function_name, bundle, artifact,
            metadata, signature_guard,
            collector.text, collector.bytecode, sha256(collector.bytecode).hexdigest(),
            compiler_version, options, collector.calls,
        )
        trace.check()
        return trace
    finally:
        _TRACE_LOCK.release()
