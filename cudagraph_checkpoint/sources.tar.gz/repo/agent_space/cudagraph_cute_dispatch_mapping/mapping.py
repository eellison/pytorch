from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from argument_flow import ArgumentFlow, LaunchFlow, ParameterFlow
from argument_flow_v2 import analyze_argument_flow
from lowering import FormalLowering, FormalLoweringSet


@dataclass(frozen=True)
class ParameterBinding:
    source_parameter_index: int
    device_parameter_index: int
    source_value: Any = field(repr=False, compare=False)
    formal: FormalLowering
    parameter: ParameterFlow


@dataclass(frozen=True)
class SiteMapping:
    source_launch: Any = field(repr=False, compare=False)
    source_path: tuple[tuple[int, int, int], ...]
    callee: tuple[str, str]
    source_arguments: tuple[Any, ...] = field(repr=False, compare=False)
    argument_types: tuple[str, ...]
    kernel: Any = field(repr=False, compare=False)
    launch: LaunchFlow
    parameters: tuple[ParameterBinding, ...]


def _sites(program: Any, formals: FormalLoweringSet, flow: ArgumentFlow) -> tuple[SiteMapping, ...]:
    from cutlass._mlir import ir

    program.check()
    formals.check()
    flow.check()
    if (formals.program is not program or flow.module is not program.module
            or flow.context is not program.context or flow.function_name != program.function_name):
        raise ValueError("Dispatch mapping requires one original compiler and formal owner")
    by_llvm = {item.llvm_arg_index: item for item in formals.formals}
    if (set(by_llvm) != set(range(len(flow.host_types)))
            or any(by_llvm[index].llvm_type != typ for index, typ in enumerate(flow.host_types))):
        raise ValueError("Tagged formals do not cover the actual LLVM entry arguments")
    with program.source_context, ir.raw_values():
        hosts = [view.operation for view in program.source_module.body.operations
                 if view.operation.name == "func.func"
                 and view.operation.attributes["sym_name"].value == program.function_name]
        if len(hosts) != 1 or len(hosts[0].regions[0].blocks) != 1:
            raise ValueError("Expected one original structured host definition")
        host = hosts[0]
        arguments = tuple(host.regions[0].blocks[0].arguments)
        source_sites = []

        def visit(operation: Any, path: tuple[tuple[int, int, int], ...]) -> None:
            for region_index, region in enumerate(operation.regions):
                for block_index, block in enumerate(region.blocks):
                    for operation_index, view in enumerate(block.operations):
                        child = view.operation
                        location = (*path, (region_index, block_index, operation_index))
                        if child.name == "cuda.launch_ex":
                            source_sites.append((child, location))
                        visit(child, location)

        visit(host, ())
        if not source_sites or len(source_sites) != len(flow.launches):
            raise ValueError("Source and compiled launch sets differ")
        result, seen_symbols, used_launches = [], set(), set()
        for source, path in source_sites:
            callee = tuple(source.attributes["callee"].value)
            if len(callee) != 2 or callee[1] in seen_symbols:
                raise ValueError("Each source site needs a distinct unambiguous kernel symbol")
            seen_symbols.add(callee[1])
            gpu = [view.operation for view in program.source_module.body.operations
                   if view.operation.name == "gpu.module"
                   and view.operation.attributes["sym_name"].value == callee[0]]
            kernels = [] if len(gpu) != 1 else [view.operation for view in gpu[0].regions[0].blocks[0].operations
                if view.operation.name == "cuda.kernel" and view.operation.attributes["sym_name"].value == callee[1]]
            source_arguments = tuple(source.operands)[1:]
            if (len(kernels) != 1 or tuple(kernels[0].attributes["function_type"].value.inputs)
                    != tuple(value.type for value in source_arguments)):
                raise ValueError("Original callee does not own the source operand signature")
            matches = [launch for launch in flow.launches if launch.registration.kernel_symbol == callee[1]]
            if len(matches) != 1:
                raise ValueError("Source callee lacks one exact compiled registration and launch")
            launch = matches[0]
            if launch.index in used_launches:
                raise ValueError("A compiled launch cannot identify two source sites")
            used_launches.add(launch.index)
            images = [image for image in flow.binaries if image.library_slot == launch.registration.library_slot]
            if (len(images) != 1 or launch.registration not in flow.registrations
                    or images[0].global_name != launch.registration.binary_global
                    or images[0].sha256 != launch.registration.binary_sha256):
                raise ValueError("Selected registration lost its actual embedded library")
            bindings, used_operands = [], set()
            for parameter in launch.parameters:
                value = parameter.source
                if (value.kind != "argument" or value.path or value.operands or value.attributes
                        or value.value is not None or value.argument not in by_llvm):
                    raise ValueError("This correspondence proof admits only unchanged whole-formal operands")
                formal = by_llvm[value.argument]
                source_value = arguments[formal.ir_arg_index]
                indices = [index for index, operand in enumerate(source_arguments) if operand == source_value]
                if (len(indices) != 1 or indices[0] in used_operands
                        or str(source_value.type) != formal.source_type
                        or parameter.llvm_type != formal.llvm_type or value.llvm_type != formal.llvm_type):
                    raise ValueError("Compiled parameter lacks one exact original formal use")
                source_index = indices[0]
                used_operands.add(source_index)
                bindings.append(ParameterBinding(source_index, parameter.index, source_value, formal, parameter))
            if used_operands != set(range(len(source_arguments))):
                raise ValueError("Original launch operands are not covered exactly")
            result.append(SiteMapping(source, path, callee, source_arguments,
                                      tuple(str(value.type) for value in source_arguments), kernels[0],
                                      launch, tuple(bindings)))
        if used_launches != {launch.index for launch in flow.launches}:
            raise ValueError("Compiled launch coverage is incomplete")
        return tuple(result)


def _site_state(site: SiteMapping) -> tuple[Any, ...]:
    return (id(site), id(site.source_launch), site.source_path, site.callee,
            tuple(id(value) for value in site.source_arguments), site.argument_types, id(site.kernel),
            id(site.launch), tuple((id(item), item.source_parameter_index, item.device_parameter_index,
                                  id(item.source_value), item.formal, item.parameter) for item in site.parameters))


@dataclass(frozen=True)
class DispatchMapping:
    program: Any = field(repr=False)
    formals: FormalLoweringSet
    flow: ArgumentFlow
    sites: tuple[SiteMapping, ...]
    _owners: tuple[Any, ...] = field(repr=False)
    _site_seals: tuple[Any, ...] = field(repr=False)

    def check(self) -> None:
        owned = self.program, self.formals, self.flow, self.sites
        if (len(owned) != len(self._owners) or any(value is not owner for value, owner in zip(owned, self._owners))
                or tuple(_site_state(site) for site in self.sites) != self._site_seals):
            raise RuntimeError("Dispatch site or compiler ownership changed")
        actual = _sites(self.program, self.formals, self.flow)
        for expected, found in zip(self.sites, actual):
            if (expected != found or expected.source_launch != found.source_launch
                    or expected.source_arguments != found.source_arguments or expected.kernel != found.kernel
                    or tuple(item.source_value for item in expected.parameters)
                    != tuple(item.source_value for item in found.parameters)):
                raise RuntimeError("Dispatch site lost its exact source/compiled correspondence")
        if len(actual) != len(self.sites):
            raise RuntimeError("Dispatch site coverage changed")


def bind_dispatch_sites(program: Any, formals: FormalLoweringSet, flow: ArgumentFlow | None = None) -> DispatchMapping:
    """Bind source uses to real compiled packs; this does not admit source control/effects."""
    if type(formals) is not FormalLoweringSet:
        raise TypeError("Expected the compiler-owned tagged formal correspondence")
    if flow is None:
        flow = analyze_argument_flow(program.module, program.function_name)
    if type(flow) is not ArgumentFlow:
        raise TypeError("Expected the unchanged generic argument-flow reader result")
    sites = _sites(program, formals, flow)
    return DispatchMapping(program, formals, flow, sites, (program, formals, flow, sites),
                           tuple(_site_state(site) for site in sites))
