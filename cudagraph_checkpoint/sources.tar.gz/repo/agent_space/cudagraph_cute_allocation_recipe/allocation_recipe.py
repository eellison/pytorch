from __future__ import annotations

import math
import operator
from dataclasses import dataclass, field, replace
from types import MappingProxyType
from typing import Any

import torch
from python_entry import EntryCall, Operand, opaque_entry
from python_entry_v2 import PythonHostTrace
from torch._utils import _element_size
from torch.fx import Node


_MAX = 2**63 - 1
_INTEGERS = frozenset((operator.add, operator.sub, operator.mul, operator.floordiv, operator.mod, operator.neg))
_ALLOCATIONS = frozenset((torch.ops.aten.empty.memory_format, torch.ops.aten.empty_strided.default,
                          torch.ops.aten.empty_like.default))
_METADATA = frozenset((torch.ops.aten.sym_size.int, torch.ops.aten.sym_stride.int,
                      torch.ops.aten.sym_numel.default, torch.ops.aten.sym_storage_offset.default))
_VIEWS = frozenset((torch.ops.aten.slice.Tensor, torch.ops.aten.alias.default, torch.ops.aten.detach.default))
_DTYPES = frozenset((torch.bool, torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64,
                    torch.float16, torch.bfloat16, torch.float32, torch.float64))


class RecipeUnsupported(ValueError):
    pass


class RecipeGuardMismatch(ValueError):
    pass


def _integer(value: Any, *, minimum: int = -(2**63)) -> int:
    if type(value) is not int or not minimum <= value <= _MAX:
        raise RecipeUnsupported("Metadata integer is negative, unsupported, or exceeds signed-i64 range")
    return value


def _span_bytes(shape: tuple[int, ...], strides: tuple[int, ...], offset: int, element_size: int) -> int:
    if len(shape) != len(strides):
        raise RecipeUnsupported("Shape and stride ranks differ")
    last = _integer(offset, minimum=0)
    for size, stride in zip(shape, strides):
        _integer(size, minimum=1)
        _integer(stride, minimum=0)
        last = _integer(last + _integer((size - 1) * stride, minimum=0), minimum=0)
    return _integer(_integer(last + 1, minimum=1) * element_size, minimum=1)


def _contiguous(shape: tuple[int, ...]) -> tuple[int, ...]:
    strides, running = [], 1
    for size in reversed(shape):
        _integer(size, minimum=1)
        strides.append(running)
        running = _integer(running * size, minimum=1)
    return tuple(reversed(strides))


def _dense(shape: tuple[int, ...], strides: tuple[int, ...]) -> bool:
    running = 1
    for axis in sorted(range(len(shape)), key=lambda index: strides[index]):
        if shape[axis] == 1:
            continue
        if strides[axis] != running:
            return False
        running = _integer(running * shape[axis], minimum=1)
    return True


@dataclass(frozen=True, eq=False)
class TensorMetadata:
    node: Node
    storage_node: Node
    input_index: int | None
    shape: tuple[int, ...]
    stride: tuple[int, ...]
    storage_offset: int
    dtype: torch.dtype
    device: torch.device
    storage_bytes: int


@dataclass(frozen=True, eq=False)
class PendingAllocation:
    node: Node
    tensor: TensorMetadata
    storage_bytes: int


@dataclass(frozen=True, eq=False)
class EvaluatedOperand:
    source: Operand
    value: Any


@dataclass(frozen=True, eq=False)
class MetadataCall:
    source: EntryCall
    arguments: tuple[Any, ...]
    keyword_arguments: tuple[tuple[str, Any], ...]
    operands: tuple[EvaluatedOperand, ...]


@dataclass(frozen=True, eq=False)
class RecipeStep:
    node: Node
    kind: str


def _input_state(tensor: torch.Tensor) -> tuple[Any, ...]:
    if (type(tensor) is not torch.Tensor or tensor.layout != torch.strided or tensor.dtype not in _DTYPES
            or tensor.device.type not in ("cpu", "cuda") or tensor.requires_grad or tensor.is_conj() or tensor.is_neg()):
        raise RecipeUnsupported("Expected an ordinary strided CPU/CUDA Tensor without autograd or view flags")
    storage = tensor.untyped_storage()
    return (id(tensor), tensor.dtype, tensor.device, tuple(tensor.shape), tuple(tensor.stride()),
            tensor.storage_offset(), storage._cdata, storage.nbytes())


def _state(value: Any) -> Any:
    if isinstance(value, Node):
        return "node", id(value)
    if type(value) is TensorMetadata:
        return (id(value), id(value.node), id(value.storage_node), value.input_index, value.shape, value.stride,
                value.storage_offset, value.dtype, value.device, value.storage_bytes)
    if type(value) is PendingAllocation:
        return id(value), id(value.node), _state(value.tensor), value.storage_bytes
    if type(value) is EvaluatedOperand:
        return id(value), id(value.source), _state(value.value)
    if type(value) is MetadataCall:
        return id(value), id(value.source), _state(value.arguments), _state(value.keyword_arguments), _state(value.operands)
    if isinstance(value, (tuple, list)):
        return tuple(_state(item) for item in value)
    if isinstance(value, (dict, MappingProxyType)):
        return tuple((key, _state(item)) for key, item in value.items())
    if value is None or type(value) in (int, bool, str):
        return type(value), value
    if type(value) is float and math.isfinite(value):
        return float, value.hex()
    raise RecipeUnsupported("Unsupported metadata packet value")


@dataclass(frozen=True, eq=False)
class MetadataPacket:
    recipe: AllocationRecipe
    inputs: tuple[torch.Tensor, ...] = field(repr=False)
    values: tuple[tuple[Node, Any], ...]
    call: MetadataCall
    allocations: tuple[PendingAllocation, ...]
    output: Any
    _input_states: tuple[Any, ...] = field(repr=False)
    _owners: tuple[Any, ...] = field(repr=False)
    _snapshot: Any = field(repr=False)

    def check(self) -> None:
        owned = self.recipe, self.inputs, self.values, self.call, self.allocations, self.output
        if len(owned) != len(self._owners) or any(value is not owner for value, owner in zip(owned, self._owners)):
            raise RuntimeError("Allocation metadata packet ownership changed")
        self.recipe.check()
        if tuple(_input_state(tensor) for tensor in self.inputs) != self._input_states:
            raise RuntimeError("Allocation metadata input ownership or layout changed")
        if _state((self.values, self.call, self.allocations, self.output)) != self._snapshot:
            raise RuntimeError("Allocation metadata source or values changed")


def _resolve(value: Any, environment: dict[Node, Any]) -> Any:
    if isinstance(value, Node):
        return environment[value]
    if isinstance(value, (tuple, list)):
        return tuple(_resolve(item, environment) for item in value)
    if isinstance(value, dict):
        return MappingProxyType({key: _resolve(item, environment) for key, item in value.items()})
    return value


def _arguments(node: Node, environment: dict[Node, Any]) -> dict[str, Any]:
    args, kwargs = _resolve(node.args, environment), dict(_resolve(node.kwargs, environment))
    schema = node.target._schema.arguments
    if len(args) > len(schema) or any(key not in {arg.name for arg in schema} for key in kwargs):
        raise RecipeUnsupported("FX arguments do not match the actual operator schema")
    values = {}
    for index, arg in enumerate(schema):
        if index < len(args):
            if arg.kwarg_only or arg.name in kwargs:
                raise RecipeUnsupported("Invalid positional or duplicate operator argument")
            values[arg.name] = args[index]
        elif arg.name in kwargs:
            values[arg.name] = kwargs[arg.name]
        elif arg.has_default_value():
            values[arg.name] = arg.default_value
        else:
            raise RecipeUnsupported("Missing required FX operator argument")
    return values


def _tensor(value: Any) -> TensorMetadata:
    if type(value) is not TensorMetadata:
        raise RecipeUnsupported("Expected a tensor-metadata FX operand")
    return value


def _evaluate_node(node: Node, environment: dict[Node, Any]) -> Any:
    target = node.target
    if target in _INTEGERS:
        args = _resolve(node.args, environment)
        if node.kwargs or len(args) != (1 if target is operator.neg else 2):
            raise RecipeUnsupported("Unsupported integer operation arguments")
        for value in args:
            _integer(value)
        if target in (operator.floordiv, operator.mod) and args[1] == 0:
            raise RecipeUnsupported("Metadata integer division by zero")
        return _integer(target(*args))
    args = _arguments(node, environment)
    if target in _METADATA:
        source = _tensor(args["self"])
        if target is torch.ops.aten.sym_numel.default:
            result = 1
            for size in source.shape:
                result = _integer(result * size, minimum=1)
            return result
        if target is torch.ops.aten.sym_storage_offset.default:
            return source.storage_offset
        dim = _integer(args["dim"])
        if not -len(source.shape) <= dim < len(source.shape):
            raise RecipeUnsupported("Metadata dimension is out of range")
        return (source.shape if target is torch.ops.aten.sym_size.int else source.stride)[dim]
    if target in _VIEWS:
        source = _tensor(args["self"])
        if target is not torch.ops.aten.slice.Tensor:
            return replace(source, node=node)
        dim, step = _integer(args["dim"]), _integer(args["step"], minimum=1)
        if not -len(source.shape) <= dim < len(source.shape):
            raise RecipeUnsupported("Slice dimension is out of range")
        dim %= len(source.shape)
        size = source.shape[dim]
        start = 0 if args["start"] is None else _integer(args["start"])
        end = _MAX if args["end"] is None else _integer(args["end"])
        start = min(max(start + size if start < 0 else start, 0), size)
        end = min(max(end + size if end < 0 else end, start), size)
        shape, strides = list(source.shape), list(source.stride)
        length = _integer(end - start + step - 1, minimum=0)
        shape[dim] = _integer(length // step, minimum=1)
        strides[dim] = _integer(strides[dim] * step, minimum=0)
        offset = _integer(source.storage_offset + _integer(start * source.stride[dim], minimum=0), minimum=0)
        result = replace(source, node=node, shape=tuple(shape), stride=tuple(strides), storage_offset=offset)
        if _span_bytes(result.shape, result.stride, offset, _element_size(result.dtype)) > result.storage_bytes:
            raise RecipeUnsupported("View layout exceeds its owned input/allocation storage")
        return result
    if target in _ALLOCATIONS:
        source = _tensor(args["self"]) if target is torch.ops.aten.empty_like.default else None
        dtype = args["dtype"] or (source.dtype if source is not None else torch.get_default_dtype())
        device = args["device"] or (source.device if source is not None else torch.device("cpu"))
        device = torch.device(device)
        if (dtype not in _DTYPES or device.type not in ("cpu", "cuda") or args["layout"] not in (None, torch.strided)
                or args["pin_memory"] not in (None, False)):
            raise RecipeUnsupported("Unsupported pending allocation dtype, layout, device, or pinned-memory option")
        if device.type == "cuda" and device.index is None:
            raise RecipeUnsupported("Pending CUDA allocation requires an explicit original device index")
        if source is not None:
            shape = source.shape
            memory_format = args["memory_format"]
            if memory_format in (None, torch.preserve_format):
                if not _dense(source.shape, source.stride):
                    raise RecipeUnsupported("empty_like preserve_format requires a checked non-overlapping dense layout")
                strides = source.stride
            elif memory_format is torch.contiguous_format:
                strides = _contiguous(shape)
            else:
                raise RecipeUnsupported("Unsupported empty_like memory format")
        else:
            shape = tuple(args["size"])
            if target is torch.ops.aten.empty_strided.default:
                strides = tuple(args["stride"])
            elif args["memory_format"] in (None, torch.contiguous_format):
                strides = _contiguous(shape)
            else:
                raise RecipeUnsupported("Unsupported empty memory format")
        size = _span_bytes(shape, strides, 0, _element_size(dtype))
        return TensorMetadata(node, node, None, shape, strides, 0, dtype, device, size)
    raise RecipeUnsupported(f"Unsupported FX allocation recipe operation: {target}")


class AllocationRecipe:
    def __init__(self, trace: PythonHostTrace) -> None:
        if type(trace) is not PythonHostTrace:
            raise TypeError("Expected the guarded original PythonHostTrace")
        trace.check()
        if len(trace.calls) != 1:
            raise RecipeUnsupported("An allocation recipe currently requires one exact opaque entry")
        self.trace = trace
        self.call = trace.calls[0]
        steps = []
        for node in trace.graph_module.graph.nodes:
            if node.op in ("placeholder", "output"):
                kind = node.op
            elif node.op != "call_function":
                raise RecipeUnsupported(f"Unsupported FX node: {node.op}")
            elif node is self.call.node and node.target is opaque_entry and not node.users:
                kind = "entry"
            elif node.target in _ALLOCATIONS:
                kind = "allocation"
            elif node.target in _VIEWS:
                kind = "view"
            elif node.target in _METADATA or node.target in _INTEGERS:
                kind = "integer"
            else:
                raise RecipeUnsupported(f"Unsupported FX allocation recipe operation: {node.target}")
            steps.append(RecipeStep(node, kind))
        if (not steps or steps[-1].kind != "output" or sum(step.kind == "output" for step in steps) != 1
                or sum(step.kind == "entry" for step in steps) != 1):
            raise RecipeUnsupported("Expected one terminal output and the exact entry node")
        self.steps = tuple(steps)
        self.input_nodes = tuple(step.node for step in steps if step.kind == "placeholder")
        self._owners = trace, self.call, self.steps, self.input_nodes

    def check(self) -> None:
        owned = self.trace, self.call, self.steps, self.input_nodes
        if len(owned) != len(self._owners) or any(value is not owner for value, owner in zip(owned, self._owners)):
            raise RuntimeError("Allocation recipe lost its original trace/call ownership")
        self.trace.check()

    def evaluate(self, inputs: tuple[torch.Tensor, ...] | list[torch.Tensor]) -> MetadataPacket:
        self.check()
        if not self.trace.accepts(inputs):
            raise RecipeGuardMismatch("Original Python host guards rejected the metadata invocation")
        inputs = tuple(inputs)
        states = tuple(_input_state(value) for value in inputs)
        values, call, allocations, output = self._evaluate(inputs)
        owned = self, inputs, values, call, allocations, output
        result = MetadataPacket(*owned, states, owned, _state((values, call, allocations, output)))
        result.check()
        return result

    def _evaluate(self, inputs: tuple[torch.Tensor, ...]) -> tuple[Any, ...]:
        if len(inputs) != len(self.input_nodes):
            raise RecipeUnsupported("Wrong number of original Tensor inputs")
        environment, allocations = {}, []
        for index, (node, tensor) in enumerate(zip(self.input_nodes, inputs)):
            state = _input_state(tensor)
            _, dtype, device, shape, strides, offset, _, storage_bytes = state
            _integer(storage_bytes, minimum=1)
            if _span_bytes(shape, strides, offset, _element_size(dtype)) > storage_bytes:
                raise RecipeUnsupported("Input metadata exceeds its actual owned storage")
            environment[node] = TensorMetadata(node, node, index, shape, strides, offset, dtype, device, storage_bytes)
        call, output = None, None
        for step in self.steps:
            node = step.node
            if step.kind == "placeholder":
                continue
            if step.kind == "output":
                output = _resolve(node.args[0], environment)
                environment[node] = output
            elif step.kind == "entry":
                args = _resolve(node.args, environment)
                if args[0] != self.call.entry_index:
                    raise RuntimeError("Opaque entry index changed")
                operands = tuple(EvaluatedOperand(source, _resolve(source.fx_argument, environment))
                                 for source in self.call.operands)
                call = MetadataCall(self.call, args[1:], tuple(_resolve(node.kwargs, environment).items()), operands)
                environment[node] = None
            else:
                value = _evaluate_node(node, environment)
                environment[node] = value
                if step.kind == "allocation":
                    allocations.append(PendingAllocation(node, value, value.storage_bytes))
        if call is None:
            raise RuntimeError("Allocation recipe did not reach its owned entry")
        return tuple((step.node, environment[step.node]) for step in self.steps), call, tuple(allocations), output
