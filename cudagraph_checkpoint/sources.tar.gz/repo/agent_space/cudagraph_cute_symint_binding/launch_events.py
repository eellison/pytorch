from __future__ import annotations

import dis
import inspect
import sys
import types
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class CallSite:
    filename: str
    lineno: int
    end_lineno: int
    col_offset: int
    end_col_offset: int


def callsite(code: types.CodeType, lasti: int) -> CallSite:
    if type(code) is not types.CodeType or type(lasti) is not int:
        raise TypeError("Expected an actual code object and instruction offset")
    instructions = list(dis.get_instructions(code, show_caches=True))
    indices = [i for i, instruction in enumerate(instructions) if instruction.offset == lasti]
    if len(indices) != 1:
        raise ValueError("The caller instruction is absent from its code object")
    index = indices[0]
    while index and instructions[index].opname == "CACHE":
        index -= 1
    instruction = instructions[index]
    if instruction.opname not in ("CALL", "CALL_FUNCTION_EX"):
        raise ValueError("Expected the currently executing Python call")
    position = instruction.positions
    values = (position.lineno, position.end_lineno, position.col_offset, position.end_col_offset)
    if any(type(value) is not int for value in values) or values[0] < 1 or values[1] < values[0]:
        raise ValueError("The call has no complete original source position")
    if values[2] < 0 or values[3] < 0:
        raise ValueError("The call has invalid source columns")
    if values[0] == values[1] and values[3] < values[2]:
        raise ValueError("The call has reversed source columns")
    return CallSite(code.co_filename, *values)


def original_callsites(code: types.CodeType) -> frozenset[CallSite]:
    sites = [callsite(code, instruction.offset) for instruction in dis.get_instructions(code)
             if instruction.opname in ("CALL", "CALL_FUNCTION_EX")]
    if not sites or len(set(sites)) != len(sites):
        raise ValueError("Original calls must have distinct complete source positions")
    return frozenset(sites)


@dataclass(frozen=True)
class _FunctionState:
    function: types.FunctionType
    code: types.CodeType
    wrapped: Any
    annotations: tuple[tuple[str, Any], ...]
    closure: tuple[Any, ...]

    def check(self) -> None:
        fn = self.function
        current = tuple(fn.__annotations__.items())
        if (fn.__code__ is not self.code or getattr(fn, "__wrapped__", None) is not self.wrapped
                or fn.__defaults__ or fn.__kwdefaults__
                or len(current) != len(self.annotations)
                or any(name != old_name or value is not old_value
                       for (name, value), (old_name, old_value) in zip(current, self.annotations))
                or len(fn.__closure__ or ()) != len(self.closure)
                or any(cell.cell_contents is not value for cell, value in zip(fn.__closure__ or (), self.closure))):
            raise RuntimeError("Original host or kernel code, annotations, or decorator association changed")


@dataclass
class CloneBundle:
    original_host: types.FunctionType
    original_kernel: types.FunctionType
    host_body: types.FunctionType
    kernel_body: types.FunctionType
    host: types.FunctionType
    kernel: types.FunctionType
    host_code: types.CodeType
    kernel_code: types.CodeType
    sites: frozenset[CallSite]
    _functions: tuple[_FunctionState, ...] = field(repr=False)
    _globals: tuple[tuple[dict[str, Any], dict[str, Any]], ...] = field(repr=False)

    @classmethod
    def create(cls, host: Any, kernel: Any) -> CloneBundle:
        import cutlass.cute as cute

        original_host = getattr(host, "__wrapped__", None)
        original_kernel = getattr(kernel, "__wrapped__", None)
        if any(type(fn) is not types.FunctionType for fn in (host, kernel, original_host, original_kernel)):
            raise TypeError("Expected the original decorated CuTe host and kernel")
        for fn in (original_host, original_kernel):
            if fn.__closure__ or fn.__defaults__ or fn.__kwdefaults__ or getattr(fn, "_preprocessed", False):
                raise ValueError("Only cold functions without closures or defaults can be cloned")
        host_globals = dict(original_host.__globals__)
        kernel_globals = dict(original_kernel.__globals__)
        kernel_body = types.FunctionType(original_kernel.__code__, kernel_globals, original_kernel.__name__)
        host_body = types.FunctionType(original_host.__code__, host_globals, original_host.__name__)
        for clone, original in ((host_body, original_host), (kernel_body, original_kernel)):
            clone.__annotations__ = dict(original.__annotations__)
            clone.__qualname__ = original.__qualname__
            clone.__module__ = original.__module__
            clone.__doc__ = original.__doc__
        cloned_kernel = cute.kernel(kernel_body)
        for namespace in (host_globals, kernel_globals):
            for name, value in tuple(namespace.items()):
                if value is kernel:
                    namespace[name] = cloned_kernel
        cloned_host = cute.jit(host_body)
        for clone, original in ((host_body, original_host), (kernel_body, original_kernel)):
            clone._decorator_location = original._decorator_location
        states = tuple(_FunctionState(
            fn, fn.__code__, getattr(fn, "__wrapped__", None), tuple(fn.__annotations__.items()),
            tuple(cell.cell_contents for cell in fn.__closure__ or ()),
        ) for fn in (host, original_host, kernel, original_kernel))
        globals_state = tuple((fn.__globals__, dict(fn.__globals__)) for fn in (original_host, original_kernel))
        result = cls(host, kernel, host_body, kernel_body, cloned_host, cloned_kernel,
                     original_host.__code__, original_kernel.__code__, original_callsites(original_host.__code__),
                     states, globals_state)
        result.check_originals()
        return result

    def check_originals(self) -> None:
        for state in self._functions:
            state.check()
        for namespace, expected in self._globals:
            if namespace.keys() != expected.keys() or any(namespace[name] is not value for name, value in expected.items()):
                raise RuntimeError("Original host/kernel globals changed after cloning")
        if any(getattr(fn, "_preprocessed", False)
               for fn in (self.original_host.__wrapped__, self.original_kernel.__wrapped__)):
            raise RuntimeError("The original functions were preprocessed instead of their clones")


@dataclass(frozen=True)
class LaunchRecord:
    site: CallSite
    symbol: str
    parameter_sources: tuple[int, ...]
    parameter_types: tuple[str, ...]
    host_parameter_types: tuple[str, ...]


@dataclass
class _PendingLaunch:
    site: CallSite
    launcher: Any
    token: object = field(default_factory=object)
    symbol: str | None = None
    arguments: tuple[Any, ...] = ()
    operands: tuple[Any, ...] = ()
    types: tuple[Any, ...] = ()
    attributes: tuple[Any, ...] = ()


_ACTIVE: ContextVar[LaunchObserver | None] = ContextVar("cute_launch_observer", default=None)


class LaunchObserver:
    def __init__(self, bundle: CloneBundle) -> None:
        self.bundle = bundle
        self.records: tuple[LaunchRecord, ...] = ()
        self._pending: list[_PendingLaunch] = []
        self._current: _PendingLaunch | None = None
        self._active = False
        self._frozen = False
        self._context_token: Any = None
        self._original_launch: Any = None
        self._original_operands: Any = None
        self._launch_wrapper: Any = None
        self._operand_wrapper: Any = None

    def __enter__(self) -> LaunchObserver:
        from cutlass.base_dsl.dsl import BaseDSL
        from cutlass.cutlass_dsl.cutlass import KernelLauncher

        if self._active or self._frozen or _ACTIVE.get() is not None:
            raise RuntimeError("Launch observation must be a single nonnested compilation scope")
        self.bundle.check_originals()
        bundle = self.bundle
        if (bundle.host_body.__code__ is not bundle.host_code or bundle.kernel_body.__code__ is not bundle.kernel_code
                or bundle.host.__code__ is not bundle.original_host.__code__
                or bundle.kernel.__code__ is not bundle.original_kernel.__code__
                or bundle.host.__wrapped__ is not bundle.host_body or bundle.kernel.__wrapped__ is not bundle.kernel_body):
            raise RuntimeError("Compilation clones changed before their cold observation scope")
        for clone, original in ((bundle.host_body, bundle.original_host.__wrapped__),
                                (bundle.kernel_body, bundle.original_kernel.__wrapped__)):
            if (clone.__annotations__.keys() != original.__annotations__.keys()
                    or any(clone.__annotations__[name] is not value for name, value in original.__annotations__.items())
                    or clone.__defaults__ or clone.__kwdefaults__ or getattr(clone, "_preprocessed", False)):
                raise RuntimeError("Compilation clone signature or cold state changed")
        for clone, (_, original_globals) in zip((bundle.host_body, bundle.kernel_body), bundle._globals):
            expected = {name: bundle.kernel if value is bundle.original_kernel else value
                        for name, value in original_globals.items()}
            if (clone.__globals__.keys() != expected.keys()
                    or any(clone.__globals__[name] is not value for name, value in expected.items())):
                raise RuntimeError("Compilation clone globals exceed the explicit kernel substitution")
        original_launch = KernelLauncher.launch
        original_operands = BaseDSL.generate_kernel_operands_and_types
        if (original_launch.__module__ != "cutlass.cutlass_dsl.cutlass"
                or original_operands.__module__ != "cutlass.base_dsl.dsl"):
            raise RuntimeError("Refusing to replace an existing compiler observer")

        def launch(launcher, *args, **kwargs):
            if _ACTIVE.get() is not self:
                return original_launch(launcher, *args, **kwargs)
            frame = sys._getframe(1)
            try:
                return self._observe_launch(launcher, args, kwargs, frame.f_code, frame.f_lasti)
            finally:
                del frame

        def operands(dsl, kernel_func, kernel_name, signature, args, kwargs):
            if _ACTIVE.get() is not self:
                return original_operands(dsl, kernel_func, kernel_name, signature, args, kwargs)
            pending = self._current
            if (pending is None or pending.symbol is not None or dsl is not pending.launcher.dsl
                    or kernel_func is not self.bundle.kernel_body):
                raise ValueError("Canonical operands escaped the exact observed kernel launch")
            bound = signature.bind(*pending.launcher.func_args, **pending.launcher.func_kwargs)
            bound.apply_defaults()
            if (kwargs or len(args) != 2 or len(bound.args) != 2
                    or any(value is not expected for value, expected in zip(args, bound.args))
                    or signature != inspect.signature(self.bundle.kernel_body, eval_str=True)):
                raise ValueError("Canonical arguments differ from the original complete kernel arguments")
            result = original_operands(dsl, kernel_func, kernel_name, signature, args, kwargs)
            if (type(kernel_name) is not str or not kernel_name
                    or len(result) != 3 or any(len(items) != 2 for items in result)):
                raise ValueError("Expected two original kernel operands, types, and attribute dictionaries")
            pending.symbol = kernel_name
            pending.arguments = tuple(args)
            pending.operands, pending.types, pending.attributes = map(tuple, result)
            return result

        self._original_launch = original_launch
        self._original_operands = original_operands
        self._launch_wrapper = launch
        self._operand_wrapper = operands
        self._context_token = _ACTIVE.set(self)
        self._active = True
        KernelLauncher.launch = launch
        BaseDSL.generate_kernel_operands_and_types = operands
        return self

    def _observe_launch(self, launcher, args, kwargs, caller_code, lasti):
        from cutlass.cutlass_dsl.cutlass import KernelLauncher

        self.bundle.check_originals()
        lineage = set()
        pending_codes = [self.bundle.host_body.__code__]
        while pending_codes:
            code = pending_codes.pop()
            lineage.add(id(code))
            pending_codes.extend(value for value in code.co_consts if type(value) is types.CodeType)
        if (self._frozen or id(caller_code) not in lineage or type(launcher) is not KernelLauncher
                or launcher.funcBody is not self.bundle.kernel_body or self._current is not None):
            raise ValueError("Kernel launch lacks the explicit compilation-clone code lineage")
        site = callsite(caller_code, lasti)
        if site not in self.bundle.sites or any(event.site == site for event in self._pending):
            raise ValueError("Kernel launch has an absent, ambiguous, or repeated original call site")
        event = _PendingLaunch(site, launcher)
        self._current = event
        try:
            result = self._original_launch(launcher, *args, **kwargs)
            if event.symbol is None or launcher._launch_name != event.symbol:
                raise ValueError("Returned compiler symbol differs from its canonical-operand event")
            self._pending.append(event)
            return result
        finally:
            self._current = None

    def freeze(self, module: Any, function_name: str) -> tuple[LaunchRecord, ...]:
        from cutlass._mlir import ir
        from cutlass.cute.tensor import _Tensor

        if not self._active or _ACTIVE.get() is not self or self._current is not None or self._frozen:
            raise RuntimeError("Freeze requires the original compilation's completed launch scope")
        if not self._pending or not callable(getattr(ir, "raw_values", None)):
            raise ValueError("Expected observed launches and the scoped raw-value compiler API")
        self.bundle.check_originals()
        try:
            with module.context, ir.raw_values():
                top = [view.operation for view in module.body.operations]
                hosts = [op for op in top if op.name == "func.func" and op.attributes["sym_name"].value == function_name]
                gpu = [op for op in top if op.name == "gpu.module"]
                if len(hosts) != 1 or len(gpu) != 1 or len(hosts[0].regions[0].blocks) != 1:
                    raise ValueError("Expected the original host function and one complete GPU module")
                host = hosts[0].regions[0].blocks[0]
                formals = tuple(host.arguments)
                if len(formals) != 3 or str(formals[2].type) != "!cuda.stream":
                    raise ValueError("Expected source, destination and stream host formals")
                host_types = tuple(str(value.type) for value in formals)
                kernel_ops = [view.operation for view in gpu[0].regions[0].blocks[0].operations
                              if view.operation.name == "cuda.kernel"]
                kernels = {op.attributes["sym_name"].value: op for op in kernel_ops}
                if len(kernels) != len(kernel_ops):
                    raise ValueError("Original GPU kernel symbols must be unique")
                gpu_name = gpu[0].attributes["sym_name"].value
                launches = []
                blocks = [host]
                while blocks:
                    block = blocks.pop()
                    for view in block.operations:
                        op = view.operation
                        if op.name == "cuda.launch_ex":
                            launches.append(op)
                        blocks.extend(child for region in op.regions for child in region.blocks)
                if (len(launches) != len(self._pending)
                        or set(kernels) != {event.symbol for event in self._pending}
                        or len(kernels) != len(self._pending)):
                    raise ValueError("Compiler events do not cover the exact original launch/symbol set")
                records = []
                for event in self._pending:
                    sources = []
                    for argument, operand, typ in zip(event.arguments, event.operands, event.types):
                        if type(argument) is not _Tensor or vars(argument).get("value") != operand or operand.type != typ:
                            raise ValueError("Canonical argument no longer owns its recorded typed SSA operand")
                        matches = [index for index, formal in enumerate(formals) if formal == operand]
                        if len(matches) != 1:
                            raise ValueError("Kernel operand is not one exact original host formal")
                        sources.append(matches[0])
                    if tuple(sources) != (0, 1):
                        raise ValueError("Only complete source/destination formal forwarding is supported")
                    matching = [op for op in launches if op.attributes["callee"].value == [gpu_name, event.symbol]]
                    if len(matching) != 1 or tuple(matching[0].operands)[1:] != event.operands:
                        raise ValueError("Original launch uses differ from the exact compiler operand event")
                    parameter_types = tuple(str(typ) for typ in event.types)
                    kernel = kernels[event.symbol]
                    if len(kernel.regions[0].blocks) != 1:
                        raise ValueError("Expected one original device entry block")
                    actual_types = tuple(str(value.type) for value in kernel.regions[0].blocks[0].arguments)
                    if actual_types != parameter_types:
                        raise ValueError("Emitted device formals differ from canonical compiler types")
                    records.append(LaunchRecord(event.site, event.symbol, tuple(sources), parameter_types, host_types))
                self.records = tuple(records)
                self._frozen = True
                return self.records
        finally:
            self._pending.clear()

    def __exit__(self, exc_type, exc, traceback) -> bool:
        from cutlass.base_dsl.dsl import BaseDSL
        from cutlass.cutlass_dsl.cutlass import KernelLauncher

        changed = (KernelLauncher.launch is not self._launch_wrapper
                   or BaseDSL.generate_kernel_operands_and_types is not self._operand_wrapper)
        KernelLauncher.launch = self._original_launch
        BaseDSL.generate_kernel_operands_and_types = self._original_operands
        _ACTIVE.reset(self._context_token)
        self._active = False
        self._current = None
        self._pending.clear()
        if changed and exc_type is None:
            raise RuntimeError("Compiler observer changed during the compilation scope")
        return False
