from __future__ import annotations

import re
from dataclasses import dataclass, field
from hashlib import sha256
from importlib.metadata import version
from typing import Any

from compiler_boundary import CompiledProgram, _snapshot
from frontend import _Collector, _TRACE_LOCK
from launch_events import CloneBundle


SOURCE_ARGUMENT = "cudagraph.source_arg"


class _TaggedCollector(_Collector):
    def __call__(self, owner: Any, module: Any, function_name: str) -> None:
        from cutlass._mlir import ir

        hooks = tuple(owner._trace_finalize_hooks) + tuple(owner._scoped_trace_finalize_hooks.get())
        if owner is not self.owner or self.calls or hooks != (self,):
            raise RuntimeError("Expected one isolated provenance-tagging hook")
        with module.context, ir.raw_values():
            hosts = [view.operation for view in module.body.operations
                     if view.operation.name == "func.func"
                     and view.operation.attributes["sym_name"].value == function_name]
            if len(hosts) != 1:
                raise RuntimeError("Expected the original source host definition")
            host = hosts[0]
            count = len(host.regions[0].blocks[0].arguments)
            previous = host.attributes.get("arg_attrs")
            if previous is not None and len(previous) != count:
                raise RuntimeError("Source argument attributes disagree with the formals")
            tagged = []
            for index in range(count):
                attrs = {} if previous is None else {item.name: item.attr for item in previous[index]}
                if SOURCE_ARGUMENT in attrs:
                    raise RuntimeError("Source provenance attribute is already assigned")
                attrs[SOURCE_ARGUMENT] = ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index)
                tagged.append(ir.DictAttr.get(attrs))
            host.attributes["arg_attrs"] = ir.ArrayAttr.get(tagged)
            if not module.operation.verify():
                raise RuntimeError("Tagged source Module failed verification")
        super().__call__(owner, module, function_name)


@dataclass(frozen=True)
class TaggedProgram(CompiledProgram):
    source_snapshot: Any = field(repr=False)
    source_metadata: tuple[Any, ...] = field(repr=False)
    source_serialized: bytes = field(repr=False)
    compiled_serialized: bytes = field(repr=False)
    _snapshot_owners: tuple[Any, Any] = field(repr=False)

    def check(self) -> None:
        import cutlass.compiler as compiler

        super().check()
        if (self.source_snapshot is not self._snapshot_owners[0]
                or self.source_metadata is not self._snapshot_owners[1]
                or type(self.source_snapshot) is not compiler.PreCompiledMlirArtifact
                or self.source_snapshot.is_consumed
                or self.source_snapshot.get_bitcode() != self.source_bytecode
                or compiler.serialize_compilation_artifact(self.source_snapshot) != self.source_serialized
                or compiler.serialize_compilation_artifact(self.artifact) != self.compiled_serialized):
            raise RuntimeError("Original compiler metadata snapshot changed")


def compile_tagged_program(host: Any, kernel: Any, *arguments: Any, arch: str = "sm_80", **keywords: Any) -> TaggedProgram:
    import cutlass.compiler as compiler
    import cutlass.cute as cute
    from cutlass._mlir import ir
    from cutlass.cutlass_dsl.cutlass import CuTeDSL

    if version("nvidia-cutlass-dsl") != "4.6.2":
        raise RuntimeError("Expected the inspected CuTe compiler version")
    if type(arch) is not str or re.fullmatch(r"sm_[0-9]+[af]?", arch) is None:
        raise ValueError("Expected an explicit CUDA architecture")
    if ir.Context.current is not None or not _TRACE_LOCK.acquire(blocking=False):
        raise RuntimeError("Compilation requires an isolated frontend context")
    try:
        bundle = CloneBundle.create(host, kernel)
        dsl = CuTeDSL._get_dsl()
        if (type(dsl) is not CuTeDSL or dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get()
                or dsl.envar.keep_ir_clean):
            raise RuntimeError("Compilation requires an isolated standard frontend")
        collector = _TaggedCollector(dsl)
        try:
            source = cute.compile.to_precompiled_mlir(
                bundle.host, *arguments, **keywords, options=f"--gpu-arch {arch}",
                no_jit_engine=True, trace_finalize_hooks=collector,
            )
        finally:
            bundle.check_originals()
            if dsl._trace_finalize_hooks or dsl._scoped_trace_finalize_hooks.get():
                raise RuntimeError("Frontend hook scope was not restored")
        if (collector.calls != 1 or collector.module is None
                or type(source) is not compiler.PreCompiledMlirArtifact or source.is_consumed
                or source.get_bitcode() != collector.bytecode):
            raise RuntimeError("Expected the original precompiled artifact and Module")
        names = tuple(metadata.symbol_name for metadata in source.metadata)
        if names != (collector.function_name,):
            raise RuntimeError("Original metadata does not identify the traced host")
    finally:
        _TRACE_LOCK.release()
    source_serialized = compiler.serialize_compilation_artifact(source)
    source_snapshot = compiler.deserialize_compilation_artifact(source_serialized)
    if (type(source_snapshot) is not compiler.PreCompiledMlirArtifact or source_snapshot.is_consumed
            or source_snapshot.get_bitcode() != collector.bytecode
            or compiler.serialize_compilation_artifact(source_snapshot) != source_serialized):
        raise RuntimeError("Native source snapshot differs from the original artifact")
    source_metadata = tuple(source_snapshot.metadata)
    native = compiler.CuteCompiler()
    native.set_device_target(arch)
    native.set_host_target(compiler.Compiler.detect_host_triple())
    native.set_abi(compiler.Abi.CutlassCall)
    compiled = native.compile_to(source, compiler.ArtifactType.CompiledMlir)
    if (not source.is_consumed or type(compiled) is not compiler.CompiledMlirArtifact or compiled.is_consumed
            or tuple(metadata.symbol_name for metadata in compiled.metadata) != names):
        raise RuntimeError("Expected the original compiled continuation")
    bytecode = compiled.get_bitcode()
    context = ir.Context()
    with context, ir.Location.unknown(), ir.raw_values():
        module = ir.Module.parse(bytecode)
        if not module.operation.verify():
            raise RuntimeError("Compiled Module failed verification")
        text, module_bytecode = _snapshot(module)
    result = TaggedProgram(
        bundle, collector.module, collector.context, source, collector.text, collector.bytecode,
        compiled, module, context, bytecode, text, module_bytecode, collector.function_name, arch,
        sha256(collector.bytecode).hexdigest(), sha256(bytecode).hexdigest(),
        source_snapshot, source_metadata, source_serialized,
        compiler.serialize_compilation_artifact(compiled), (source_snapshot, source_metadata),
    )
    result.check()
    return result
