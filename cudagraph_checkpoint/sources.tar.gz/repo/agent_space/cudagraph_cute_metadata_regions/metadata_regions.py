from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from accessors import _function, _tagged_arguments
from cfg_values import CFGProgram, ValueType, _type
from region_binding import BoundRegion, RegionEvaluation
from region_helpers import RegionIf
from values import ScalarValue, evaluate


_NUMERIC = frozenset({"i1", "i8", "i16", "i32", "i64", "f32", "f64"})


@dataclass(frozen=True)
class UnavailablePointer:
    llvm_type: str
    size: int

    def data(self) -> bytes:
        raise TypeError("An unavailable pointer has no bytes")

    def __bytes__(self) -> bytes:
        return self.data()

    def __reduce_ex__(self, protocol):
        raise TypeError("An unavailable pointer cannot be serialized")


@dataclass(frozen=True)
class MetadataAggregate:
    llvm_type: str
    fields: tuple[tuple[tuple[int, ...], ScalarValue | UnavailablePointer], ...]

    def data(self) -> bytes:
        raise TypeError("A metadata aggregate has no descriptor bytes")

    def __bytes__(self) -> bytes:
        return self.data()

    def __reduce_ex__(self, protocol):
        raise TypeError("A metadata aggregate cannot be serialized")


def _validate(value: Any, typ: ValueType, *, aggregate_leaf: bool = False) -> None:
    if type(value) not in (MetadataAggregate, UnavailablePointer, ScalarValue) or value.llvm_type != typ.llvm_type:
        raise ValueError("Metadata value does not match its exact compiler type")
    if typ.leaves is not None:
        if (type(value) is not MetadataAggregate or type(value.fields) is not tuple
                or any(type(item) is not tuple or len(item) != 2
                       or type(item[1]) not in (ScalarValue, UnavailablePointer) for item in value.fields)
                or tuple((path, item.llvm_type) for path, item in value.fields) != typ.leaves):
            raise ValueError("Metadata aggregate lacks complete typed leaf coverage")
        for path, item in value.fields:
            if type(path) is not tuple or any(type(index) is not int or index < 0 for index in path):
                raise ValueError("Metadata aggregate paths must be exact component indices")
            _validate(item, ValueType(item.llvm_type), aggregate_leaf=True)
    elif typ.llvm_type in _NUMERIC:
        if type(value) is not ScalarValue:
            raise ValueError("Numeric metadata must contain a concrete scalar")
        value.data()
    elif typ.llvm_type.startswith("!llvm.ptr"):
        if type(value) not in (UnavailablePointer, ScalarValue) or type(value.size) is not int or value.size <= 0:
            raise ValueError("Pointer metadata requires a positive supplied storage width")
        if type(value) is UnavailablePointer:
            return
        if (aggregate_leaf or type(value) is not ScalarValue or type(value.value) is not int
                or not 0 <= value.value < 2**(8 * value.size)):
            raise ValueError("Tensor pointer leaves must be unavailable; only a scalar environment handle may be known")
    else:
        raise ValueError("Unsupported metadata value type")


def _check_computation(cfg: CFGProgram) -> None:
    if type(cfg) is not CFGProgram:
        raise TypeError("Expected an owned compiler-derived CFGProgram")
    cfg.check()

    def numeric_slot(slot: int) -> None:
        typ = cfg.types[slot]
        if typ.leaves is not None or typ.llvm_type not in _NUMERIC:
            raise ValueError("Metadata computation reads a pointer or whole aggregate")

    def expression(flow: Any) -> None:
        if flow.llvm_type not in _NUMERIC:
            raise ValueError("Metadata computation reads a pointer or whole aggregate")
        if flow.kind == "argument":
            typ = cfg.types[flow.argument]
            if flow.path:
                if typ.leaves is None or (flow.path, flow.llvm_type) not in typ.leaves:
                    raise ValueError("Metadata projection lacks its exact scalar-leaf source")
            else:
                numeric_slot(flow.argument)
        for operand in flow.operands:
            expression(operand)

    for index, block in enumerate(cfg.blocks):
        if index:
            for slot in block.arguments:
                numeric_slot(slot)
        for instruction in block.instructions:
            numeric_slot(instruction.result)
            expression(instruction.expression)
        for slot in block.terminator.values:
            numeric_slot(slot)
        for edge in block.terminator.edges:
            for slot in edge.arguments:
                numeric_slot(slot)


def evaluate_metadata_cfg(cfg: CFGProgram, arguments: tuple[Any, ...]) -> tuple[ScalarValue, ...]:
    """Evaluate scalar computation only; entry aggregates are projection sources."""
    _check_computation(cfg)
    if type(arguments) is not tuple or len(arguments) != len(cfg.argument_types):
        raise ValueError("Metadata helper arguments differ from its original signature")
    slots = [None] * len(cfg.types)
    block_index, incoming = 0, arguments
    for _ in cfg.blocks:
        block = cfg.blocks[block_index]
        if len(incoming) != len(block.arguments):
            raise ValueError("Metadata helper edge lost its block arguments")
        for slot, value in zip(block.arguments, incoming):
            _validate(value, cfg.types[slot])
            slots[slot] = value
        for instruction in block.instructions:
            flow = instruction.expression
            if flow.kind == "argument":
                result = slots[flow.argument]
                if flow.path:
                    if type(result) is not MetadataAggregate:
                        raise ValueError("Metadata projection requires its original aggregate")
                    result = dict(result.fields)[flow.path]
            else:
                numeric = tuple(value if type(value) is ScalarValue and value.llvm_type in _NUMERIC else None
                                for value in slots)
                result = evaluate(flow, numeric, cfg.context)
            _validate(result, cfg.types[instruction.result])
            slots[instruction.result] = result
        terminator = block.terminator
        if terminator.kind == "return":
            result = tuple(slots[slot] for slot in terminator.values)
            if (any(type(value) is not ScalarValue or value.llvm_type not in _NUMERIC for value in result)
                    or tuple(value.llvm_type for value in result) != cfg.result_types):
                raise ValueError("Metadata helper may return only its exact numeric scalar types")
            return result
        selected = 0
        if terminator.kind == "conditional":
            condition = slots[terminator.values[0]]
            if type(condition) is not ScalarValue or condition.llvm_type != "i1":
                raise ValueError("Metadata helper requires a concrete i1 branch")
            selected = 0 if condition.integer(signed=False) else 1
        elif terminator.kind != "jump":
            raise ValueError("Unsupported metadata helper terminator")
        edge = terminator.edges[selected]
        incoming = tuple(slots[slot] for slot in edge.arguments)
        block_index = edge.block
    raise RuntimeError("Acyclic metadata helper did not reach a return")


def evaluate_metadata_region(bound: BoundRegion, source_arguments: dict[int, Any]) -> RegionEvaluation:
    from cutlass._mlir import ir

    if type(bound) is not BoundRegion:
        raise TypeError("Expected the original owned BoundRegion")
    bound.check()
    if (type(source_arguments) is not dict or any(type(index) is not int for index in source_arguments)
            or set(source_arguments) != set(bound.plan.source_ids)):
        raise ValueError("Metadata inputs must identify every original source formal")
    with bound.program.context, ir.Location.unknown(), ir.raw_values():
        host = _tagged_arguments(_function(bound.program.module, bound.program.function_name, "llvm.func"))
        if set(host) != set(source_arguments):
            raise ValueError("Metadata inputs lost their original compiler source IDs")
        for index, value in host.items():
            _validate(source_arguments[index], _type(value.type))
    for leaf in bound.leaves:
        _check_computation(leaf.cfg)
    environment = {value: source_arguments[index] for value, index in zip(bound.plan.formals, bound.plan.source_ids)}
    helpers = {id(leaf.source): leaf for leaf in bound.leaves}
    branches = []

    def leaf_value(leaf: Any, values: dict[Any, Any]) -> ScalarValue:
        helper = helpers[id(leaf)]
        if any(value not in values for value in leaf.input_origin):
            raise ValueError("Metadata region needs an unavailable scalar merge value")
        inputs = tuple(values[leaf.input_origin[index]] for index in helper.local_order)
        result = evaluate_metadata_cfg(helper.cfg, inputs)
        if len(result) != 1 or result[0].llvm_type != leaf.result_type:
            raise ValueError("Metadata region helper changed its exact scalar result")
        return result[0]

    def run_block(block: Any, incoming: dict[Any, Any]) -> tuple[ScalarValue, ...]:
        local = dict(incoming)
        for step in block.steps:
            if type(step) is not RegionIf:
                raise ValueError("Unsupported metadata source-region control")
            condition = leaf_value(step.condition, local)
            if condition.llvm_type != "i1":
                raise ValueError("Metadata source branch requires an i1 condition")
            selected = bool(condition.integer(signed=False))
            branches.append((step.operation, selected))
            results = run_block(step.true_block if selected else step.false_block, local)
            if len(results) != len(step.results):
                raise RuntimeError("Metadata source yields do not cover the original merges")
            for value, result in zip(step.results, results):
                if str(value.type) != result.llvm_type:
                    raise ValueError("Metadata source yield changed its original merge type")
                local[value] = result
        return tuple(leaf_value(leaf, local) for leaf in block.yield_helpers)

    result = run_block(bound.plan.root, environment)
    if len(result) != 1:
        raise ValueError("Metadata region must produce one original source scalar")
    return RegionEvaluation(result[0], tuple(branches))


def evaluate_metadata_regions(regions: tuple[BoundRegion, ...], source_arguments: dict[int, Any]) -> tuple[RegionEvaluation, ...]:
    if type(regions) is not tuple or any(type(bound) is not BoundRegion for bound in regions):
        raise TypeError("Expected an exact tuple of owned source regions")
    if regions and any(bound.program is not regions[0].program for bound in regions):
        raise ValueError("Metadata regions must belong to one original compiled program")
    return tuple(evaluate_metadata_region(bound, source_arguments) for bound in regions)
